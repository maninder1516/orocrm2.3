<?php

namespace IZMO\ReportConfigBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ReportTemplateType extends AbstractType {

    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder
                ->add('templateName', 'text', ['required' => true, 'label' => 'izmo.report_template.template_name.label', 'attr' => ['maxlength' => 255]])
                ->add('templatePath', 'text', ['required' => true, 'label' => 'izmo.report_template.template_path.label', 'attr' => ['maxlength' => 255]])
                 ->add('templateClass', 'text', ['required' => true, 'label' => 'izmo.report_template.template_class.label', 'attr' => ['maxlength' => 255]])
                ->add('isActive', 'checkbox', ['required' => true, 'label' => 'izmo.report_template.is_active.label']);
     }

    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefaults(array(
            'data_class' => 'IZMO\ReportConfigBundle\Entity\ReportTemplate'
        ));
    }

    public function getName() {
        return 'report_template_form';
    }

}
