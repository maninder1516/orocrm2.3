<?php

namespace IZMO\ReportConfigBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ReportConfigType extends AbstractType {

    public function buildForm(FormBuilderInterface $builder, array $options) {        
        $builder
                ->add('url', 'text', ['required' => false, 'label' => 'izmo.reportconfig.url.label', 'attr' => ['maxlength' => 255] ])
                ->add('reportTitle', 'text', ['required' => true, 'label' => 'izmo.reportconfig.title.label', 'attr' => ['maxlength' => 255] ])
              //  ->add('aclClassId', 'text', ['required' => false, 'label' => 'izmo.reportconfig.acl_class_id.label', 'attr' => ['readonly' => true] ])                              
        ;
    }

    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefaults(array(
            'data_class' => 'IZMO\ReportConfigBundle\Entity\ReportConfig'
        ));
    }

    public function getName() {
        return 'report_config_form';
    }

}
