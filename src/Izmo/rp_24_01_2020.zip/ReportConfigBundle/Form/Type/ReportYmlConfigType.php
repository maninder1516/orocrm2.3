<?php

namespace IZMO\ReportConfigBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ReportYmlConfigType extends AbstractType {

    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder
                ->add('ymlConfigContent', 'textarea', ['required' => true, 'label' => 'izmo.reportymlconfig.yml_config_content.label'])
        ;
    }

    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefaults(array(
            'data_class' => 'IZMO\ReportConfigBundle\Entity\ReportYmlConfig'
        ));
    }

    public function getName() {
        return 'report_ymlconfig_form';
    }

}
