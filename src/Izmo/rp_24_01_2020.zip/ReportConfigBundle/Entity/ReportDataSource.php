<?php

namespace IZMO\ReportConfigBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\Config;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\ConfigField;
use Oro\Bundle\OrganizationBundle\Entity\Organization;

/**
 *
 * @ORM\Table(name="izmo_report_datasource")
 * @ORM\Entity 
 * @Config(
 *      defaultValues={
 *          "entity"={
 *              "icon"="",
 *          },
 *          "security"={
 *              "type"="ACL",
 *              "group_name"=""
 *          },
 *          "dataaudit"={
 *              "auditable"=true
 *          },
 *      }
 * )
 */
class ReportDataSource {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string")
     */
    private $name;
    
    /**
     * @ORM\Column(name="display_name", type="string")
     */
    private $displayName;
    
     /**
     * @var string
     *
     * @ORM\Column(name="type", type="integer")
     */
    private $type;

    /**
     * @var string
     *
     * @ORM\Column(name="parameters", type="text", nullable=true)
     */
    private $parameters;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Set Name
     * 
     * @param string $name
     * 
     * @return ReportDataSource
     */
    public function setName($name) {
        $this->name = $name;
        return $this;
    }

    /**
     * Get Name
     * 
     * @return string
     */
    public function getName() {
        return $this->name;
    }
    
    /**
     * 
     * @param string $displayName
     * @return ReportDataSource
     */
    public function setDisplayName($displayName){
        $this->displayName = $displayName;
        return $this;
    }
    
    /**
     * 
     * @return $displayName
     */
    public function getDisplayName(){
        return $this->displayName;
    }
    
    /**
     * Set Type
     * 
     * @param integer $type
     * 
     * @return ReportDataSource
     */
    public function setType($type) {
        $this->type = $type;
        return $this;
    }

    /**
     * Get Type
     * 
     * @return integer
     */
    public function getType() {
        return $this->type;
    }

    /**
     * Set Parameters
     * 
     * @param string $parameters
     * 
     * @return ReportDataSource
     */
    public function setParameters($parameters) {
        $this->parameters = $parameters;
        return $this;
    }

    /**
     * Get parameters
     * 
     * @return string
     */
    public function getParameters() {
        return $this->parameters;
    }

}
