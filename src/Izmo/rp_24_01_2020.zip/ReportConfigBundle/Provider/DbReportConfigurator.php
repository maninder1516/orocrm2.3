<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace IZMO\ReportConfigBundle\Provider;

use IZMO\ReportConfigBundle\Provider\AbstractReportConfigurator;

class DbReportConfigurator extends AbstractReportConfigurator {

    /**
     * 
     * @return type
     */
    public function getReportConfiguration() {
        $this->reportConfiguration = $this->container->get('reports_config.service_provider')->getReportConfigurationFromDB($this->reportId);
        if (!(empty($this->reportConfiguration))) {
            $dateDefaultProperties = $this->container->get('ymlparser.service.provider')->parseYmlFiles("report_date_default_properties.yml", '/../../ReportConfigBundle/Resources/config')['default_properties'];
            if (!(empty($dateDefaultProperties))) {
                $this->reportConfiguration['date_default_properties'] = $dateDefaultProperties;
            }
            $this->reportConfiguration['report_url'] = $this->reportId;
            return $this->reportConfiguration;
        } else {
            return null;
        }
    }

}

?>