<?php

namespace IZMO\ReportConfigBundle\Provider;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

class ReportExportProvider {

    /**
     * @var ContainerInterface
     */
    protected $container;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container) {
        $this->container = $container;
    }

    public function getReportConfigRepository() {
        return $this->container->get('doctrine')->getRepository('IZMOReportConfigBundle:ReportConfig');
    }

    public function getTranslation($name) {
        return $this->container->get('translator')->trans($name);
    }

    function getConfigReportData($config, $filter = null) {
        $container = $this->container;
        $funcName = $config['function_name'];
        $serviceName = $config['service_name'];
        if (empty($config['function_params'])) {
            return $container->get($serviceName)->$funcName();
        } else {
            $fparam = [];
            foreach ($config['function_params'] as $fkey => $fval) {
                if ((!(empty($fval['type'])))) {
                    if (($fval['type'] == 'filter') && (!(empty($fval['param'])))) {
                        $param = $fval['param'];
                        if (!(empty($filter[$param]['val']))) {  // here changes has to be done.
                            $fparam[$param]['val'] = $filter[$param]['val'];
                            $fparam[$param]['translatable'] = isset($fval['is_translatable']) ? $fval['is_translatable'] : 0;
                        } elseif ((!(empty($filter[$param])))) { //during sub lvl..
                            $fparam[$param]['val'] = $filter[$param];
                            $fparam[$param]['translatable'] = isset($fval['is_translatable']) ? $fval['is_translatable'] : 0;
                        }
                    } elseif (($fval['type'] == 'val') && (!(empty($fval['param_name']))) && (!(empty($fval['param_val'])))) {
                        $fparam[$fval['param_name']]['val'] = $fval['param_val'];
                        $fparam[$fval['param_name']]['translatable'] = isset($fval['is_translatable']) ? $fval['is_translatable'] : 0;
                    }
                }
            }

            return $container->get($serviceName)->$funcName($fparam);
        }
    }

    /**
     *  Get the Report Export Filters
     */
    function getReportExportFilters($exportFiltersArr, $filtersData) {
        $filter = [];
        $filterDetails = [];
        foreach ($exportFiltersArr as $key => $val) {
            if (empty($filter[$key])) {
                $col = $val['col'];
                if ((!(empty($filtersData))) && (!(empty($filtersData->$col)))) {
                    $filter[$key] = $filtersData->$col;
                } else {
                    if ($val['default'] == 'cur_yr') {
                        $filter[$key] = date("Y");
                    } elseif ((!(empty($_REQUEST))) && (!(empty($val['can_be_zero']))) && ($val['can_be_zero'] == 'true') && isset($_REQUEST[$val['col']]) && (($_REQUEST[$val['col']]) == 0)) {
                        $filter[$key] = 0;
                    } elseif ((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])) {
                        $filter[$key] = $this->getConfigReportData($val, $filter);  //HERE CHANGES NEEDED
                    } else {
                        $filter[$key] = $val['default'];
                    }
                }
            }
            $dataType[$key] = $val['data_type'];
        }
        $filterDetails = [$filter, $dataType];

        return $filterDetails;
    }

    /**
     *  Get the Context Details
     */
    function getContextDetails($exportContextsArr) {
        $filter = $exportContextsArr;
        $context = [];
        $contextDetails = [];
        foreach ($exportContextsArr as $cKey => $cVal) {
            if ((!(empty($_REQUEST))) && (!(empty($_REQUEST[$cVal['col']])))) {
                $context[$cKey] = $_REQUEST[$cVal['col']];
            } else {
                if ($cVal['default'] == 'cur_yr') {
                    $context[$cKey] = date("Y");
                } elseif ((!(empty($_REQUEST))) && (!(empty($cVal['can_be_zero']))) && ($cVal['can_be_zero'] == 'true') && isset($_REQUEST[$cVal['col']]) && (($_REQUEST[$cVal['col']]) == 0)) {
                    $context[$cKey] = 0;
                } elseif ((!(empty($cVal['type']))) && ($cVal['type'] == 'function') && (!(empty($cVal['function_name']))) && ($cVal['service_name'])) {
                    $context[$cKey] = $this->getConfigReportData($cVal, $filter);
                    //$context[$cKey] = (!(empty($cVal['function_params']))) ? $this->container->get($this->reportConfigProviderId)->getConfigReportData($cVal, $filter) : $this->container->get($this->reportConfigProviderId)->getConfigReportData($cVal);
                } elseif ((!empty($cVal['type'])) && ($cVal['type'] == 'db_function') && (!(empty($cVal['function_name'])))) { // newly added to handle by db configuration
                    $dbFuncParam = (!(empty($cVal['db_function_params']))) ? $cVal['db_function_params'] : NULL;
                    $context[$cKey] = $this->container->get('reports_config.service_provider')->getParamDataByDbConfig($cVal['function_name'], $dbFuncParam, $filter, $context); // contains all previous context arr values                    
                } elseif ((!(empty($cVal['type']))) && ($cVal['type'] == 'fixed')) {
                    $context[$cKey] = $cVal['val'];
                } else {
                    $context[$cKey] = $cVal['default'];
                }
            }
            $dataType[$cKey] = $cVal['data_type'];
        }
        $contextDetails = [$context, $dataType];

        return $contextDetails;
    }

    /**
     *  Get the Report Title for Export
     */
    function getExportReportTitle($reportName, $filtersData) {
        $reportTitle = $reportName;
        foreach ($filtersData as $k => $val) {
            if ($val != '' && !is_array($val)) {
                $reportTitle = $reportTitle . '_' . $val;
            }
        }

        return $reportTitle;
    }

}
