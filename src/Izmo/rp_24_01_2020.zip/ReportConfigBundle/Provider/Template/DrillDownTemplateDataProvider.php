<?php

namespace IZMO\ReportConfigBundle\Provider\Template;

use IZMO\ReportConfigBundle\Provider\Template\AbstractReportTemplateProvider;
use IZMO\ReportConfigBundle\Utils\ReportConfigConstants;

class DrillDownTemplateDataProvider extends AbstractReportTemplateProvider {

    /**
     * 
     * @return type
     */
    protected function processFilters() {
        if (!(empty($this->config['filters']))) {
            $filtersConfig = $this->config['filters'];
            $data = $this->request;
            $filter = $res = $dataType = [];
            $filtersJson = $data['filters'];
            $filtersData = json_decode($filtersJson);
            foreach ($filtersConfig as $key => $val) {
                if (empty($filter[$key])) {
                    $col = $val['col'];
                    if ((!(empty($filtersData))) && (!(empty($filtersData->$col)))) {
                        $filter[$key] = $filtersData->$col;
                    } else {
                        if ($val['default'] == 'cur_yr') {
                            $filter[$key] = date("Y");
                        } elseif ((!(empty($data))) && (!(empty($val['can_be_zero']))) && ($val['can_be_zero'] == 'true') && isset($data[$val['col']]) && (($data[$val['col']]) == 0)) {
                            $filter[$key] = 0;
                        } elseif ((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])) {
                            $filter[$key] = (!(empty($val['function_params']))) ? $this->container->get($this->reportConfigProviderId)->getConfigReportData($val, $filter) : $this->container->get($this->reportConfigProviderId)->getConfigReportData($val);
                        } elseif ((!empty($cVal['type'])) && ($cVal['type'] == 'db_function') && (!(empty($cVal['function_name'])))) { // newly added to handle by db configuration
                            $dbFuncParam = (!(empty($cVal['db_function_params']))) ? $cVal['db_function_params'] : NULL;
                            $filter[$key] = $this->container->get($this->reportConfigProviderId)->getParamDataByDbConfig($cVal['function_name'], $dbFuncParam, $filter);
                        } else {
                            $filter[$key] = $val['default'];
                        }
                    }
                }
                $dataType[$key] = $val['data_type'];
            }
            $res['filters'] = $filter;
            $res['datatypes'] = $dataType;
            return $res;
        }
    }

    /**
     * 
     * @return type
     */
    protected function getFilterConfig() {
        if (!(empty($this->config['filters']))) {
            $filtersConfig = $this->config['filters'];
            $data = $this->request;
            $filter = $res = $dataType = [];
            foreach ($filtersConfig as $key => $cVal) {  // filters index config provided
                if ((!(empty($data))) && (!(empty($data[$cVal['col']])))) {
                    $filter[$key]['val'] = $data[$cVal['col']];
                } else {
                    if ($cVal['default'] == 'cur_yr') {
                        $filter[$key]['val'] = date("Y");
                    } elseif ((!(empty($data))) && (!(empty($cVal['can_be_zero']))) && ($cVal['can_be_zero'] == 'true') && isset($data[$cVal['col']]) && (($data[$cVal['col']]) == 0)) {
                        $filter[$key]['val'] = 0;
                    } elseif ((!(empty($cVal['type']))) && ($cVal['type'] == 'function') && (!(empty($cVal['function_name']))) && ($cVal['service_name'])) {

                        $filter[$key] = (!(empty($cVal['function_params']))) ? $this->container->get($this->reportConfigProviderId)->getConfigReportData($cVal, $filter) : $this->container->get($this->reportConfigProviderId)->getConfigReportData($cVal);
                    } elseif ((!empty($cVal['type'])) && ($cVal['type'] == 'db_function') && (!(empty($cVal['function_name'])))) { // newly added to handle by db configuration
                        $dbFuncParam = (!(empty($cVal['db_function_params']))) ? $cVal['db_function_params'] : NULL;
                        $filter[$key] = $this->container->get($this->reportConfigProviderId)->getParamDataByDbConfig($cVal['function_name'], $dbFuncParam, $filter);
                    } else {
                        $filter[$key]['val'] = $cVal['default'];
                    }
                }
                $filter[$key]['field_type'] = $cVal['field_type'];
                if ($cVal['field_type'] == 'calendar') {
                    $filter[$key]['date_properties'] = (!(empty($cVal['date_properties']))) ? $cVal['date_properties'] : null;
                } elseif ($cVal['field_type'] == 'date_range') {
                    $filter[$key]['date_properties'] = (!(empty($cVal['date_properties']))) ? $cVal['date_properties'] : null;
                }

                $filter[$key]['field_name'] = $cVal['field_name'];
                $filter[$key]['required'] = (!(empty($cVal['required']))) ? $cVal['required'] : false;
                if (!(empty($cVal['data_src']))) {
                    $filterDataSrc = $cVal['data_src'];
                    if ((!(empty($filterDataSrc['service_name']))) && (!(empty($filterDataSrc['function_name'])))) {
                        $funName = $filterDataSrc['function_name'];
                        $filter[$key]['data_src'] = $this->container->get($filterDataSrc['service_name'])->$funName();
                    }
                } else if (!(empty($cVal['db_data_src']))) {
                    $dbDataSrc = $cVal['db_data_src'];
                    $dbDataSrcParam = (!(empty($cVal['db_data_src_params']))) ? $cVal['db_data_src_params'] : null;
                    $filter[$key]['data_src'] = $this->container->get('reports_config.service_provider')->getDataSrcConfig($cVal['db_data_src'], $dbDataSrcParam);
                }
            }
            return $filter;
        }
    }

    public function renderTemplate($templateParams, $extraParams, $templating) {
        $errFlg = 0;
        $combinedTemplateParams = [];
        try {
            $twigPath = $this->getTemplateName();
            $combinedTemplateParams = array_merge($templateParams, $extraParams);
        } catch (\Exception $e) {
            $errFlg = 1;
        } finally {
            if ($errFlg == 1) {
                $combinedTemplateParams['errorHandlr'] = 1;
            }
            return $templating->render($twigPath, $combinedTemplateParams);
        }
    }

    /**
     * 
     * @return type
     */
    public function prepareTemplateParams() {
        $reportConfig = $this->config;
        $filter = $this->getFilterConfig();
        $reportType = 0;
        $isGrndTotal = (!(empty($reportConfig['isGrandTotal']))) ? $reportConfig['isGrandTotal'] : 0;
        $hideColsForGrandTotal = ((!(empty($isGrndTotal))) && (!(empty($reportConfig['hide_cols_for_grand_total'])))) ? $reportConfig['hide_cols_for_grand_total'] : [];
        $isSubGrndTotal = (!(empty($reportConfig['isSubGrandTotal']))) ? $reportConfig['isSubGrandTotal'] : 0;
        $twigDispFilter = $filter;
        foreach ($twigDispFilter as $key => $val) {
            if ((!(empty($filter[$key]['val']))) && ($filter[$key]['val'] == 'none')) {
                $twigDispFilter[$key]['val'] = '';
            }
        }
        $reportConfigLevelDetails = $reportConfig['levels'];

        $reportTitleInfo = $this->getReportTitle($filter);
        $reportTitle = $reportTitleInfo['title'];
        $reportTitleKey = $reportTitleInfo['title_key'];

        if (!(empty($reportConfigLevelDetails))) {

            $levelWisePrimarykeyCols = $this->getPrimaryKeyCols();
            $levelWiseExpndrCols = $this->getExpanderCols();
        }
        return array('report_hdr' => $reportTitle, 'pageTitle' => $reportTitle, 'pageTitleKey' => $reportTitleKey, 'filters' => $twigDispFilter, 'lvl_wise_pk_col' => $levelWisePrimarykeyCols, 'lvl_wise_expndr_cols' => $levelWiseExpndrCols, 'is_grand_total' => $isGrndTotal, 'is_sub_grand_total' => $isSubGrndTotal, 'hid_cols_for_grand_sum' => $hideColsForGrandTotal);
    }

    /**
     * 
     * @param type $col
     * @return type
     */
    private function preparePrimaryOrExpndrCols($col) {
        $levelWisePrepareCols = '';
        $reportLevelConfig = $this->config['levels'];
        foreach ($reportLevelConfig as $key => $cVal) {
            if ($key > -1) {
                if ((!(empty($cVal[$col]))) || ($cVal[$col] == 0)) {
                    if (($cVal[$col] != 'none')) {
                        $levelWisePrepareCols .= $cVal[$col] . ',';
                    }
                }
            }
        }
        $levelWisePrepareCols = rtrim($levelWisePrepareCols, ',');
        return $levelWisePrepareCols;
    }

    /**
     * 
     * @return type
     */
    private function getPrimaryKeyCols() {
        return $this->preparePrimaryOrExpndrCols('primary_key_col');
    }

    /**
     * @return type
     */
    private function getExpanderCols() {
        return $this->preparePrimaryOrExpndrCols('expander_output_col');
    }

    /**
     * @param type $filter
     * @return type
     */
    protected function getContexts($filter) {
        if (!(empty($this->config['contexts']))) {
            $contextsConfig = $this->config['contexts'];
            $context = $dataType = [];
            $reqObj = $this->request;
            foreach ($contextsConfig as $cKey => $cVal) {
                if ((!(empty($reqObj))) && (!(empty($reqObj[$cVal['col']])))) {
                    $context[$cKey] = $reqObj[$cVal['col']];
                } else {
                    if ($cVal['default'] == 'cur_yr') {
                        $context[$cKey] = date("Y");
                    } elseif ((!(empty($reqObj))) && (!(empty($cVal['can_be_zero']))) && ($cVal['can_be_zero'] == 'true') && isset($reqObj[$cVal['col']]) && (($reqObj[$cVal['col']]) == 0)) {
                        $context[$cKey] = 0;
                    } elseif ((!(empty($cVal['type']))) && ($cVal['type'] == 'function') && (!(empty($cVal['function_name']))) && ($cVal['service_name'])) {

                        $context[$cKey] = (!(empty($cVal['function_params']))) ? $this->container->get($this->reportConfigProviderId)->getConfigReportData($cVal, $filter) : $this->container->get($this->reportConfigProviderId)->getConfigReportData($cVal);
                    } elseif ((!empty($cVal['type'])) && ($cVal['type'] == 'db_function') && (!(empty($cVal['function_name'])))) { // newly added to handle by db configuration
                        $dbFuncParam = (!(empty($cVal['db_function_params']))) ? $cVal['db_function_params'] : NULL;
                        $context[$cKey] = $this->container->get($this->reportConfigProviderId)->getParamDataByDbConfig($cVal['function_name'], $dbFuncParam, $filter, $context); // contains all previous context arr values
                    } else {
                        $context[$cKey] = $cVal['default'];
                    }
                }
                $dataType[$cKey] = $cVal['data_type'];
            }
            $res['contexts'] = $context;
            $res['datatypes'] = $dataType;
            return $res;
        }
    }

    protected function getExtraParams() {
        if (!(empty($this->config['extra_params']))) {
            $extraParamConfig = $this->config['extra_params'];
            $extraParam = $dataType = [];
            $reqObj = $this->request;
            foreach ($extraParamConfig as $cKey => $cVal) {
                //logic for order by added
                if ($cKey == 'order_by') {
                    //logic to be implemented
                    $extraParam[$cKey] = $this->orderBy(); // since we need columns reference.
                    if (empty($extraParam[$cKey])) {
                        $extraParam[$cKey] = $cVal['default'];
                    }
                    // logic to be written
                } else {
                    //
                    if ((!(empty($reqObj))) && (!(empty($reqObj[$cVal['col']])))) {
                        $extraParam[$cKey] = $reqObj[$cVal['col']];
                    } else {
                        if ($cVal['default'] == 'cur_yr') {
                            $extraParam[$cKey] = date("Y");
                        } elseif ((!(empty($reqObj))) && (!(empty($cVal['can_be_zero']))) && ($cVal['can_be_zero'] == 'true') && isset($reqObj[$cVal['col']]) && (($reqObj[$cVal['col']]) == 0)) {
                            $extraParam[$cKey] = 0;
                        } elseif ((!(empty($cVal['type']))) && ($cVal['type'] == 'function') && (!(empty($cVal['function_name']))) && ($cVal['service_name'])) {
                            // NEED TO DEBUG ---
                            $extraParam[$cKey] = $this->container->get($this->reportConfigProviderId)->getConfigReportData($cVal);
                            //  $extraParam[$cKey] = (!(empty($cVal['function_params']))) ? $this->container->get($this->reportConfigProviderId)->getConfigReportData($cVal, []) : $this->container->get($this->reportConfigProviderId)->getConfigReportData($cVal);
                        } elseif ((!empty($cVal['type'])) && ($cVal['type'] == 'db_function') && (!(empty($cVal['function_name'])))) { // newly added to handle by db configuration
                            $dbFuncParam = (!(empty($cVal['db_function_params']))) ? $cVal['db_function_params'] : NULL;
                            $extraParam[$cKey] = $this->container->get($this->reportConfigProviderId)->getParamDataByDbConfig($cVal['function_name'], $dbFuncParam);
                        } else {
                            $extraParam[$cKey] = $cVal['default'];
                        }
                    }
                }
                $dataType[$cKey] = $cVal['data_type'];
            }
            $res['extra_params'] = $extraParam;
            $res['datatypes'] = $dataType;
            return $res;
        }
    }

    public function pluck($a, $prop) {
        $out = array();
        for ($i = 0, $len = count($a); $i < $len; $i++) {
            $out[] = (($prop == 'db') && (!(empty($a[$i]['tab_alias'])))) ? $a[$i]['tab_alias'] . '.' . $a[$i][$prop] : $a[$i][$prop];
        }
        return $out;
    }

    protected function orderBy() {

        $order = null;
        $request = $this->request;
        $columns = $this->config['serverside_processing_detail']['columns'];
        if (isset($request['order']) && count($request['order'])) {
            $orderBy = array();
            $dtColumns = $this->pluck($columns, 'dt');
            for ($i = 0, $ien = count($request['order']); $i < $ien; $i++) {
                // Convert the column index into the column data property
                $columnIdx = intval($request['order'][$i]['column']);
                $requestColumn = $request['columns'][$columnIdx];
                $columnIdx = array_search($requestColumn['data'], $dtColumns);
                $column = $columns[$columnIdx];
                if ($requestColumn['orderable'] == 'true') {
                    $dir = $request['order'][$i]['dir'] === 'asc' ? 'ASC' : 'DESC';
                    $orderBy[] = (!(empty($column['tab_alias']))) ? $column['tab_alias'] . '.' . $column['db'] . ' ' . $dir : $column['db'] . ' ' . $dir;
                }
            }
            $order = 'ORDER BY ' . implode(', ', $orderBy);
        }
        return $order;
    }

    /**
     * 
     * @return type
     */
    public function processTemplateData() {
        $filtersArray = $this->processFilters();
        $filters = $filtersArray['filters'];
        $contextArray = $this->getContexts($filters);
        $contexts = $contextArray['contexts'];
        $extraParamsArr = $this->getExtraParams();
        $extraParams = $extraParamsArr['extra_params'];
        $dataType = array_merge($filtersArray['datatypes'], $contextArray['datatypes'], $extraParamsArr['datatypes']);
        $data = $this->request;
        $reportType = (!(empty($data['level']))) ? $data['level'] : 0;
        $reportConfig = $this->config;
        if (!(empty($reportConfig['levels'][$reportType]))) {
            $storedProcName = $this->getStoredProcedureName($filters, $reportType);
            $storedProcParameters = $this->getStoredProcedureParams($reportType);
            $url = $this->getReportUrl($reportType);
            if ((!(empty($storedProcParameters))) && (!(empty($storedProcName)))) {
                $filterParams = [];
                $filterParams['report_type'] = $reportType;
                $filterParams['pk_info'] = NULL;
                $filterParams['pk_info'] = $this->preparePrimaryKeyColParams((!(empty($data['id']))) ? $data['id'] : null, $reportType);
                if (!(empty($filterParams['pk_info']))) {
                    $dataType = array_merge($dataType, $filterParams['pk_info']['datatypes']);
                }
                $filterParams['sp_params'] = $this->prepareStoredProcedureParams($storedProcParameters, $filters, $contexts, $extraParams, $dataType, $filterParams['pk_info']['pk']);
                $serverProcessConfig = ((!(empty($isSeperateServerSideForTypes))) && (!(empty($reportConfig['serverside_processing_detail'])))) ? $reportConfig['serverside_processing_detail'] : $reportConfig['serverside_processing_detail'];

                $params['server_config'] = $serverProcessConfig;
                $params['sp_name'] = $storedProcName;
                $params['url'] = $url;
                $params['sp_params'] = $filterParams;
                $params['report_title'] = $this->getReportTitleForDataProcessed($filters);
                return $this->invokeStoredProcedure($params);
            } else {
                $errorFlag = 1;
                $logger->crit("stored procedure parameters or stored procedure name not found for prod_type field for report");
            }
        }
    }

    /**
     * 
     * @param type $filter
     * @return type
     */
    protected function getStoredProcedureName($filter = null, $level = 0) {  //to do
        $reportConfig = $this->config;
        if (!(empty($reportConfig['levels'][$level]))) {
            $reportwiseConfiguration = $reportConfig['levels'][$level];
            if (!(empty($reportwiseConfiguration['stored_proc']))) {
                $storedProcName = $reportwiseConfiguration['stored_proc'];
            } else if ((!(empty($reportConfig['select_stored_proc_name']['report']))) && (!(empty($reportConfig['select_stored_proc_name']['report']['service_name']))) && (!(empty($reportConfig['select_stored_proc_name']['report']['function_name'])))) {
                $storedProcName = $this->container->get($this->reportConfigProviderId)->getConfigReportData($reportConfig['select_stored_proc_name']['report'], $filter);
            }// else if block - testing pending : needed or not condition chk?
        }
        return $storedProcName;
    }

    /**
     * 
     * @return type
     */
    protected function getStoredProcedureParams($level = 0) {
        $reportConfig = $this->config;
        if (!(empty($reportConfig['levels'][$level]))) {
            $reportwiseConfiguration = $reportConfig['levels'][$level];
            return $reportwiseConfiguration['stored_proc_params'];
        }
    }

    /*
     * 
     * @param type $storedProcParameters
     * @param type $filter
     * @param type $context
     * @param type $dataType
     * @return type
     */

    protected function prepareStoredProcedureParams($storedProcParameters, $filter, $context, $extraParams, $dataType, $pkArr = null) {
        $spParametersLabelArray = explode(',', $storedProcParameters);
        $spFilterParam = [];
        foreach ($spParametersLabelArray as $key => $val) {
            if (preg_match("/^" . ReportConfigConstants::CONTEXT_PREFIX_TYPE . "*/", $val)) {
                list($arr, $cntxtField) = preg_split('[' . ReportConfigConstants::CONTEXT_PREFIX_TYPE . ']', $val);
                $spFilterParam[$key]['context'] = $context[$cntxtField];
                $spFilterParam[$key]['data_type'] = $dataType[$cntxtField];
            } else if (preg_match("/^" . ReportConfigConstants::FILTER_PREFIX_TYPE . "*/", $val)) {
                list($arr, $filterField) = preg_split('[' . ReportConfigConstants::FILTER_PREFIX_TYPE . ']', $val);
                $spFilterParam[$key]['filter'] = $filter[$filterField];
                $spFilterParam[$key]['data_type'] = $dataType[$filterField];
            } else if (preg_match("/^" . ReportConfigConstants::EXTRA_PARAM_PREFIX_TYPE . "*/", $val)) {
                list($arr, $filterField) = preg_split('[' . ReportConfigConstants::EXTRA_PARAM_PREFIX_TYPE . ']', $val);
                $spFilterParam[$key]['extra'] = $extraParams[$filterField];
                $spFilterParam[$key]['data_type'] = $dataType[$filterField];
            } else if (preg_match("/^" . ReportConfigConstants::PRIMARY_KEY_PREFIX_TYPE . "*/", $val)) {
                list($arr, $filterField) = preg_split('[' . ReportConfigConstants::PRIMARY_KEY_PREFIX_TYPE . ']', $val);
                $spFilterParam[$key]['pk'] = $pkArr[$filterField]['pk_value'];
                $spFilterParam[$key]['data_type'] = $dataType[$filterField];
            }
        }

        return $spFilterParam;
    }

    /*
     * 
     * @param type $params
     * @return type
     */

    protected function invokeStoredProcedure($params) {
        return $this->container->get('reports_config.service_provider')->processServerSideData($this->request, $params);
    }

    /**
     * 
     * @return type
     */
    private function preparePrimaryKeyColParams($pkIds = null, $levelSelected = 0) {
        $res = [];
        $pkArr = [];
        $dataTypes = [];
        $serverProcessConfig = $this->config['serverside_processing_detail'];
        $reportwiseConfiguration = $this->config['levels'][$levelSelected];
        foreach ($serverProcessConfig['columns'] as $k => $v) {
            if ((!(empty($v['hidden']))) && ($v['hidden'] == 1) && ((!(empty($v['primary_key_info']))))) {
                $pkArr[$v['db']]['pk_value'] = $v['primary_key_info']['default'];
                $dataType[$v['db']] = $v['primary_key_info']['data_type'];
            }
        }
        if (!(empty($pkIds))) {
            if ($levelSelected > 0) {
                $pkEvalConfig = explode(',', $reportwiseConfiguration['request_parameters']);
                $pk_values_cnt = count($pkEvalConfig);
                $pk = explode('_', $pkIds);
                for ($i = 0; $i < $pk_values_cnt; $i++) {
                    $pkArr[$pkEvalConfig[$i]]['pk_value'] = $pk[$i];
                }
            }
        }
        $res['pk'] = $pkArr;
        $res['datatypes'] = $dataType;
        return $res;
    }

    /**
     * 
     * @return type
     */
    private function getReportUrl($levelSelected = 0) {
        $url = '';
        $reportConfigDetails = $this->config['levels'];
        if (!(empty($reportConfigDetails[$levelSelected + 1]['url']))) {
            $url = $reportConfigDetails[$levelSelected + 1]['url'];
        } elseif (!(empty($this->config['report_url']))) {
            $url = $this->config['report_url'];
        }
        return $url;
    }

}
