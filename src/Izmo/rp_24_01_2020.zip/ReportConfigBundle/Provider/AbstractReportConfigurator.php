<?php

namespace IZMO\ReportConfigBundle\Provider;

use Symfony\Component\DependencyInjection\ContainerInterface;
use IZMO\ReportConfigBundle\Utils\ReportConfigConstants;

abstract class AbstractReportConfigurator {

    protected $reportId;
    protected $request;
    protected $reportConfiguration;
    protected $container;
    protected $reportConfigProviderId;

    public function __construct(ContainerInterface $container, $reportId, $request) {
        $this->reportId = $reportId;
        $this->request = $request;
        $this->container = $container;
        $this->reportConfigProviderId = 'reports_config.service_provider';
    }

    /**
     * 
     * @return type
     */
    public function getTableColumnElements() {
        return $this->reportConfiguration['table_cols'];
    }

    /**
     * 
     * @return type
     */
    public function getExportElements() {
        return (!(empty($this->reportConfiguration['exports']))) ? $this->reportConfiguration['exports'] : null;
    }

    /**
     * 
     * @return type
     */
    public function getNoOfRowsPerPage() {
        $rowsPerPageConfig = $this->container->get('izmo_user_security_info.user_security_provider')->getNoOfRowsForReportPerPageForUser();
        $rowsPerPageConfig = (empty($rowsPerPageConfig)) ? $this->container->get('ymlparser.service.provider')->parseYmlFiles('reports_config.yml', '/../../ReportConfigBundle/Resources/config')['report_config']['pagination']['no_of_rows_per_page'] : $rowsPerPageConfig;
        return $rowsPerPageConfig;
    }

    public function getContextsForExport($filters) {
        // to be implemented...
    }

    public function getFiltersForExport($filters) {
        // to be implemented...
    }

    abstract public function getReportConfiguration();

    public function getReportTemplateDataProvider() {
        $templateDataProvider = $this->reportConfiguration['template_provider'];
        if (!(empty($templateDataProvider['template_class']))) {
            $templateProviderClass = $templateDataProvider['template_class'];
            return new $templateProviderClass($this->container, $this->reportConfiguration, $this->request);
        }
    }

}
