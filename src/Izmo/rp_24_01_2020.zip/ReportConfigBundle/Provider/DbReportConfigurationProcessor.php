<?php

namespace IZMO\ReportConfigBundle\Provider;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use IZMO\ReportConfigBundle\Provider\DbReportConfigurator;
use IZMO\ReportConfigBundle\Provider\Template\DrillDownTemplateDataProvider;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class DbReportConfigurationProcessor {

    /**
     * @var ContainerInterface
     */
    protected $container;
    protected $templating;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container, $templating) {
        $this->container = $container;
        $this->templating = $templating;
    }

    /**
     * 
     * @param type $reportId
     * @param type $request
     * @param type $type
     * @param type $reportFlg
     * @return type
     */
    public function processReportConfig($reportId, $request) {
        $logger = $this->container->get('logger');
        $errorFlag = 0;
        try {
            if (!(empty($request))) {                
                $reportObj = new DbReportConfigurator($this->container, $reportId, $request);
                $reportConfig = $reportObj->getReportConfiguration();
                if (!(empty($reportConfig))) {
                    $columnsConfig = $reportObj->getTableColumnElements(); 
                    echo 'Hello';                         
                    print_r($reportObj);
                    //print_r($columnsConfig);
                    die;  
                    
                    $templateDataProviderObj = $reportObj->getReportTemplateDataProvider();                   
                    return $templateDataProviderObj->processTemplateData();
                } else {
                    $errorFlag = 1;
                    $logger->crit("No Configuration provided for the given report");
                }
            } else {
                $errorFlag = 1;
                $logger->crit("No Parameters posted for ajax call in given report");
            }
        } catch (\Exception $e) {
            $errorFlag = 1;
            $logger->crit("Exception occured during fetching data with details below:");
            $logger->crit($e);
        }
    }

    /**
     * 
     * @param type $reportId
     * @param type $request
     * @param type $type
     * @param type $reportFlg
     * @return Response
     */
    public function initReport($reportId, $request) {       
        $reportObj = new DbReportConfigurator($this->container, $reportId, $request);        
        $rowsPerPageConfig = $errorFlag = 0;
        $logger = $this->container->get('logger');
        $exportsArr = $columnsConfig = $templateParams = $params = [];       
        try {
            $reportConfig = $reportObj->getReportConfiguration();           
            if (!(empty($reportConfig))) {
                $templateDataProviderObj = $reportObj->getReportTemplateDataProvider();
                $rowsPerPageConfig = $reportObj->getNoOfRowsPerPage();
                $columnsConfig = $reportObj->getTableColumnElements();                
                $exportsArr = $reportObj->getExportElements();
                if (!(empty($reportConfig['date_default_properties']))) {
                    $params['date_default_properties'] = $reportConfig['date_default_properties'];
                } else {
                    $params['date_default_properties'] = '';
                }
                $params['export_elements'] = $exportsArr;
                $params['cols_config'] = $columnsConfig;
                $params['rows_per_page'] = $rowsPerPageConfig;
                $params['report_id'] = $reportId;
                $params['errorHandlr'] = $errorFlag;                   
                $templateParams = $templateDataProviderObj->prepareTemplateParams();
            }// config available
            else {
                $logger->crit("No configuration details found for report selected");
                throw new NotFoundHttpException(" Report Configuration Does not Exist ");
            }
        }// try block
        catch (NotFoundHttpException $e) {
            throw $e;
        } catch (\Exception $e) {
            $params['errorHandlr'] = 1;
            $logger->crit(" exception occured while retriving data with exception info below:");
            $logger->crit($e);
        } finally {
            if (!(empty($templateDataProviderObj))) {
                return $templateDataProviderObj->renderTemplate($templateParams, $params, $this->templating);
            }
        }
    }

}
