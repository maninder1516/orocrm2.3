<?php

namespace IZMO\ReportConfigBundle\Provider;

/**
 * ExportDataClass is the base class for Export Data Class Selection.
 */
abstract class AbstractFactoryExportDataClass {

    /**
     * Initilize Export Data Class.
     */
    public function getExportDataClass($exportTo, $fileName, $fileType) {
        $dataClass = NULL;
        switch ($fileType) {
            case "xls":
                $dataClass = new ExcelExportData($exportTo, $fileName);
                break;
            case "csv":
                $dataClass = new CsvExportData($exportTo, $fileName);
                break;
            default:
                $dataClass = new ExcelExportData($exportTo, $fileName);
                break;
        }
        return $dataClass;
    }

}
