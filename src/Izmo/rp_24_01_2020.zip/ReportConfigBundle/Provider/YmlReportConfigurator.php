<?php

namespace IZMO\ReportConfigBundle\Provider;

use IZMO\ReportConfigBundle\Provider\AbstractReportConfigurator;

class YmlReportConfigurator extends AbstractReportConfigurator {

    /**
     * 
     * @return array
     */
    public function getReportConfiguration() {        
        $this->reportConfiguration = $this->container->get('ymlparser.service.provider')->parseYmlFiles($this->reportId . ".yml", '/../../ReportConfigBundle/Resources/config')['config'];
        $dateDefaultProperties = $this->container->get('ymlparser.service.provider')->parseYmlFiles("report_date_default_properties.yml", '/../../ReportConfigBundle/Resources/config')['default_properties'];
        if (!(empty($dateDefaultProperties))) {
            $this->reportConfiguration['date_default_properties'] = $dateDefaultProperties;
            $this->reportConfiguration['report_url'] = $this->reportId;
        }
        return $this->reportConfiguration;
    }

}
