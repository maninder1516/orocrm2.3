<?php

namespace IZMO\ReportConfigBundle\Controller;

use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query;
use Doctrine\ORM\EntityRepository;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use IZMO\ReportConfigBundle\Provider\YmlReportConfigProcess;
use IZMO\ReportConfigBundle\Utils\ReportConfigConstants;
use IZMO\ReportConfigBundle\Entity\ReportYmlConfig;

/**
 * @Route("/yml-config")
 */
class ReportYmlConfigController extends Controller {

    /**
     *  Get Report Config Repository
     */
    public function getReportConfigRepository() {
        return $this->getDoctrine()->getRepository('IZMOReportConfigBundle:ReportConfig');
    }

    /**
     * @Route("/process_yml_content", name="process_yml_content_to_sp_params")
     */
    public function getParamDetailsForYmlProcessing() {
        $ymlContent = filter_input(INPUT_POST, 'yml_content');
        $spId = filter_input(INPUT_POST, 'sp_sel');
        $reportId = filter_input(INPUT_POST, 'report_id');
        $res = $this->get('reports_config.service_provider')->getParamDetailsForYmlProcessing($ymlContent, $spId, $reportId);

        if (is_array($res)) {
            return new Response(json_encode(['res' => $res]));
        } else {
            return $res;
        }
    }

}
