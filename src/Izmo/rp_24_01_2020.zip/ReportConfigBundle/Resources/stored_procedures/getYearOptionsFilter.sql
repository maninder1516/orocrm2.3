CREATE PROCEDURE `getYearOptionsFilter`()
BEGIN
SELECT *
FROM (
select `year` as `key`, `year` as `val` from izmo_salesdata_year
) as years_datasrc;
END