CREATE PROCEDURE `getTargetReportConfigByCatId`(IN categoryId INT)
BEGIN
SELECT report_stored_proc, export_stored_proc, index_codes from izmo_target_report_config WHERE FIND_IN_SET(categoryId, category_id);
END