CREATE PROCEDURE `getStoredProcMappedToReport`(IN report_id INT)
BEGIN
select  reportbuilderstoredprocedure_id,reportconfig_id from izmo_report_builder_report_stored_proc_mapper where reportconfig_id = report_id;
END