CREATE PROCEDURE `getStoredProcedureYmlContentMapped`(IN sp_id INT)
BEGIN
SELECT group_concat(yml_content_map) as yml_param_map FROM izmo_report_sp_parameters where stored_procedure_id = sp_id  group by stored_procedure_id;
END