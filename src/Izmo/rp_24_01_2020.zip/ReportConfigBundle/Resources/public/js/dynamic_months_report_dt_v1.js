 require(['jquery', 'izmodatatables/js/datatables.min','orotranslation/js/translator'], function ($,cd,trans) {
     $(document).ready(function () {
            console.log("IN Report Config - Dynamic Months");
            var tabInfoOb = $('.dt-datatab-info');
            var url = tabInfoOb.attr('report-id');
            var tabBdy = $(tabInfoOb.attr('tbdyref'));
            var theadRef = tabInfoOb.attr('theadref');
            var ordrFlg = 0;
            ordrFlg = parseInt(tabInfoOb.attr('is-ordering'));
            var custOrder = parseInt(tabInfoOb.attr('custom-ordering-col-def'));
            var customOrderDef = (custOrder == 1) ? JSON.parse(tabInfoOb.attr('ordering-col-def')): null;
            var loadr = $('#loading');
            var errBlk = $('.err_msg');
            var cnt = 0;
            var colProp = [];
            $(theadRef + ' th', this).each(function (i) {
                colProp[i] = $(this).attr('class');
                cnt++;
            });
            var rowsToDisplay = (($('#no_of_rows').val() == undefined) || ($('#no_of_rows').val() == '')) ? 50 : parseInt($('#no_of_rows').val());
            function baseErr(tabEl){
                errBlk.show();
                $('.scrollable-container').animate({scrollTop: $(".err_msg_blk")},'slow');
                loadr.hide();
                $(tabEl+'_wrapper').hide();
            }   
            function initDT(tabEl){
                console.log('Hello 12');
                $(".report-div-blk").hide();
                loadr.show();     
                var ordering = ordrFlg;
                var table = $(tabEl).DataTable({
                "preDrawCallback": function () {
                    loadr.show();
                },
                "language": {
                    "paginate": {
                        "previous": trans('prev.label'),
                        "next": trans('next.label')
                    },
                    "zeroRecords": trans('datatables.data.no_record_found.label')
                },
                "serverSide": true,
                "searching": false,
                "ordering": ordering,
                "aoColumnDefs": customOrderDef,
                "pagingType": "simple",
                "deferRender": true,
                "pageLength" : rowsToDisplay,
                "bDestroy": true,
                "ajax": {
                    "url": encodeURI(url),
                    "type": "POST",
                    "data": {'filters': $('#filter-info').val()},
                    dataSrc: function (json) {
                        if(json.err == 1){
                            baseErr(tabEl);
                            console.log("error getting data");
                            return false;
                        }
                        else if (json.no_data) {
                             return false;
                        } else {
                            if (json.url != '') {
                                $(tabEl).find('tbody').attr('data-url', json.url);
                            }
                            if(json.report_title != undefined && json.report_title.title != undefined){
                                $(".report_title_hdr").html(json.report_title.title);
                            }
                            
                            (!(errBlk.is(':hidden'))) ? errBlk.hide() : '';
                            return json.data;
                        }
                    },
                    complete: function () {
                        loadr.hide();
                        $('span.hide-col').parent().css('cursor','default');
                    },
                    error: function (e) {
                        baseErr(tabEl);
                        return false;
                    }
                },
                "fnDrawCallback": function (oSettings) {
                    $(".report-div-blk").show();
                    if(oSettings.aoData.length > 0){
                    tabBdy.find('tr').each(function () {
                        $('td', this).each(function (i) {
                            $(this).addClass(colProp[i]);
                        });
                    });
                    this.find('thead tr th').css('width', 'auto');
                }
                else{
                    $(".report-div-blk").hide();
                        if(errBlk.is(':hidden')){
                            $('.report_no_rec').show();}
                }
                 var tabObjWrap = $(tabEl+'_wrapper'); 
                 if((tabObjWrap.find('a.previous').hasClass('disabled')) && (tabObjWrap.find('a.next').hasClass('disabled'))) { tabObjWrap.find('div.dataTables_paginate').hide()}
                   
                }
            });
        }
        //NEW CODE BLOCK ADDED
         $.initDTabl = function (tablElem) {            
            var formName = document.getElementsByClassName("dt-datatab-info")[0].getAttribute('form-name');
            initFormProperties(formName, tablElem);
        }
        function initFormProperties(formName, tablElem) {            
            document.forms[formName].onsubmit = function (e) {
                e.preventDefault();
                e.stopPropagation();
                $(tablElem + ' tbody').off('click');
                initFilters(formName);
                initDT(tablElem);
                return false;
            }
        }

        function initFilters(formName) {  // JS way
            console.log('Hello 78');
            var filterArr = {};
            var elements = document.forms[formName].elements;
            for (i in elements) {
                var el = elements[i];
                if (typeof (el) == 'object') {
                    var fieldType = el.getAttribute('data-fieldType');
                    var fieldName = el.getAttribute('name');
                    var fieldVal = el.value;
                    switch (fieldType) {
                        case "select":
                        {
                            filterArr[fieldName] = el.options[el.selectedIndex].value;
                            break;
                        }
                        case "text":
                        {
                            filterArr[fieldName] = fieldVal;
                            break;
                        }
                        case "calendar":
                        {
                            if (fieldVal != '') {
                                filterArr[fieldName] = dateFormatter.convertDateToBackendFormat(fieldVal);
                            } else {
                                filterArr[fieldName] = '';
                            }
                            break;
                        }
                        case "date-range":
                        {
                            if (filterArr[fieldName] != undefined) {
                                var nxtIndx = filterArr[fieldName].length;
                                filterArr[fieldName][nxtIndx] = (fieldVal != '') ? dateFormatter.convertDateToBackendFormat(fieldVal) : '';
                            } else {
                                filterArr[fieldName] = [];
                                filterArr[fieldName][0] = (fieldVal != '') ? dateFormatter.convertDateToBackendFormat(fieldVal) : '';
                            }
                        }
                    }
                }

            }
            document.getElementById("filter-info").value = JSON.stringify(filterArr);
        }
        
        //
        $.initDTabl('#l-0-tab-id-0'); 
    });
});