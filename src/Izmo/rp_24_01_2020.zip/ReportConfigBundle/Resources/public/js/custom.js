require(['jquery', 'orotranslation/js/translator', 'oroui/js/mediator', 'routing'], function ($, trans, mediator, routing) {
    $(document).ready(function () {
        $('.sav-report-config').click(function (e) {
            var formName = document.getElementsByName("report_config_form")[0].getAttribute('name');
            var ymlContent = $('#yml_content').val();
            if (!(validateRequiredFields(formName))) {
                return false;
            } else {
                if (ymlContent == ' ') {
                    $("#aceEditor").addClass('required-flg');
                    $('.errorymlmsg').css('display', 'block');
                    return false;
                } else {
                    $.ajax({
                        url: $('.report-info-flg').attr('validate-yml-content-url'),
                        type: 'POST',
                        data: {'ymlContent': ymlContent},
                        success: function (response) {
                            var res = JSON.parse(response);
                            if (res.error_flg == 1) {
                                $("#aceEditor").addClass('required-flg');
                                $('.errorymlmsg').css('display', 'block');                                
                                return false;
                            } else {
                                $('.errorymlmsg').css('display', 'none');
                                $("#aceEditor").removeClass('required-flg');
                                return true;
                            }
                        }
                    });
                }              
            }
        });

        // Save report template validations
        $('.save-report-template').click(function (e) {
            var formName = document.getElementsByName("report_template_form")[0].getAttribute('name');
            if (!(validateRequiredFields(formName))) {
                return false;
            } else {
                return true;
            }
        });

        // Set the virtula acl id with report name
        $("#report_name").on('keyup', function () {
            var reportName = $(this).val();
            reportName = reportName.replace(/-/g, ' ');
            reportName = reportName.replace(/_/g, ' ');
            reportName = capitalize(reportName);
            $("#acl_class_id").val(reportName);
        });

        // Capitalize
        function capitalize(s) {
            if (typeof s !== 'string')
                return '';
            return s.charAt(0).toUpperCase() + s.slice(1);
        }

        // Validate the rquired fields
        function validateRequiredFields(formName) {
            var elements = document.forms[formName].elements;
            var err = 0;
            for (i in elements) {
                var el = elements[i];
                if (typeof (el) == 'object') {
                    var fieldType = el.type;
                    if (el.getAttribute('required') == 'required') {
                        switch (fieldType) {
                            case "select":
                            {
                                if (el.options[el.selectedIndex].value == '') {
                                    $(el).parent().addClass('required-flg');
                                    err = 1;
                                } else {
                                    $(el).parent().removeClass('required-flg');
                                }
                                break;
                            }
                            case "text":
                            {
                                if (el.value === '') {
                                    $(el).addClass('required-flg');
                                    err = 1;
                                } else {
                                    $(el).removeClass('required-flg');
                                }
                                break;
                            }
                            case "date-range":
                            {
                                if (!(validateCalendarRangeFilters(el, 1))) {
                                    err = 1;
                                }
                                break;
                            }
                            default:
                            {
                                if (el.value == '') {
                                    $(el).addClass('required-flg');
                                    err = 1;
                                } else {
                                    $(el).removeClass('required-flg');
                                }
                                break;
                            }
                        }
                    } else {
                        if (fieldType == 'date-range') {
                            if (!(validateCalendarRangeFilters(el, 0))) {  // for comparision of to & from dates.
                                err = 1;
                            }
                            break;
                        }
                    }
                } 
            }
            if (err == 1) {
                $('.filters-err-msg').show();
                return false;
            } else {
                $('.filters-err-msg').hide();
                return true;
            }
        }
        
        $('.sav-report-config').click(function () {
            return validateMapping();
        });

        // YAML Editor INTEGRATION
        var textarea = $('#yml_content');
        var editor = ace.edit("aceEditor");
        editor.setTheme("ace/theme/cobalt");
        editor.getSession().setMode("ace/mode/yaml");
        editor.getSession().getAnnotations();
        editor.setHighlightActiveLine(false);
        textarea.val(editor.getValue());
        // Assign to Hidden Text Area
        editor.getSession().on('change', function () {
            textarea.val(editor.getValue());
            console.log('CONTENT CHANGED');
            var ymlContent = editor.getSession().getValue();
            if (ymlContent !== '') {
                $.ajax({
                    url: $('.report-info-flg').attr('validate-yml-content-url'),
                    type: 'POST',
                    data: {'ymlContent': ymlContent},
                    success: function (response) {
                        var res = JSON.parse(response);
                        if (res.error_flg == 1) {
                            $("#aceEditor").addClass('required-flg');
                            $('.errorymlmsg').css('display', 'block');
                            return;
                        } else {
                            $('.errorymlmsg').css('display', 'none');
                            $("#aceEditor").removeClass('required-flg');
                            mapSpToYml();
                        }
                    }
                });
            } else {
                $("#aceEditor").removeClass('required-flg');
                $('.errorymlmsg').css('display', 'none');
            }
        });

        $('#sel_stored_procedure').change(function () {
            mapSpToYml();
        });
        
        function mapSpToYml() {
            $('.updated-yml-map-info').hide();
            $('.err-process').html('');
            var ymlContent = $('#yml_content').val();
            var spSel = $('#sel_stored_procedure').val();
            var updatedSpSel = $('.updated-yml-map-info').data('sel-sp');
            var reportId = $('.report-info-flg').attr('report-id');
            var html = '';
            if (ymlContent == '' || ymlContent == 'undefined') {
                $('#aceEditor').addClass('required-flg');
                $('#sel_stored_procedure').addClass('required-flg');
            } else {
                $.ajax({
                    url: $('.report-info-flg').attr('yml-param-process-url'),
                    type: 'POST',
                    data: {'yml_content': ymlContent, 'sp_sel': spSel, 'report_id': reportId},
                    success: function (response) {
                        var res = JSON.parse(response);
                        if (res.res['err']) {
                            $('.sp_mapper').html('');
                            if (res.res['err'] == 1) {
                                $('#aceEditor').addClass('required-flg');
                                $('.err-process').html(res.res['msg']);
                            } else if (res.res['err'] == 2) {
                                $('#sel_stored_procedure').addClass('required-flg');
                                $('.err-process').html(res.res['msg']);
                            } else if (res.res['err'] == 3) {
                                $('#aceEditor').addClass('required-flg');
                                $('#sel_stored_procedure').addClass('required-flg');
                                $('.err-process').html(res.res['msg']);
                            }
                        } else { // in update method.                            
                            var optionsVal = "<option value=''></option>";

                            var filterOptionsVal, contextOptionsVal, extraParamOptionsVal, pkParamOptionsVal = '';
                            $('#aceEditor').removeClass('required-flg');
                            $('#sel_stored_procedure').removeClass('required-flg');

                            if (typeof res.res['filter'] !== 'undefined') {
                                // does not exist
                                optionsVal += "<option value='filter'>" + trans('Filter') + "</option>";
                                $.each(res.res['filter'], function (key, val) {
                                    filterOptionsVal += "<option value='" + key + "'>" + val + "</option>";
                                });
                            }
                            if (typeof res.res['context'] !== 'undefined') {
                                // does not exist
                                optionsVal += "<option value='context'>" + trans('Context') + "</option>";
                                $.each(res.res['context'], function (key, val) {
                                    contextOptionsVal += "<option value='" + key + "'>" + val + "</option>";
                                });
                            }
                            if (typeof res.res['extra'] !== 'undefined') {
                                optionsVal += "<option value='extra'>" + trans('Extra') + "</option>";
                                // does not exist
                                $.each(res.res['extra'], function (key, val) {
                                    extraParamOptionsVal += "<option value='" + key + "'>" + val + "</option>";
                                });
                            }
                            if (typeof res.res['pk'] !== 'undefined') {
                                optionsVal += "<option value='pk'>" + trans('Primary Key') + "</option>";
                                // does not exist
                                $.each(res.res['pk'], function (key, val) {
                                    pkParamOptionsVal += "<option value='" + key + "'>" + val + "</option>";
                                });
                            }

                            $(document).on('change', '.param_type_sel', function () {
                                var paramTypSel = $(this).val();
                                var selKey = $(this).data('sel-key'); //param Id
                                if (paramTypSel == 'extra') {
                                    $('select#param_type_contents_' + selKey).html(extraParamOptionsVal).show();
                                } else if (paramTypSel == 'filter') {
                                    $('select#param_type_contents_' + selKey).html(filterOptionsVal).show();
                                } else if (paramTypSel == 'context') {
                                    $('select#param_type_contents_' + selKey).html(contextOptionsVal).show();
                                } else if (paramTypSel == 'pk') {
                                    $('select#param_type_contents_' + selKey).html(pkParamOptionsVal).show();
                                } else if (paramTypSel == '') {
                                    $('select#param_type_contents_' + selKey).html('').show();
                                }
                            });
                            if (res.res['sp_param_yml_map']) {
                                var updateHtml = '<span><div class="sp_mapper_parm_typ_hdr"><b>Param Type</b></div><b> Stored Procedure Param  </b></span>';
                                var paramTypes = [];
                                $.each(res.res['sp_param_yml_map'], function (key, val) {
                                    paramTypes[key] = val.split(":")[0];
                                    updateHtml += "<li><div class='sp_param_map_val'><select class='param_type_sel' data-sel-key=" + key + ">" + optionsVal + "</select>&nbsp;&nbsp;&nbsp;&nbsp;<select class='param_contents' name='param-sel-content[]' id='param_type_contents_" + key + "'></select>&nbsp;&nbsp;&nbsp;&nbsp;<input type='hidden' name='sp-param-input[]' value='" + key + "'><input type='text' value='" + res.res['sp_param'][key] + "' readonly='true'></div></li>";
                                });
                                $('.sp_mapper').html(updateHtml);
                                $('.sp_mapper li').each(function (i, v) {
                                    var ky = $(v).find('select.param_type_sel').data('sel-key');
                                    if (paramTypes[ky]) {
                                        $(v).find('select.param_type_sel').find('option[value="' + paramTypes[ky] + '"]').attr('selected', 'selected').change();
                                    }
                                    if (res.res['sp_param_yml_map'][ky]) {
                                        $(v).find('select.param_contents').find('option[value="' + res.res['sp_param_yml_map'][ky] + '"]').attr('selected', 'selected').change();
                                    }
                                });
                            } else {
                                html = '<span><div style="width: 500px !important;display: inline-block"><b>Param Type</b></div><b> Stored Procedure Param  </b></span>';
                                $.each(res.res['sp_param'], function (key, val) {
                                    html += "<li><div class='sp_param_map_val'><select class='param_type_sel' data-sel-key=" + key + ">" + optionsVal + "</select>&nbsp;&nbsp;&nbsp;&nbsp;<select class='param_contents' name='param-sel-content[]' id='param_type_contents_" + key + "'></select>&nbsp;&nbsp;&nbsp;&nbsp;<input type='hidden' name='sp-param-input[]' value='" + key + "'><input type='text' value='" + val + "' readonly='true'></div></li>";
                                });
                                $('.sp_mapper').html(html);
                                $('.sp_mapper').show();
                                $('select.param_contents').hide();
                            }
                        }
                    },
                    error: function (err) {
                        console.log(err);
                    }
                });
            }
            //
        }


        function validateMapping() {  // validation to check all params are mapped properly
            if ($('.sp_mapper').html() != '') {
                var err = 0;
                $('.sp_mapper li').each(function (i, v) {
                    var el = $(v).find('select.param_contents');
                    var parmTypEl = $(v).find('select.param_type_sel');
                    if (el.val() == null) {
                        parmTypEl.addClass('required-flg');
                        el.addClass('required-flg');
                        err = 1;
                    } else {
                        parmTypEl.removeClass('required-flg');
                        el.removeClass('required-flg');
                    }
                });
                if (err == 1) {
                    return false;
                } else {
                    return true;
                }
            } else {
                return true;
            }
        }

    });
});

