require(['jquery', 'jquery-ui', 'routing', 'orolocale/js/formatter/datetime', 'oroui/js/messenger'], function ($, jui, routing, dateFormatter, Messenger)
{
    $(document).ready(function () {

        function initFilters(formName) {  // JS way
            var filterArr = {};

            var elements = document.forms[formName].elements;
            for (i in elements) {
                var el = elements[i];
                if (typeof (el) == 'object') {
                    var fieldType = el.getAttribute('data-fieldType');
                    var fieldName = el.getAttribute('name');
                    var fieldVal = el.value;

                    switch (fieldType) {
                        case "select":
                        {
                            filterArr[fieldName] = el.options[el.selectedIndex].value;
                            break;
                        }
                        case "text":
                        {
                            filterArr[fieldName] = fieldVal;
                            break;
                        }
                        case "calendar":
                        {
                            if (fieldVal != '') {
                                filterArr[fieldName] = dateFormatter.convertDateToBackendFormat(fieldVal);
                            } else {
                                filterArr[fieldName] = '';
                            }
                            break;
                        }
                        case "date-range":
                        {
                            if (filterArr[fieldName] != undefined) {
                                var nxtIndx = filterArr[fieldName].length;
                                filterArr[fieldName][nxtIndx] = (fieldVal != '') ? dateFormatter.convertDateToBackendFormat(fieldVal) : '';
                            } else {
                                filterArr[fieldName] = [];
                                filterArr[fieldName][0] = (fieldVal != '') ? dateFormatter.convertDateToBackendFormat(fieldVal) : '';
                            }
                        }
                    }
                }
            }

            return JSON.stringify(filterArr);
        }

        var exportElements = document.getElementsByClassName('export-btn');

        for (var i = 0; i < exportElements.length; i++) {
            exportElements[i].addEventListener("click", function () {
                console.log("Clicked here :");
                var exportEl = this;
                var exportId = exportEl.getAttribute('export_id');
                var tablRef = document.getElementsByClassName("dt-datatab-info")[0];
                var reportId = tablRef.getAttribute('report-id');
                var urlRef = encodeURI(reportId) + '/export/' + exportId;
                var formName = tablRef.getAttribute('form-name');
                var jsonFilters = initFilters(formName);

                Messenger.notificationFlashMessage('info', "Started to Export Data");
                $.ajax({
                    "url": urlRef,
                    "type": "POST",
                    "data": {'filters': jsonFilters},
                    success: function (res, status, xhr) {
                        var contentType = xhr.getResponseHeader("Content-Type");
                        var fileName = "";
                        var disposition = xhr.getResponseHeader('Content-Disposition');
                        fileName = getFileName(disposition);

                        var blob = new Blob([res], {type: contentType});
                        var link = document.createElement('a');
                        link.href = window.URL.createObjectURL(blob);
                        link.download = fileName;
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    },
                    complete: function () {
                        Messenger.notificationFlashMessage('success', "Export Data Completed Successfully");
                    },
                    error: function (error) {
                        Messenger.notificationFlashMessage('error', "Failed to Export Data");
                        Messenger.notificationFlashMessage('error', error.responseText);
                        return false;
                    }
                });
            })
        }
    });

    // Get the file name from Content-Disposition
    function getFileName(disposition) {
        var filename = "";
        var downloadType = disposition.substr(0, disposition.indexOf(';'));
        if (disposition && disposition.indexOf(downloadType) !== -1) {
            var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
            var matches = filenameRegex.exec(disposition);
            if (matches !== null && matches[1]) {
                filename = matches[1].replace(/['"]/g, '');
                return filename;
            }
        }
    }
});