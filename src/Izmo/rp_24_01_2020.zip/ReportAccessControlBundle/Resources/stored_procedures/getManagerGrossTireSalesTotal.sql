DROP PROCEDURE IF EXISTS `getManagerGrossTireSalesTotal`;

CREATE PROCEDURE getManagerGrossTireSalesTotal (IN sel_year INT, IN start_date DATE, IN end_date DATE, IN cmp_date1 INT, IN cmp_date2 INT, IN category_id INT,IN usr_ids VARCHAR(1500),IN is_mgr INT,IN bu_ids VARCHAR(500),IN ownrBuIdLgnUsr INT,IN turnoverType INT)
BEGIN
DECLARE todays_date DATE;
DECLARE cur_month INT;
DECLARE cur_yr INT;
DECLARE target_year INT;
DECLARE target_month INT;
DECLARE sales_type varchar(100);

SET todays_date = current_date();
SET cur_month = MONTH(todays_date);
SET cur_yr = YEAR(todays_date);
SET target_year = YEAR(start_date);
SET target_month = MONTH(start_date);

IF turnoverType = 2 then
    SET sales_type = 'net_amount';
ELSEIF turnoverType = 3 then
    SET sales_type = 'quantity';
ELSE
    SET sales_type = 'gross_amount';
END IF;

	
	set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
	SET @sql_query = concat("select STRAIGHT_JOIN 	
		IFNULL(ROUND(SUM(",sales_type,"), 0),0) as actualSales,
		IFNULL(ROUND(( CASE WHEN YEAR(report_date) = ",cur_yr," AND MONTH(report_date) = ",cur_month," THEN( ROUND((( SUM(",sales_type,") / ",cmp_date1,") * ",cmp_date2,"),0)) ELSE (SUM(",sales_type,")) END),0) ,0)  as estimatedSales,
		IFNULL(ROUND((select SUM(IFNULL(iptcd.gross,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",target_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = ",target_month," and iptcd.platform_sales_category_id = ",category_id,"), 0), 0) as goalSales
	from 
		sales_report_mv
	where 
		business_unit_id IN (",bu_ids,") and 
		report_date between '",start_date,"' and '",end_date,"' and user_id in (",usr_ids,") and index_code in('05','15','25');");
        


	
    
	PREPARE stmt FROM @sql_query; 
        EXECUTE stmt; 
	DEALLOCATE PREPARE stmt;

END;

