CREATE PROCEDURE `getQuadSpeedometerWidgetData`(IN sel_year INT, IN start_date DATE, IN end_date DATE, IN cmp_date1 INT, IN cmp_date2 INT, IN usr_ids VARCHAR(400))
BEGIN
	SET @sql_query = concat("select STRAIGHT_JOIN 
		ROUND(SUM(sh.netpricetotal), 0) - ROUND(SUM(CASE WHEN pi.partindexcode = '0005' THEN sh.netpricetotal ELSE 0 END),0) - ROUND(SUM(CASE WHEN pn.partnichecode = 'L600' THEN sh.netpricetotal ELSE 0 END),0) - ROUND(SUM(CASE WHEN pi.partindexcode = 'F' THEN sh.netpricetotal ELSE 0 END),0) - ROUND(SUM(CASE WHEN pi.partindexcode = 'LPDIS' and ps.partsegmentcode not in('LP60', 'CV42') THEN sh.netpricetotal ELSE 0 END),0) as actualPRC,
		ROUND((((ROUND(SUM(sh.netpricetotal), 0) - ROUND(SUM(CASE WHEN pi.partindexcode = '0005' THEN sh.netpricetotal ELSE 0 END),0) - ROUND(SUM(CASE WHEN pn.partnichecode = 'L600' THEN sh.netpricetotal ELSE 0 END),0) - ROUND(SUM(CASE WHEN pi.partindexcode = 'F' THEN sh.netpricetotal ELSE 0 END),0) - ROUND(SUM(CASE WHEN pi.partindexcode = 'LPDIS' and ps.partsegmentcode not in('LP60', 'CV42') THEN sh.netpricetotal ELSE 0 END),0)) / ",cmp_date1,") * ",cmp_date2,"), 0) as estimatedPRC,
		ROUND((select sum(tdtl.sales_others) from izmo_target st inner join izmo_target_details tdtl on tdtl.target_id = st.id where st.syear = ",sel_year," and tdtl.month_year = MONTHNAME(sh.invoicedate) and st.owner_id IN (",usr_ids,")), 0) as goalPRC,
		ROUND(SUM(CASE WHEN pi.partindexcode = '0005' THEN sh.quantitybought ELSE 0 END), 0) as actualQTYPneu,
		ROUND(((ROUND(SUM(CASE WHEN pi.partindexcode = '0005' THEN sh.quantitybought ELSE 0 END), 0) / ",cmp_date1,") * ",cmp_date2,"), 0) as estimatedQTYPneu,
		ROUND((select sum(tdtl.quantity_tyres) from izmo_target st inner join izmo_target_details tdtl on tdtl.target_id = st.id where st.syear = ",sel_year," and tdtl.month_year = MONTHNAME(sh.invoicedate) and st.owner_id IN (",usr_ids,")), 0) as goalQTYPneu,
		ROUND(SUM(CASE WHEN pn.partnichecode = 'L600' THEN sh.quantitybought ELSE 0 END), 0) as actualQTYLub,
		ROUND(((ROUND(SUM(CASE WHEN pn.partnichecode = 'L600' THEN sh.quantitybought ELSE 0 END), 0) / ",cmp_date1,") * ",cmp_date2,"), 0) as estimatedQTYLub,
		ROUND((select sum(tdtl.quantity_lubricants) from izmo_target st inner join izmo_target_details tdtl on tdtl.target_id = st.id where st.syear = ",sel_year," and tdtl.month_year = MONTHNAME(sh.invoicedate) and st.owner_id IN (",usr_ids,")), 0) as goalQTYLub,
		ROUND(SUM(CASE WHEN pi.partindexcode = 'F' THEN sh.netpricetotal ELSE 0 END), 0) as actualFL,
		ROUND(((ROUND(SUM(CASE WHEN pi.partindexcode = 'F' THEN sh.netpricetotal ELSE 0 END), 0) / ",cmp_date1,") * ",cmp_date2,"), 0) as estimatedFL,
		ROUND((select sum(tdtl.sales_fluoro) from izmo_target st inner join izmo_target_details tdtl on tdtl.target_id = st.id where st.syear = ",sel_year," and tdtl.month_year = MONTHNAME(sh.invoicedate) and st.owner_id IN (",usr_ids,")), 0) as goalFL
	from 
		izmo_sales_history sh
		inner join
		izmo_partfamily pf on pf.id = sh.partfamily
		inner join
		izmo_partindex pi on pi.id = pf.partindex_id
		inner join
		izmo_partsegment ps on ps.id = pf.partsegment_id
		inner join
		izmo_partniche pn on pn.id = pf.partniche_id
	where 
		sh.invoicedate between '",start_date,"' and '",end_date,"' and sh.owner_id in (",usr_ids,");");
        
	
    
	PREPARE stmt FROM @sql_query; 
        EXECUTE stmt; 
	DEALLOCATE PREPARE stmt; 
	
END