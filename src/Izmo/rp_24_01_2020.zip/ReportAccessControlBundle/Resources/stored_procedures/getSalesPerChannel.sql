CREATE DEFINER=`root`@`%` PROCEDURE `getSalesPerChannel`(IN workingDaysTillCurrentDay INT,IN workingDaysTillCurrentMonth INT,IN userIds VARCHAR(200),IN start_date DATE, IN end_date DATE,IN prev_start_date DATE, IN prev_end_date DATE)
BEGIN
	set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
	SET @sql_query = concat("SELECT STRAIGHT_JOIN
	ccm.channel_name AS channelName,
	ROUND(SUM((CASE WHEN ish.netpricetotal IS NOT NULL  and ish.invoicedate between '",start_date,"' AND '",end_date,"' THEN ish.netpricetotal ELSE 0 END)), 0) AS actual,	
	ROUND((SUM((CASE WHEN ish.netpricetotal IS NOT NULL and ish.invoicedate between '",start_date,"' AND '",end_date,"' THEN ish.netpricetotal ELSE 0 END)) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,", 0) AS projection,
	ROUND(((SUM(CASE WHEN ish.netpricetotal IS NOT NULL  and ish.invoicedate between '",start_date,"' AND '",end_date,"' THEN ish.netpricetotal ELSE 0 END) / ((SUM(CASE WHEN ish.netpricetotal IS NOT NULL and ish.invoicedate between '",start_date,"' AND '",end_date,"' THEN ish.netpricetotal ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,")) * 100),0) AS projectionper,
    ROUND(SUM((CASE WHEN ish.invoicedate between '",prev_start_date,"' AND '",prev_end_date,"' THEN ish.netpricetotal ELSE 0 END)), 0) AS actualprev
FROM client_category_mapping ccm
INNER JOIN orocrm_account oa on oa.clientcategory = ccm.category_code
INNER JOIN izmo_sales_history ish on ish.clientnumber = oa.id 
INNER JOIN oro_user ou on ou.id = ish.owner_id
INNER JOIN oro_business_unit obu on obu.id = ou.business_unit_owner_id
where ccm.channel_name is not null AND ish.invoicedate between '",prev_start_date,"' AND '",end_date,"' AND ou.id IN (",userIds,") and ccm.business_unit = obu.id
GROUP BY ccm.channel_name;"); 
	 PREPARE stmt FROM @sql_query; 
     EXECUTE stmt; 
	 DEALLOCATE PREPARE stmt;
END