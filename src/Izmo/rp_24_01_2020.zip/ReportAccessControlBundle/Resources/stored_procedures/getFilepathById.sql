CREATE PROCEDURE `getFilepathById`(IN id INT)
BEGIN

SET @sql_query = CONCAT("select filepath from izmo_data_report_info where id = ",id);

PREPARE stmt from @sql_query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

END