CREATE PROCEDURE `getPartIndexData`(IN env_id VARCHAR(255))
BEGIN
	SET @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
	SET SESSION group_concat_max_len = 1000000;
    SET @sql_query = concat("SELECT GROUP_CONCAT(pi.id) AS id, pi.partindexcode AS partindexcode, pi.partindexlabel AS partindexlabel 
FROM izmo_partindex pi 
WHERE pi.environment IN (",env_id,") GROUP BY pi.partindexcode");

    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
	DEALLOCATE PREPARE stmt; 
END