CREATE PROCEDURE `getImportDataExport`(IN userIds VARCHAR(1500),IN from_date VARCHAR(100),IN to_date VARCHAR(100),IN platform VARCHAR(100),IN uploadstatus VARCHAR(100))
BEGIN
set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
SET @sql_query = CONCAT("select SQL_CALC_FOUND_ROWS STRAIGHT_JOIN a.id as id,a.createdat as date,a.filename as filename,a.actual_records as actual_records,a.actual_turnover as source_net_turnover,a.available_records as available_records,a.available_turnover as boost_net_turnover,bu.name
      as platform,(case  
      when a.actual_records=a.available_records and a.actual_turnover=a.available_turnover
      then 'Successful' 
      else 'Failed' 
	  end) as status,a.error_message as error_message from izmo_data_report_info a inner join oro_business_unit bu on a.business_unit_id=bu.id inner join oro_user o on o.business_unit_owner_id=bu.id ");
      
       IF from_date != 'none' and to_date != 'none' THEN
		SET @sql_query = concat(@sql_query," where DATE(a.createdat) between STR_TO_DATE('",from_date,"','%Y-%m-%d %H,%i,%s') and STR_TO_DATE('",to_date," 23,59,59','%Y-%m-%d %H,%i,%s')");       
       END IF;
    
    IF platform != 'none' THEN
		SET @sql_query = concat(@sql_query," and o.business_unit_owner_id = ",platform," "); 
	END IF;
    
    SET @sql_query = concat(@sql_query," group by a.filename,a.createdat");
    
    IF uploadstatus = '1' THEN
		SET @sql_query = concat(@sql_query," having a.actual_records=a.available_records and a.actual_turnover=a.available_turnover"); 
    ELSEIF uploadstatus = '2' THEN
		SET @sql_query = concat(@sql_query," having a.actual_records!=a.available_records or a.actual_turnover!=a.available_turnover");
	ELSE
		SET @sql_query = concat(@sql_query," ");
	END IF;
    
	SET @sql_query = CONCAT(@sql_query, ' ', "ORDER BY date DESC");
    
	#select @sql_query;
PREPARE stmt from @sql_query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;    

END