CREATE DEFINER=`root`@`%` PROCEDURE `getSalesPerSalesmanData`(IN usr_ids VARCHAR(1500), IN salesman VARCHAR(100),IN bu_ids VARCHAR(500),IN owner_bu_id INT,IN where_cond VARCHAR(500),IN order_cond VARCHAR(500),IN page_limit VARCHAR(40),IN pk_col_for_cnt VARCHAR(20),IN cnt_flg INT,IN turnoverType INT)
BEGIN

DECLARE curStartDate DATE;
DECLARE curEndDate DATE;
DECLARE curYearStartDate DATE;
DECLARE curYearEndDate DATE;
DECLARE histStartDate DATE;
DECLARE histEndDate DATE;
DECLARE histMonthEndDate DATE;
DECLARE presentYear INT;
DECLARE presentMonth INT;
DECLARE presentDate INT;
DECLARE todays_date DATE;
DECLARE previousdate DATE;
DECLARE previousYearStartDate DATE;
DECLARE previousYearEndDate DATE;
DECLARE curMonthEndDate DATE;
DECLARE workingDaysTillCurrentDay INT;
DECLARE workingDaysTillCurrentMonth INT;
DECLARE prevYearWorkingDays INT;

DECLARE yearlyWorkingDaysTillCurrentDay INT;
DECLARE workingDaysTillCurrentYear INT;

DECLARE prevYearWorkingDaysTillCurrentMonth INT;
DECLARE cur_month INT;
DECLARE cur_yr INT;
DECLARE is_group_lvl INT;
DECLARE curReportYr INT;
DECLARE curReportMonth INT;
DECLARE prevReportYr INT;
DECLARE prevReportMonth INT;
DECLARE sales_type varchar(100);
DECLARE target_type varchar(100);



SET todays_date = current_date();
SET presentYear = YEAR(todays_date);
SET presentMonth = MONTH(todays_date);
SET presentDate = DAY(todays_date);
SET previousdate = subdate(todays_date, 1);
SET cur_month = MONTH(todays_date);
SET cur_yr = YEAR(todays_date);
SET curStartDate = (concat_ws('-', presentYear,presentMonth, 01));
SET curEndDate = (concat_ws('-', presentYear,presentMonth, presentDate));
SET curMonthEndDate = (concat_ws('-', presentYear,presentMonth, DAY(LAST_DAY(todays_date))));
SET is_group_lvl = 0;

IF curStartDate = curEndDate THEN
	SET curStartDate =  DATE_FORMAT(CURRENT_DATE - INTERVAL 1 MONTH, '%Y-%m-01');
	SET curEndDate = DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, '%Y-%m-%d');
END IF;

SET histStartDate = DATE_FORMAT(curStartDate - INTERVAL 1 YEAR, '%Y-%m-01');
SET histEndDate = DATE_FORMAT(curEndDate - INTERVAL 1 YEAR, '%Y-%m-%d');
SET histEndDate = LAST_DAY(histEndDate);
SET histMonthEndDate = DATE_FORMAT(curMonthEndDate - INTERVAL 1 YEAR, '%Y-%m-%d');
SET curYearStartDate =  DATE_FORMAT(CURRENT_DATE, '%Y-01-01');
SET curYearEndDate =  DATE_FORMAT(CURRENT_DATE, '%Y-12-31');

SET previousYearStartDate =  DATE_FORMAT(curYearStartDate - INTERVAL 1 YEAR, '%Y-%m-%d');
SET previousYearEndDate =  DATE_FORMAT(curYearEndDate - INTERVAL 1 YEAR, '%Y-%m-%d');

SET curReportYr = year(curEndDate);
SET curReportMonth = month(curEndDate);
SET prevReportYr = year(histEndDate);
SET prevReportMonth = month(histEndDate);

IF turnoverType = 1 then
    SET sales_type = 'gross_amount';
	SET target_type = 'gross';
ELSEIF turnoverType = 2 then
    SET sales_type = 'net_amount';
	SET target_type = 'net';
ELSEIF turnoverType = 3 then
    SET sales_type = 'quantity';
	SET target_type = 'qty';
ELSE
    SET sales_type = 'net_amount';
    SET target_type = 'net';
END IF;

   
SELECT (TOTAL_WEEKDAYS(curStartDate, previousdate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curStartDate and previousdate)) into workingDaysTillCurrentDay;
SELECT (TOTAL_WEEKDAYS(curStartDate, curMonthEndDate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curStartDate and curMonthEndDate)) into workingDaysTillCurrentMonth;
SELECT (TOTAL_WEEKDAYS(histStartDate, histMonthEndDate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between histStartDate and histMonthEndDate)) into prevYearWorkingDaysTillCurrentMonth;

SELECT (TOTAL_WEEKDAYS(curYearStartDate, previousdate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curYearStartDate and previousdate)) into yearlyWorkingDaysTillCurrentDay;
SELECT (TOTAL_WEEKDAYS(curYearStartDate, curYearEndDate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curYearStartDate and curYearEndDate)) into workingDaysTillCurrentYear;
SELECT (TOTAL_WEEKDAYS(previousYearStartDate, previousYearEndDate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between previousYearStartDate and previousYearEndDate)) into prevYearWorkingDays;

set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';

select group_level from oro_business_unit where id = owner_bu_id into is_group_lvl;
	
	IF is_group_lvl = 1 THEN
		SET @sql_query = CONCAT("SELECT STRAIGHT_JOIN SQL_CALC_FOUND_ROWS 
salesman as salesmanname,

ROUND(SUM(CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END),0) as actual,

IFNULL(ROUND((select SUM((CASE WHEN tcd.",target_type," IS NOT NULL THEN tcd.",target_type," ELSE 0 END)) from izmo_user_sales_target_category_detail tcd inner join izmo_user_target iut on iut.id = tcd.target_id where iut.year = YEAR('",curStartDate,"') and iut.salesman_id = user_id and tcd.month = MONTH('",curStartDate,"') and tcd.usr_sales_category_id = 1),0), 0) AS target,

IFNULL(ROUND(((SUM(CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END) / (select SUM((CASE WHEN tcd.",target_type," IS NOT NULL THEN tcd.",target_type," ELSE 0 END)) from izmo_user_sales_target_category_detail tcd inner join izmo_user_target iut on iut.id = tcd.target_id where iut.year = YEAR('",curStartDate,"') and iut.salesman_id = user_id and tcd.month = MONTH('",curStartDate,"') and tcd.usr_sales_category_id = 1)) * 100),0),0) AS performance,

IFNULL(ROUND((CASE when YEAR('",curEndDate,"') = ",cur_yr," AND MONTH('",curEndDate,"') = ",cur_month," THEN ((SUM(CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE (SUM(CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END)) END), 0), 0) AS projection,

IFNULL(ROUND((((CASE when YEAR('",curEndDate,"') = ",cur_yr," AND MONTH('",curEndDate,"') = ",cur_month," THEN ((SUM(CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE (SUM(CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END)) END) / (select SUM((CASE WHEN tcd.",target_type," IS NOT NULL THEN tcd.",target_type," ELSE 0 END)) from izmo_user_sales_target_category_detail tcd inner join izmo_user_target iut on iut.id = tcd.target_id where iut.year = YEAR('",curStartDate,"') and iut.salesman_id = user_id and tcd.month = MONTH('",curStartDate,"') and tcd.usr_sales_category_id = 1)) * 100),0),0) AS projectionper,

IFNULL(ROUND(SUM((CASE WHEN report_year = ",prevReportYr," and report_month =",prevReportMonth," THEN ",sales_type," ELSE 0 END)) * ",workingDaysTillCurrentMonth," / ",prevYearWorkingDaysTillCurrentMonth,", 0),0) As historyper,

IFNULL(((ROUND((CASE when YEAR('",curEndDate,"') = ",cur_yr," AND MONTH('",curEndDate,"') = ",cur_month," THEN ((SUM(CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE (SUM(CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END)) END), 0))/(ROUND(SUM((CASE WHEN report_year = ",prevReportYr," and report_month =",prevReportMonth," THEN ",sales_type," ELSE 0 END)), 0)))*100,0) AS targetprev,

ROUND(SUM(CASE WHEN report_year = ",curReportYr,"  THEN ",sales_type," ELSE 0 END),0) as actualyearly,
IFNULL(ROUND((CASE when YEAR('",curEndDate,"') = ",cur_yr,"  THEN ((SUM(CASE WHEN report_year = ",curReportYr,"  THEN ",sales_type," ELSE 0 END) / ",yearlyWorkingDaysTillCurrentDay,") * ",workingDaysTillCurrentYear,") ELSE (SUM(CASE WHEN report_year = ",curReportYr,"  THEN ",sales_type," ELSE 0 END)) END), 0), 0) AS projectionyearly,
IFNULL(ROUND((((CASE when YEAR('",curEndDate,"') = ",cur_yr,"  THEN ((SUM(CASE WHEN report_year = ",curReportYr,"  THEN ",sales_type," ELSE 0 END) / ",yearlyWorkingDaysTillCurrentDay,") * ",workingDaysTillCurrentYear,") ELSE (SUM(CASE WHEN report_year = ",curReportYr,"  THEN ",sales_type," ELSE 0 END)) END) / (select SUM((CASE WHEN tcd.",target_type," IS NOT NULL THEN tcd.",target_type," ELSE 0 END)) from izmo_user_sales_target_category_detail tcd inner join izmo_user_target iut on iut.id = tcd.target_id where iut.year = YEAR('",curStartDate,"') and iut.salesman_id = user_id  and tcd.usr_sales_category_id = 1)) * 100),0),0) AS projectionperyearly,
IFNULL(ROUND(((IFNULL(ROUND((CASE when YEAR('",curEndDate,"') = ",cur_yr,"  THEN ((SUM(CASE WHEN report_year = ",curReportYr,"  THEN ",sales_type," ELSE 0 END) / ",yearlyWorkingDaysTillCurrentDay,") * ",workingDaysTillCurrentYear,") ELSE (SUM(CASE WHEN report_year = ",curReportYr,"  THEN ",sales_type," ELSE 0 END)) END), 0), 0))*100)/(IFNULL(ROUND(SUM((CASE WHEN report_year = ",prevReportYr,"  THEN ",sales_type," ELSE 0 END)) * ",workingDaysTillCurrentYear," / ",prevYearWorkingDays,", 0),0)),0),0) as performenceyearly



FROM sales_report_consolidated_mv
WHERE 
groupby_type = 'SALESMAN_ID' and
business_unit_id IN (",bu_ids,") AND report_year in (",curReportYr,",",prevReportYr,")  and user_id in (",usr_ids,")
GROUP BY user_id");
    
	ELSE
	SET @sql_query = CONCAT("SELECT STRAIGHT_JOIN SQL_CALC_FOUND_ROWS
salesman as salesmanname,
ROUND(SUM(CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END),0) as actual,

IFNULL(ROUND((select SUM((CASE WHEN tcd.",target_type," IS NOT NULL THEN tcd.",target_type," ELSE 0 END)) from izmo_user_sales_target_category_detail tcd inner join izmo_user_target iut on iut.id = tcd.target_id where iut.year = YEAR('",curStartDate,"') and iut.salesman_id = user_id and tcd.month = MONTH('",curStartDate,"') and tcd.usr_sales_category_id = 1),0), 0) AS target,

IFNULL(ROUND(((SUM(CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END) / (select SUM((CASE WHEN tcd.",target_type," IS NOT NULL THEN tcd.",target_type," ELSE 0 END)) from izmo_user_sales_target_category_detail tcd inner join izmo_user_target iut on iut.id = tcd.target_id where iut.year = YEAR('",curStartDate,"') and iut.salesman_id = user_id and tcd.month = MONTH('",curStartDate,"') and tcd.usr_sales_category_id = 1)) * 100),0),0) AS performance,

IFNULL(ROUND((CASE when YEAR('",curEndDate,"') = ",cur_yr," AND MONTH('",curEndDate,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE (SUM(CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END)) END), 0), 0) AS projection,

IFNULL(ROUND((((CASE when YEAR('",curEndDate,"') = ",cur_yr," AND MONTH('",curEndDate,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE (SUM(CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END)) END) / (select SUM((CASE WHEN tcd.",target_type," IS NOT NULL THEN tcd.",target_type," ELSE 0 END)) from izmo_user_sales_target_category_detail tcd inner join izmo_user_target iut on iut.id = tcd.target_id where iut.year = YEAR('",curStartDate,"') and iut.salesman_id = user_id and tcd.month = MONTH('",curStartDate,"') and tcd.usr_sales_category_id = 1)) * 100),0),0) AS projectionper,

IFNULL(ROUND(SUM((CASE WHEN YEAR('",histEndDate,"') = ",prevReportYr," and MONTH('",histEndDate,"') =",prevReportMonth," THEN ",sales_type," ELSE 0 END)) * ",workingDaysTillCurrentMonth," / ",prevYearWorkingDaysTillCurrentMonth,", 0),0) As historyper,


IFNULL(((ROUND((CASE when YEAR('",curEndDate,"') = ",cur_yr," AND MONTH('",curEndDate,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE (SUM(CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END)) END), 0))/(ROUND(SUM((CASE WHEN report_date between '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END)), 0)))*100,0) AS targetprev,

ROUND(SUM(CASE WHEN YEAR('",curEndDate,"') = ",cur_yr,"  THEN ",sales_type," ELSE 0 END),0) as actualyearly,

IFNULL(ROUND((CASE when YEAR('",curEndDate,"') = ",cur_yr,"  THEN ((SUM(CASE WHEN YEAR('",curEndDate,"') = ",cur_yr,"  THEN ",sales_type," ELSE 0 END) / ",yearlyWorkingDaysTillCurrentDay,") * ",workingDaysTillCurrentYear,") ELSE (SUM(CASE WHEN YEAR('",curEndDate,"') = ",cur_yr,"  THEN ",sales_type," ELSE 0 END)) END), 0), 0) AS projectionyearly,

IFNULL(ROUND((((CASE WHEN YEAR('",curEndDate,"') = ",cur_yr,"  THEN ((SUM(CASE WHEN YEAR('",curEndDate,"') = ",cur_yr,"  THEN ",sales_type," ELSE 0 END) / ",yearlyWorkingDaysTillCurrentDay,") * ",workingDaysTillCurrentYear,") ELSE (SUM(CASE WHEN YEAR('",curEndDate,"') = ",cur_yr,"  THEN ",sales_type," ELSE 0 END)) END) / (select SUM((CASE WHEN tcd.",target_type," IS NOT NULL THEN tcd.",target_type," ELSE 0 END)) from izmo_user_sales_target_category_detail tcd inner join izmo_user_target iut on iut.id = tcd.target_id where iut.year = YEAR('",curStartDate,"') and iut.salesman_id = user_id  and tcd.usr_sales_category_id = 1)) * 100),0),0) AS projectionperyearly,

IFNULL(ROUND(((IFNULL(ROUND((CASE WHEN YEAR('",curEndDate,"') = ",cur_yr,"  THEN ((SUM(CASE WHEN YEAR('",curEndDate,"') = ",cur_yr,"  THEN ",sales_type," ELSE 0 END) / ",yearlyWorkingDaysTillCurrentDay,") * ",workingDaysTillCurrentYear,") ELSE (SUM(CASE WHEN YEAR('",curEndDate,"') = ",cur_yr,"  THEN ",sales_type," ELSE 0 END)) END), 0), 0))*100)/(IFNULL(ROUND(SUM((CASE WHEN YEAR(report_date) = ",prevReportYr,"  THEN ",sales_type," ELSE 0 END)) * ",workingDaysTillCurrentYear," / ",prevYearWorkingDays,", 0),0)),0),0) as performenceyearly



FROM sales_report_mv
WHERE business_unit_id IN (",bu_ids,") and year(report_date) in (",curReportYr,",",prevReportYr,")  and user_id in (",usr_ids,")
GROUP BY user_id");
	END IF;
IF page_limit != '' THEN
  SET @sql_query = CONCAT(@sql_query, ' ', page_limit);
END IF;

PREPARE stmt from @sql_query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
  
END