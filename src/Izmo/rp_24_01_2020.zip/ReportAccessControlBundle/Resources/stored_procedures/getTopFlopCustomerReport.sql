DROP PROCEDURE IF EXISTS `getTopFlopCustomerReport`;
CREATE PROCEDURE `getTopFlopCustomerReport`(IN userIds VARCHAR(1500), IN salesmanSearchData VARCHAR(200),IN channelSearchData VARCHAR(200),IN client_name VARCHAR(200),IN client_number VARCHAR(200),IN categoryId INT,IN bu_ids VARCHAR(500),IN owner_bu_id INT,IN turnover_type INT,IN where_cond VARCHAR(500),IN order_cond VARCHAR(500),IN page_limit VARCHAR(40),IN pk_col_for_cnt VARCHAR(20),IN cnt_flg INT)
BEGIN
 
DECLARE curStartDate DATE;
DECLARE curEndDate DATE;
DECLARE histStartDate DATE;
DECLARE histEndDate DATE;
DECLARE cur_yr INT; 
DECLARE cur_month INT; 
DECLARE presentDate INT;
DECLARE todays_date DATE;
DECLARE curYearStartDate DATE;
DECLARE curYearEndDate DATE;
DECLARE currentEndDate DATE;
DECLARE startyear DATE;
DECLARE endyear DATE;
DECLARE previousdate DATE;
DECLARE prevYearStartDate DATE;
DECLARE prevYearEndDate DATE;
DECLARE curMonthEndDate DATE;
DECLARE workingDaysTillCurrentDay INT;
DECLARE workingDaysTillCurrentMonth INT;
DECLARE workingDaysTillCurrentDayByYr INT;
DECLARE workingDaysInYr INT;
DECLARE lastDay INT;
DECLARE hist_yr INT;
DECLARE is_group_lvl INT;
DECLARE hist_month INT;
DECLARE sales_type varchar(100);

SET todays_date = current_date();
SET cur_yr = YEAR(todays_date);
SET cur_month = MONTH(todays_date);
SET presentDate = DAY(todays_date);
SET previousdate = subdate(todays_date, 1);


SET curStartDate = (concat_ws('-', cur_yr,cur_month, 01));
SET curEndDate = (concat_ws('-', cur_yr,cur_month, presentDate));
SET currentEndDate = (concat_ws('-', cur_yr,cur_month, presentDate));
SET curYearStartDate = (concat_ws('-', cur_yr,01, 01));
SET curYearEndDate = curEndDate;
SET startyear = (CONCAT(cur_yr,'-',01,'-',01));
SET endyear = (CONCAT(cur_yr,'-',12,'-',31));
SET curMonthEndDate = (concat_ws('-', cur_yr,cur_month, DAY(LAST_DAY(todays_date))));


SET histStartDate = DATE_FORMAT(curStartDate - INTERVAL 1 YEAR, '%Y-%m-01');
SET histEndDate = LAST_DAY(DATE_FORMAT(currentEndDate - INTERVAL 1 YEAR, '%Y-%m-%d'));


SET hist_yr = YEAR(histEndDate); 
SET hist_month = MONTH(histEndDate);

    SET prevYearStartDate = (concat_ws('-', hist_yr,01, 01));
    SET prevYearEndDate = (concat_ws('-', hist_yr,12, 31));
IF turnover_type = 1 then
	SET sales_type = 'gross_amount';
ELSEIF turnover_type = 2 then
	SET sales_type = 'net_amount';
ELSEIF turnover_type = 3 then
	SET sales_type = 'quantity';
ELSE
	SET sales_type = 'net_amount';
END IF;    

set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
   select group_level from oro_business_unit where id = owner_bu_id into is_group_lvl;

SELECT (TOTAL_WEEKDAYS(curStartDate, previousdate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curStartDate and previousdate)) into workingDaysTillCurrentDay;
SELECT (TOTAL_WEEKDAYS(curStartDate, curMonthEndDate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curStartDate and curMonthEndDate)) into workingDaysTillCurrentMonth;

SELECT (TOTAL_WEEKDAYS(startyear, previousdate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between startyear and previousdate)) into workingDaysTillCurrentDayByYr;
SELECT (TOTAL_WEEKDAYS(startyear, endyear) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between startyear and endyear)) into workingDaysInYr;

IF is_group_lvl = 1 THEN

SET @sql_query = CONCAT("SELECT SQL_CALC_FOUND_ROWS name, clientnumber,salesman, channelname, salestotal, salestotalprev, variation, Ind, performance, yearsalestotal, yearsalestotalprev, yearvariation, histInd, yearperformance 
		from (SELECT STRAIGHT_JOIN 
	customer as name,client_number as clientnumber, salesman,channel AS channelname,
	ROUND(SUM(CASE WHEN report_year  = ",cur_yr," and report_month = ",cur_month," THEN ",sales_type," ELSE 0 END) ,0) AS salestotal,
	ROUND(((SUM(CASE WHEN report_year  = ",hist_yr," and report_month = ",hist_month," THEN ",sales_type," ELSE 0 END))* ",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,",0) AS salestotalprev,
	IFNULL(ROUND(((((SUM(CASE WHEN report_year  = ",cur_yr," and report_month = ",cur_month," THEN ",sales_type," ELSE 0 END)) - (
	((SUM(CASE WHEN report_year  = ",hist_yr," and report_month = ",hist_month," THEN ",sales_type," ELSE 0 END))* ",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,"
	)) / (
	((SUM(CASE WHEN report_year  = ",hist_yr," and report_month = ",hist_month," THEN ",sales_type," ELSE 0 END))* ",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,"
	)) * 100),0),0) AS variation,
	'' as Ind,
	IFNULL(ROUND(((SUM(((CASE WHEN report_year  = ",cur_yr," and report_month = ",cur_month," THEN ",sales_type," ELSE 0 END))) / (((select SUM((CASE WHEN tcd.net IS NOT NULL THEN tcd.net ELSE 0 END)) from izmo_client_sales_target_category_detail tcd inner join izmo_client_target iut on iut.id = tcd.target_id where tcd.client_sales_category_id = ",categoryId," and iut.year = ",cur_yr," and tcd.month = ",cur_month,"  and iut.account_id = cust_id ) / ",workingDaysTillCurrentMonth,") * ",workingDaysTillCurrentDay,")) * 100), 0), 0) AS performance,
	ROUND(SUM(CASE WHEN report_year  = ",cur_yr,"  THEN ",sales_type," ELSE 0 END) ,0) AS yearsalestotal,
	ROUND(((SUM(CASE WHEN report_year  = ",hist_yr,"  THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDayByYr,") /",workingDaysInYr,",0) AS yearsalestotalprev,
	IFNULL(ROUND(((((SUM(CASE WHEN report_year  = ",cur_yr,"  THEN ",sales_type," ELSE 0 END)) - ((((SUM(CASE WHEN report_year  = ",hist_yr,"  THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDayByYr,") /",workingDaysInYr,") 
	)) / ((((SUM(CASE WHEN report_year  = ",hist_yr,"  THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDayByYr,") /",workingDaysInYr,") )) * 100),0),0) AS yearvariation,  
	'' as histInd,
	IFNULL(ROUND(((SUM(((CASE WHEN report_year  = ",cur_yr,"  THEN ",sales_type," ELSE 0 END))) / (((select SUM((CASE WHEN tcd.net IS NOT NULL THEN tcd.net ELSE 0 END)) from izmo_client_sales_target_category_detail tcd inner join izmo_client_target iut on iut.id = tcd.target_id where tcd.client_sales_category_id = ",categoryId," and iut.year = ",cur_yr,"  and iut.account_id = cust_id) / ",workingDaysInYr,") * ",workingDaysTillCurrentDayByYr,")) * 100), 0), 0) AS yearperformance
	FROM
		 sales_report_consolidated_mv        				
        WHERE 
		groupby_type = 'CUST_ID' and
        business_unit_id IN (",bu_ids,") and 
		report_year in (",cur_yr,",",hist_yr,") and user_id IN(",userIds,") ");
		
		
		IF salesmanSearchData != 'none' THEN
			SET @sql_query = concat(@sql_query,"and salesman LIKE '%",salesmanSearchData,"%'");       
		END IF;	
		
		IF channelSearchData != 'none' THEN
			SET @sql_query = concat(@sql_query,"and channel LIKE '%",channelSearchData,"%'");       
		END IF;	
		
		IF client_name != 'none' THEN
			SET @sql_query = concat(@sql_query,"and customer LIKE '%",client_name,"%'");
		END IF;
		
		IF client_number != 'none' THEN
			SET @sql_query = concat(@sql_query,"and client_number LIKE '%",client_number,"%'");
		END IF;
ELSE
  
  SET @sql_query = CONCAT("SELECT SQL_CALC_FOUND_ROWS name, clientnumber,salesman, channelname, salestotal, salestotalprev, variation, Ind, performance, yearsalestotal, yearsalestotalprev, yearvariation, histInd, yearperformance 
		from (SELECT STRAIGHT_JOIN 
	customer as name,client_number as clientnumber, salesman,channel AS channelname,
	ROUND(SUM(CASE WHEN report_date BETWEEN '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END) ,0) AS salestotal,
	ROUND(((SUM(CASE WHEN report_date BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END))* ",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,",0) AS salestotalprev,
	IFNULL(ROUND(((((SUM(CASE WHEN report_date BETWEEN '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END)) - (
	((SUM(CASE WHEN report_date BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END))* ",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,"
	)) / (
	((SUM(CASE WHEN report_date BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END))* ",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,"
	)) * 100),0),0) AS variation,
	'' as Ind,
	IFNULL(ROUND(((SUM(((CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END))) / (((select SUM((CASE WHEN tcd.net IS NOT NULL THEN tcd.net ELSE 0 END)) from izmo_client_sales_target_category_detail tcd inner join izmo_client_target iut on iut.id = tcd.target_id where tcd.client_sales_category_id = ",categoryId," and iut.year = ",cur_yr," and tcd.month = ",cur_month,"  and iut.account_id = cust_id ) / ",workingDaysTillCurrentMonth,") * ",workingDaysTillCurrentDay,")) * 100), 0), 0) AS performance,
	ROUND(SUM(CASE WHEN report_date BETWEEN '",curYearStartDate,"' AND '",curYearEndDate,"' THEN ",sales_type," ELSE 0 END) ,0) AS yearsalestotal,
	ROUND(((SUM(CASE WHEN report_date BETWEEN '",prevYearStartDate,"' AND '",prevYearEndDate,"' THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDayByYr,") /",workingDaysInYr,",0) AS yearsalestotalprev,
	IFNULL(ROUND(((((SUM(CASE WHEN report_date BETWEEN '",curYearStartDate,"' AND '",curYearEndDate,"' THEN ",sales_type," ELSE 0 END)) - ((((SUM(CASE WHEN report_date BETWEEN '",prevYearStartDate,"' AND '",prevYearEndDate,"' THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDayByYr,") /",workingDaysInYr,") 
	)) / ((((SUM(CASE WHEN report_date BETWEEN '",prevYearStartDate,"' AND '",prevYearEndDate,"' THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDayByYr,") /",workingDaysInYr,") )) * 100),0),0) AS yearvariation,  
	'' as histInd,
	IFNULL(ROUND(((SUM(((CASE WHEN report_date between '",curYearStartDate,"' AND '",curYearEndDate,"' THEN ",sales_type," ELSE 0 END))) / (((select SUM((CASE WHEN tcd.net IS NOT NULL THEN tcd.net ELSE 0 END)) from izmo_client_sales_target_category_detail tcd inner join izmo_client_target iut on iut.id = tcd.target_id where tcd.client_sales_category_id = ",categoryId," and iut.year = ",cur_yr,"  and iut.account_id = cust_id) / ",workingDaysInYr,") * ",workingDaysTillCurrentDayByYr,")) * 100), 0), 0) AS yearperformance
	FROM
		 sales_report_mv        				
        WHERE business_unit_id IN (",bu_ids,") and report_date BETWEEN '",prevYearStartDate,"' AND '",curEndDate,"' and user_id IN(",userIds,") ");
		
		
		IF salesmanSearchData != 'none' THEN
			SET @sql_query = concat(@sql_query,"and salesman LIKE '%",salesmanSearchData,"%'");       
		END IF;	
		
		IF channelSearchData != 'none' THEN
			SET @sql_query = concat(@sql_query,"and channel LIKE '%",channelSearchData,"%'");       
		END IF;	
		
		IF client_name != 'none' THEN
			SET @sql_query = concat(@sql_query,"and customer LIKE '%",client_name,"%'");
		END IF;
		
		IF client_number != 'none' THEN
			SET @sql_query = concat(@sql_query,"and client_number LIKE '%",client_number,"%'");
		END IF;
		
END IF; #is_group_lvl condition.	
		
	SET @sql_query = concat(@sql_query," group by cust_id,channel");
	
    SET @sql_query = concat(@sql_query, ") as topflopdata WHERE yearsalestotal > 0 ");
    
	IF order_cond !='' THEN
      SET @sql_query = CONCAT(@sql_query, ' ', order_cond);
    ELSE
		SET @sql_query = CONCAT(@sql_query, ' ', "order by yearvariation,name");
    END IF;
    
    
    
    IF page_limit != '' THEN
	  SET @sql_query = CONCAT(@sql_query, ' ', page_limit);
    END IF; 
    
       PREPARE stmt from @sql_query;
       EXECUTE stmt;
       DEALLOCATE PREPARE stmt;
END