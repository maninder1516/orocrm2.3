CREATE PROCEDURE `getBUIdFromMultipleCode`(IN sitename VARCHAR(100))
BEGIN
	
    DECLARE ConsolidatedBUCode varchar(255);
    DECLARE tempBusinessUnitID INT;
    DECLARE finalBusinessUnitID INT;
    
    IF sitename = '' THEN
		SET sitename = null;
    END IF;
    
	IF sitename = 'MOARNAGIS' THEN
		SET sitename = 'MORANGIS';
	END IF; 
	
	SELECT consolidatedBU INTO ConsolidatedBUCode FROM consolidate_info;
    
    IF ConsolidatedBUCode IS NOT NULL THEN
		SET sitename = ConsolidatedBUCode;
    END IF;

	SELECT id INTO tempBusinessUnitID FROM oro_business_unit WHERE multiplecodes LIKE concat("%",sitename,"%") COLLATE utf8_unicode_ci order by id asc limit 1;
    
    IF tempBusinessUnitID IS NULL THEN
		SELECT id INTO finalBusinessUnitID FROM oro_business_unit WHERE business_unit_owner_id IS NULL;
	ELSE
		SET finalBusinessUnitID = tempBusinessUnitID;
    END IF;
    
	SELECT finalBusinessUnitID;
END