CREATE DEFINER=`root`@`%` PROCEDURE `getIncompleteCustomerRecord`(IN user_owner_ids VARCHAR(255),IN lowerLimit INT,IN upperLimit INT)
BEGIN
SELECT `id`,`client`,`salesman`,`user_owner_id`,SUBSTR(`field_name_list`, 1, LENGTH(`field_name_list`) - 1) AS `empty_fields` FROM 
(SELECT OA.id,`name` AS `client`, CONCAT(OU.first_name,' ',OU.last_name) AS salesman,OA.user_owner_id,CONCAT(
	(CASE WHEN (`name`='' OR `name` IS NULL) THEN 'Name,' ELSE '' END),
	(CASE WHEN (address1='' OR address1 IS NULL) THEN 'Address 1,' ELSE '' END),
	(CASE WHEN (address2='' OR address2 IS NULL) THEN 'Address 2,' ELSE '' END),
	(CASE WHEN (agentcode='' OR agentcode IS NULL) THEN 'Agent code,' ELSE '' END),
	(CASE WHEN (city='' OR city IS NULL) THEN 'City,' ELSE '' END),
	(CASE WHEN (aemail='' OR aemail IS NULL) THEN 'aemail,' ELSE '' END),
	(CASE WHEN (dealernumber='' OR dealernumber IS NULL) THEN 'Dealer Number,' ELSE '' END),
	(CASE WHEN (deliveryzone='' OR deliveryzone IS NULL) THEN 'Delivery Zone,' ELSE '' END),
	(CASE WHEN (fax='' OR fax IS NULL) THEN 'Fax,' ELSE '' END),
	(CASE WHEN (hometelephone='' OR hometelephone IS NULL) THEN 'Home Telephone,' ELSE '' END),
	(CASE WHEN (officetelephone='' OR officetelephone IS NULL) THEN 'Office Telephone,' ELSE '' END),
	(CASE WHEN (paymentterms='' OR paymentterms IS NULL) THEN 'Payment Terms,' ELSE '' END),
	(CASE WHEN (postboxno='' OR postboxno IS NULL) THEN 'Post Box No,' ELSE '' END),
	(CASE WHEN (zipcode='' OR zipcode IS NULL) THEN 'Zip Code,' ELSE '' END),
	(CASE WHEN (panel='' OR panel IS NULL) THEN 'Panel,' ELSE '' END),
	(CASE WHEN (noofemployees='' OR noofemployees IS NULL) THEN 'No Of Employees,' ELSE '' END),
	(CASE WHEN (noofproductivestaff='' OR noofproductivestaff IS NULL) THEN 'No Of Productive Staff,' ELSE '' END),
	(CASE WHEN (clientcategory='' OR clientcategory IS NULL) THEN 'Client Category,' ELSE '' END),
	(CASE WHEN (clientnumber='' OR clientnumber IS NULL) THEN 'Client Number,' ELSE '' END),
	(CASE WHEN (creditlimit='' OR creditlimit IS NULL) THEN 'Credit Limit,' ELSE '' END),
	(CASE WHEN (discountcategory='' OR discountcategory IS NULL) THEN 'Discount Category,' ELSE '' END),
	(CASE WHEN (noofproductives='' OR noofproductives IS NULL) THEN 'No Of Productives,' ELSE '' END),
	(CASE WHEN (incident_code_id='' OR incident_code_id IS NULL) THEN 'Incident Code ID,' ELSE '' END),
	(CASE WHEN (potential_id='' OR potential_id IS NULL) THEN 'Potential ID,' ELSE '' END),
	(CASE WHEN (op_blocked='' OR op_blocked IS NULL) THEN 'OP Blocked,' ELSE '' END),
	(CASE WHEN (outstanding_credit='' OR outstanding_credit IS NULL) THEN 'Outstanding Credit,' ELSE '' END),
	(CASE WHEN (channel='' OR channel IS NULL) THEN 'Channel,' ELSE '' END),
	(CASE WHEN (frequency_of_visit='' OR frequency_of_visit IS NULL) THEN 'Frequency Of Visit,' ELSE '' END),
	(CASE WHEN (other_panels='' OR other_panels IS NULL) THEN 'Other Panels,' ELSE '' END),
	(CASE WHEN (website='' OR website IS NULL) THEN 'Website,' ELSE '' END),
	(CASE WHEN (social_network='' OR social_network IS NULL) THEN 'Social Network,' ELSE '' END)
) AS field_name_list
FROM `orocrm_account` OA
JOIN `oro_user` OU ON OA.user_owner_id = OU.id
WHERE FIND_IN_SET(OA.user_owner_id,user_owner_ids)) t1
LIMIT lowerLimit,upperLimit;
END$$