DROP PROCEDURE IF EXISTS `getSalesOverTimeData`;

CREATE PROCEDURE `getSalesOverTimeData`(IN pId VARCHAR(1500),IN userIds VARCHAR(1500),IN start_date DATE, IN end_date DATE,IN bu_ids VARCHAR(500),IN owner_bu_id INT)
BEGIN
DECLARE reportYr INT;
DECLARE reportMonthStart INT;
DECLARE reportMonthEnd INT;
DECLARE is_group_lvl INT;

SET reportYr = YEAR(start_date);
SET reportMonthStart = MONTH(start_date);
SET reportMonthEnd = MONTH(end_date);
SET is_group_lvl = 0;

	set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
	
	select group_level from oro_business_unit where id = owner_bu_id into is_group_lvl;
	
	IF is_group_lvl = 1 THEN
	
	SET @sql_query = concat("SELECT DATE_FORMAT(concat(report_year,'-',report_month,'-',01),'%b') AS month,ROUND(SUM((CASE WHEN net_amount IS NOT NULL THEN net_amount ELSE 0 END)), 0) AS actual
    FROM sales_report_consolidated_mv 
WHERE groupby_type = 'INDEX_ID' and business_unit_id IN (",bu_ids,") and  report_year = ",reportYr," and report_month between ",reportMonthStart," and ",reportMonthEnd,"  AND user_id IN (",userIds,")"); 


	IF pId != 0 THEN
		SET @sql_query = concat(@sql_query," AND index_id IN(",pId,")");       
    END IF;	
 

SET @sql_query = concat(@sql_query," GROUP BY month order by report_month");

ELSE

	SET @sql_query = concat("SELECT DATE_FORMAT(report_date,'%b') AS month,ROUND(SUM((CASE WHEN net_amount IS NOT NULL THEN net_amount ELSE 0 END)), 0) AS actual
    FROM sales_report_mv
WHERE business_unit_id IN (",bu_ids,") and report_date >= '",start_date,"' AND report_date <= '",end_date,"' AND user_id IN (",userIds,")"); 


	IF pId != 0 THEN
		SET @sql_query = concat(@sql_query," AND index_id IN(",pId,")");       
    END IF;	
 

SET @sql_query = concat(@sql_query," GROUP BY month order by month(report_date)");

 END IF;
    
    PREPARE stmt FROM @sql_query;
    EXECUTE stmt; 
	DEALLOCATE PREPARE stmt; 
END