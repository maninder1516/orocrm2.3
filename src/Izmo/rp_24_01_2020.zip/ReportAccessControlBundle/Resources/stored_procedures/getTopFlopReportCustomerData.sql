CREATE DEFINER=`root`@`%` PROCEDURE `getOutStandingCreditReportCustomerData`(IN usr_ids VARCHAR(500),IN cur_start_date DATE, IN cur_end_date DATE,IN cmpdate1 INT,IN lowerLimit INT,IN upperLimit INT)
BEGIN
	set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
	SET @sql_query = concat("SELECT oca.name as client,
    concat(ou.first_name,' ',ou.last_name) as salesman,
    oca.creditlimit AS available,
    oca.op_blocked as creditBlocked,
    oca.incident_code_id as incidentCode,
    IFNULL(ROUND((oca.creditlimit / (SUM(sh.netpricetotal) / ",cmpdate1,")), 0),0) as daysLeft
    FROM orocrm_account oca 
	INNER JOIN izmo_sales_history sh ON oca.id = sh.clientnumber
	INNER JOIN oro_user ou ON oca.user_owner_id = ou.id	
	WHERE oca.user_owner_id IN(",usr_ids,") and sh.invoicedate between '", cur_start_date,"' AND '", cur_end_date,"' and sh.netpricetotal > 0 
    GROUP BY oca.id having daysLeft <= 5 ORDER BY daysLeft LIMIT ",lowerLimit,",",upperLimit," ;");

    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
	DEALLOCATE PREPARE stmt; 
END