CREATE PROCEDURE `getAccountAndTheoreticalVisitsCount`(IN usrIds VARCHAR(800))
BEGIN
set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
 
 set @sql_qry =  CONCAT("SELECT COUNT(DISTINCT oa.id) AS accountcounts, (select SUM(
                CASE WHEN vfc.frequency_type = 1 THEN (vfc.no_of_visits * 3) WHEN vfc.frequency_type = 3 THEN vfc.no_of_visits ELSE 0 END)
                from izmo_visit_frequency_config vfc
                inner join izmo_channel_master icm on icm.id = vfc.channel_id 
                inner join client_category_mapping ccm on ccm.channel_name = icm.channel_name
                where vfc.potential_source_id = oa.potential_id and vfc.business_unit_id = bu.id and ccm.category_code = oa.clientcategory 
				and ccm.business_unit = bu.id) as theoretical_visits
                FROM orocrm_account oa INNER JOIN oro_user ou  ON ou.id = oa.user_owner_id INNER JOIN oro_business_unit bu on bu.id = ou.business_unit_owner_id WHERE ou.id IN (",usrIds,") and (ou.multiplecodes NOT LIKE '%dummy%')");

prepare stmt from @sql_qry;
execute stmt;
DEALLOCATE prepare stmt;
END