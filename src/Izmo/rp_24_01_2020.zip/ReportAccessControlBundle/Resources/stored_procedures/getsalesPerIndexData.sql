CREATE PROCEDURE `getsalesPerIndexData`(IN organization INT,IN workingDaysTillCurrentDay1 INT,IN workingDaysTillCurrentMonth1 INT,IN userIds VARCHAR(1500),IN start_date1 DATE, IN end_date1 DATE,IN prev_start_date1 DATE, IN prev_end_date1 DATE,IN bu_ids VARCHAR(500),IN owner_bu_id INT,IN turnoverType INT,IN workingDaysTillCurrentYear INT,IN startDayOfCurYr DATE, IN endDayOfCurYr DATE)
BEGIN 

DECLARE start_date DATE;
DECLARE end_date DATE;
DECLARE prev_start_date DATE;
DECLARE prev_end_date DATE;
DECLARE todays_date DATE;
DECLARE presentYear INT;
DECLARE presentMonth INT;
DECLARE presentDate INT;
DECLARE workingDaysTillCurrentDay INT;
DECLARE workingDaysTillCurrentMonth INT;
DECLARE curMonthEndDate DATE;
DECLARE cur_month INT;
DECLARE cur_yr INT;
DECLARE is_group_lvl INT;
DECLARE curReportYr INT;
DECLARE curReportMonth INT;
DECLARE prevReportYr INT;
DECLARE prevReportMonth INT;
DECLARE sales_type varchar(100);

SET todays_date = current_date();
SET presentYear = YEAR(todays_date);
SET presentMonth = MONTH(todays_date);
SET presentDate = DAY(todays_date);
SET start_date = (concat_ws('-', presentYear,presentMonth, 01));
SET end_date = (concat_ws('-', presentYear,presentMonth, presentDate));
SET prev_start_date = (concat_ws('-', presentYear-1,presentMonth, 01));
SET prev_end_date = prev_end_date1; 
SET curMonthEndDate = (concat_ws('-', presentYear,presentMonth, DAY(LAST_DAY(todays_date))));
SET cur_month = MONTH(todays_date);
SET cur_yr = YEAR(todays_date);

IF start_date = end_date THEN
	SET start_date =  DATE_FORMAT(CURRENT_DATE - INTERVAL 1 MONTH, '%Y-%m-01');
	SET end_date = DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, '%Y-%m-%d');
	SET prev_start_date =  DATE_FORMAT(prev_start_date - INTERVAL 1 MONTH, '%Y-%m-01');
	SET prev_end_date =  DATE_FORMAT(prev_end_date - INTERVAL 1 DAY, '%Y-%m-%d');
	
END IF;

IF turnoverType = 1 then
	SET sales_type = 'gross_amount';
ELSEIF turnoverType = 2 then
	SET sales_type = 'net_amount';
ELSEIF turnoverType = 3 then
	SET sales_type = 'quantity';
ELSE
	SET sales_type = 'net_amount';
END IF;

SET curReportYr = YEAR(end_date);
SET curReportMonth = MONTH(end_date);

SET prevReportYr = YEAR(prev_end_date);
SET prevReportMonth = MONTH(prev_end_date);

SET is_group_lvl = 0;

	set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
    
  	SET workingDaysTillCurrentDay = workingDaysTillCurrentDay1;
    SET workingDaysTillCurrentMonth = workingDaysTillCurrentMonth1;
    select group_level from oro_business_unit where id = owner_bu_id into is_group_lvl;
    IF is_group_lvl = 1 THEN
		
		SET @sql_query = concat("SELECT STRAIGHT_JOIN
	distinct(index_code) AS partindex,
	index_label AS index_description,
	ROUND(SUM((CASE 
		WHEN report_year = ",curReportYr," and report_month =",curReportMonth," and index_code in ('05','15','25') THEN quantity 
		WHEN report_year = ",curReportYr," and report_month =",curReportMonth," and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 
	END)), 0) AS actual,
	IFNULL(ROUND( CASE WHEN YEAR('",end_date,"') = ",cur_yr," and MONTH('",end_date,"') = ",cur_month," THEN ((SUM(CASE
		WHEN report_year = ",curReportYr," and report_month =",curReportMonth," and index_code in ('05','15','25') THEN quantity
		WHEN report_year = ",curReportYr," and report_month =",curReportMonth," and index_code not in ('05','15','25') THEN ",sales_type,"
    ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE ( SUM(CASE
		WHEN report_year = ",curReportYr," and report_month =",curReportMonth," and index_code in ('05','15','25') THEN quantity 
		WHEN report_year = ",curReportYr," and report_month =",curReportMonth," and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END )) END , 0),0) as projection,
    ROUND(SUM((CASE
		WHEN report_year = ",prevReportYr," and report_month =",prevReportMonth," and index_code in ('05','15','25') THEN quantity
		WHEN report_year = ",prevReportYr," and report_month =",prevReportMonth," and index_code not in ('05','15','25') THEN ",sales_type,"
        ELSE 0 END)), 0) AS actualprev,	
	IFNULL(ROUND( ((CASE WHEN YEAR('",end_date,"') = ",cur_yr," and MONTH('",end_date,"') = ",cur_month," THEN ((SUM(CASE
		WHEN report_year = ",curReportYr," and report_month =",curReportMonth," and index_code in ('05','15','25') THEN quantity
		WHEN report_year = ",curReportYr," and report_month =",curReportMonth," and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE ( SUM(CASE
			WHEN report_year = ",curReportYr," and report_month =",curReportMonth," and index_code in ('05','15','25')  THEN quantity 
			WHEN report_year = ",curReportYr," and report_month =",curReportMonth," and index_code not in ('05','15','25')  THEN ",sales_type," 
            ELSE 0 END )) END)/((SUM((CASE
				WHEN report_year = ",prevReportYr," and report_month =",prevReportMonth," and index_code in ('05','15','25') THEN quantity
				WHEN report_year = ",prevReportYr," and report_month =",prevReportMonth," and index_code not in ('05','15','25') THEN ",sales_type," 
                ELSE 0 END)))))*100 , 0),0) as performance,
	
	ROUND(SUM((CASE
		WHEN report_year = ",curReportYr," and index_code in ('05','15','25') THEN quantity
		WHEN report_year = ",curReportYr," and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END)), 0) AS actual_yearly,
	IFNULL(ROUND( CASE WHEN YEAR('",end_date,"') = ",cur_yr," THEN ((SUM(CASE
		WHEN report_year = ",curReportYr," and index_code in ('05','15','25') THEN quantity 
		WHEN report_year = ",curReportYr," and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END) / ",workingDaysTillCurrentYear,") * ",workingDaysTillCurrentYear,") ELSE ( SUM(CASE
			WHEN report_year = ",curReportYr," and index_code in ('05','15','25') THEN quantity
			WHEN report_year = ",curReportYr," and index_code not in ('05','15','25') THEN ",sales_type," 
            ELSE 0 END )) END , 0),0) as projection_yearly,
	IFNULL(ROUND( ((CASE WHEN YEAR('",end_date,"') = ",cur_yr," THEN ((SUM(CASE
		WHEN report_year = ",curReportYr," and index_code in ('05','15','25') THEN quantity
		WHEN report_year = ",curReportYr," and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END) / ",workingDaysTillCurrentYear,") * ",workingDaysTillCurrentYear,") ELSE ( SUM(CASE
			WHEN report_year = ",curReportYr," and index_code in ('05','15','25') THEN quantity
			WHEN report_year = ",curReportYr," and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END )) END)/((SUM((CASE
			WHEN report_year = ",prevReportYr," and index_code in ('05','15','25') THEN quantity
			WHEN report_year = ",prevReportYr," and index_code not in ('05','15','25') THEN ",sales_type," 
            ELSE 0 END)))))*100 , 0),0) as performance_yearly
	
	
FROM sales_report_consolidated_mv
where 
groupby_type = 'INDEX_ID' and
business_unit_id IN (",bu_ids,") and report_year in (",curReportYr,",",prevReportYr,") AND report_month = (",curReportMonth,") and user_id IN (",userIds,")
GROUP BY index_code;"); 
	
		ELSE
		
	
		SET @sql_query = concat("SELECT STRAIGHT_JOIN
	distinct(index_code) AS partindex,
	index_label AS index_description,
	ROUND(SUM((CASE
		WHEN report_date between '",start_date,"' AND '",end_date,"' and index_code in ('05','15','25') THEN quantity
		WHEN report_date between '",start_date,"' AND '",end_date,"' and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END)), 0) AS actual,
	IFNULL(ROUND( CASE WHEN YEAR('",end_date,"') = ",cur_yr," and MONTH('",end_date,"') = ",cur_month," THEN ((SUM(CASE
		WHEN report_date between '", start_date,"' AND '", end_date,"' and index_code in ('05','15','25') THEN quantity
		WHEN report_date between '", start_date,"' AND '", end_date,"' and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE ( SUM(CASE
			WHEN report_date between '", start_date,"' AND '", end_date,"' and index_code in ('05','15','25') THEN quantity 
			WHEN report_date between '", start_date,"' AND '", end_date,"' and index_code not in ('05','15','25') THEN ",sales_type," 
            ELSE 0 END )) END , 0),0) as projection,
    ROUND(SUM((CASE
		WHEN report_date between '",prev_start_date,"' AND '",prev_end_date,"' and index_code in ('05','15','25') THEN quantity
		WHEN report_date between '",prev_start_date,"' AND '",prev_end_date,"' and index_code not in ('05','15','25') THEN ",sales_type," 
    ELSE 0 END)), 0) AS actualprev,	
	IFNULL(ROUND( ((CASE WHEN YEAR('",end_date,"') = ",cur_yr," and MONTH('",end_date,"') = ",cur_month," THEN ((SUM(CASE
		WHEN report_date between '", start_date,"' AND '", end_date,"' and index_code in ('05','15','25') THEN quantity
		WHEN report_date between '", start_date,"' AND '", end_date,"' and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE ( SUM(CASE
			WHEN report_date between '", start_date,"' AND '", end_date,"' and index_code in ('05','15','25') THEN quantity
			WHEN report_date between '", start_date,"' AND '", end_date,"' and index_code not in ('05','15','25') THEN ",sales_type," 
            ELSE 0 END )) END)/((SUM((CASE
				WHEN report_date between '",prev_start_date,"' AND '",prev_end_date,"' and index_code in ('05','15','25') THEN quantity
				WHEN report_date between '",prev_start_date,"' AND '",prev_end_date,"' and index_code not in ('05','15','25') THEN ",sales_type," 
                ELSE 0 END)))))*100 , 0),0) as performance,
	
	ROUND(SUM((CASE
		WHEN report_date between '",startDayOfCurYr,"' AND '",endDayOfCurYr,"' and index_code in ('05','15','25') THEN quantity
		WHEN report_date between '",startDayOfCurYr,"' AND '",endDayOfCurYr,"' and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END)), 0) AS actual_yearly,
	IFNULL(ROUND( CASE WHEN YEAR('",endDayOfCurYr,"') = ",cur_yr," THEN ((SUM(CASE
		WHEN report_date between '", startDayOfCurYr,"' AND '", endDayOfCurYr,"' and index_code in ('05','15','25') THEN quantity
		WHEN report_date between '", startDayOfCurYr,"' AND '", endDayOfCurYr,"' and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END) / ",workingDaysTillCurrentYear,") * ",workingDaysTillCurrentYear,") ELSE ( SUM(CASE
			WHEN report_date between '", startDayOfCurYr,"' AND '", endDayOfCurYr,"' and index_code in ('05','15','25') THEN quantity
			WHEN report_date between '", startDayOfCurYr,"' AND '", endDayOfCurYr,"' and index_code not in ('05','15','25') THEN ",sales_type," 
            ELSE 0 END )) END , 0),0) as projection_yearly,
	IFNULL(ROUND( ((CASE WHEN YEAR('",endDayOfCurYr,"') = ",cur_yr," THEN ((SUM(CASE
		WHEN report_date between '", startDayOfCurYr,"' AND '", endDayOfCurYr,"' and index_code in ('05','15','25') THEN quantity
		WHEN report_date between '", startDayOfCurYr,"' AND '", endDayOfCurYr,"' and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END) / ",workingDaysTillCurrentYear,") * ",workingDaysTillCurrentYear,") ELSE ( SUM(CASE
			WHEN report_date between '", startDayOfCurYr,"' AND '", endDayOfCurYr,"' and index_code in ('05','15','25') THEN quantity
			WHEN report_date between '", startDayOfCurYr,"' AND '", endDayOfCurYr,"' and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END )) END)/((SUM((CASE
			WHEN report_date between '",startDayOfCurYr,"' AND '",endDayOfCurYr,"' and index_code in ('05','15','25') THEN quantity 
			WHEN report_date between '",startDayOfCurYr,"' AND '",endDayOfCurYr,"' and index_code not in ('05','15','25') THEN ",sales_type," 
        ELSE 0 END)))))*100 , 0),0) as performance_yearly
	
FROM sales_report_mv
where business_unit_id IN (",bu_ids,") and report_date between '",prev_start_date,"' AND '",end_date,"' and user_id IN (",userIds,")
GROUP BY index_code;"); 
	
	END IF;
    
    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt; 
END