CREATE PROCEDURE `getPerformancePartsSalesNetTurnoverExcel`(IN usr_ids VARCHAR(500),IN index_code VARCHAR(100),IN segment_code VARCHAR(100),IN niche_code VARCHAR(100),IN family_code VARCHAR(100),IN sel_year INT,IN index_label VARCHAR(500),IN segment_label varchar(500),IN niche_label varchar(500),IN family_label VARCHAR(500))
BEGIN
    DECLARE historical_end_date DATE;
    DECLARE historical_start_date DATE;
    DECLARE cur_start_date DATE;
    DECLARE cur_end_date DATE;

    SET historical_end_date = (concat_ws("-", sel_year - 1,12, 31));
    SET historical_start_date = (concat_ws("-", sel_year - 1,01, 01));
    SET cur_start_date = (concat_ws("-", sel_year,01, 01));
    SET cur_end_date = (concat_ws("-", sel_year,12, 31));
    
  
   SET @sql_query = CONCAT('
   SELECT STRAIGHT_JOIN 
   concat_ws("-",pi.partindexcode,pi.partindexlabel) as partindexcode,
   concat_ws("-",ps.partsegmentcode,ps.partsegmentlabel) as partsegmentcode,
   concat_ws("-",pn.partnichecode,pn.partnichelabel)  as partnichecode,
   concat_ws("-",pf.partfamilycode,pf.partfamilylabel) as partfamilycode,
   MONTHNAME(sh.invoicedate) AS mon,
   ROUND(SUM(CASE WHEN sh.invoicedate BETWEEN "',cur_start_date,'" AND "',cur_end_date,'" THEN sh.netpricetotal ELSE 0 END) ,0) AS salestotal,
   ROUND((SUM(CASE WHEN sh.invoicedate BETWEEN "',cur_start_date,'" AND "',cur_end_date,'" THEN sh.netpricetotal ELSE 0 END))/(SUM(CASE WHEN sh.invoicedate BETWEEN "',historical_start_date,'" AND "',historical_end_date,'" THEN sh.netpricetotal ELSE 0 END)) * 100,0) AS histDelta
    FROM
	orocrm_account a 
                INNER JOIN 
        oro_user u on u.id = a.user_owner_id
                INNER JOIN 
        oro_business_unit bu ON bu.id = u.business_unit_owner_id
                INNER JOIN
        izmo_sales_history sh ON a.id = sh.clientnumber
                INNER JOIN
        izmo_partfamily pf ON pf.id = sh.partfamily
                INNER JOIN
        izmo_partindex pi ON pi.id = pf.partindex_id
                INNER JOIN
        izmo_partsegment ps ON ps.id = pf.partsegment_id
                INNER JOIN
        izmo_partniche pn ON pn.id = pf.partniche_id
    WHERE
    sh.invoicedate >= "',historical_start_date,'"
        AND sh.invoicedate <= "',cur_end_date,'"
        AND u.id IN (',usr_ids,')');
        IF index_code != "none" THEN
                SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexcode LIKE "%',index_code,'%" ');
        END IF;
        IF index_label != "none" THEN

                SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexlabel LIKE "%',index_label,'%" ');
        END IF;
        IF segment_code != "none" THEN
                    SET @sql_query = CONCAT(@sql_query, ' AND ps.partsegmentcode LIKE "%',segment_code,'%" ');
            END IF;
         IF segment_label != "none" THEN
                    SET @sql_query = CONCAT(@sql_query, ' AND ps.partsegmentlabel LIKE "%',segment_label,'%" ');
        END IF;
        IF niche_code != "none" THEN
               SET @sql_query = CONCAT(@sql_query, ' AND pn.partnichecode LIKE "%',niche_code,'%" ');
        END IF;
        IF niche_label != "none" THEN
               SET @sql_query = CONCAT(@sql_query, ' AND pn.partnichelabel LIKE "%',niche_label,'%" ');
        END IF;
        IF family_code != "none" THEN
            SET @sql_query = CONCAT(@sql_query, ' AND pf.partfamilycode like "%',family_code,'%" ');
        END IF;
        IF family_label != "none" THEN
                    SET @sql_query = CONCAT(@sql_query, ' AND pf.partfamilylabel like "%', family_label, '%" ');
        END IF;
   
	SET @sql_query = CONCAT(@sql_query, ' GROUP By pi.partindexcode,ps.partsegmentcode, pn.partnichecode,pf.partfamilycode,MONTH(sh.invoicedate) ');
    
    PREPARE stmt FROM @sql_query;  
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
END