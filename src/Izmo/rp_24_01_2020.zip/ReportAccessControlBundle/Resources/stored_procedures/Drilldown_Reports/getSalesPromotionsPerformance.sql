DROP PROCEDURE IF EXISTS `getSalesPromotionsPerformance`;

CREATE PROCEDURE `getSalesPromotionsPerformance`(IN report_type INT, IN usr_ids VARCHAR(1500),IN platform_id INT,IN promotion_id INT,IN usr_id_sel INT,IN category_code_id INT,IN promo_date DATE,IN promo_name VARCHAR(200),IN category_type INT, IN client_code VARCHAR(50), IN client_name VARCHAR(50),IN owner_bu_id INT, IN show_client_with_turnover VARCHAR(5), IN platform VARCHAR(200), IN chanel_code_name VARCHAR(200), IN where_cond VARCHAR(500),IN order_cond VARCHAR(500),IN page_limit VARCHAR(30), IN pk_col_for_cnt VARCHAR(20), IN cnt_flg INT, IN is_start INT)
BEGIN 
	DECLARE cmp_date1 int;
	DECLARE cmp_date2 int;
	DECLARE cur_start_date DATE;
    DECLARE curr_month_first_day DATE;
    DECLARE cur_end_date DATE;
	DECLARE todays_date DATE;
    DECLARE presentYear INT;
    DECLARE startyear DATE;
    DECLARE endyear DATE;
	DECLARE currentlastdate DATE;
	DECLARE previousdate DATE;
    DECLARE historical_start_date DATE; 
	DECLARE historical_end_date DATE;
	DECLARE cur_dat DATE;
	DECLARE prev_dat DATE;
	
	SET cur_dat = current_date();
	SET prev_dat = subdate(cur_dat, 1);

    set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
		SET @sql_query = CONCAT("
			SELECT  STRAIGHT_JOIN SQL_CALC_FOUND_ROWS
				obu.name as platform,
				p.izmopromotionname as promotion_name,
                p.izmopromotionstartdate as promotion_start,
                p.izmopromotionenddate as promotion_end,
				CONCAT_WS(' ', u.first_name, u.last_name) AS salesman,				
				CONCAT_WS('-', ccm.category_code, ccm.channel_name) AS chanel_code_name,
                a.clientnumber as account_code,
				a.name as client,
               ");
			IF report_type < 1 THEN
              SET @sql_query = CONCAT(@sql_query," CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				WHEN (select sum( CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				ELSE 0 END as target,
				
                CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id IN (",usr_ids,")  THEN ifnull(sh.quantity, 0)  ELSE 0 END)), 0) 
				WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id IN (",usr_ids,")  THEN ifnull(sh.net_amount, 0) ELSE 0 END)), 0) 
				ELSE 0 END AS sales_total,
				
                 IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id IN (",usr_ids,")    THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id IN (",usr_ids,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0) as target_vs_total_perc,
				
                CASE WHEN '",cur_dat,"' between p.izmopromotionstartdate and p.izmopromotionenddate 
				THEN (IFNULL(CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.user_id IN (",usr_ids,")   THEN ifnull(sh.quantity, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when current_date > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end)))) -
 (select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))					))) * 100, 0)
				WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.user_id IN (",usr_ids,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					 - (select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))
					)) * 100), 0)
				ELSE 0 END,0))
				ELSE (
				IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id IN (",usr_ids,")    THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id IN (",usr_ids,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0)
				)
				END
				as projection_perc,				
				obu.id as platform_id,  
                p.id as promotion_id,
				u.id  as salesman_id, 					
				ccm.category_code as category_code_id,
				a.id as account_id,
				
                CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0)  ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 0 
				WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 1 
				ELSE 0 END as targetType");
                ELSEIF report_type = 1 THEN
               SET @sql_query = CONCAT(@sql_query," CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				WHEN (select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				ELSE 0 END as target,
				
                CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id = u.id    THEN ifnull(sh.quantity, 0)  ELSE 0 END)), 0) 
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id = u.id   THEN ifnull(sh.net_amount, 0) ELSE 0 END)), 0) 
				ELSE 0 END AS sales_total,
				
               IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = u.id    THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = u.id   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0) as target_vs_total_perc,
                CASE WHEN '",cur_dat,"' between p.izmopromotionstartdate and p.izmopromotionenddate THEN (IFNULL(CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((((sum(CASE WHEN sh.user_id = u.id   THEN ifnull(sh.quantity, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					-  (select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))
					))) * 100), 0)
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((((sum(CASE WHEN sh.user_id = u.id   THEN ifnull(sh.net_amount, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					-  (select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))
					))) * 100), 0)
				ELSE 0 END,0) )
				ELSE (
				IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = u.id    THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = u.id   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0)
				)
				END
				as projection_perc,
				obu.id as platform_id,
                p.id as promotion_id,
				u.id  as salesman_id,
				ccm.category_code as category_code_id,
				a.id as account_id,
				
                CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0)  ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 0 
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 1 
				ELSE 0 END as targetType");
                ELSE
                 SET @sql_query = CONCAT(@sql_query," CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				WHEN (select sum( CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				ELSE 0 END as target,
                CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.quantity, 0)  ELSE 0 END)), 0) 
				WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END)), 0) 
				ELSE 0 END AS sales_total,
                  IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0) as target_vs_total_perc,
                CASE WHEN '",cur_dat,"' between p.izmopromotionstartdate and p.izmopromotionenddate THEN 
				(IFNULL(CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.user_id = (",usr_id_sel,")    THEN ifnull(sh.quantity, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id =(",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					-  (select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))
					))) * 100, 0)
				WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					- (select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end)))
					)) * 100, 0)
				ELSE 0 END,0))
				ELSE
				(IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0))
				END
				as projection_perc,
				obu.id as platform_id,
                p.id as promotion_id,
                u.id  as salesman_id,
				ccm.category_code as category_code_id,
				a.id as account_id,
				
                CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0)  ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 0 
				WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 1 
				ELSE 0 END as targetType");
                END IF;
                SET @sql_query = CONCAT(@sql_query,"
			FROM
				izmo_promotion p				
				inner join oro_business_unit obu on obu.id = p.business_unit_owner_id
				inner join izmo_promotionsalesman pps on pps.promotion_id = p.id
				inner join izmo_promotion_to_partmaster c on c.promotion_id = p.id
				inner join oro_user u on u.id = pps.salesman_id
				left join sales_report_consolidated_mv sh on c.partmaster_id = sh.master_id and sh.report_date between p.izmopromotionstartdate and p.izmopromotionenddate 
				and sh.user_id = pps.salesman_id and sh.groupby_type = 'PROMOTION_DATA'
				left join orocrm_account a on a.id = sh.cust_id
				left join client_category_mapping ccm on ccm.category_code = a.clientcategory
				
			WHERE
				('",promo_date,"' between p.izmopromotionstartdate and p.izmopromotionenddate) and p.is_challenge = 0 ");

    IF report_type < 5 THEN
		SET @sql_query = CONCAT(@sql_query,"and u.id in (",usr_ids,")");
    ELSE
		SET @sql_query = CONCAT(@sql_query,"and u.id = (",usr_id_sel,")");
    END IF;
     
    IF promo_name != 'none' THEN
		SET @sql_query = CONCAT(@sql_query," and p.izmopromotionname LIKE '%",promo_name,"%' ");
    END IF;
	IF client_name != 'none' THEN
		SET @sql_query = CONCAT(@sql_query," and a.name LIKE '%",client_name,"%' ");
	END IF;
	IF client_code != 'none' THEN
		SET @sql_query = CONCAT(@sql_query," and a.clientnumber LIKE '%",client_code,"%' ");
	END IF;
	
	IF platform != 'none' THEN
		SET @sql_query = CONCAT(@sql_query," and obu.name LIKE '%",platform,"%' ");
	END IF;
	IF chanel_code_name != 'none' THEN			
		SET @sql_query = CONCAT(@sql_query," AND CONCAT_WS('-', ccm.category_code, ccm.channel_name) LIKE '%",chanel_code_name,"%' ");
	END IF;
		
	
	IF(show_client_with_turnover = 'on') THEN
        SET @sql_query = concat(@sql_query, " AND a.clientnumber IS NOT NULL and a.clientnumber <> '' "); 
	ELSE
		SET @sql_query = concat(@sql_query, " AND (a.clientnumber IS NULL OR a.clientnumber = '') "); 
    END IF;
	
    IF report_type = 0 THEN
		SET @sql_query = concat(@sql_query," GROUP BY obu.id ");   
	ELSEIF report_type = 1 THEN
		SET @sql_query = concat(@sql_query," AND obu.id = ",platform_id," GROUP BY obu.id,p.id ");
	ELSEIF report_type = 2 THEN
		SET @sql_query = concat(@sql_query," AND obu.id = ",platform_id," AND p.id = ",promotion_id," GROUP BY obu.id,p.id,u.id "); 		
	ELSEIF report_type = 3 THEN
		SET @sql_query = concat(@sql_query," AND obu.id = ",platform_id," AND p.id = ",promotion_id," AND u.id = ",usr_id_sel," GROUP BY obu.id,p.id,u.id,ccm.category_code ");
   	ELSEIF report_type = 4 THEN
		SET @sql_query = concat(@sql_query," AND obu.id = ",platform_id," AND p.id = ",promotion_id," AND ccm.category_code = ",category_code_id,"
    GROUP BY obu.id,p.id,u.id,ccm.category_code,a.id");
    END IF;
		
SET @sql_query = CONCAT(@sql_query," UNION ALL (");
SET @sql_query = CONCAT(@sql_query,"
			SELECT  STRAIGHT_JOIN 
				obu.name as platform,
				p.izmopromotionname as promotion_name,
                p.izmopromotionstartdate as promotion_start,
                p.izmopromotionenddate as promotion_end,
				CONCAT_WS(' ', u.first_name, u.last_name) AS salesman,
				CONCAT_WS('-', ccm.category_code, ccm.channel_name) AS chanel_code_name,
                a.clientnumber as account_code,
				a.name as client,
               ");
                IF report_type < 1 THEN
              SET @sql_query = CONCAT(@sql_query," CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				WHEN (select sum( CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				ELSE 0 END as target,
                CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id IN (",usr_ids,")  THEN ifnull(sh.quantity, 0)  ELSE 0 END)), 0) 
				WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id IN (",usr_ids,")  THEN ifnull(sh.net_amount, 0) ELSE 0 END)), 0) 
				ELSE 0 END AS sales_total,
                IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id IN (",usr_ids,")    THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id IN (",usr_ids,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0) as target_vs_total_perc,
				CASE WHEN '",cur_dat,"' between p.izmopromotionstartdate and p.izmopromotionenddate THEN (
                IFNULL(CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.user_id IN (",usr_ids,")   THEN ifnull(sh.quantity, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					-(select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))
					)
					)) * 100, 0)
				WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.user_id IN (",usr_ids,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					-(select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end)))
					)) * 100, 0)
				ELSE 0 END,0))
				ELSE (
				IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id IN (",usr_ids,")    THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id IN (",usr_ids,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0)
				)
				END
				as projection_perc,
				obu.id as platform_id,
                p.id as promotion_id,
				u.id  as salesman_id,
				ccm.category_code as category_code_id,
				a.id as account_id,				
				
                CASE WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.quantity, 0)  ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 0 
				WHEN (select sum(CASE WHEN pps.salesman_id IN (",usr_ids,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 1 
				ELSE 0 END as targetType");
                ELSEIF report_type = 1 THEN
               SET @sql_query = CONCAT(@sql_query," CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				WHEN (select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				ELSE 0 END as target,
                CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id = u.id    THEN ifnull(sh.quantity, 0)  ELSE 0 END)), 0) 
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id = u.id   THEN ifnull(sh.net_amount, 0) ELSE 0 END)), 0) 
				ELSE 0 END AS sales_total,
                IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = u.id    THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = u.id   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0) as target_vs_total_perc,
				CASE WHEN '",cur_dat,"' between p.izmopromotionstartdate and p.izmopromotionenddate THEN (
                IFNULL(CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.user_id = u.id   THEN ifnull(sh.quantity, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					- (select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))
					)
					)) * 100, 0)
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.user_id = u.id   THEN ifnull(sh.net_amount, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					-(select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))
					)
					)) * 100, 0)
				ELSE 0 END,0) )
				ELSE (
				IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = u.id    THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = u.id   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0)
				)
				END
				as projection_perc,
				obu.id as platform_id,
                p.id as promotion_id,					
				u.id  as salesman_id,
				ccm.category_code as category_code_id,
				a.id as account_id,
				
                CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0)  ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 0 
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 1 
				ELSE 0 END as targetType");
                ELSE
                 SET @sql_query = CONCAT(@sql_query," CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				WHEN (select sum( CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				ELSE 0 END as target,
                CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.quantity, 0)  ELSE 0 END)), 0) 
				WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END)), 0) 
				ELSE 0 END AS sales_total,
                  IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0) as target_vs_total_perc,
                CASE WHEN '",cur_dat,"' between p.izmopromotionstartdate and p.izmopromotionenddate THEN (IFNULL(CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.user_id = (",usr_id_sel,")    THEN ifnull(sh.quantity, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id =(",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					 -(select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end)))
					)) * 100, 0)
				WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					 - (select count(id) from izmo_businessclosure where business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end)))
					)) * 100, 0)
				ELSE 0 END,0))
				ELSE
				IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.quantity, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.user_id = (",usr_id_sel,")   THEN ifnull(sh.net_amount, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0)
				END
				as projection_perc,
				obu.id as platform_id,
                p.id as promotion_id,				
				u.id  as salesman_id,
				ccm.category_code as category_code_id,
				a.id as account_id,
                
                CASE WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.quantity, 0)  ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 0 
				WHEN (select sum(CASE WHEN pps.salesman_id = (",usr_id_sel,") THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN 1 
				ELSE 0 END as targetType");
                END IF;
                SET @sql_query = CONCAT(@sql_query," FROM
				izmo_promotion p				
				inner join oro_business_unit obu on obu.id = p.business_unit_owner_id
				inner join izmo_promotionsalesman pps on pps.promotion_id = p.id
				inner join izmo_promotion_to_partfamily c on c.promotion_id = p.id
				inner join oro_user u on u.id = pps.salesman_id
				left join sales_report_consolidated_mv sh on c.partfamily_id = sh.family_id and sh.report_date between p.izmopromotionstartdate and p.izmopromotionenddate 
				and sh.user_id = pps.salesman_id and sh.groupby_type = 'PROMOTION_DATA'
				left join orocrm_account a on a.id = sh.cust_id
				left join client_category_mapping ccm on ccm.category_code = a.clientcategory
			WHERE
				('",promo_date,"' between p.izmopromotionstartdate and p.izmopromotionenddate) and p.is_challenge = 0 ");

     IF report_type < 5 THEN
		SET @sql_query = CONCAT(@sql_query,"and u.id in (",usr_ids,")");
     ELSE
		SET @sql_query = CONCAT(@sql_query,"and u.id = (",usr_id_sel,")");
     END IF;
     
     IF promo_name != 'none' THEN
		SET @sql_query = CONCAT(@sql_query," and p.izmopromotionname LIKE '%",promo_name,"%' ");
     END IF;
	  IF client_name != 'none' THEN
		SET @sql_query = CONCAT(@sql_query," and a.name LIKE '%",client_name,"%' ");
	 END IF;
	IF client_code != 'none' THEN
		SET @sql_query = CONCAT(@sql_query," and a.clientnumber LIKE '%",client_code,"%' ");
	END IF;
	
	IF platform != 'none' THEN
		SET @sql_query = CONCAT(@sql_query," and obu.name LIKE '%",platform,"%' ");
	END IF;
	IF chanel_code_name != 'none' THEN		
		SET @sql_query = CONCAT(@sql_query," AND CONCAT_WS('-', ccm.category_code, ccm.channel_name) LIKE '%",chanel_code_name,"%' ");
	END IF;
	
	IF(show_client_with_turnover = 'on') THEN
        SET @sql_query = concat(@sql_query, " AND a.clientnumber IS NOT NULL and a.clientnumber <> '' "); 
	ELSE
		SET @sql_query = concat(@sql_query, " AND (a.clientnumber IS NULL OR a.clientnumber = '') "); 
    END IF;
	 
    IF report_type = 0 THEN
		SET @sql_query = concat(@sql_query," GROUP BY obu.id ");   
	ELSEIF report_type = 1 THEN
		SET @sql_query = concat(@sql_query," AND obu.id = ",platform_id," GROUP BY obu.id,p.id ");
	ELSEIF report_type = 2 THEN
		SET @sql_query = concat(@sql_query," AND obu.id = ",platform_id," AND p.id = ",promotion_id," GROUP BY obu.id,p.id,u.id "); 		
	ELSEIF report_type = 3 THEN
		SET @sql_query = concat(@sql_query," AND obu.id = ",platform_id," AND p.id = ",promotion_id," AND u.id = ",usr_id_sel," GROUP BY obu.id,p.id,u.id,ccm.category_code ");
   	ELSEIF report_type = 4 THEN
		SET @sql_query = concat(@sql_query," AND obu.id = ",platform_id," AND p.id = ",promotion_id," AND ccm.category_code = ",category_code_id,"
    GROUP BY obu.id,p.id,u.id,ccm.category_code,a.id");
    END IF;

	
    SET @sql_query = concat(@sql_query," ) ");
    
   IF page_limit != '' THEN
	  SET @sql_query = CONCAT(@sql_query, ' ', page_limit);
    END IF;
 
    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
 	
END