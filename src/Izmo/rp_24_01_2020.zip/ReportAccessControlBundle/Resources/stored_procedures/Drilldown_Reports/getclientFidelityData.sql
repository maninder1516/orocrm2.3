DROP PROCEDURE IF EXISTS `getclientFidelityData`;
CREATE PROCEDURE `getclientFidelityData`(IN userIds VARCHAR(1500), IN salesmanSearchData VARCHAR(200),IN client_name VARCHAR(200),IN client_code VARCHAR(200),IN bu_ids VARCHAR(500),IN owner_bu_id INT,IN where_cond VARCHAR(500),IN order_cond VARCHAR(500),IN page_limit VARCHAR(40),IN pk_col_for_cnt VARCHAR(20),IN cnt_flg INT)
BEGIN

	DECLARE FIDELITY_MINIMUM_VALUE INT;
	DECLARE startDate DATE;
	DECLARE endDate DATE;
	DECLARE IN_MONTHS INT;
    
    SET IN_MONTHS = 5;
    
	set endDate = date_sub(date_sub(date_add(last_day(current_date()), interval 1 DAY), interval 1 month), interval 1 day);
	set startDate = date_sub(date_add(last_day(current_date()), interval 1 DAY), interval 2 month);

	SELECT CONVERT(config_value,UNSIGNED INTEGER) INTO FIDELITY_MINIMUM_VALUE FROM `custom_config`WHERE config_label = 'FIDELITY_MINIMUM_VALUE' and business_unit_owner_id = owner_bu_id;
	 
	set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
	SET @sql_query = CONCAT("
	SELECT SQL_CALC_FOUND_ROWS clientnumber,`customer`,`code`,`salesman`,`count`,
		(CASE 
			WHEN (`count` >= 0 AND `count` <= 2) THEN 'To Activate'
			WHEN (`count` >= 3 AND `count` <= 4) THEN 'To Retain'
			WHEN (`count` >= 5 ) THEN 'Faithful'
		END) AS `type`
	FROM
    (
		SELECT COUNT(code) AS COUNT,clientnumber,customer,CODE,netpricetotal,salesman FROM 
		(
			SELECT mv.cust_id as 'clientnumber', mv.customer AS 'customer', mv.client_number AS 'code', sum(mv.net_amount) as 'netpricetotal', 
			mv.report_date as 'invoicedate', mv.salesman AS `salesman`
			from sales_report_mv mv
			WHERE mv.business_unit_id IN (",bu_ids,") and mv.channel IN ('RI','RA') AND mv.user_id IN (",userIds,") 
				and mv.report_date BETWEEN '", startDate,"' - INTERVAL ",IN_MONTHS," MONTH AND '", endDate,"' ");
	
	IF salesmanSearchData != 'none' THEN
		SET @sql_query = concat(@sql_query," and mv.salesman LIKE '%",salesmanSearchData,"%'");       
	END IF;			
	IF client_name != 'none' THEN
		SET @sql_query = concat(@sql_query," and mv.customer LIKE '%",client_name,"%'");
	END IF;
	IF client_code != 'none' THEN
		SET @sql_query = concat(@sql_query," and mv.client_number LIKE '",client_code,"%'");
	END IF;
	SET @sql_query = concat(@sql_query,	" GROUP BY YEAR(mv.report_date), MONTH(mv.report_date), mv.cust_id
			ORDER BY mv.report_date DESC
		) tbl2 
        where netpricetotal >= ",FIDELITY_MINIMUM_VALUE," 
		GROUP BY tbl2.clientnumber
		ORDER BY tbl2.clientnumber ASC
	) tbl3 
    ");
        
        IF page_limit != '' THEN
		  SET @sql_query = CONCAT(@sql_query, ' ', page_limit);
		END IF; 
    
     
 PREPARE stmt from @sql_query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
               
END