DROP PROCEDURE IF EXISTS `getSalesPromotionsPerformanceExcel`;

CREATE PROCEDURE `getSalesPromotionsPerformanceExcel`(IN usr_ids VARCHAR(1500),IN promo_date DATE,IN promo_name VARCHAR(200),IN category_type INT,IN client_code VARCHAR(50), IN client_name VARCHAR(50),IN owner_bu_id INT, IN show_client_with_turnover VARCHAR(5), IN platform VARCHAR(200), IN chanel_code_name VARCHAR(200))
BEGIN
	DECLARE cmp_date1 int;
	DECLARE cmp_date2 int;
	DECLARE cur_start_date DATE;
    DECLARE curr_month_first_day DATE;
    DECLARE cur_end_date DATE;
	DECLARE todays_date DATE; 
    DECLARE presentYear INT;
    DECLARE startyear DATE;
    DECLARE endyear DATE;
	DECLARE currentlastdate DATE;
	DECLARE previousdate DATE;
    DECLARE historical_start_date DATE; 
	DECLARE historical_end_date DATE;
    
	DECLARE cur_dat DATE;
	DECLARE prev_dat DATE;
	
	SET cur_dat = current_date();
	SET prev_dat = subdate(cur_dat, 1);
    
    set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
    
    	SET @sql_query = CONCAT("
			SELECT  STRAIGHT_JOIN  
				obu.name as platform,
				p.izmopromotionname as promotion_name,
                p.izmopromotionstartdate as promotion_start,
                p.izmopromotionenddate as promotion_end,
				CONCAT_WS(' ', u.first_name, u.last_name) AS salesman,
				CONCAT_WS('-', ccm.category_code, ccm.channel_name) AS chanel_code_name,
                a.clientnumber as account_code,
				a.name as client, 
				CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				WHEN (select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				ELSE 0 END as target,
                CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.owner_id = u.id    THEN ifnull(sh.quantitybought, 0)  ELSE 0 END)), 0) 
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.owner_id = u.id   THEN ifnull(sh.netpricetotal, 0) ELSE 0 END)), 0) 
				ELSE 0 END AS sales_total,
                IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.owner_id = u.id    THEN ifnull(sh.quantitybought, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.owner_id = u.id   THEN ifnull(sh.netpricetotal, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0) as target_vs_total_perc,
                CASE WHEN '",cur_dat,"' between p.izmopromotionstartdate and p.izmopromotionenddate THEN (IFNULL(CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.owner_id = u.id    THEN ifnull(sh.quantitybought, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					 -(select count(id) from izmo_businessclosure where  business_unit_owner_id = ",owner_bu_id," and  bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end)))
					)) * 100, 0)
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.owner_id = u.id   THEN ifnull(sh.netpricetotal, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					 - (select count(id) from izmo_businessclosure where  business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end)))
					)) * 100, 0)
				ELSE 0 END,0))
				ELSE
				IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.owner_id = u.id   THEN ifnull(sh.quantitybought, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.owner_id = u.id   THEN ifnull(sh.netpricetotal, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0)
				END
				as projection_perc
            FROM
				izmo_promotion p
				inner join izmo_promotionsalesman pps on pps.promotion_id = p.id
				inner join izmo_promotion_to_partmaster c on c.promotion_id = p.id
				inner join oro_user u on u.id = pps.salesman_id
				left join izmo_sales_history sh on c.partmaster_id = sh.partmaster and sh.invoicedate between p.izmopromotionstartdate and p.izmopromotionenddate and sh.montantcv42 != 0
				and sh.owner_id = pps.salesman_id
				left join orocrm_account a on a.id = sh.clientnumber
				left join client_category_mapping ccm on ccm.category_code = a.clientcategory
			WHERE
				('",promo_date,"' between p.izmopromotionstartdate and p.izmopromotionenddate) 
                and p.is_challenge = 0
                and u.id in (",usr_ids,") ");
     
		IF promo_name != 'none' THEN
			SET @sql_query = CONCAT(@sql_query," and p.izmopromotionname LIKE '%",promo_name,"%' ");
		END IF;
		IF client_name != 'none' THEN
			SET @sql_query = CONCAT(@sql_query," and a.name LIKE '%",client_name,"%' ");
		END IF;
		IF client_code != 'none' THEN
			SET @sql_query = CONCAT(@sql_query," and a.clientnumber LIKE '%",client_code,"%' ");
		END IF;
		IF platform != 'none' THEN
			SET @sql_query = CONCAT(@sql_query," and obu.name LIKE '%",platform,"%' ");
		END IF;
		IF chanel_code_name != 'none' THEN			
			SET @sql_query = CONCAT(@sql_query," AND CONCAT_WS('-', ccm.category_code, ccm.channel_name) LIKE '%",chanel_code_name,"%' ");
		END IF;
		IF(show_client_with_turnover = 'on') THEN
			SET @sql_query = concat(@sql_query, " AND a.clientnumber IS NOT NULL and a.clientnumber <> '' "); 
		ELSE
			SET @sql_query = concat(@sql_query, " AND (a.clientnumber IS NULL OR a.clientnumber = '') "); 
		END IF;
	 	 
		SET @sql_query = concat(@sql_query," GROUP BY obu.id,p.id,u.id,ccm.category_code,a.id");
	 
		SET @sql_query = CONCAT(@sql_query,"  UNION ALL (");
			SET @sql_query = CONCAT(@sql_query," 
			SELECT  STRAIGHT_JOIN  
				obu.name as platform,
				p.izmopromotionname as promotion_name,
                p.izmopromotionstartdate as promotion_start,
                p.izmopromotionenddate as promotion_end,
				CONCAT_WS(' ', u.first_name, u.last_name) AS salesman,
				CONCAT_WS('-', ccm.category_code, ccm.channel_name) AS chanel_code_name,
                a.clientnumber as account_code,
				a.name as client, 
				CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				WHEN (select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id), 0) 
				ELSE 0 END as target,
                CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.owner_id = u.id    THEN ifnull(sh.quantitybought, 0)  ELSE 0 END)), 0) 
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND((sum(CASE WHEN sh.owner_id = u.id   THEN ifnull(sh.netpricetotal, 0) ELSE 0 END)), 0) 
				ELSE 0 END  AS sales_total,
                IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.owner_id = u.id    THEN ifnull(sh.quantitybought, 0) ELSE 0 END)) /(select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.owner_id = u.id   THEN ifnull(sh.netpricetotal, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0) as target_vs_total_perc,
                CASE WHEN '",cur_dat,"' between p.izmopromotionstartdate and p.izmopromotionenddate THEN (IFNULL(CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.owner_id = u.id    THEN ifnull(sh.quantitybought, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					 -(select count(id) from izmo_businessclosure where  business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end)))
					)) * 100, 0)
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(CASE WHEN sh.owner_id = u.id   THEN ifnull(sh.netpricetotal, 0) ELSE 0 END)) / (((select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) / p.working_days) * ((SELECT (TOTAL_WEEKDAYS(p.izmopromotionstartdate, (case when '",cur_dat,"' > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end))))
					 - (select count(id) from izmo_businessclosure where  business_unit_owner_id = ",owner_bu_id," and bcdate between p.izmopromotionstartdate and (case when DATE(",cur_dat,") > p.izmopromotionenddate then p.izmopromotionenddate else '",prev_dat,"' end)))
					)) * 100, 0)
				ELSE 0 END,0))
				ELSE
				IFNULL(ROUND(((CASE WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.owner_id = u.id   THEN ifnull(sh.quantitybought, 0) ELSE 0 END))/(select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.quantity, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id))
				WHEN (select sum(CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id) > 0 
					THEN ((sum(CASE WHEN sh.owner_id = u.id   THEN ifnull(sh.netpricetotal, 0) ELSE 0 END))/(select sum( CASE WHEN pps.salesman_id = u.id THEN ifnull(pps.price, 0) ELSE 0 END) from izmo_promotionsalesman pps where p.id = pps.promotion_id)) 
				ELSE 0 END))*100,0),0)
				END
				as projection_perc
                FROM
				izmo_promotion p
				inner join izmo_promotionsalesman pps on pps.promotion_id = p.id
				inner join izmo_promotion_to_partfamily c on c.promotion_id = p.id
				inner join oro_user u on u.id = pps.salesman_id
				left join izmo_sales_history sh on c.partfamily_id = sh.partfamily and sh.invoicedate between p.izmopromotionstartdate and p.izmopromotionenddate and sh.montantcv42 != 0
				and sh.owner_id = pps.salesman_id
				left join orocrm_account a on a.id = sh.clientnumber
				left join client_category_mapping ccm on ccm.category_code = a.clientcategory
			WHERE
				('",promo_date,"' between p.izmopromotionstartdate and p.izmopromotionenddate) 
				and p.is_challenge = 0
                and u.id in (",usr_ids,") ");
     
		IF promo_name != 'none' THEN
			SET @sql_query = CONCAT(@sql_query," and p.izmopromotionname LIKE '%",promo_name,"%' ");
		END IF;
		IF client_name != 'none' THEN
			SET @sql_query = CONCAT(@sql_query," and a.name LIKE '%",client_name,"%' ");
		END IF;
		IF client_code != 'none' THEN
			SET @sql_query = CONCAT(@sql_query," and a.clientnumber LIKE '%",client_code,"%' ");
		END IF;
		IF platform != 'none' THEN
			SET @sql_query = CONCAT(@sql_query," and obu.name LIKE '%",platform,"%' ");
		END IF;
		IF chanel_code_name != 'none' THEN		
			SET @sql_query = CONCAT(@sql_query," AND CONCAT_WS('-', ccm.category_code, ccm.channel_name) LIKE '%",chanel_code_name,"%' ");
		END IF;
		IF(show_client_with_turnover = 'on') THEN
			SET @sql_query = concat(@sql_query, " AND a.clientnumber IS NOT NULL and a.clientnumber <> '' "); 
		ELSE
			SET @sql_query = concat(@sql_query, " AND (a.clientnumber IS NULL OR a.clientnumber = '') "); 
		END IF;
		
		
		SET @sql_query = concat(@sql_query," GROUP BY obu.id,p.id,u.id,ccm.category_code,a.id )");
     
  	PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
	DEALLOCATE PREPARE stmt;
END