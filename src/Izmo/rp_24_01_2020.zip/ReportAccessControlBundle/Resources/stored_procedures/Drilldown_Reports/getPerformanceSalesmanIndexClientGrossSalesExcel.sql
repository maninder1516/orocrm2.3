CREATE PROCEDURE `getPerformanceSalesmanIndexClientGrossSalesExcel`(IN usr_ids VARCHAR(500),IN index_code VARCHAR(100),IN sel_year INT,IN index_label VARCHAR(500),IN salesman VARCHAR(200),IN client_name VARCHAR(200),IN category_type INT)
BEGIN

    DECLARE cmp_date1 int;
	DECLARE cmp_date2 int;
	DECLARE cur_start_date DATE;
    DECLARE curr_month_first_day DATE;
    DECLARE cur_end_date DATE;
	DECLARE todays_date DATE;
    DECLARE presentYear INT;
    DECLARE startyear DATE;
    DECLARE endyear DATE;
	DECLARE currentlastdate DATE;
	DECLARE previousdate DATE;
    DECLARE historical_start_date DATE; 
	DECLARE historical_end_date DATE;
    DECLARE grnd_sales_tot INT;
    
	SET todays_date = current_date();
	SET presentYear = YEAR(todays_date);
     SET previousdate = subdate(todays_date, 1);
     SET curr_month_first_day = concat_ws('-', year(todays_date), month(todays_date), '01');
    
    SET currentlastdate = (CONCAT(presentYear,'-',MONTH(todays_date),'-',DAY(LAST_DAY(now()))));	
    SET historical_start_date = (concat_ws('-', sel_year - 1,01, 01));
	SET historical_end_date = (concat_ws('-', sel_year - 1,12, 31));
    SET startyear = (CONCAT(presentYear,'-',01,'-',01));
    SET endyear = (CONCAT(presentYear,'-',12,'-',31));
    
    SET cur_start_date = (concat_ws('-', sel_year,01, 01));
    SET cur_end_date = (concat_ws('-', sel_year,12, 31));
	
    set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
   
   	SELECT (TOTAL_WEEKDAYS(curr_month_first_day, previousdate) - (select count(id) from izmo_businessclosure where bcdate between curr_month_first_day and todays_date)) into cmp_date1;
    SELECT (TOTAL_WEEKDAYS(curr_month_first_day	, currentlastdate) - (select count(id) from izmo_businessclosure where bcdate between curr_month_first_day and currentlastdate)) into cmp_date2;
	 
   SELECT (SELECT ROUND((SUM(CASE WHEN sh.invoicedate between DATE(cur_start_date) and DATE(cur_end_date) THEN sh.tariffpricetotal ELSE 0 END)),0)
    FROM 
				 orocrm_account a
					INNER JOIN
				  oro_user u ON u.id = a.user_owner_id
					INNER JOIN
				  oro_business_unit bu ON bu.id = u.business_unit_owner_id
					INNER JOIN
				  izmo_sales_history sh ON a.id = sh.clientnumber
					INNER JOIN
				  izmo_partfamily pf ON pf.id = sh.partfamily
					INNER JOIN
				  izmo_partindex pi ON pi.id = pf.partindex_id
					INNER JOIN
				  izmo_partsegment ps ON ps.id = pf.partsegment_id
			WHERE
				sh.invoicedate between DATE(cur_start_date) and DATE(cur_end_date)
        AND FIND_IN_SET(u.id,usr_ids) 
        AND CASE WHEN index_code <> 'none' THEN pi.partindexcode LIKE CONCAT('%', index_code,'%')  ELSE 1=1 END  AND CASE WHEN index_label <> 'none' THEN pi.partindexlabel LIKE CONCAT('%', index_label,'%')  ELSE 1=1 END AND CASE WHEN salesman <> 'none' THEN concat_ws("", u.first_name,u.last_name) like CONCAT('%', salesman,'%')  ELSE 1=1  END AND CASE WHEN client_name <> 'none' THEN  a.name LIKE concat('%',client_name,'%') ELSE 1=1 END
        )INTO grnd_sales_tot;
    
         
  		SET @sql_query = CONCAT(" SELECT STRAIGHT_JOIN
   CONCAT_WS(' ', u.first_name, u.last_name) AS salesman,
				concat_ws('-',pi.partindexcode,pi.partindexlabel) as partindexcode,
				a.name as client,
				MONTHNAME(sh.invoicedate) AS mon, 
				'' as subtotal,
				ROUND(SUM(CASE WHEN sh.invoicedate between '",cur_start_date,"' and '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) AS salestotal,
				ROUND((select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = u.id and istcd.month = MONTH(sh.invoicedate) and istcd.usr_sales_category_id = ",category_type,"),0) as target,
                ROUND((CASE WHEN MONTH(sh.invoicedate) = MONTH('",todays_date,"') and MAX(YEAR(sh.invoicedate)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) END)/((select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and istcd.month = MONTH(sh.invoicedate) and iut.salesman_id = u.id  and istcd.usr_sales_category_id = ",category_type,")),0) * 100
                  as proj_vs_target,
                  ROUND((SUM(CASE WHEN sh.invoicedate between '",historical_start_date,"' and '",historical_end_date,"' THEN sh.tariffpricetotal ELSE 0 END))/(CASE WHEN MONTH(sh.invoicedate) = MONTH('",todays_date,"') and MAX(YEAR(sh.invoicedate)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) END),0
                ) * 100 as hist_vs_projection_perf,
                ROUND((SUM(CASE WHEN sh.invoicedate between '",cur_start_date,"' and '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END))/",grnd_sales_tot," * 100,5) as weight_of_line_for_total     
FROM 
				 orocrm_account a
					INNER JOIN
				  oro_user u ON u.id = a.user_owner_id
					INNER JOIN
				  oro_business_unit bu ON bu.id = u.business_unit_owner_id
					INNER JOIN
				  izmo_sales_history sh ON a.id = sh.clientnumber
					INNER JOIN
				  izmo_partfamily pf ON pf.id = sh.partfamily
					INNER JOIN
				  izmo_partindex pi ON pi.id = pf.partindex_id
					INNER JOIN
				  izmo_partsegment ps ON ps.id = pf.partsegment_id
			WHERE
				(sh.invoicedate between '",cur_start_date,"' and '",cur_end_date,"')
        AND u.id IN (",usr_ids,")");
       
    	IF index_code != "none" THEN
			SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexcode LIKE "%',index_code,'%" ');
		END IF;
		IF index_label != "none" THEN
		  
			SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexlabel LIKE "%',index_label,'%" ');
		END IF;
		IF salesman !="none" THEN
			SET @sql_query = CONCAT(@sql_query, ' AND concat_ws("", u.first_name,u.last_name) like "%',salesman,'%"');
        END IF;
		IF client_name !="none" THEN
			SET @sql_query = CONCAT(@sql_query, ' AND a.name LIKE "%',client_name,'%"');
        END IF;
   
	SET @sql_query = CONCAT(@sql_query, ' GROUP BY u.id,pi.id,a.id,MONTH(sh.invoicedate)  ');
	
    PREPARE stmt FROM @sql_query;  
    EXECUTE stmt; 
	DEALLOCATE PREPARE stmt;
    
END