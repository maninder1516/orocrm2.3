CREATE PROCEDURE `getPerformanceSalesmanIndexClientGrossSales`(IN report_type INT, IN usr_ids VARCHAR(500),IN usr_id_sel INT,IN partindex_id INT,IN account_id INT,IN sel_year INT,IN srch_filter VARCHAR(200),IN index_code VARCHAR(200),IN index_label VARCHAR(200),IN category_type INT,IN client_name VARCHAR(200),IN where_cond VARCHAR(500),IN order_cond VARCHAR(500),IN page_limit VARCHAR(30), IN pk_col_for_cnt VARCHAR(20), IN cnt_flg INT, IN is_start INT)
BEGIN
    DECLARE cmp_date1 int;
    DECLARE cmp_date2 int;
    DECLARE cur_start_date DATE;
    DECLARE curr_month_first_day DATE;
    DECLARE cur_end_date DATE;
    DECLARE todays_date DATE;
    DECLARE presentYear INT;
    DECLARE startyear DATE;
    DECLARE endyear DATE;
    DECLARE currentlastdate DATE;
    DECLARE previousdate DATE;
    DECLARE historical_start_date DATE; 
    DECLARE historical_end_date DATE;
    
    SET todays_date = current_date();
    SET presentYear = YEAR(todays_date);
    SET previousdate = subdate(todays_date, 1);
    SET curr_month_first_day = concat_ws('-', year(todays_date), month(todays_date), '01');
    
    SET currentlastdate = (CONCAT(presentYear,'-',MONTH(todays_date),'-',DAY(LAST_DAY(now()))));	
    SET historical_start_date = (concat_ws('-', sel_year - 1,01, 01));
    SET historical_end_date = (concat_ws('-', sel_year - 1,12, 31));
    SET startyear = (CONCAT(presentYear,'-',01,'-',01));
    SET endyear = (CONCAT(presentYear,'-',12,'-',31));
    
    SET cur_start_date = (concat_ws('-', sel_year,01, 01));
    SET cur_end_date = (concat_ws('-', sel_year,12, 31));
	
    set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
   
    IF  report_type = 0  THEN
		SELECT (TOTAL_WEEKDAYS(startyear, previousdate) - (select count(id) from izmo_businessclosure where bcdate between startyear and previousdate)) into cmp_date1;
		SELECT (TOTAL_WEEKDAYS(startyear, endyear) - (select count(id) from izmo_businessclosure where bcdate between startyear and endyear)) into cmp_date2;
	ELSE 
		SELECT (TOTAL_WEEKDAYS(curr_month_first_day, previousdate) - (select count(id) from izmo_businessclosure where bcdate between curr_month_first_day and todays_date)) into cmp_date1;
		SELECT (TOTAL_WEEKDAYS(curr_month_first_day	, currentlastdate) - (select count(id) from izmo_businessclosure where bcdate between curr_month_first_day and currentlastdate)) into cmp_date2;
	END IF;
    
    #qry 1 start
	IF report_type = 0 and is_start = 0 THEN
		SET @sql_query = CONCAT("
			SELECT  STRAIGHT_JOIN SQL_CALC_FOUND_ROWS
				CONCAT_WS(' ', u.first_name, u.last_name) AS salesman,
				concat_ws('-',pi.partindexcode,pi.partindexlabel) as partindexcode,
				a.name as client,
				MONTHNAME(sh.invoicedate) AS mon, 
                '' as subtotal,
				ROUND(SUM(CASE WHEN sh.invoicedate between '",cur_start_date,"' and '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END),0) as salestotal,");
				IF srch_filter !='none' THEN
				SET @sql_query = CONCAT(@sql_query," ROUND((select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",srch_filter,"' , '%') and istcd.usr_sales_category_id = ",category_type,"),0) as target,
                IFNULL(ROUND((CASE WHEN MONTH(sh.invoicedate) = MONTH('",todays_date,"') and MAX(YEAR(sh.invoicedate)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) END)/(select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",srch_filter,"' , '%') and istcd.usr_sales_category_id = ",category_type,"),0),0) * 100 as proj_vs_target,
                ");
				ELSE
				SET @sql_query = CONCAT(@sql_query," ROUND((select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.usr_sales_category_id = ",category_type,"),0) as target,
                 IFNULL(ROUND((CASE WHEN MONTH(sh.invoicedate) = MONTH('",todays_date,"') and MAX(YEAR(sh.invoicedate)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) END)/(select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.usr_sales_category_id = ",category_type,"),0),0) * 100 as proj_vs_target,
                ");
				END IF;
				
				SET @sql_query = CONCAT(@sql_query," ROUND((SUM(CASE WHEN sh.invoicedate between '",historical_start_date,"' and '",historical_end_date,"' THEN sh.tariffpricetotal ELSE 0 END))/(CASE WHEN MONTH(sh.invoicedate) = MONTH('",todays_date,"') and MAX(YEAR(sh.invoicedate)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) END),0
                ) * 100 as hist_vs_projection_perf,
                '' as histInd,
                 ''  as weight_of_line_for_total,
                '' as salesman_id,'' as partindex_id , '' as client_id,",report_type," as report_lvl,",is_start," as is_start ");
           SET @sql_query = CONCAT(@sql_query,"      
			FROM
				orocrm_account a
					INNER JOIN
				  oro_user u ON u.id = a.user_owner_id
					INNER JOIN
				  oro_business_unit bu ON bu.id = u.business_unit_owner_id
					INNER JOIN
				  izmo_sales_history sh ON a.id = sh.clientnumber
					INNER JOIN
				  izmo_partfamily pf ON pf.id = sh.partfamily
					INNER JOIN
				  izmo_partindex pi ON pi.id = pf.partindex_id					
			WHERE
				(sh.invoicedate between '",cur_start_date,"' and '",cur_end_date,"') and u.id in (",usr_ids,")
                AND CASE WHEN '",srch_filter,"' <> 'none' THEN concat_ws(' ', u.first_name,u.last_name) like CONCAT('%', '",srch_filter,"' , '%') ELSE 1=1 END");
IF index_code != 'none'
	THEN
    SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexcode LIKE "%',index_code,'%" ');
END IF;
IF index_label != 'none'
	THEN
    SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexlabel LIKE "%',index_label,'%" ');
END IF;
IF client_name != 'none'
	THEN
    SET @sql_query = CONCAT(@sql_query, ' AND a.name LIKE "%',client_name,'%" ');
    END IF;

        #qry 1 end
        SET @sql_query = CONCAT(@sql_query, ' UNION ALL ');
    #qry 2 start
    END IF;
	
    #cond 2
    IF report_type = 0 and is_start = 0 THEN
		SET @sql_query = CONCAT(@sql_query,'
			( SELECT  STRAIGHT_JOIN ');
    ELSE 
		SET @sql_query = CONCAT('
			SELECT  STRAIGHT_JOIN SQL_CALC_FOUND_ROWS');
    END IF;
     
    IF report_type < 3 THEN
    SET @sql_query = concat(@sql_query,"
				CONCAT_WS(' ', u.first_name, u.last_name) AS salesman,
				concat_ws('-',pi.partindexcode,pi.partindexlabel) as partindexcode,
				a.name as client,
				MONTHNAME(sh.invoicedate) AS mon, 
				'' as subtotal,
				ROUND(SUM(CASE WHEN sh.invoicedate between '",cur_start_date,"' and '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) AS salestotal,");
			IF srch_filter !='none' THEN
				SET @sql_query = CONCAT(@sql_query,"ROUND((select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where  iut.year = ",sel_year," and (case when ",report_type," > 0 then iut.salesman_id = ",usr_id_sel," else iut.salesman_id IN (",usr_ids,") end) and istcd.month = MONTH(sh.invoicedate) and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",srch_filter,"' , '%') and istcd.usr_sales_category_id = ",category_type,"),0) as target,
                IFNULL(ROUND((CASE WHEN MONTH(sh.invoicedate) = MONTH('",todays_date,"') and MAX(YEAR(sh.invoicedate)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) END)/(select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where  iut.year = ",sel_year," and (case when ",report_type," > 0 then iut.salesman_id = ",usr_id_sel," else iut.salesman_id IN (",usr_ids,") end) and istcd.month = MONTH(sh.invoicedate) and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",srch_filter,"' , '%') and istcd.usr_sales_category_id = ",category_type,"),0),0) * 100 as proj_vs_target,
                ");
				ELSE
				SET @sql_query = CONCAT(@sql_query,"ROUND((select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and (case when ",report_type," > 0 then iut.salesman_id = ",usr_id_sel," else iut.salesman_id IN (",usr_ids,") end) and istcd.month = MONTH(sh.invoicedate) and  istcd.usr_sales_category_id = ",category_type,"),0) as target,
                 IFNULL(ROUND((CASE WHEN MONTH(sh.invoicedate) = MONTH('",todays_date,"') and MAX(YEAR(sh.invoicedate)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) END)/(select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and (case when ",report_type," > 0 then iut.salesman_id = ",usr_id_sel," else iut.salesman_id IN (",usr_ids,") end) and istcd.month = MONTH(sh.invoicedate) and  istcd.usr_sales_category_id = ",category_type,"),0),0) * 100 as proj_vs_target,
                ");
				END IF;
            
           	SET @sql_query = CONCAT(@sql_query,"  IFNULL(ROUND((SUM(CASE WHEN sh.invoicedate between '",historical_start_date,"' and '",historical_end_date,"' THEN sh.tariffpricetotal ELSE 0 END))/(CASE WHEN MONTH(sh.invoicedate) = MONTH('",todays_date,"') and MAX(YEAR(sh.invoicedate)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) END),0
                ),0) * 100 as hist_vs_projection_perf,
                '' as histInd,
                '' as weight_of_line_for_total,'' as salesman_id,'' as partindex_id , '' as client_id , ",report_type," as report_lvl,",is_start," as is_start 
				FROM 
				 orocrm_account a
					INNER JOIN
				  oro_user u ON u.id = a.user_owner_id
					INNER JOIN
				  oro_business_unit bu ON bu.id = u.business_unit_owner_id
					INNER JOIN
				  izmo_sales_history sh ON a.id = sh.clientnumber
					INNER JOIN
				  izmo_partfamily pf ON pf.id = sh.partfamily
					INNER JOIN
				  izmo_partindex pi ON pi.id = pf.partindex_id
			WHERE
				(sh.invoicedate between '",cur_start_date,"' and '",cur_end_date,"' and u.id in (",usr_ids,")) 
                AND CASE WHEN '",srch_filter,"' <> 'none' THEN concat_ws(' ', u.first_name,u.last_name) like CONCAT('%', '",srch_filter,"' , '%') ELSE 1=1 END  ");
IF index_code != 'none'
	THEN
    SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexcode LIKE "%',index_code,'%" ');
END IF;
IF index_label != 'none'
	THEN
    SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexlabel LIKE "%',index_label,'%" ');
END IF;
IF client_name != 'none'
	THEN
    SET @sql_query = CONCAT(@sql_query, ' AND a.name LIKE "%',client_name,'%" ');
    END IF;
IF report_type > 0 THEN
  SET @sql_query = CONCAT(@sql_query, ' AND u.id = ',usr_id_sel,'');
END IF ;
 IF report_type > 1 THEN
  SET @sql_query = CONCAT(@sql_query, ' AND pi.id = ',partindex_id,'');
END IF ;
 IF report_type > 2 THEN
  SET @sql_query = CONCAT(@sql_query, ' AND a.id = ',account_id,'');
END IF ;
   
SET @sql_query = CONCAT(@sql_query, ' GROUP BY MONTH(sh.invoicedate) ');
    IF report_type = 0 and is_start = 0 THEN
                  SET @sql_query = CONCAT(@sql_query, " ) ");
                END IF;
   SET @sql_query = CONCAT(@sql_query, " UNION ALL ( SELECT  STRAIGHT_JOIN ");
    
    END IF;
	SET @sql_query = concat(@sql_query,"
				CONCAT_WS(' ', u.first_name, u.last_name) AS salesman,
				concat_ws('-',pi.partindexcode,pi.partindexlabel) as partindexcode,
				a.name as client,");
                IF report_type < 3 THEN
                  SET @sql_query = concat(@sql_query," '' as mon , ");
                  ELSE
                  SET @sql_query = concat(@sql_query," MONTHNAME(sh.invoicedate) as mon ,");
                END IF;
				SET @sql_query = concat(@sql_query,"
				'' as subtotal,
				ROUND(SUM(CASE WHEN sh.invoicedate between '",cur_start_date,"' and '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) AS salestotal,
				ROUND((select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = u.id ");
          
               IF report_type > 2 THEN
               SET @sql_query = concat(@sql_query," and istcd.month = MONTH(sh.invoicedate) ");
                END IF;
                 SET @sql_query = CONCAT(@sql_query," and istcd.usr_sales_category_id = ",category_type,"),0) as target,
                IFNULL(ROUND((CASE WHEN MONTH(sh.invoicedate) = MONTH('",todays_date,"') and MAX(YEAR(sh.invoicedate)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) END)/((select SUM(istcd.gross) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = u.id ");
                 IF report_type > 2 THEN
               SET @sql_query = concat(@sql_query," and istcd.month = MONTH(sh.invoicedate) ");
                END IF;
                 SET @sql_query = CONCAT(@sql_query," and istcd.usr_sales_category_id = ",category_type,")),0),0) * 100
                  as proj_vs_target,
                  IFNULL(ROUND((SUM(CASE WHEN sh.invoicedate between '",historical_start_date,"' and '",historical_end_date,"' THEN sh.tariffpricetotal ELSE 0 END))/(CASE WHEN MONTH(sh.invoicedate) = MONTH('",todays_date,"') and MAX(YEAR(sh.invoicedate)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN sh.invoicedate between  '",cur_start_date,"' AND '",cur_end_date,"' THEN sh.tariffpricetotal ELSE 0 END)) END),0
                ),0) * 100 as hist_vs_projection_perf,
                '' as histInd,
                ''  as weight_of_line_for_total,
				u.id as salesman_id,
                pi.id as partindex_id ,
                a.id as client_id ,
                ",report_type," as report_lvl,
                ",is_start," as is_start 
				FROM 
				 orocrm_account a
					INNER JOIN
				  oro_user u ON u.id = a.user_owner_id
					INNER JOIN
				  oro_business_unit bu ON bu.id = u.business_unit_owner_id
					INNER JOIN
				  izmo_sales_history sh ON a.id = sh.clientnumber
					INNER JOIN
				  izmo_partfamily pf ON pf.id = sh.partfamily
					INNER JOIN
				  izmo_partindex pi ON pi.id = pf.partindex_id
			WHERE
				(sh.invoicedate between '",cur_start_date,"' and '",cur_end_date,"') 
                ");
     IF report_type = 0 THEN
		SET @sql_query = CONCAT(@sql_query,"and u.id in (",usr_ids,")");
     ELSE
		SET @sql_query = CONCAT(@sql_query,"and u.id = (",usr_id_sel,")");
     END IF;
     
                
    SET @sql_query = CONCAT(@sql_query," AND CASE WHEN '",srch_filter,"' <> 'none' THEN concat_ws(' ', u.first_name,u.last_name) like CONCAT('%', '",srch_filter,"' , '%') ELSE 1=1 END ");
	IF index_code != 'none'
	THEN
    SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexcode LIKE "%',index_code,'%" ');
END IF;
IF index_label != 'none'
	THEN
    SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexlabel LIKE "%',index_label,'%" ');
END IF;
    IF client_name != 'none'
	THEN
    SET @sql_query = CONCAT(@sql_query, ' AND a.name LIKE "%',client_name,'%" ');
    END IF;
    IF report_type = 0 THEN
    SET @sql_query = concat(@sql_query," GROUP BY u.id )");
   
	ELSEIF report_type = 1 THEN
     SET @sql_query = concat(@sql_query," GROUP BY u.id,pi.id ");
   
   	ELSEIF report_type = 2 THEN
     SET @sql_query = concat(@sql_query," AND pi.id = ",partindex_id,"
   GROUP BY u.id,pi.id,a.id");
	
    ELSEIF report_type = 3 THEN
     SET @sql_query = concat(@sql_query," AND pi.id = ",partindex_id," AND a.id = ",account_id,"
   GROUP BY u.id,pi.id,a.id,MONTH(sh.invoicedate)");
	END IF;
   IF page_limit != '' THEN
	  SET @sql_query = CONCAT(@sql_query, ' ', page_limit);
    END IF;
   IF report_type > 0 and report_type < 3 THEN
     SET @sql_query = CONCAT(@sql_query, ' )');
   END IF;
  
    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
END