CREATE PROCEDURE `getPerformancePartsSalesByChannelGrossTurnoverExcel`(IN usr_ids VARCHAR(255),IN sel_year INT,IN ref_code VARCHAR(100),IN channel_name VARCHAR(255))
BEGIN

    DECLARE historical_end_date DATE;
    DECLARE historical_start_date DATE;
    DECLARE cur_start_date DATE;
    DECLARE cur_end_date DATE;

    SET historical_end_date = (concat_ws("-", sel_year - 1,12, 31));
    SET historical_start_date = (concat_ws("-", sel_year - 1,01, 01));
    SET cur_start_date = (concat_ws("-", sel_year,01, 01));
    SET cur_end_date = (concat_ws("-", sel_year,12, 31));
    
    SET @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';

    #qry 1 start
    IF ref_code != 'none' THEN
	
SET @sql_query = CONCAT('
SELECT STRAIGHT_JOIN
	ccm.channel_name as channel_name,
	concat_ws("-",pm.partmastercode,pm.partmasterlabel) as partmastercode,
   concat_ws("-",pi.partindexcode,pi.partindexlabel) as partindexcode,
   concat_ws("-",ps.partsegmentcode,ps.partsegmentlabel) as partsegmentcode,
   concat_ws("-",pn.partnichecode,pn.partnichelabel)  as partnichecode,
   concat_ws("-",pf.partfamilycode,pf.partfamilylabel) as partfamilycode,
    MONTHNAME(sh.invoicedate) AS mon,
	ROUND(SUM(CASE WHEN sh.invoicedate BETWEEN "',cur_start_date,'" AND "',cur_end_date,'" THEN sh.tariffpricetotal ELSE 0 END) ,0) AS salestotal,
	IFNULL(ROUND((SUM(CASE WHEN sh.invoicedate BETWEEN "',cur_start_date,'" AND "',cur_end_date,'" THEN sh.tariffpricetotal ELSE 0 END))/(SUM(CASE WHEN sh.invoicedate BETWEEN "',historical_start_date,'" AND "',historical_end_date,'" THEN sh.tariffpricetotal ELSE 0 END)) * 100,0),0) AS histInd   
FROM
	orocrm_account a 
		INNER JOIN 
	oro_user u on u.id = a.user_owner_id
		INNER JOIN 
	oro_business_unit bu ON bu.id = u.business_unit_owner_id
	INNER JOIN
			client_category_mapping ccm on ccm.category_code = a.clientcategory and ccm.business_unit = bu.id
				INNER JOIN
			izmo_channel_master icm on icm.channel_name = ccm.channel_name
		INNER JOIN
	izmo_sales_history sh ON a.id = sh.clientnumber
		INNER JOIN 
	izmo_partmaster pm on pm.id = sh.partmaster
		INNER JOIN
	izmo_partfamily pf ON pf.id = pm.partfamily_id
		INNER JOIN
	izmo_partniche pn ON pn.id = pf.partniche_id
		INNER JOIN
	izmo_partsegment ps ON ps.id = pn.partsegment_id
		INNER JOIN
	izmo_partindex pi ON pi.id = ps.partindex_id 
    WHERE
    sh.invoicedate >= "',historical_start_date,'"
        AND sh.invoicedate <= "',cur_end_date,'"
        and pm.partmastercode like "%',ref_code,'%" AND u.id IN (',usr_ids,')');
       
    
		IF channel_name != "none" THEN
			SET @sql_query = CONCAT(@sql_query, ' AND ccm.channel_name LIKE "%',channel_name,'%" ');
		END IF;
    
		SET @sql_query = CONCAT(@sql_query, ' GROUP By icm.id,pm.partmastercode,MONTH(sh.invoicedate)');
	 
    PREPARE stmt FROM @sql_query;  
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    END IF;
END