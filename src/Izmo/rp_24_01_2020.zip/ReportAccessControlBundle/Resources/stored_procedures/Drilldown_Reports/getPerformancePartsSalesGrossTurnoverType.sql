CREATE PROCEDURE `getPerformancePartsSalesGrossTurnoverType`(IN report_type INT,IN usr_ids VARCHAR(500),IN partindex_id INT,IN partsegment_id INT,IN partniche_id INT,IN partfamily_id INT,IN index_code VARCHAR(100),IN segment_code VARCHAR(100),IN niche_code VARCHAR(100),IN family_code VARCHAR(100),IN sel_year INT,IN index_label VARCHAR(500),IN segment_label varchar(500),IN niche_label varchar(500),IN family_label VARCHAR(500),IN where_cond VARCHAR(500),IN order_cond VARCHAR(500),IN page_limit VARCHAR(30), IN pk_col_for_cnt VARCHAR(20), IN cnt_flg INT, IN is_start INT)
BEGIN

    DECLARE historical_end_date DATE;
    DECLARE historical_start_date DATE;
    DECLARE cur_start_date DATE;
    DECLARE cur_end_date DATE;

    SET historical_end_date = (concat_ws("-", sel_year - 1,12, 31));
    SET historical_start_date = (concat_ws("-", sel_year - 1,01, 01));
    SET cur_start_date = (concat_ws("-", sel_year,01, 01));
    SET cur_end_date = (concat_ws("-", sel_year,12, 31));
    
    SET @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';

    SET @sql_query = '';
    #qry 1 start
	IF report_type = 0 and is_start = 0 THEN
		SET @sql_query = CONCAT('
			SELECT  STRAIGHT_JOIN SQL_CALC_FOUND_ROWS
				concat_ws("-",pi.partindexcode,pi.partindexlabel) as partindexcode,
				concat_ws("-",ps.partsegmentcode,ps.partsegmentlabel) as partsegmentcode,
				concat_ws("-",pn.partnichecode,pn.partnichelabel)  as partnichecode,
				concat_ws("-",pf.partfamilycode,pf.partfamilylabel) as partfamilycode,
				MONTHNAME(sh.invoicedate) AS mon, 
				ROUND(SUM(CASE WHEN sh.invoicedate BETWEEN "',cur_start_date,'" AND "',cur_end_date,'" THEN sh.tariffpricetotal ELSE 0 END) ,0) AS salestotal,
				IFNULL(ROUND((SUM(CASE WHEN sh.invoicedate BETWEEN "',cur_start_date,'" AND "',cur_end_date,'" THEN sh.tariffpricetotal ELSE 0 END))/(SUM(CASE WHEN sh.invoicedate BETWEEN "',historical_start_date,'" AND "',historical_end_date,'" THEN sh.tariffpricetotal ELSE 0 END)) * 100,0),0) AS histInd,
				"" as pindx_id,
				"" as pseg_id,
				"" as pniche_id,
				"" as pfamily_id');
           SET @sql_query = CONCAT(@sql_query,'      
			FROM
				orocrm_account a 
					INNER JOIN 
				oro_user u on u.id = a.user_owner_id
					INNER JOIN 
				oro_business_unit bu ON bu.id = u.business_unit_owner_id
					INNER JOIN
				izmo_sales_history sh ON a.id = sh.clientnumber
					INNER JOIN
				izmo_partfamily pf ON pf.id = sh.partfamily
					INNER JOIN
				izmo_partindex pi ON pi.id = pf.partindex_id
					INNER JOIN
				izmo_partsegment ps ON ps.id = pf.partsegment_id
					INNER JOIN
				izmo_partniche pn ON pn.id = pf.partniche_id
			WHERE
				sh.invoicedate >= "',historical_start_date,'" AND sh.invoicedate <= "',cur_end_date,'" AND u.id IN (',usr_ids,')');

		IF report_type = 0 THEN
			IF index_code != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexcode LIKE "%',index_code,'%" ');
			END IF;
			IF index_label != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexlabel LIKE "%',index_label,'%" ');
			END IF;
		END IF;
		
		IF report_type < 2 THEN
			IF segment_code != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND ps.partsegmentcode LIKE "%',segment_code,'%" ');
			END IF;
			IF segment_label != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND ps.partsegmentlabel LIKE "%',segment_label,'%" ');
			END IF;
		END IF;
			
		IF report_type < 3 THEN
			IF niche_code != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND pn.partnichecode LIKE "%',niche_code,'%" ');
			END IF;
			IF niche_label != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND pn.partnichelabel LIKE "%',niche_label,'%" ');
			END IF;
		END IF;
			
		IF report_type = 0 THEN
			SET @sql_query = CONCAT(@sql_query, '');
		ELSEIF report_type = 1 THEN	
			SET @sql_query = CONCAT(@sql_query, ' and pi.id =',partindex_id,'');
		ELSEIF report_type = 2 THEN	
			SET @sql_query = CONCAT(@sql_query, ' and pi.id =',partindex_id,' and ps.id =',partsegment_id,'');
		ELSEIF report_type = 3 THEN	
			SET @sql_query = CONCAT(@sql_query, ' and pi.id =',partindex_id,' and ps.id =',partsegment_id,' and pn.id = ',partniche_id,'');
		END IF;
        #qry 1 end
        SET @sql_query = CONCAT(@sql_query, ' UNION ALL ');
    #qry 2 start
    END IF;
	
    #cond 2
    IF report_type = 0 and is_start = 0 THEN
		SET @sql_query = CONCAT(@sql_query,'
			SELECT  STRAIGHT_JOIN ');
	ELSEIF report_type < 4 or ( report_type = 0 and is_start !=0) THEN
			SET @sql_query = CONCAT(@sql_query,'SELECT  STRAIGHT_JOIN SQL_CALC_FOUND_ROWS ');
	END IF;
    #end cond2
    
    #cond 3
    IF report_type < 4 THEN
		SET @sql_query = CONCAT(@sql_query,'
				concat_ws("-",pi.partindexcode,pi.partindexlabel) as partindexcode,
				concat_ws("-",ps.partsegmentcode,ps.partsegmentlabel) as partsegmentcode,
				concat_ws("-",pn.partnichecode,pn.partnichelabel)  as partnichecode,
				concat_ws("-",pf.partfamilycode,pf.partfamilylabel) as partfamilycode,
				MONTHNAME(sh.invoicedate) AS mon,
				ROUND(SUM(CASE WHEN sh.invoicedate BETWEEN "',cur_start_date,'" AND "',cur_end_date,'" THEN sh.tariffpricetotal ELSE 0 END) ,0) AS salestotal,
				IFNULL(ROUND((SUM(CASE WHEN sh.invoicedate BETWEEN "',cur_start_date,'" AND "',cur_end_date,'" THEN sh.tariffpricetotal ELSE 0 END))/(SUM(CASE WHEN sh.invoicedate BETWEEN "',historical_start_date,'" AND "',historical_end_date,'" THEN sh.tariffpricetotal ELSE 0 END)) * 100,0),0) AS histInd,
				"" as pindx_id,
				"" as pseg_id,
				"" as pniche_id,
				"" as pfamily_id');
                SET @sql_query = CONCAT(@sql_query,'      
			FROM
				orocrm_account a 
					INNER JOIN 
				oro_user u on u.id = a.user_owner_id
					INNER JOIN 
				oro_business_unit bu ON bu.id = u.business_unit_owner_id
					INNER JOIN
				izmo_sales_history sh ON a.id = sh.clientnumber
					INNER JOIN
				izmo_partfamily pf ON pf.id = sh.partfamily
					INNER JOIN
				izmo_partindex pi ON pi.id = pf.partindex_id
					INNER JOIN
				izmo_partsegment ps ON ps.id = pf.partsegment_id
					INNER JOIN
				izmo_partniche pn ON pn.id = pf.partniche_id
			WHERE
				sh.invoicedate >= "',historical_start_date,'" AND sh.invoicedate <= "',cur_end_date,'" AND u.id IN (',usr_ids,')');
                IF report_type < 1 THEN
			IF index_code != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexcode LIKE "%',index_code,'%" ');
			END IF;
			IF index_label != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexlabel LIKE "%',index_label,'%" ');
			END IF;
		END IF;
		
		IF report_type < 2 THEN
			IF segment_code != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND ps.partsegmentcode LIKE "%',segment_code,'%" ');
			END IF;
			IF segment_label != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND ps.partsegmentlabel LIKE "%',segment_label,'%" ');
			END IF;
		END IF;
			
		IF report_type < 3 THEN
			IF niche_code != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND pn.partnichecode LIKE "%',niche_code,'%" ');
			END IF;
			IF niche_label != "none" THEN
				SET @sql_query = CONCAT(@sql_query, ' AND pn.partnichelabel LIKE "%',niche_label,'%" ');
			END IF;
		END IF;
			
		IF report_type = 0 THEN
			SET @sql_query = CONCAT(@sql_query, ' GROUP By MONTH(sh.invoicedate)');
		ELSEIF report_type = 1 THEN	
			SET @sql_query = CONCAT(@sql_query, ' and pi.id =',partindex_id,' GROUP By MONTH(sh.invoicedate) ');
		ELSEIF report_type = 2 THEN	
			SET @sql_query = CONCAT(@sql_query, ' and pi.id =',partindex_id,' and ps.id =',partsegment_id,' GROUP By MONTH(sh.invoicedate) ');
		ELSEIF report_type = 3 THEN	
			SET @sql_query = CONCAT(@sql_query, ' and pi.id =',partindex_id,' and ps.id =',partsegment_id,' and pn.id = ',partniche_id,' GROUP By MONTH(sh.invoicedate) ');
		END IF;
        #qry 2 end
        SET @sql_query = CONCAT(@sql_query, ' UNION ALL ');
     END IF;          
    #end of cond 3
   #condition 4
   #qry 3 start
   IF report_type < 4 THEN
   SET @sql_query = CONCAT(@sql_query, '
SELECT STRAIGHT_JOIN ');
   ELSEIF report_type = 4 THEN
   SET @sql_query = CONCAT(@sql_query, '
SELECT STRAIGHT_JOIN SQL_CALC_FOUND_ROWS');
   END IF;
SET @sql_query = CONCAT(@sql_query, '
   concat_ws("-",pi.partindexcode,pi.partindexlabel) as partindexcode,
   concat_ws("-",ps.partsegmentcode,ps.partsegmentlabel) as partsegmentcode,
   concat_ws("-",pn.partnichecode,pn.partnichelabel)  as partnichecode,
   concat_ws("-",pf.partfamilycode,pf.partfamilylabel) as partfamilycode,
    MONTHNAME(sh.invoicedate) AS mon,
	ROUND(SUM(CASE WHEN sh.invoicedate BETWEEN "',cur_start_date,'" AND "',cur_end_date,'" THEN sh.tariffpricetotal ELSE 0 END) ,0) AS salestotal,
	IFNULL(ROUND((SUM(CASE WHEN sh.invoicedate BETWEEN "',cur_start_date,'" AND "',cur_end_date,'" THEN sh.tariffpricetotal ELSE 0 END))/(SUM(CASE WHEN sh.invoicedate BETWEEN "',historical_start_date,'" AND "',historical_end_date,'" THEN sh.tariffpricetotal ELSE 0 END)) * 100,0),0) AS histInd,
    pi.id as pindx_id,
    ps.id as pseg_id,
    pn.id as pniche_id,
    pf.id as pfamily_id');

SET @sql_query = CONCAT(@sql_query, '    
FROM
	orocrm_account a 
					INNER JOIN 
				oro_user u on u.id = a.user_owner_id
					INNER JOIN 
				oro_business_unit bu ON bu.id = u.business_unit_owner_id
					INNER JOIN
				izmo_sales_history sh ON a.id = sh.clientnumber
					INNER JOIN
				izmo_partfamily pf ON pf.id = sh.partfamily
					INNER JOIN
				izmo_partindex pi ON pi.id = pf.partindex_id
					INNER JOIN
				izmo_partsegment ps ON ps.id = pf.partsegment_id
					INNER JOIN
				izmo_partniche pn ON pn.id = pf.partniche_id
    WHERE
    sh.invoicedate >= "',historical_start_date,'"
        AND sh.invoicedate <= "',cur_end_date,'"
        AND u.id IN (',usr_ids,')');
       
    IF report_type < 1
       THEN
		IF index_code != "none" THEN
			SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexcode LIKE "%',index_code,'%" ');
		END IF;
		IF index_label != "none" THEN
		  
			SET @sql_query = CONCAT(@sql_query, ' AND pi.partindexlabel LIKE "%',index_label,'%" ');
		END IF;
    END IF;
    
     
    
    IF report_type < 2 THEN
    
    IF segment_code != "none" THEN
        	SET @sql_query = CONCAT(@sql_query, ' AND ps.partsegmentcode LIKE "%',segment_code,'%" ');
	END IF;
     IF segment_label != "none" THEN
		SET @sql_query = CONCAT(@sql_query, ' AND ps.partsegmentlabel LIKE "%',segment_label,'%" ');
    END IF;
    
    END IF;
    
   
    
     IF report_type < 3 THEN
		 IF niche_code != "none" THEN
			SET @sql_query = CONCAT(@sql_query, ' AND pn.partnichecode LIKE "%',niche_code,'%" ');
		 END IF;
		  IF niche_label != "none" THEN
			SET @sql_query = CONCAT(@sql_query, ' AND pn.partnichelabel LIKE "%',niche_label,'%" ');
		END IF;
      END IF;
    
   
    
    
    IF report_type < 4 THEN
    
    IF family_code != "none" THEN
		
        SET @sql_query = CONCAT(@sql_query, ' AND pf.partfamilycode like "%',family_code,'%" ');
	END IF;
    
    IF family_label != "none" THEN
		SET @sql_query = CONCAT(@sql_query, ' AND pf.partfamilylabel like "%', family_label, '%" ');
    END IF;
    
    END IF;

		IF report_type = 0 THEN
			SET @sql_query = CONCAT(@sql_query, ' GROUP By pi.partindexcode ');
		ELSEIF report_type = 1 THEN	
		SET @sql_query = CONCAT(@sql_query, ' and pi.id =',partindex_id,' GROUP By pi.partindexcode,ps.partsegmentcode');
		ELSEIF report_type = 2 THEN	
		SET @sql_query = CONCAT(@sql_query, ' and pi.id =',partindex_id,' and ps.id =',partsegment_id,' GROUP By pi.partindexcode,ps.partsegmentcode, pn.partnichecode ');
		ELSEIF report_type = 3 THEN	
		SET @sql_query = CONCAT(@sql_query, ' and pi.id =',partindex_id,' and ps.id =',partsegment_id,' and pn.id = ',partniche_id,' GROUP By pi.partindexcode,ps.partsegmentcode, pn.partnichecode,pf.partfamilycode');
		ELSEIF report_type = 4 THEN	
		SET @sql_query = CONCAT(@sql_query, ' and pi.id =',partindex_id,' and ps.id =',partsegment_id,' and pn.id = ',partniche_id,' and pf.id = ',partfamily_id,' GROUP By pi.partindexcode,ps.partsegmentcode, pn.partnichecode,pf.partfamilycode,MONTH(sh.invoicedate) ');
		END IF;
    
   IF page_limit != '' THEN
	  SET @sql_query = CONCAT(@sql_query, ' ', page_limit);
    END IF;
   #end of condition 4
   
    PREPARE stmt FROM @sql_query;  
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
END