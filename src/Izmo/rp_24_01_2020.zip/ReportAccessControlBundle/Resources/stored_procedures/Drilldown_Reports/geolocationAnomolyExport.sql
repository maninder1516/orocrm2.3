CREATE PROCEDURE `geolocationAnomolyExport`(IN usr_ids VARCHAR(255),IN salesman_name VARCHAR(255),IN client_name VARCHAR(255),IN appointment_date VARCHAR(100), IN cal_acc_rel_table varchar(150) , IN geoloc_distance_threshold INT)
BEGIN
set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
	
SET @sql_query = CONCAT("
			SELECT  STRAIGHT_JOIN SQL_CALC_FOUND_ROWS
				CONCAT_WS(' ', u.first_name, u.last_name) as salesman_name,
                a.name as client_name,
                oce.title as appointment_title,
                DATE(oce.start_at) as appointment_date,
                concat_ws('',a.address1,a.address2,city,zipcode) as appointment_address,
                ia.address as address_geolocation
			FROM
            oro_calendar_event oce
            INNER JOIN 
            ",cal_acc_rel_table," cal_acc_rel_tab ON oce.id = cal_acc_rel_tab.calendarevent_id
            INNER JOIN 
            orocrm_account a ON a.id = cal_acc_rel_tab.account_id 
            INNER JOIN
            oro_user u on a.user_owner_id = u.id
            INNER JOIN
            oro_business_unit bu on u.business_unit_owner_id = bu.id 
            LEFT JOIN
            izmo_attendance ia on ia.calendarevent_id = oce.id and ia.owner_id IN (",usr_ids,")
            LEFT JOIN
            izmo_visitreport ivr on ivr.calendarevent_id = oce.id AND ivr.owner_id IN (",usr_ids,")
            WHERE u.id IN (",usr_ids,") and (6371 * 2 * ASIN(SQRT(POWER(SIN((a.latitude - abs(SUBSTRING(ia.gps_coordinates,1,LOCATE('|',ia.gps_coordinates)-1))) * pi()/180 / 2), 2) + COS(a.latitude * pi()/180 ) * COS(abs(SUBSTRING(ia.gps_coordinates,1,LOCATE('|',ia.gps_coordinates)-1)) * pi()/180) * POWER(SIN((a.longitude - SUBSTRING(ia.gps_coordinates,LOCATE('|',ia.gps_coordinates)+1,LENGTH(ia.gps_coordinates))) *pi()/180 / 2), 2) ))) > ",geoloc_distance_threshold,"
            ");
     
    IF salesman_name != 'none' THEN
    SET @sql_query = concat(@sql_query," AND CONCAT(u.first_name,'',u.last_name) LIKE '%",salesman_name,"%'  ");
    END IF;
    
    IF client_name != 'none' THEN
    SET @sql_query = concat(@sql_query," AND a.name LIKE '%",client_name,"%'  ");
    END IF;
    
    IF appointment_date !='none' THEN
    SET @sql_query = concat(@sql_query," AND DATE(oce.start_at) = '",appointment_date,"'  ");
    END IF;
    
	
     SET @sql_query = concat(@sql_query,"  GROUP BY u.id,a.id ");
   
   	PREPARE stmt FROM @sql_query; 
        EXECUTE stmt; 
	DEALLOCATE PREPARE stmt;
END