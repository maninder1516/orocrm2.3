CREATE PROCEDURE `getTotalVisitsDoneForSalesman`(IN usr_ids VARCHAR(1500),IN client_name VARCHAR(255),IN client_code VARCHAR(50), IN startDate varchar(255), IN endDate varchar(255), IN cal_acc_rel_table varchar(255), IN interval_config_hrs INT)
BEGIN

DECLARE monthEndDate DATE;
DECLARE futureStartDate DATE;

SET monthEndDate = last_day(current_date());
SET futureStartDate = date_add(current_date(), interval 1 Day);

set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';

	SET @sql_query = CONCAT("
			SELECT  STRAIGHT_JOIN SQL_CALC_FOUND_ROWS
			sum(case when (date(oce.start_at) between '",startDate,"' and '",endDate,"') and (ia.ispresent = 1 and ia.calendarevent_id = oce.id) and (ia.createdat <= DATE_ADD(oce.start_at, INTERVAL ",interval_config_hrs," HOUR)) THEN 1 ELSE 0 END) as no_of_visits_done
		FROM
		orocrm_account a 
		LEFT JOIN 
		",cal_acc_rel_table," cal_acc_rel_tab ON a.id = cal_acc_rel_tab.account_id 
		LEFT JOIN 
		oro_calendar_event oce ON oce.id = cal_acc_rel_tab.calendarevent_id and date(oce.start_at) between '",startDate,"' and '",monthEndDate,"'
		LEFT JOIN
		oro_user u on a.user_owner_id = u.id
		LEFT JOIN
		oro_business_unit bu on u.business_unit_owner_id = bu.id 
		LEFT JOIN
		izmo_attendance ia on ia.calendarevent_id = oce.id 
		LEFT JOIN
		izmo_visitreport ivr on ivr.calendarevent_id = oce.id 
		LEFT JOIN 
		client_category_mapping ccm ON a.clientcategory = ccm.category_code  
        LEFT JOIN 
        izmo_channel_master cm ON cm.channel_name = ccm.channel_name
		WHERE u.id IN (",usr_ids,") 
		");
     
    IF client_name != 'none' THEN
		SET @sql_query = concat(@sql_query," AND a.name LIKE '%",client_name,"%'  ");
    END IF;
    
    IF client_code != 'none' THEN
		SET @sql_query = concat(@sql_query," AND a.clientnumber LIKE '%",client_code,"%'  ");
    END IF;
        
	SET @sql_query = concat(@sql_query," GROUP BY u.id ");
    
	#SELECT @sql_query;
    
  	PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
	DEALLOCATE PREPARE stmt;
END