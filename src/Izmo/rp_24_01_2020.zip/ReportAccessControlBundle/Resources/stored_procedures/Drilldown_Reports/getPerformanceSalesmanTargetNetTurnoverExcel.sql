CREATE PROCEDURE `getPerformanceSalesmanTargetNetTurnoverExcel`(IN usr_ids VARCHAR(1500),IN sel_year INT,IN srch VARCHAR(500),IN category_type INT,IN bu_ids VARCHAR(500),IN owner_bu_id INT,IN turnover_type INT)
BEGIN
    DECLARE cur_start_date DATE;
    DECLARE cur_end_date DATE;
    
    DECLARE cmp_date1 int;
    DECLARE cmp_date2 int;
    DECLARE curr_month_first_day DATE;
    DECLARE todays_date DATE;
    DECLARE presentYear INT;
    DECLARE currentlastdate DATE;
    DECLARE previousdate DATE;
    DECLARE sales_type varchar(100);
    
    IF turnover_type = 1 then
        SET sales_type = 'gross_amount';
    ELSEIF turnover_type = 2 then
        SET sales_type = 'net_amount';
    ELSEIF turnover_type = 3 then
        SET sales_type = 'quantity';
    ELSE
        SET sales_type = 'net_amount';
    END IF;
    
    IF category_type = 6 then
	SET sales_type = 'quantity';
    END IF; 
    
    SET cur_start_date = (concat_ws('-', sel_year,01, 01));
    SET cur_end_date = (concat_ws('-', sel_year,12, 31));
    
    SET todays_date = current_date();
    SET presentYear = YEAR(todays_date);
    SET previousdate = subdate(todays_date, 1);
    SET curr_month_first_day = concat_ws('-', year(todays_date), month(todays_date), '01');
    
    SET currentlastdate = (CONCAT(presentYear,'-',MONTH(todays_date),'-',DAY(LAST_DAY(now()))));	
    
    set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
   SELECT (TOTAL_WEEKDAYS(curr_month_first_day, previousdate) - (select count(id) from izmo_businessclosure where  business_unit_owner_id = owner_bu_id and bcdate between curr_month_first_day and todays_date)) into cmp_date1;
	SELECT (TOTAL_WEEKDAYS(curr_month_first_day	, currentlastdate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curr_month_first_day and currentlastdate)) into cmp_date2;
   
    SET @sql_query = CONCAT("
    
			SELECT  STRAIGHT_JOIN
			    salesman,
				MONTHNAME(report_date) AS mon, 
				IFNULL(ROUND(SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' THEN ",sales_type," ELSE 0 END)),0) AS salestotal,
				IFNULL(ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = user_id  and istcd.month = MONTH(report_date)  and istcd.usr_sales_category_id = ",category_type,"),0),0) as goalTotal,
				IFNULL(ROUND(((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' THEN ",sales_type," ELSE 0 END))/(
				select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = user_id  and istcd.month = MONTH(report_date)  and istcd.usr_sales_category_id = ",category_type,"
				))*100,0),0) as actual_vs_target,
                IFNULL(ROUND(((CASE WHEN MONTH(report_date) = MONTH('",todays_date,"') and MAX(YEAR(report_date)) = YEAR('",todays_date,"') THEN (((SUM(CASE WHEN report_date between  '",cur_start_date,"' AND '",cur_end_date,"' THEN ",sales_type," ELSE 0 END) ) / (",cmp_date1,")) * (",cmp_date2,")) ELSE (SUM(CASE WHEN report_date between  '",cur_start_date,"' AND '",cur_end_date,"' THEN ",sales_type," ELSE 0 END)) END)/((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year,"  and iut.salesman_id = user_id  and istcd.month = MONTH(report_date)  and istcd.usr_sales_category_id = 1)))* 100,0) ,0)
				as proj_vs_target
    FROM
	sales_report_mv     
	WHERE
     business_unit_id IN (",bu_ids,") and
		(report_date between '",cur_start_date,"' and '",cur_end_date,"') 
		and user_id IN (",usr_ids,")");

   
		IF srch != 'none' THEN
			SET @sql_query = CONCAT(@sql_query, " and salesman like CONCAT('%', '",srch,"' , '%') ");
		END IF;
        
			SET @sql_query = CONCAT(@sql_query, " GROUP By user_id,month(report_date);");
   
    
    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
END