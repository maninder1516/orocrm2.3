CREATE PROCEDURE `dashboardComplaints`(IN user_id VARCHAR(500),IN current_month_start_date DATE,IN current_end_date DATE,IN cal_acc_rel_table varchar(250))
BEGIN
  SET @query=CONCAT("(SELECT 
    (visit_report.createdat) AS createdate,
    acc.name AS client_name,
    acc.clientnumber AS clientnumber,
	visit_report.complaint AS complaint,
    visit_report.complaint_comments AS complaint_comments,
    visit_report.comments AS comments,
    visit_report.complaintStatus AS status,
    visit_report.resolutionComments AS resolutionComments,
    visit_report.resolutionDate AS resolutionDate,
    CONCAT(usr.first_name,' ', usr.last_name) AS salesman
FROM
    izmo_visitreport visit_report
        INNER JOIN
    oro_user usr ON visit_report.owner_id = usr.id
        INNER JOIN
    oro_calendar cal ON (cal.user_owner_id = usr.id)
        INNER JOIN
    oro_calendar_event cal_evnt ON (cal_evnt.calendar_id = cal.id
        AND cal_evnt.id = visit_report.calendarevent_id)
        INNER JOIN
    ",cal_acc_rel_table," cal_acc_rel ON cal_evnt.id = cal_acc_rel.calendarevent_id
        INNER JOIN
    orocrm_account acc ON acc.id = cal_acc_rel.account_id
WHERE
    ((visit_report.createdat >= '",current_month_start_date,"'
        AND visit_report.createdat <= '",current_end_date,"' AND visit_report.complaint = 1)
       )
        AND visit_report.owner_id IN (",user_id,")
        ) 
	UNION ALL
    (SELECT 
    (visit_report.createdat) AS createdate,
    acc.name AS client_name,
    acc.clientnumber AS clientnumber,
    visit_report.complaint AS complaint,
    visit_report.complaint_comments AS complaint_comments,
    visit_report.comments AS comments,
    visit_report.complaintStatus AS status,
    visit_report.resolutionComments AS resolutionComments,
    visit_report.resolutionDate AS resolutionDate,
    CONCAT(usr.first_name,' ', usr.last_name) AS salesman
FROM
    izmo_visitreport visit_report
        INNER JOIN
    oro_user usr ON visit_report.owner_id = usr.id
        INNER JOIN
    oro_calendar cal ON (cal.user_owner_id = usr.id
        )
        INNER JOIN
    oro_calendar_event cal_evnt ON (cal_evnt.calendar_id = cal.id
        AND cal_evnt.id = visit_report.calendarevent_id)
        INNER JOIN
    ",cal_acc_rel_table," cal_acc_rel ON cal_evnt.id = cal_acc_rel.calendarevent_id
        INNER JOIN
    orocrm_account acc ON acc.id = cal_acc_rel.account_id
   WHERE
    (visit_report.complaint = 1 AND visit_report.createdat <= '",current_month_start_date,"' AND visit_report.complaintStatus='open')
        AND visit_report.owner_id IN (",user_id,")
        )");
	 
	SET @query = concat(@query,";");
	PREPARE stmt FROM @query; 
        EXECUTE stmt; 
	DEALLOCATE PREPARE stmt;
END