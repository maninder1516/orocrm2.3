CREATE PROCEDURE `getNetSalesExcludingTireSalesWidgetDataForManager`(IN curStartDate DATE,IN curEndDate DATE,IN yr INT ,IN userIds VARCHAR(1500), IN workingDaysTillCurrentDay INT,IN workingDaysTillCurrentMonth INT, IN category_id INT, IN is_mgr INT,IN bu_ids VARCHAR(500),IN ownrBuIdLgnUsr INT,IN turnoverType INT)
BEGIN

DECLARE curMonth INT;
DECLARE todays_date DATE;
DECLARE cur_month INT;
DECLARE cur_yr INT;
DECLARE sales_type varchar(100);


SET todays_date = current_date();
SET cur_month = MONTH(todays_date);
SET cur_yr = YEAR(todays_date);
set curMonth = MONTH(curStartDate);

IF turnoverType = 1 then
    SET sales_type = 'gross_amount';
ELSEIF turnoverType = 2 then
    SET sales_type = 'net_amount';
ELSEIF turnoverType = 3 then
    SET sales_type = 'quantity';
ELSE
    SET sales_type = 'net_amount';
END IF;     
  
	 
set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
SET @sql_query = concat("select STRAIGHT_JOIN 
IFNULL(ROUND(SUM(",sales_type,") - SUM((CASE WHEN (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)), 0),0) as actual,
IFNULL(ROUND( CASE WHEN YEAR('",curEndDate,"') = ",cur_yr," AND MONTH('",curEndDate,"') = ",cur_month," THEN (((SUM(",sales_type,") - SUM((CASE WHEN (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) )/ ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE (SUM(",sales_type,") - SUM((CASE WHEN (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) END , 0),0) as estimation,");
IF is_mgr > 0 THEN
SET @sql_query = concat(@sql_query,"IFNULL(ROUND((select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",yr," and ipt.bu_id IN (",bu_ids,") and iptcd.month = ",curMonth," and iptcd.platform_sales_category_id =  ",category_id,"),0),0) as target,
IFNULL(ROUND(
( CASE WHEN YEAR('",curEndDate,"') = ",cur_yr," AND MONTH('",curEndDate,"') = ",cur_month," THEN (((SUM(",sales_type,") - SUM((CASE WHEN (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) )/ ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE (SUM(",sales_type,") - SUM((CASE WHEN (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) END)
/(select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",yr," and ipt.bu_id IN (",bu_ids,") and iptcd.month = ",curMonth," and iptcd.platform_sales_category_id = ",category_id,"), 0), 0) as performance");
ELSE
SET @sql_query = concat(@sql_query,"IFNULL(ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",yr," and istcd.month = ",curMonth," and iut.salesman_id IN (",userIds,") and istcd.usr_sales_category_id = ",category_id,"),0),0) as target,
IFNULL(ROUND(
( CASE WHEN YEAR('",curEndDate,"') = ",cur_yr," AND MONTH('",curEndDate,"') = ",cur_month," THEN (((SUM(",sales_type,") - SUM((CASE WHEN (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,") ELSE (SUM(",sales_type,") - SUM((CASE WHEN (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) END)
/(select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",yr," and istcd.month = ",curMonth," and iut.salesman_id IN (",userIds,") and istcd.usr_sales_category_id = ",category_id,"), 0), 0) as performance");
END IF;
SET @sql_query = concat(@sql_query," FROM
sales_report_mv
where business_unit_id IN (",bu_ids,") and report_date between '",curStartDate,"' and '",curEndDate,"' and user_id IN(",userIds,");");


    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt; 
END