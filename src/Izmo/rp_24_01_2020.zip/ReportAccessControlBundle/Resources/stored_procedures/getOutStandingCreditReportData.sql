CREATE PROCEDURE `getOutStandingCreditReportData`(IN usr_ids VARCHAR(1500),IN cur_start_date DATE, IN cur_end_date DATE,IN cmpdate1 INT,IN bu_ids VARCHAR(500),IN ownrBuIdLgnUsr INT,IN turnoverType INT)
BEGIN
DECLARE curStartDate DATE;
DECLARE curEndDate DATE;
DECLARE presentYear INT;
DECLARE presentMonth INT;
DECLARE presentDate INT;
DECLARE todays_date DATE;
DECLARE curYearStartDate DATE;
DECLARE curYearEndDate DATE;
DECLARE startyear DATE;
DECLARE endyear DATE;
DECLARE curMonthEndDate DATE;
DECLARE workingDaysTillCurrentDay INT;
DECLARE lastDay INT;
DECLARE prevYr INT;
DECLARE sales_type varchar(100);

SET todays_date = current_date();
SET presentYear = YEAR(todays_date);
SET presentMonth = MONTH(todays_date);
SET presentDate = DAY(todays_date);
SET curEndDate = (concat_ws('-', presentYear,presentMonth, presentDate));
SET curStartDate = DATE_FORMAT(CURRENT_DATE - INTERVAL 90 DAY, '%Y-%m-%d');

IF turnoverType = 1 then
    SET sales_type = 'tariffpricetotal';
ELSEIF turnoverType = 2 then
    SET sales_type = 'netpricetotal';
ELSEIF turnoverType = 3 then
    SET sales_type = 'quantitybought';
ELSE
    SET sales_type = 'netpricetotal';
END IF;

set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
   

SELECT (TOTAL_WEEKDAYS(curStartDate, curEndDate) - (select count(id) from izmo_businessclosure where bcdate between curStartDate and curEndDate)) into workingDaysTillCurrentDay;

	set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
    SET @sql_query = concat("SELECT account_code,client, salesman,available, creditBlocked, incidentCode, 
					(case when daysLeft < 0 then 0 else daysLeft end) as 'daysLeft' 
		from (
        SELECT STRAIGHT_JOIN 
	oca.clientnumber as account_code,
    oca.name as client,
    concat(ou.first_name,' ',ou.last_name) as salesman,
    ROUND(oca.creditlimit, 2) AS available,
    oca.op_blocked as creditBlocked,
    oca.incident_code_id as incidentCode,
    IFNULL(ROUND((oca.creditlimit / (SUM(sh.",sales_type,") / 90)), 0),0) as daysLeft
    FROM orocrm_account oca 
	INNER JOIN izmo_sales_history sh /*use index(izm_sales_history_invoicedate_netprice_clientnum)*/ ON oca.id = sh.clientnumber
	INNER JOIN oro_user ou ON oca.user_owner_id = ou.id
    WHERE oca.user_owner_id IN(",usr_ids,") and sh.invoicedate between '",curStartDate,"' AND '",curEndDate,"' 
    group by oca.id ) as data 
    where ((available < 0 and (incidentCode is not null or incidentCode <> '')) or (available = 0 and (incidentCode is not null or incidentCode <> ''))
    or (available > 0 and daysLeft between 1 and 5)) order by daysLeft,client;
    
    "); 

    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
	DEALLOCATE PREPARE stmt; 
END