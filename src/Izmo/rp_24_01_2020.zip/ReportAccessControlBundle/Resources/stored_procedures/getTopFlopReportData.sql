DROP PROCEDURE IF EXISTS `getTopFlopReportData`;
CREATE PROCEDURE `getTopFlopReportData`(IN curStartDate DATE, IN curEndDate Date, IN histStartDate DATE, IN histEndDate Date,IN userIds VARCHAR(1500),IN bu_ids VARCHAR(500),IN ownrBuIdLgnUsr INT,IN workingDaysTillCurrentDay INT,IN workingDaysTillCurrentMonth INT,IN turnoverType INT)
BEGIN

DECLARE historyEndDate DATE;
DECLARE presentYear INT;
DECLARE presentMonth INT;
DECLARE presentDate INT;
DECLARE todays_date DATE;
DECLARE curYearStartDate DATE;
DECLARE curYearEndDate DATE;
DECLARE currentEndDate DATE;
DECLARE previousdate DATE;
DECLARE curMonthEndDate DATE;
DECLARE sales_type varchar(100);


SET todays_date = current_date();
SET presentYear = YEAR(todays_date);
SET presentMonth = MONTH(todays_date);
SET presentDate = DAY(todays_date);
SET previousdate = subdate(todays_date, 1);

SET curMonthEndDate = (concat_ws('-', presentYear,presentMonth, DAY(LAST_DAY(todays_date))));

SET currentEndDate = (concat_ws('-', presentYear,presentMonth, presentDate));
SET histEndDate = LAST_DAY(DATE_FORMAT(currentEndDate - INTERVAL 1 YEAR, '%Y-%m-%d'));

IF turnoverType = 1 then
	SET sales_type = 'gross_amount';
ELSEIF turnoverType = 2 then
	SET sales_type = 'net_amount';
ELSEIF turnoverType = 3 then
	SET sales_type = 'quantity';
ELSE
	SET sales_type = 'net_amount';
END IF; 

set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
   


    SET @sql_query = CONCAT("SELECT account_code,name, salestotal, salestotalprev, variation, performance FROM (SELECT 
	client_number as account_code,
    customer as name, 
	IFNULL(ROUND(SUM(CASE WHEN report_date BETWEEN '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END) ,0), 0) AS salestotal,
	
	IFNULL(ROUND((((SUM(CASE WHEN report_date BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,"),0), 0) AS salestotalprev,
	
	IFNULL(ROUND(((((SUM(CASE WHEN report_date BETWEEN '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END)) - (
	(((SUM(CASE WHEN report_date BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,")
	)) / (
	((SUM(CASE WHEN report_date BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,")
	) * 100),0), 0) AS variation,
	
    IFNULL(ROUND(((SUM(((CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END))) / (((select SUM((CASE WHEN tcd.net IS NOT NULL THEN tcd.net ELSE 0 END)) from izmo_client_sales_target_category_detail tcd inner join izmo_client_target iut on iut.id = tcd.target_id where tcd.client_sales_category_id = 1 and iut.year = YEAR('",curStartDate,"') and tcd.month = MONTH('",curStartDate,"')  and iut.account_id = cust_id ) / ",workingDaysTillCurrentMonth,") * ",workingDaysTillCurrentDay,")) * 100), 0), 0) AS performance
	FROM 
		sales_report_mv
        WHERE business_unit_id IN (",bu_ids,") and report_date BETWEEN '",histStartDate,"' AND '",curEndDate,"' and user_id IN(",userIds,") 
	group by cust_id) as topflopdata
    WHERE salestotal > 0 and salestotalprev > 0 
    order by variation,name  limit 0,10 ");
    
    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;

END