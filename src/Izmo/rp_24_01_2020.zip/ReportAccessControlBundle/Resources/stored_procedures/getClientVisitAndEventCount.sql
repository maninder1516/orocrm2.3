CREATE PROCEDURE `getClientVisitAndEventCount`(IN currentStartDate DATETIME,IN currentEndDate DATETIME,IN calEvntAccRelTable VARCHAR(150),IN usrIds VARCHAR(800))
BEGIN
	set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
	SET @sql_query = concat("SELECT COUNT(DISTINCT oca.id) as clientvisitcounts, COUNT(calevt.id) as eventcounts 
    FROM oro_calendar_event calevt 
    INNER JOIN oro_calendar oc on oc.id = calevt.calendar_id
    INNER JOIN oro_user ou on oc.user_owner_id = ou.id
    LEFT JOIN ",calEvntAccRelTable," cntxt on cntxt.calendarevent_id = calevt.id
 LEFT JOIN orocrm_account oca on oca.id = cntxt.account_id
 LEFT JOIN izmo_attendance att on att.calendarevent_id = calevt.id
 WHERE ou.id IN (",usrIds,")  and (ou.multiplecodes NOT LIKE '%dummy%') and calevt.start_at >= '",currentStartDate,"' and calevt.start_at <= '",currentEndDate,"' 
 and att.ispresent = 1
 ");
  
    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
END