CREATE DEFINER=`root`@`%` PROCEDURE `getTotalWeekDaysForDates`(IN currentStartDate DATE,IN currentEndDate DATE)
BEGIN
SELECT TOTAL_WEEKDAYS(currentStartDate,currentEndDate) - (select count(id) from izmo_businessclosure where bcdate between currentStartDate and currentEndDate) AS WeekDays;
END