CREATE DEFINER=`root`@`%` PROCEDURE `getCurActiveChallengesData`(IN usr_ids VARCHAR(500),IN business_unit_ids VARCHAR(255),IN start_date VARCHAR(255))
BEGIN
	SET @query = CONCAT("
		select 
			bunit.name, 
			a.izmopromotionname as promotionName, 
			CASE WHEN (select sum(ifnull(pps.quantity, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(ifnull(pps.quantity, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id), 0) 
				WHEN (select sum(ifnull(pps.price, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id) > 0 
					THEN ROUND((select sum(ifnull(pps.price, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id), 0) 
				ELSE 0 END as goalTotal,
			CASE WHEN (select sum(ifnull(pps.quantity, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id) > 0 
					THEN 0 
				WHEN (select sum(ifnull(pps.price, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id) > 0 
					THEN 1 
				ELSE 0 END as targetType,
			CASE WHEN (select sum(ifnull(pps.quantity, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id) > 0 
					THEN ROUND((sum(ifnull(d.quantitybought, 0)) + sum(ifnull(e.quantitybought, 0))), 0) 
				WHEN (select sum(ifnull(pps.price, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id) > 0 
					THEN ROUND((sum(ifnull(d.netpricetotal, 0)) + sum(ifnull(e.netpricetotal, 0))), 0) 
				ELSE 0 END as totalSales,
			CASE WHEN (select sum(ifnull(pps.quantity, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(ifnull(d.quantitybought, 0)) + sum(ifnull(e.quantitybought, 0))) / (select sum(ifnull(pps.quantity, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id)) * 100, 0) 
				WHEN (select sum(ifnull(pps.price, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id) > 0 
					THEN ROUND(((sum(ifnull(d.netpricetotal, 0)) + sum(ifnull(e.netpricetotal, 0))) / (select sum(ifnull(pps.price, 0)) from izmo_promotionsalesman pps where a.id = pps.promotion_id)) * 100, 0) 
				ELSE 0 END as delta,
                '' as ind
			from izmo_promotion a
			left join oro_business_unit bunit on bunit.id = a.business_unit_owner_id
			left join izmo_promotion_to_partmaster c on a.id = c.promotion_id
			left join izmo_promotion_to_partfamily b on b.promotion_id = a.id
			left join izmo_partfamily f on f.id = b.partfamily_id 
			left join izmo_partmaster g on g.id = c.partmaster_id
			left join izmo_sales_history d on d.partfamily = b.partfamily_id and d.invoicedate between a.izmopromotionstartdate and a.izmopromotionenddate
			left join izmo_sales_history e on e.partmaster = c.partmaster_id and e.invoicedate between a.izmopromotionstartdate and a.izmopromotionenddate
			left join oro_user h on h.id=d.owner_id and h.id IN (",usr_ids,") and (h.multiplecodes NOT LIKE '%dummy%')
			left join oro_user i on i.id=e.owner_id and i.id IN (",usr_ids,") and (i.multiplecodes NOT LIKE '%dummy%')
            where a.business_unit_owner_id in (",business_unit_ids,")  and a.izmopromotionstatus = 1 and a.is_challenge = 1");
    IF start_date != 'none' THEN
		SET @query = CONCAT(@query, " AND '",start_date,"' between a.izmopromotionstartdate and a.izmopromotionenddate" );
    END IF;
    
    SET @query = CONCAT(@query, " group by bunit.name, a.id");

	PREPARE stmt FROM @query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
END