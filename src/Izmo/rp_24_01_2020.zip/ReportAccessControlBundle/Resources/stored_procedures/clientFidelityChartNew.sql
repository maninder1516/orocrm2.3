CREATE  `clientFidelityChartNew`(IN curr_month INT, IN IN_MONTHS INT, IN USER_OWNER_IDS VARCHAR(1500),IN salesmanSearchData VARCHAR(200),IN client_name VARCHAR(200),IN client_code VARCHAR(200),IN bu_ids VARCHAR(500),IN owner_bu_id INT,IN manager_flag INT)
BEGIN
DECLARE X INT;
DECLARE Y INT;
DECLARE startDate DATE;
DECLARE endDate DATE;
DECLARE endMonth INT;
DECLARE startMonth INT;
DECLARE endYear INT;
DECLARE startYear INT;

DECLARE FIDELITY_MINIMUM_VALUE INT;
SELECT CONVERT(config_value,UNSIGNED INTEGER) INTO FIDELITY_MINIMUM_VALUE FROM `custom_config`WHERE config_label = 'FIDELITY_MINIMUM_VALUE'  and business_unit_owner_id = owner_bu_id;

set endDate = date_sub(date_sub(date_add(last_day(current_date()), interval 1 DAY), interval 1 month), interval 1 day);
set startDate = date_sub(date_add(last_day(current_date()), interval 1 DAY), interval 2 month);

IF manager_flag = 1 THEN
	set endMonth = MONTH(endDate);
	set startMonth = MONTH(date_sub(startDate,interval 5 month));
	set endYear = YEAR(endDate);
	set startYear = YEAR(date_sub(startDate,interval 5 month));
END IF;


SET x = curr_month;
SET Y = 0;


SET @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
SET @sql_query = "";

SET IN_MONTHS = 5;

WHILE x  >= 1 DO
	
	SET @sql_query = CONCAT(@sql_query,"
	
		SELECT STRAIGHT_JOIN COUNT(`code`) AS `type_count`, `type`, ",X," AS `month` FROM 
		(
			SELECT clientnumber,`customer`,`code`,`salesman`,`count`,invmonth,
			  (CASE 
			    WHEN (`count` >= 0 AND `count` <= 2) THEN 'To Activate'
			    WHEN (`count` >= 3 AND `count` <= 4) THEN 'To Retain'
			    WHEN (`count` >= 5 /*AND `count` <= 6*/) THEN 'Faithful'
			  END) AS `type`
			FROM
			(
			SELECT COUNT(CODE) AS COUNT,clientnumber,customer,CODE,salesman, invmonth FROM 
			(");
			IF manager_flag != 1 THEN
				SET @sql_query = CONCAT(@sql_query,"SELECT mv.cust_id as 'clientnumber', mv.customer AS 'customer', mv.client_number AS 'code', sum(mv.net_amount) as 'netpricetotal', 
					mv.report_date as 'invoicedate', mv.salesman AS `salesman`, MONTH(mv.report_date) AS invmonth
				from sales_report_mv mv
				WHERE mv.business_unit_id IN (",bu_ids,") and mv.channel IN ('RI','RA') AND mv.user_id IN (",USER_OWNER_IDS,")"); 
				
				IF salesmanSearchData != 'none' THEN
					SET @sql_query = concat(@sql_query," and mv.salesman LIKE '%",salesmanSearchData,"%'");       
				END IF;			
				IF client_name != 'none' THEN
					SET @sql_query = concat(@sql_query," and mv.customer LIKE '%",client_name,"%'");
				END IF;
				IF client_code != 'none' THEN
					SET @sql_query = concat(@sql_query," and mv.client_number LIKE '",client_code,"%'");
				END IF;
				
				SET @sql_query = concat(@sql_query," and 
					mv.report_date BETWEEN '",startDate,"' - INTERVAL ",IN_MONTHS," MONTH AND LAST_DAY('",startDate,"' - INTERVAL ",Y," MONTH)
				GROUP BY YEAR(mv.report_date), MONTH(mv.report_date), mv.cust_id
				ORDER BY mv.report_date DESC");
			ELSE
				SET @sql_query = CONCAT(@sql_query,"SELECT mv.cust_id as 'clientnumber', mv.customer AS 'customer', mv.client_number AS 'code', sum(mv.net_amount) as 'netpricetotal', 
					 mv.salesman AS `salesman`,mv.report_month as invmonth
				from sales_report_consolidated_mv mv force index(sr_mv_grpbytpe_buid_chnnl_usrid_rptyr_rptmonth_netamnt)
				WHERE mv.groupby_type = 'CUST_ID' and mv.business_unit_id IN (",bu_ids,") and mv.channel IN ('RI','RA') AND mv.user_id IN (",USER_OWNER_IDS,")"); 
				
				IF salesmanSearchData != 'none' THEN
					SET @sql_query = concat(@sql_query," and mv.salesman LIKE '%",salesmanSearchData,"%'");       
				END IF;			
				IF client_name != 'none' THEN
					SET @sql_query = concat(@sql_query," and mv.customer LIKE '%",client_name,"%'");
				END IF;
				IF client_code != 'none' THEN
					SET @sql_query = concat(@sql_query," and mv.client_number LIKE '",client_code,"%'");
				END IF;
				
				SET @sql_query = concat(@sql_query," and 
					(((mv.report_month BETWEEN ",startMonth," AND 12 AND mv.report_month > MONTH(LAST_DAY('",startDate,"' - INTERVAL ",Y," MONTH))) AND mv.report_year=",startYear,") OR (mv.report_month BETWEEN 1 and MONTH(LAST_DAY('",startDate,"' - INTERVAL ",Y," MONTH)) AND  mv.report_year=YEAR(LAST_DAY('",startDate,"' - INTERVAL ",Y," MONTH))))
				GROUP BY mv.report_year, mv.report_month, mv.cust_id
				ORDER BY mv.report_year DESC,mv.report_month DESC");
			END IF;	
			SET @sql_query = concat(@sql_query,	"	)
			 tbl2 where netpricetotal >= ",FIDELITY_MINIMUM_VALUE,"
			GROUP BY tbl2.clientnumber
			ORDER BY tbl2.clientnumber ASC) tbl3
		) tbl4
		GROUP BY `type`"
	);
	
	IF X > 1 THEN SET @sql_query = CONCAT(@sql_query," UNION ALL "); end if; 
	
 SET  X = X - 1; 
 SET  Y = Y + 1; 
END WHILE; 
SET @sql_query = CONCAT(@sql_query,"ORDER BY `month`,`type`;"); 
		
		
    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
	DEALLOCATE PREPARE stmt; 
	
	
		
END