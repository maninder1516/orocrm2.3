DROP PROCEDURE IF EXISTS `getAnnualTotalSalesWithoutTiresData`;
CREATE PROCEDURE `getAnnualTotalSalesWithoutTiresData`(IN yr INT, IN organization INT,IN ownerId VARCHAR(1500),IN yr_cmp_date1 INT,IN yr_cmp_date2 INT,IN categoryId INT,IN is_mgr INT,IN bu_ids VARCHAR(500),IN owner_bu_id INT,IN turnoverType INT)
BEGIN 
	   DECLARE is_group_lvl INT;
           DECLARE sales_type varchar(100);

    IF turnoverType = 1 then
        SET sales_type = 'gross_amount';
    ELSEIF turnoverType = 2 then
        SET sales_type = 'net_amount';
    ELSEIF turnoverType = 3 then
        SET sales_type = 'quantity';
    ELSE
        SET sales_type = 'net_amount';
    END IF;
    
    SET is_group_lvl = 0;
    set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
	
    select group_level from oro_business_unit where id = owner_bu_id into is_group_lvl;
	
	IF is_group_lvl = 1 THEN
	
	SET @sql_query = concat("SELECT STRAIGHT_JOIN
    ROUND(SUM(",sales_type,") - SUM((CASE WHEN index_code in ('05', '15', '25') THEN ",sales_type," ELSE 0 END)),0) AS actualVal,
    ROUND((((SUM(",sales_type,") - SUM((CASE WHEN index_code in ('05', '15', '25') THEN ",sales_type," ELSE 0 END)))/ ",yr_cmp_date1,") * ",yr_cmp_date2,"), 0) as estimationVal,");
	IF is_mgr > 0 THEN
		SET @sql_query = concat(@sql_query,"
		IFNULL(ROUND((
		select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",yr," and ipt.bu_id IN (",bu_ids,") and iptcd.platform_sales_category_id =  ",categoryId,"
		),0),0) AS targetVal,
		ROUND((((SUM(",sales_type,") - SUM((CASE WHEN index_code in ('05', '15', '25') THEN ",sales_type," ELSE 0 END))) /(select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",yr," and ipt.bu_id IN (",bu_ids,") and iptcd.platform_sales_category_id =  ",categoryId,")) * 100), 0) as performanceVal");
	ELSE
		SET @sql_query = concat(@sql_query,"
		IFNULL(ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ", yr, " and iut.salesman_id IN (",ownerId,") and istcd.usr_sales_category_id = ",categoryId,"),0),0) AS targetVal,
		ROUND((((SUM(",sales_type,") - SUM((CASE WHEN index_code in ('05', '15', '25') THEN ",sales_type," ELSE 0 END))) /(select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ", yr, " and iut.salesman_id IN (",ownerId,") and istcd.usr_sales_category_id = ",categoryId,")) * 100), 0) as performanceVal");
	END IF;
	SET @sql_query = concat(@sql_query,"
	FROM 
    sales_report_consolidated_mv
	WHERE groupby_type = 'SALESMAN_ID' and business_unit_id IN (",bu_ids,") and user_id IN (",ownerId,") and report_year = ", yr, ";");
	
	ELSE
	
	SET @sql_query = concat("SELECT STRAIGHT_JOIN
    ROUND(SUM(",sales_type,") - SUM((CASE WHEN index_code in ('05', '15', '25') THEN ",sales_type," ELSE 0 END)),0) AS actualVal,
    ROUND((((SUM(",sales_type,") - SUM((CASE WHEN index_code in ('05', '15', '25') THEN ",sales_type," ELSE 0 END)))/ ",yr_cmp_date1,") * ",yr_cmp_date2,"), 0) as estimationVal,");
	IF is_mgr > 0 THEN
		SET @sql_query = concat(@sql_query,"
		IFNULL(ROUND((
		select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",yr," and ipt.bu_id IN (",bu_ids,") and iptcd.platform_sales_category_id =  ",categoryId,"
		),0),0) AS targetVal,
		ROUND((((SUM(",sales_type,") - SUM((CASE WHEN index_code in ('05', '15', '25') THEN ",sales_type," ELSE 0 END))) /(select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",yr," and ipt.bu_id IN (",bu_ids,") and iptcd.platform_sales_category_id =  ",categoryId,")) * 100), 0) as performanceVal");
	ELSE
		SET @sql_query = concat(@sql_query,"
		IFNULL(ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ", yr, " and iut.salesman_id IN (",ownerId,") and istcd.usr_sales_category_id = ",categoryId,"),0),0) AS targetVal,
		ROUND((((SUM(",sales_type,") - SUM((CASE WHEN index_code in ('05', '15', '25') THEN ",sales_type," ELSE 0 END))) /(select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ", yr, " and iut.salesman_id IN (",ownerId,") and istcd.usr_sales_category_id = ",categoryId,")) * 100), 0) as performanceVal");
	END IF;
	
	SET @sql_query = concat(@sql_query,"
	FROM 
    sales_report_mv
	WHERE business_unit_id IN (",bu_ids,") and user_id IN (",ownerId,") and year(report_date) = ", yr, ";");
	
	END IF;
    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
	DEALLOCATE PREPARE stmt; 
END