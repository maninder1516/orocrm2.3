CREATE PROCEDURE `getDashboardTargetWidgetData`(IN sel_year INT, IN cur_start_date DATE, IN cur_end_date DATE, IN prev_start_date DATE, IN prev_end_date DATE, IN cmpdate1 INT, IN cmpdate2 INT,IN usr_ids VARCHAR(1500), IN is_mgr INT,IN bu_ids VARCHAR(500),IN ownrBuIdLgnUsr INT,IN turnoverType INT)
BEGIN
DECLARE family_codes VARCHAR(8000);
DECLARE todays_date DATE;
DECLARE cur_month INT;
DECLARE cur_yr INT;
DECLARE agent_codes VARCHAR(1000);
DECLARE sales_type varchar(100);

SET prev_start_date = DATE_FORMAT(cur_start_date - INTERVAL 1 YEAR, '%Y-%m-%d');
 
SET todays_date = current_date();
SET cur_month = MONTH(todays_date);
SET cur_yr = YEAR(todays_date);

IF turnoverType = 1 then
    SET sales_type = 'gross_amount';
ELSEIF turnoverType = 2 then
    SET sales_type = 'net_amount';
ELSEIF turnoverType = 3 then
    SET sales_type = 'quantity';
ELSE
    SET sales_type = 'net_amount';
END IF; 

(SELECT CONCAT("'",replace(config_value,",","','"),"'") FROM custom_config where config_label = 'FAMILY_CODES' into family_codes);
(SELECT config_value FROM custom_config where config_label = 'AGENT_CODE' and business_unit_owner_id = ownrBuIdLgnUsr into agent_codes);

	SET @sql_query = CONCAT("
		SELECT  STRAIGHT_JOIN
			'Net Turnover' as targetName, 
			IFNULL(ROUND(SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END), 0),0) as actual,				
			IFNULL(ROUND( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END , 0),0) as projection,	
				");
	IF is_mgr > 0 THEN
		SET @sql_query = CONCAT(@sql_query ,"			
			IFNULL(ROUND((((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END)) / 
(select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 1)
) * 100),0),0) as projpercent,
			IFNULL(ROUND((select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 1), 0), 0) as goalSales,
			IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 1)) * 100),0),0) as indicator,
			");
	ELSE
	SET @sql_query = CONCAT(@sql_query ,"			
			IFNULL(ROUND((((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END)) / (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 1)) * 100),0),0) as projpercent,
			IFNULL(ROUND((select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 1), 0), 0) as goalSales,
			IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 1)) * 100),0),0) as indicator,
			");
	END IF;
	
		SET @sql_query = CONCAT(@sql_query,"	IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END) / (SUM(CASE WHEN report_date between '", prev_start_date,"' AND '", prev_end_date,"' THEN ",sales_type," ELSE 0 END))) * 100),0),0) as history
		from sales_report_mv
		where business_unit_id IN (",bu_ids,") and user_id IN (",usr_ids,") and report_date between '", prev_start_date,"' AND '", cur_end_date,"' 
		UNION ALL");
	
		SET @sql_query = CONCAT(@sql_query, "
			SELECT	'Net Turnover without Tires' as targetName,
				IFNULL(ROUND(SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)), 0),0) as actual,				
				IFNULL(ROUND(
				(CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN 
				(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) / ",cmpdate1,") * ",cmpdate2,")
				ELSE (
				SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))
				) END)
				, 0),0) as projection,");	
			IF is_mgr > 0 THEN
				SET @sql_query = CONCAT(@sql_query, "IFNULL(ROUND((((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) / 
			(select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 2)
			) * 100),0),0) as projpercent,
                IFNULL(ROUND((select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 2), 0), 0) as goalSales,				
				IFNULL(ROUND(((
				(CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN 
				(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) / ",cmpdate1,") * ",cmpdate2,")
				ELSE (
				SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))
				) END)
				/ (select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 2)) * 100),0),0) as indicator,");
			ELSE
				SET @sql_query = CONCAT(@sql_query, "IFNULL(ROUND((((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) / (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 2)) * 100),0),0) as projpercent,
                IFNULL(ROUND((select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 2), 0), 0) as goalSales,				
				IFNULL(ROUND(((
				(CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN 
				(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) / ",cmpdate1,") * ",cmpdate2,")
				ELSE (
				SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))
				) END)
				/ (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 2)) * 100),0),0) as indicator,");
				
		    END IF;
				
				SET @sql_query = CONCAT(@sql_query, "IFNULL(ROUND(((
				(CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN 
				(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) / ",cmpdate1,") * ",cmpdate2,")
				ELSE (
				SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))
				) END)
				/ (SUM(CASE WHEN report_date between '", prev_start_date,"' AND '", prev_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",prev_start_date,"' and '",prev_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)))) * 100),0),0) as history
                from sales_report_mv
			where business_unit_id IN (",bu_ids,") and user_id IN (",usr_ids,") and report_date between '", prev_start_date,"' AND '", cur_end_date,"' 
			UNION ALL");
                
		SET @sql_query = CONCAT(@sql_query, "
			SELECT	'Net Turnover without Tires and Agents Client Category' as targetName,
					IFNULL(ROUND(SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))), 0),0) as actual,
				IFNULL(ROUND(
				(CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN 
				(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) ) / ",cmpdate1,") * ",cmpdate2,")
				ELSE (
				SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))))
				) END)
				, 0),0) as projection,");
				IF is_mgr > 0 THEN
				SET @sql_query = CONCAT(@sql_query, "	
				IFNULL(ROUND((((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))))) / 
				(select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 3)
				) * 100),0),0) as projpercent,
                IFNULL(ROUND((
				select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 3
				), 0), 0) as goalSales,
				IFNULL(ROUND(((
				(CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN 
				(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) ) / ",cmpdate1,") * ",cmpdate2,")
				ELSE (
				SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) )
				) END)
				/ (select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 3)) * 100),0),0) as indicator,");
				ELSE
				SET @sql_query = CONCAT(@sql_query, "	
				IFNULL(ROUND((((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) ) / (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 3)) * 100),0),0) as projpercent,
                IFNULL(ROUND((select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 3), 0), 0) as goalSales,
				IFNULL(ROUND(((
				(CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN 
				(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)))) / ",cmpdate1,") * ",cmpdate2,")
				ELSE (
				SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)))
				) END)
				/ (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 3)) * 100),0),0) as indicator,");
				END IF;
				
				SET @sql_query = CONCAT(@sql_query, "	
				IFNULL(ROUND(((
				(CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN 
				(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)))) / ",cmpdate1,") * ",cmpdate2,")
				ELSE (
				SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) -((SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - (SUM(CASE WHEN report_date between '",cur_start_date,"' and '",cur_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) 
				) END)
				/ (SUM(CASE WHEN report_date between '", prev_start_date,"' AND '", prev_end_date,"' THEN ",sales_type," ELSE 0 END) - (SUM(CASE WHEN report_date between '",prev_start_date,"' and '",prev_end_date,"' and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END)) - ((SUM(CASE WHEN report_date between '",prev_start_date,"' and '",prev_end_date,"' and client_category_code in (",agent_codes,") THEN ",sales_type," ELSE 0 END)) - (SUM(CASE WHEN report_date between '",prev_start_date,"' and '",prev_end_date,"' and client_category_code in (",agent_codes,") and (index_code = '05' or index_code  = '15'  or index_code = '25') THEN ",sales_type," ELSE 0 END))) )) * 100),0),0) as history
                
                from sales_report_mv
			where business_unit_id IN (",bu_ids,") and user_id IN (",usr_ids,") and report_date between '", prev_start_date,"' AND '", cur_end_date,"' 
			UNION ALL");
                
		SET @sql_query = CONCAT(@sql_query, "
			SELECT	'Turnover of Index 2,4,6,8' as targetName,
				IFNULL(ROUND(SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END), 0),0) as actual,
				IFNULL(ROUND( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END , 0),0) as projection,	");
			IF is_mgr > 0 THEN
				SET @sql_query = CONCAT(@sql_query, "
				IFNULL(ROUND(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / 
				(select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 4)
				) * 100),0),0) as projpercent,
                IFNULL(ROUND((
				select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 4
				), 0), 0) as goalSales,
				IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (
			select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 4
			)) * 100),0),0) as indicator,		");
		    ELSE
			SET @sql_query = CONCAT(@sql_query, "
				IFNULL(ROUND(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 4)) * 100),0),0) as projpercent,
                IFNULL(ROUND((select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 4), 0), 0) as goalSales,
				IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 4)) * 100),0),0) as indicator,		");
		END IF;
			SET @sql_query = CONCAT(@sql_query, "
				IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END) / (SUM(CASE WHEN report_date between '", prev_start_date,"' AND '", prev_end_date,"' THEN ",sales_type," ELSE 0 END))) * 100),0),0) as history
                from sales_report_mv
			where business_unit_id IN (",bu_ids,") and user_id IN (",usr_ids,") and report_date between '", prev_start_date,"' AND '", cur_end_date,"' and index_code IN ('02','04','06','08','36')
			UNION ALL 
			SELECT	'Turnover Eurorepar Car Service' as targetName,
				IFNULL(ROUND(SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END), 0),0) as actual,
				IFNULL(ROUND( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END , 0),0) as projection,
			");  
        IF is_mgr > 0 THEN
			SET @sql_query = CONCAT(@sql_query, "
				IFNULL(ROUND(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / 
				(select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 5)
				) * 100),0),0) as projpercent,
                IFNULL(ROUND((select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 5), 0), 0) as goalSales,
				IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ 
			(select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 5)
			) * 100),0),0) as indicator,");
	    ELSE
				SET @sql_query = CONCAT(@sql_query, "
				IFNULL(ROUND(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 5)) * 100),0),0) as projpercent,
                IFNULL(ROUND((select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 5), 0), 0) as goalSales,
				IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 5)) * 100),0),0) as indicator,");
		END IF;	
		SET @sql_query = CONCAT(@sql_query, "	
				IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END) / (SUM(CASE WHEN report_date between '", prev_start_date,"' AND '", prev_end_date,"' THEN ",sales_type," ELSE 0 END))) * 100),0),0) as history
            from sales_report_mv
			where business_unit_id IN (",bu_ids,") and user_id IN (",usr_ids,") and report_date between '", prev_start_date,"' AND '", cur_end_date,"' and (index_code = '07') 
			UNION ALL");
           
		   
		SET @sql_query = CONCAT(@sql_query, "
			SELECT	'Net Turnover of Tires' as targetName,
				IFNULL(ROUND(SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END), 0),0) as actual,
				IFNULL(ROUND( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END , 0),0) as projection,");
			IF is_mgr > 0 THEN
				SET @sql_query = CONCAT(@sql_query, " IFNULL(ROUND(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / (
			select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 6
			)) * 100),0),0) projpercent,
                IFNULL(ROUND((
				select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 6
				), 0), 0) as goalSales,				
				IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 6)) * 100),0),0) as indicator,
			");
			ELSE 
				SET @sql_query = CONCAT(@sql_query, " IFNULL(ROUND(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 6)) * 100),0),0) projpercent,
                IFNULL(ROUND((select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 6), 0), 0) as goalSales,				
				IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 6)) * 100),0),0) as indicator,
			");
			END IF;
			SET @sql_query = CONCAT(@sql_query, "	IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END) / (SUM(CASE WHEN report_date between '", prev_start_date,"' AND '", prev_end_date,"' THEN ",sales_type," ELSE 0 END))) * 100),0),0) as history
                
                from sales_report_mv
			where business_unit_id IN (",bu_ids,") and user_id IN (",usr_ids,") and report_date between '", prev_start_date,"' AND '", cur_end_date,"' and (index_code in ('05','15','25')) 
			UNION ALL");
            IF family_codes != '' THEN
				SET @sql_query = CONCAT(@sql_query, "
				SELECT	'Net Turnover Families' as targetName,
				IFNULL(ROUND(SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END), 0),0) as actual,
				IFNULL(ROUND( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END , 0),0) as projection,
				");
				
				IF is_mgr > 0 THEN
				SET @sql_query = CONCAT(@sql_query, "
				IFNULL(ROUND((((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END)) / 
				(select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 7)
				) * 100),0),0) projpercent,
                IFNULL(ROUND((
				select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 7
				), 0), 0)  as goalSales,
               IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 7)) * 100),0),0) as indicator,");
				ELSE
				SET @sql_query = CONCAT(@sql_query, "
				IFNULL(ROUND((((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END)) / (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 7)) * 100),0),0) projpercent,
                IFNULL(ROUND((select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 7), 0), 0)  as goalSales,
               IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 7)) * 100),0),0) as indicator,");
			END IF;
			SET @sql_query = CONCAT(@sql_query, "
                IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END) / (SUM(CASE WHEN report_date between '", prev_start_date,"' AND '", prev_end_date,"' THEN ",sales_type," ELSE 0 END))) * 100),0),0) as history
            from sales_report_mv
			where business_unit_id IN (",bu_ids,") and user_id IN (",usr_ids,") and report_date between '", prev_start_date,"' AND '", cur_end_date,"' AND family_code IN (",family_codes,")
                UNION ALL
				");
		    ELSE
            SET @sql_query = CONCAT(@sql_query, "
			SELECT	'Net Turnover Families' as targetName,
				0 as actual,
				0 as projection,
				0 projpercent,
                0 as goalSales,
                0 as indicator,
                0 as history
                UNION ALL");
            END IF;

		SET @sql_query = CONCAT(@sql_query, "
			SELECT	'Net Turnover IAM' as targetName,
				IFNULL(ROUND(SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END), 0),0) as actual,				
				IFNULL(ROUND( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END , 0),0) as projection,");
			IF is_mgr > 0 THEN
					SET @sql_query = CONCAT(@sql_query, "IFNULL(ROUND(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / (select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 8)) * 100),0),0) projpercent,
                IFNULL(ROUND((select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 8), 0), 0) as goalSales,				
				IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (select SUM(IFNULL(iptcd.net,0)) from  izmo_platform_sales_target_category_detail iptcd  inner join izmo_platform_target ipt on ipt.id = iptcd.target_id where ipt.year = ",sel_year," and ipt.bu_id IN (",bu_ids,") and iptcd.month = MONTH('",cur_start_date,"') and iptcd.platform_sales_category_id = 8)) * 100),0),0) as indicator,");
			ELSE	
				SET @sql_query = CONCAT(@sql_query, "IFNULL(ROUND(((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 8)) * 100),0),0) projpercent,
                IFNULL(ROUND((select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 8), 0), 0) as goalSales,				
				IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END)
			/ (select SUM(IFNULL(istcd.net,0)) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = MONTH('",cur_start_date,"') and istcd.usr_sales_category_id = 8)) * 100),0),0) as indicator,");
			
			END IF;
			SET @sql_query = CONCAT(@sql_query, "	IFNULL(ROUND(((
			( CASE WHEN YEAR('",cur_end_date,"') = ",cur_yr," and MONTH('",cur_end_date,"') = ",cur_month," THEN ((SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END) / ",cmpdate1,") * ",cmpdate2,") ELSE ( SUM(CASE WHEN report_date between '", cur_start_date,"' AND '", cur_end_date,"' THEN ",sales_type," ELSE 0 END )) END) / (SUM(CASE WHEN report_date between '", prev_start_date,"' AND '", prev_end_date,"' THEN ",sales_type," ELSE 0 END))) * 100),0),0) as history
			from sales_report_mv
			where business_unit_id IN (",bu_ids,") and user_id IN (",usr_ids,") and report_date between '", prev_start_date,"' AND '", cur_end_date,"' and (index_code IN (13,12)) 
                ;");
                
  
   
    PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
	
END