CREATE PROCEDURE `getSalesPerChannelData`(IN usr_ids VARCHAR(1500), IN salesman VARCHAR(100),IN bu_ids VARCHAR(500),IN owner_bu_id INT,IN where_cond VARCHAR(500),IN order_cond VARCHAR(500),IN page_limit VARCHAR(40),IN pk_col_for_cnt VARCHAR(20),IN cnt_flg INT,IN turnoverType INT)
BEGIN

DECLARE curStartDate DATE;
DECLARE curEndDate DATE;
DECLARE histStartDate DATE;
DECLARE histEndDate DATE;
DECLARE presentYear INT;
DECLARE presentMonth INT;
DECLARE presentDate INT;
DECLARE todays_date DATE;
DECLARE previousdate DATE;
DECLARE curMonthEndDate DATE;
DECLARE workingDaysTillCurrentDay INT;
DECLARE workingDaysTillCurrentMonth INT;
DECLARE cur_month INT;
DECLARE cur_yr INT;
DECLARE is_group_lvl INT;
DECLARE curReportYr INT;
DECLARE curReportMonth INT;
DECLARE prevReportYr INT;
DECLARE prevReportMonth INT;
DECLARE sales_type varchar(100);


SET todays_date = current_date();
SET presentYear = YEAR(todays_date);
SET presentMonth = MONTH(todays_date);
SET presentDate = DAY(todays_date);
SET previousdate = subdate(todays_date, 1);

IF turnoverType = 1 then
    SET sales_type = 'gross_amount';
ELSEIF turnoverType = 2 then
    SET sales_type = 'net_amount';
ELSEIF turnoverType = 3 then
    SET sales_type = 'quantity';
ELSE
    SET sales_type = 'net_amount';
END IF;


SET curStartDate = (concat_ws('-', presentYear,presentMonth, 01));
SET curEndDate = (concat_ws('-', presentYear,presentMonth, presentDate));
SET curMonthEndDate = (concat_ws('-', presentYear,presentMonth, DAY(LAST_DAY(todays_date))));
SET cur_month = MONTH(todays_date);
SET cur_yr = YEAR(todays_date);

IF curStartDate = curEndDate THEN
	SET curStartDate =  DATE_FORMAT(CURRENT_DATE - INTERVAL 1 MONTH, '%Y-%m-01');
	SET curEndDate = DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, '%Y-%m-%d');
END IF;

SET histStartDate = DATE_FORMAT(curStartDate - INTERVAL 1 YEAR, '%Y-%m-01');
SET histEndDate = DATE_FORMAT(curEndDate - INTERVAL 1 YEAR, '%Y-%m-%d');
SET histEndDate = LAST_DAY(histEndDate);
	
	SET curReportYr = year(curEndDate);
	SET curReportMonth = month(curEndDate);
	
	SET prevReportYr = year(histEndDate);
	SET prevReportMonth = month(histEndDate);
	
SET is_group_lvl = 0;

set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
   

SELECT (TOTAL_WEEKDAYS(curStartDate, previousdate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curStartDate and previousdate)) into workingDaysTillCurrentDay;
SELECT (TOTAL_WEEKDAYS(curStartDate, curMonthEndDate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curStartDate and curMonthEndDate)) into workingDaysTillCurrentMonth;

	
	select group_level from oro_business_unit where id = owner_bu_id into is_group_lvl;
	
	IF is_group_lvl = 1 THEN
		
		SET @sql_query = CONCAT("SELECT SQL_CALC_FOUND_ROWS STRAIGHT_JOIN
	channel AS channelName,
    ROUND(SUM((CASE WHEN ",sales_type," IS NOT NULL  and report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END)), 0) AS actual,
    IFNULL(ROUND(( CASE WHEN ",curReportYr," = ",cur_yr," AND ",curReportMonth," = ",cur_month,"  THEN( ROUND((( SUM( CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,"),0)) ELSE (SUM( CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN (",sales_type,")  ELSE 0 END)) END),0) ,0)  as projection,
    ROUND(SUM((CASE WHEN report_year = ",prevReportYr," and report_month =",prevReportMonth,"  THEN ",sales_type," ELSE 0 END)), 0) AS actualprev,
	IFNULL(ROUND((( ( CASE WHEN ",curReportYr," = ",cur_yr," AND ",curReportMonth," = ",cur_month," THEN( ROUND((( SUM(CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN ",sales_type," ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,"),0)) ELSE (SUM( CASE WHEN report_year = ",curReportYr," and report_month =",curReportMonth," THEN (",sales_type,") ELSE 0 END)) END)/ (SUM((CASE WHEN report_year = ",prevReportYr," and report_month =",prevReportMonth," THEN ",sales_type," ELSE 0 END)))) * 100),0),0) AS performance
    FROM sales_report_consolidated_mv
	where 
	groupby_type = 'CHANNEL_ID' and
	business_unit_id IN (",bu_ids,") and channel is not null AND report_year in (",curReportYr,",",prevReportYr,") AND report_month = (",curReportMonth,") and user_id IN (",usr_ids,") 
	GROUP BY channel");
	
		ELSE
		
	
		SET @sql_query = CONCAT("SELECT SQL_CALC_FOUND_ROWS STRAIGHT_JOIN
	channel AS channelName,
    ROUND(SUM((CASE WHEN ",sales_type," IS NOT NULL  and report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END)), 0) AS actual,
    IFNULL(ROUND(( CASE WHEN ",curReportYr," = ",cur_yr," AND ",curReportMonth," = ",cur_month,"  THEN( ROUND((( SUM( CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,"),0)) ELSE (SUM( CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN (",sales_type,")  ELSE 0 END)) END),0) ,0)  as projection,
    ROUND(SUM((CASE WHEN report_date between '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END)), 0) AS actualprev,
	IFNULL(ROUND((( ( CASE WHEN ",curReportYr," = ",cur_yr," AND ",curReportMonth," = ",cur_month," THEN( ROUND((( SUM(CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,"),0)) ELSE (SUM( CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN (",sales_type,") ELSE 0 END)) END)/ (SUM((CASE WHEN report_date between '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END)))) * 100),0),0) AS performance
    FROM sales_report_mv
	where business_unit_id IN (",bu_ids,") and channel is not null AND report_date between '",histStartDate,"' AND '",curEndDate,"' AND user_id IN (",usr_ids,") 
	GROUP BY channel");
	
	END IF;
    
    IF page_limit != '' THEN
	  SET @sql_query = CONCAT(@sql_query, ' ', page_limit);
    END IF; 

	PREPARE stmt from @sql_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
  
END