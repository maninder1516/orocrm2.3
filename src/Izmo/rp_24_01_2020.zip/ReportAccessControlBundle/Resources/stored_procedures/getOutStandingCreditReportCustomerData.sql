CREATE DEFINER=`root`@`%` PROCEDURE `getTopFlopReportCustomerData`(IN curStartDate DATE, IN curEndDate Date, IN histStartDate DATE, IN histEndDate Date,IN userIds VARCHAR(255),IN curYearStartDate Date,IN curYearEndDate Date,IN prevYearStartDate Date,IN prevYearEndDate Date,IN workingDaysTillCurrentDay INT,IN workingDaysTillCurrentMonth INT,IN salesmanSearchData VARCHAR(200),IN channelSearchData VARCHAR(200),IN categoryId INT,IN lowerLimit INT,IN upperLimit INT)
BEGIN

    SET @sql_query = CONCAT("SELECT STRAIGHT_JOIN 
	a.name as name, concat(u.first_name,' ',u.last_name) as salesman,ccm.channel_name AS channelname,
	ROUND(SUM(CASE WHEN sh.invoicedate BETWEEN '",curStartDate,"' AND '",curEndDate,"' THEN sh.tariffpricetotal ELSE 0 END) ,0) AS salestotal,
	ROUND(SUM(CASE WHEN sh.invoicedate BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN sh.tariffpricetotal ELSE 0 END),0) AS salestotalprev,
	IFNULL(ROUND((SUM(CASE WHEN sh.invoicedate BETWEEN '",curStartDate,"' AND '",curEndDate,"' THEN sh.tariffpricetotal ELSE 0 END))/(SUM(CASE WHEN sh.invoicedate BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN sh.tariffpricetotal ELSE 0 END)) * 100,0), 0) AS variation,
	IFNULL(ROUND(((SUM(((CASE WHEN sh.invoicedate between '",curStartDate,"' AND '",curEndDate,"' THEN sh.tariffpricetotal ELSE 0 END))) / (((select SUM((CASE WHEN tcd.gross IS NOT NULL THEN tcd.gross ELSE 0 END)) from izmo_client_sales_target_category_detail tcd inner join izmo_client_target iut on iut.id = tcd.target_id where tcd.client_sales_category_id = ",categoryId," and iut.year = YEAR('",curStartDate,"')) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,")) * 100), 0), 0) AS performance,
	ROUND(SUM(CASE WHEN sh.invoicedate BETWEEN '",curYearStartDate,"' AND '",curYearEndDate,"' THEN sh.tariffpricetotal ELSE 0 END) ,0) AS yearsalestotal,
	ROUND(SUM(CASE WHEN sh.invoicedate BETWEEN '",prevYearStartDate,"' AND '",prevYearEndDate,"' THEN sh.tariffpricetotal ELSE 0 END),0) AS yearsalestotalprev,
	IFNULL(ROUND((SUM(CASE WHEN sh.invoicedate BETWEEN '",curYearStartDate,"' AND '",curYearEndDate,"' THEN sh.tariffpricetotal ELSE 0 END))/(SUM(CASE WHEN sh.invoicedate BETWEEN '",prevYearStartDate,"' AND '",prevYearEndDate,"' THEN sh.tariffpricetotal ELSE 0 END)) * 100,0), 0) AS yearvariation,
	IFNULL(ROUND(((SUM(((CASE WHEN sh.invoicedate between '",curYearStartDate,"' AND '",curYearEndDate,"' THEN sh.tariffpricetotal ELSE 0 END))) / (((select SUM((CASE WHEN tcd.gross IS NOT NULL THEN tcd.gross ELSE 0 END)) from izmo_client_sales_target_category_detail tcd inner join izmo_client_target iut on iut.id = tcd.target_id where tcd.client_sales_category_id = ",categoryId," and iut.year = YEAR('",prevYearStartDate,"')) / ",workingDaysTillCurrentDay,") * ",workingDaysTillCurrentMonth,")) * 100), 0), 0) AS yearperformance
	FROM
		orocrm_account a
        INNER JOIN
			izmo_sales_history sh ON a.id = sh.clientnumber		
		INNER JOIN 
			oro_user u on u.id = a.user_owner_id					
		INNER JOIN 
			oro_business_unit bu ON bu.id = u.business_unit_owner_id
		INNER JOIN 
			client_category_mapping ccm on ccm.category_code = a.clientcategory and ccm.business_unit = bu.id         				
        WHERE sh.invoicedate BETWEEN '",prevYearStartDate,"' AND '",curEndDate,"' and a.user_owner_id IN(",userIds,") and sh.tariffpricetotal > 0 ");
   
	IF salesmanSearchData != 'none' THEN
		SET @sql_query = concat(@sql_query,"and concat(u.first_name,' ',u.last_name) LIKE '%",salesmanSearchData,"%'");       
    END IF;	
    
	IF channelSearchData != 'none' THEN
		SET @sql_query = concat(@sql_query,"and ccm.channel_name LIKE '%",channelSearchData,"%'");       
    END IF;	    

    
    
		SET @sql_query = concat(@sql_query," group by a.id,ccm.id order by yearsalestotal desc limit ",lowerLimit,",",upperLimit," ;");
	
	#select @sql_query;
    PREPARE stmt FROM @sql_query; 
	EXECUTE stmt; 
	DEALLOCATE PREPARE stmt;

END