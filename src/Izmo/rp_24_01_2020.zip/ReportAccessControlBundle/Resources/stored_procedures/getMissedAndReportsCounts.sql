CREATE DEFINER=`root`@`%` PROCEDURE `getMissedAndReportsCounts`(IN start_date VARCHAR(100),IN end_date VARCHAR(100),IN usrIds VARCHAR(1500),IN appointment_hours INT)
BEGIN

DECLARE timeZoneOffset varchar(20);
DECLARE timeOffset VARCHAR(20);
SET timeZoneOffset = RIGHT(start_date,5);

IF LOCATE(':',timeZoneOffset) = 0 THEN
SELECT INSERT(timeZoneOffset,4, 0, ':') into timeOffset;
END IF;

SET @sql_qry = CONCAT("SELECT 
    IFNULL(SUM(CASE
        WHEN
            calevt.start_at
            BETWEEN STR_TO_DATE(('",start_date,"'),'%Y-%m-%d %H:%i:%s') AND STR_TO_DATE(('",end_date,"'),'%Y-%m-%d %H:%i:%s') 
                AND calevt.calendar_id = oc.id AND (((att.ispresent = 0 and att.calendarevent_id = calevt.id) OR (att.ispresent is null)) OR (
 att.createdat > DATE_ADD(calevt.start_at, INTERVAL ",appointment_hours," HOUR)
 ))
        THEN
            1
        ELSE 0
    END),0) AS missedcounts,
    COUNT(DISTINCT vr.id) AS reportcounts
FROM
    oro_calendar_event calevt
        INNER JOIN
    oro_calendar oc ON calevt.calendar_id = oc.id
		INNER JOIN
	oro_user ou on ou.id = oc.user_owner_id
        LEFT JOIN
    izmo_attendance att ON att.calendarevent_id = calevt.id
 
        LEFT JOIN
    izmo_visitreport vr ON vr.calendarevent_id = calevt.id
WHERE
    calevt.start_at BETWEEN STR_TO_DATE(('",start_date,"'),'%Y-%m-%d %H:%i:%s') AND  STR_TO_DATE(('",end_date,"'),'%Y-%m-%d %H:%i:%s') and ou.id IN (",usrIds,") and (ou.multiplecodes NOT LIKE '%dummy%')" );
 
 PREPARE stmt from @sql_qry;
 EXECUTE stmt;
 DEALLOCATE PREPARE stmt;
END