DROP PROCEDURE IF EXISTS `getIncompleteCustomerRecordData`;
CREATE PROCEDURE `getIncompleteCustomerRecordData`(IN userIds VARCHAR(1500), IN salesmanSearchData VARCHAR(200),IN client_name VARCHAR(200),IN client_code VARCHAR(50), IN where_cond VARCHAR(500),IN order_cond VARCHAR(500),IN page_limit VARCHAR(40),IN pk_col_for_cnt VARCHAR(20),IN cnt_flg INT)
BEGIN
set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
SET @sql_query = CONCAT("SELECT SQL_CALC_FOUND_ROWS STRAIGHT_JOIN OA.id,OA.clientnumber as `account_code`, `name` as `client`, CONCAT(OU.first_name,' ',OU.last_name) AS salesman,OA.user_owner_id,CONCAT(
	(CASE WHEN (`name`='' OR `name` IS NULL) THEN 'Name,' ELSE '' END),
	(CASE WHEN (address1='' OR address1 IS NULL) THEN 'izmo.extend_account.columns.address1.label,' ELSE '' END),
	(CASE WHEN (address2='' OR address2 IS NULL) THEN 'izmo.extend_account.columns.address2.label,' ELSE '' END),
	(CASE WHEN (agentcode='' OR agentcode IS NULL) THEN 'izmo.extend_account.columns.agentcode.label,' ELSE '' END),
	(CASE WHEN (city='' OR city IS NULL) THEN 'izmo.extend_account.columns.city.label,' ELSE '' END),
	(CASE WHEN (aemail='' OR aemail IS NULL) THEN 'izmo.extend_account.columns.aemail.label,' ELSE '' END),
	(CASE WHEN (dealernumber='' OR dealernumber IS NULL) THEN 'izmo.extend_account.columns.dealernumber.label,' ELSE '' END),
	(CASE WHEN (deliveryzone='' OR deliveryzone IS NULL) THEN 'izmo.extend_account.columns.deliveryzone.label,' ELSE '' END),
	(CASE WHEN (fax='' OR fax IS NULL) THEN 'izmo.extend_account.columns.fax.label,' ELSE '' END),
	(CASE WHEN (hometelephone='' OR hometelephone IS NULL) THEN 'izmo.extend_account.columns.hometelephone.label,' ELSE '' END),
	(CASE WHEN (officetelephone='' OR officetelephone IS NULL) THEN 'izmo.extend_account.columns.officetelephone.label,' ELSE '' END),
	(CASE WHEN (paymentterms='' OR paymentterms IS NULL) THEN 'izmo.extend_account.columns.paymentterms.label,' ELSE '' END),
	(CASE WHEN (postboxno='' OR postboxno IS NULL) THEN 'izmo.extend_account.columns.postboxno.label,' ELSE '' END),
	(CASE WHEN (zipcode='' OR zipcode IS NULL) THEN 'izmo.extend_account.columns.zipcode.label,' ELSE '' END),
	(CASE WHEN (panel='' OR panel IS NULL) THEN 'izmo.extend_account.columns.panel.label,' ELSE '' END),
	(CASE WHEN (noofemployees='' OR noofemployees IS NULL) THEN 'izmo.extend_account.columns.noofemployees.label,' ELSE '' END),
	(CASE WHEN (noofproductivestaff='' OR noofproductivestaff IS NULL) THEN 'izmo.extend_account.columns.noofproductivestaff.label,' ELSE '' END),
	(CASE WHEN (clientcategory='' OR clientcategory IS NULL) THEN 'izmo.extend_account.columns.clientcategory.label,' ELSE '' END),
	(CASE WHEN (clientnumber='' OR clientnumber IS NULL) THEN 'izmo.extend_account.columns.clientnumber.label,' ELSE '' END),
	(CASE WHEN (creditlimit='' OR creditlimit IS NULL) THEN 'izmo.extend_account.columns.creditlimit.label,' ELSE '' END),
	(CASE WHEN (discountcategory='' OR discountcategory IS NULL) THEN 'izmo.extend_account.columns.discountcategory.label,' ELSE '' END),
	(CASE WHEN (noofproductives='' OR noofproductives IS NULL) THEN 'izmo.extend_account.columns.noofproductives.label,' ELSE '' END),
	(CASE WHEN (incident_code_id='' OR incident_code_id IS NULL) THEN 'izmo.extend_account.columns.noofproductives.label,' ELSE '' END),
	(CASE WHEN (potential_id='' OR potential_id IS NULL) THEN 'izmo.extend_account.columns.potential.label,' ELSE '' END),
	(CASE WHEN (op_blocked='' OR op_blocked IS NULL) THEN 'izmo.extend_account.columns.opblocked.label,' ELSE '' END),
	(CASE WHEN (outstanding_credit='' OR outstanding_credit IS NULL) THEN 'izmo.extend_account.columns.outstandingcredit.label,' ELSE '' END),
	(CASE WHEN (channel='' OR channel IS NULL) THEN 'izmo.extend_account.columns.channel.label,' ELSE '' END),
	(CASE WHEN (frequency_of_visit='' OR frequency_of_visit IS NULL) THEN 'izmo.extend_account.columns.theoreticalfrequencyofvisit.label,' ELSE '' END),
	(CASE WHEN (other_panels='' OR other_panels IS NULL) THEN 'izmo.extend_account.columns.other_panels.label,' ELSE '' END),
	(CASE WHEN (website='' OR website IS NULL) THEN 'izmo.extend_account.columns.website.label,' ELSE '' END),
	(CASE WHEN (social_network='' OR social_network IS NULL) THEN 'izmo.extend_account.columns.socialnetwork.label,' ELSE '' END)
) AS field_name_list 
FROM `orocrm_account` OA 
JOIN `oro_user` OU ON OA.user_owner_id = OU.id
WHERE FIND_IN_SET(OA.user_owner_id,'",userIds,"') ");		

	IF salesmanSearchData != 'none' THEN
		SET @sql_query = concat(@sql_query," and CONCAT(OU.first_name,' ',OU.last_name) LIKE '%",salesmanSearchData,"%'");       
	END IF;	
	
	IF client_name != 'none' THEN
		SET @sql_query = concat(@sql_query," and OA.name LIKE '%",client_name,"%'");
	END IF;
	IF client_code != 'none' THEN
		SET @sql_query = concat(@sql_query," and OA.clientnumber LIKE '%",client_code,"%'");
	END IF;

    IF page_limit != '' THEN
	  SET @sql_query = CONCAT(@sql_query, ' ', page_limit);
    END IF;  

 PREPARE stmt from @sql_query;
   EXECUTE stmt;
   DEALLOCATE PREPARE stmt;
               
END