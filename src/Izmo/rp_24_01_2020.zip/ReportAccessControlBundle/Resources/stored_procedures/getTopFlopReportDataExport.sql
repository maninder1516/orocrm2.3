DROP PROCEDURE IF EXISTS `getTopFlopReportDataExport`;
CREATE PROCEDURE `getTopFlopReportDataExport`(IN userIds VARCHAR(1500), IN salesmanSearchData VARCHAR(200),IN channelSearchData VARCHAR(200),IN client_name VARCHAR(200),IN client_number VARCHAR(200),IN categoryId INT,IN bu_ids VARCHAR(500),IN owner_bu_id INT,IN turnover_type INT)
BEGIN

DECLARE curStartDate DATE;
DECLARE curEndDate DATE;
DECLARE histStartDate DATE;
DECLARE histEndDate DATE;
DECLARE presentYear INT;
DECLARE presentMonth INT;
DECLARE presentDate INT;
DECLARE todays_date DATE;
DECLARE curYearStartDate DATE;
DECLARE curYearEndDate DATE;
DECLARE startyear DATE;
DECLARE endyear DATE;
DECLARE prevYr INT;
DECLARE previousdate DATE;
DECLARE prevYearStartDate DATE;
DECLARE prevYearEndDate DATE;
DECLARE curMonthEndDate DATE;
DECLARE workingDaysTillCurrentDay INT;
DECLARE workingDaysTillCurrentMonth INT;
DECLARE workingDaysTillCurrentDayByYr INT;
DECLARE workingDaysInYr INT;
DECLARE lastDay INT;
DECLARE sales_type varchar(100);

SET todays_date = current_date();
SET presentYear = YEAR(todays_date);
SET presentMonth = MONTH(todays_date);
SET presentDate = DAY(todays_date);
SET previousdate = subdate(todays_date, 1);


SET curStartDate = (concat_ws('-', presentYear,presentMonth, 01));
SET curEndDate = (concat_ws('-', presentYear,presentMonth, presentDate));
SET curYearStartDate = (concat_ws('-', presentYear,01, 01));
SET curYearEndDate = curEndDate;
SET startyear = (CONCAT(presentYear,'-',01,'-',01));
SET endyear = (CONCAT(presentYear,'-',12,'-',31));
SET curMonthEndDate = (concat_ws('-', presentYear,presentMonth, DAY(LAST_DAY(todays_date))));

SET histStartDate = DATE_FORMAT(curStartDate - INTERVAL 1 YEAR, '%Y-%m-01');
SET histEndDate = LAST_DAY(DATE_FORMAT(curEndDate - INTERVAL 1 YEAR, '%Y-%m-%d'));
SET prevYr = YEAR(histEndDate);

    SET prevYearStartDate = (concat_ws('-', prevYr,01, 01));
    SET prevYearEndDate = (concat_ws('-', prevYr,12, 31));

IF turnover_type = 1 then
	SET sales_type = 'gross_amount';
ELSEIF turnover_type = 2 then
	SET sales_type = 'net_amount';
ELSEIF turnover_type = 3 then
	SET sales_type = 'quantity';
ELSE
	SET sales_type = 'net_amount';
END IF;     

set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
   

SELECT (TOTAL_WEEKDAYS(curStartDate, previousdate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curStartDate and previousdate)) into workingDaysTillCurrentDay;
SELECT (TOTAL_WEEKDAYS(curStartDate, curMonthEndDate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between curStartDate and curMonthEndDate)) into workingDaysTillCurrentMonth;

SELECT (TOTAL_WEEKDAYS(startyear, previousdate) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between startyear and previousdate)) into workingDaysTillCurrentDayByYr;
SELECT (TOTAL_WEEKDAYS(startyear, endyear) - (select count(id) from izmo_businessclosure where business_unit_owner_id = owner_bu_id and bcdate between startyear and endyear)) into workingDaysInYr;

SET @sql_query = CONCAT("SELECT name, clientnumber,salesman, channelname, salestotal, salestotalprev, variation, performance, yearsalestotal, yearsalestotalprev, yearvariation, yearperformance 
		from (SELECT STRAIGHT_JOIN 
	customer as name, client_number as clientnumber,salesman,channel AS channelname,
	ROUND(SUM(CASE WHEN report_date BETWEEN '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END) ,0) AS salestotal,
	ROUND(((SUM(CASE WHEN report_date BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END))* ",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,",0) AS salestotalprev,
		IFNULL(ROUND(((((SUM(CASE WHEN report_date BETWEEN '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END)) - (
	((SUM(CASE WHEN report_date BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END))* ",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,"
	)) / (
	((SUM(CASE WHEN report_date BETWEEN '",histStartDate,"' AND '",histEndDate,"' THEN ",sales_type," ELSE 0 END))* ",workingDaysTillCurrentDay,")/",workingDaysTillCurrentMonth,"
	)) * 100),0),0) AS variation,
    IFNULL(ROUND(((SUM(((CASE WHEN report_date between '",curStartDate,"' AND '",curEndDate,"' THEN ",sales_type," ELSE 0 END))) / (((select SUM((CASE WHEN tcd.net IS NOT NULL THEN tcd.net ELSE 0 END)) from izmo_client_sales_target_category_detail tcd inner join izmo_client_target iut on iut.id = tcd.target_id where tcd.client_sales_category_id = ",categoryId," and iut.year = YEAR('",curStartDate,"') and tcd.month = MONTH('",curStartDate,"')  and iut.account_id = cust_id ) / ",workingDaysTillCurrentMonth,") * ",workingDaysTillCurrentDay,")) * 100), 0), 0) AS performance,
	ROUND(SUM(CASE WHEN report_date BETWEEN '",curYearStartDate,"' AND '",curYearEndDate,"' THEN ",sales_type," ELSE 0 END) ,0) AS yearsalestotal,
	ROUND(((SUM(CASE WHEN report_date BETWEEN '",prevYearStartDate,"' AND '",prevYearEndDate,"' THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDayByYr,") /",workingDaysInYr,",0) AS yearsalestotalprev,
	IFNULL(ROUND(((((SUM(CASE WHEN report_date BETWEEN '",curYearStartDate,"' AND '",curYearEndDate,"' THEN ",sales_type," ELSE 0 END)) - ((((SUM(CASE WHEN report_date BETWEEN '",prevYearStartDate,"' AND '",prevYearEndDate,"' THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDayByYr,") /",workingDaysInYr,") 
	)) / ((((SUM(CASE WHEN report_date BETWEEN '",prevYearStartDate,"' AND '",prevYearEndDate,"' THEN ",sales_type," ELSE 0 END))*",workingDaysTillCurrentDayByYr,") /",workingDaysInYr,") )) * 100),0),0) AS yearvariation,
    IFNULL(ROUND(((SUM(((CASE WHEN report_date between '",curYearStartDate,"' AND '",curYearEndDate,"' THEN ",sales_type," ELSE 0 END))) / (((select SUM((CASE WHEN tcd.net IS NOT NULL THEN tcd.net ELSE 0 END)) from izmo_client_sales_target_category_detail tcd inner join izmo_client_target iut on iut.id = tcd.target_id where tcd.client_sales_category_id = ",categoryId," and iut.year = YEAR('",curYearStartDate,"')  and iut.account_id = cust_id) / ",workingDaysInYr,") * ",workingDaysTillCurrentDayByYr,")) * 100), 0), 0) AS yearperformance
	FROM
		sales_report_mv        				
        WHERE 
        business_unit_id IN (",bu_ids,") and
        report_date BETWEEN '",prevYearStartDate,"' AND '",curEndDate,"' and user_id IN(",userIds,") ");
		
		
		IF salesmanSearchData != 'none' THEN
			SET @sql_query = concat(@sql_query,"and salesman LIKE '%",salesmanSearchData,"%'");       
		END IF;	
		
		IF channelSearchData != 'none' THEN
			SET @sql_query = concat(@sql_query,"and channel LIKE '%",channelSearchData,"%'");       
		END IF;	
		
		IF client_name != 'none' THEN
			SET @sql_query = concat(@sql_query,"and customer LIKE '%",client_name,"%'");
		END IF;
		
		IF client_number != 'none' THEN
			SET @sql_query = concat(@sql_query,"and client_number LIKE '%",client_number,"%'");
		END IF;
		
		
	SET @sql_query = concat(@sql_query," group by cust_id,channel");
	
    SET @sql_query = concat(@sql_query, ") as topflopdata WHERE yearsalestotal > 0 ");
    
	
		SET @sql_query = CONCAT(@sql_query, ' ', "order by yearvariation,name");
    
   PREPARE stmt from @sql_query;
   EXECUTE stmt;
   DEALLOCATE PREPARE stmt;
              
END