require(['jquery', 'orolocale/js/formatter/number','orolocale/js/locale-settings','orotranslation/js/translator','oroconfig/js/configuration'], function ($, numberFormatter,localeSettings,_trans,config) {
    $(document).ready(function () {
        var isCurSymPrep =  config.get('is-currency-symbol-prepend');    
        var curSym = localeSettings.getCurrencySymbol(); 
        var tabl = $('.dashboard-top-flop-tab'); 
        tabl.hide();
        $('.topflop-loader').show();
        $.ajax({
            url: $('.dashboard_top_flop_url').val(),
            type: 'POST',
            success: function (resp) {
               ajaxCallFunction(resp);   
            }
        });
        
        $('#dashboard_top_flop_select').on('change', function() {
            $('.topflop-loader').show();
            $.ajax({
                  type: "POST",
                  url: $('.dashboard_top_flop_url').val(),
                  data: {'salestype': $(this).val()}, 
                  success: function (resp){
                      ajaxCallFunction(resp); 
                  }
            });
        });
        
        function ajaxCallFunction(resp){
            var res;
                if ($.trim(resp) && (res = JSON.parse(resp)))
                {
                    if(res['err'] == 1){
                        $('.topflop-loader').hide();
                        tabl.hide();
                        $('.err-topflop').show();                                            
                    }else{ 
                        if(res != ''){                    
                            var rws = '';  
                            $.each(res, function (i, item) {
                            if(isCurSymPrep){
                            var salestotal = curSym + ''+ numberFormatter.formatInteger(item.salestotal);
                            var salestotalprev = curSym + ''+ numberFormatter.formatInteger(item.salestotalprev);                   
                            }
                            else{
                                var salestotal = numberFormatter.formatInteger(item.salestotal) + ' '+ curSym;
                                var salestotalprev = numberFormatter.formatInteger(item.salestotalprev) + ' '+ curSym;
                            }               
                                rws += '<tr><td>'+item.account_code+'</td><td>'+item.name+'</td><td>'+salestotal+'</td><td>'+salestotalprev+'</td><td>'+item.variation+'</td><td>'+item.performance+'</td></tr>';
                            });
                            $('.topflop-loader').hide();
                            $('.top-flop-res').empty().append(rws);
                            tabl.show();
                        }
                        else{
                            $('.topflop-loader').hide();
                            $('.top-flop-res').empty().append('<tr><td colspan="6">'+_trans('datatables.data.no_record_found.label')+'</td></tr>'); 
                            tabl.show();  
                        }                        
                    }
                }
        }    
    });
});     