var options = {packages: ['corechart'], callback : drawChart};
google.load('visualization', '1', options);
function drawChart() {
require(['jquery'], function ($) {            
    $(function() {
        $('.salesovertime-loader').show();
        $.ajax({
            url: $('.dashboard_sales_over_time_url').val(),
            type: 'POST',
            success: function (response) {
                    ajaxCallFunction(response);  
                }
            });            
            $('#part_index_select').on('change', function() {  
                var data = {request : $(this).val()};
                $('.salesovertime-loader').show();
                $.ajax({
                    type: "POST",
                    url: $('.dashboard_sales_over_time_url').val(),
                    data: data, 
                    success: function (response)
                    {
                        ajaxCallFunction(response);
                    }
                });
            });   
            function ajaxCallFunction(response){
                obj = JSON.parse(response);
                if(obj['err'] == 1){
                    $('.salesovertime-loader').hide();
                    $('.dashboard-salesovertime-tab').hide();
                    $('.err-salesovertime').show();                     
                }
                else{
                    stringToReplace = obj['sales_over_time_data'];
                    replace1 = stringToReplace.replace(/\[/gi, '["');
                    replace2 = replace1.replace(/\,/gi, '",');
                    finalString = replace2.replace(/\]",/gi, '],');

                    var data = new google.visualization.DataTable();  
                    data.addColumn('string', 'Element');  
                    data.addColumn('number', 'Sales Over Time');
                    var stringData = '['+finalString+']';
                    data.addRows(JSON.parse(stringData));
                    var view = new google.visualization.DataView(data);
                    var options = {
                      title: "",
                      width:600,
                    };
                    options.legend = 'none';
                    var chart = new google.visualization.ColumnChart(document.getElementById("columnchart"));              
                    var result = "<option value='0'>- Select -</option>";
                    $.each(obj['part_index_data'], function(key, value) {
                        var sel = '';
                        if(obj['partIndexId'] == key){
                            var sel = 'selected';
                        }
                        result += "<option value="+key+" "+sel+">"+value+"</option>";
                    });
                    $('.salesovertime-loader').hide();
                    $('.dashboard-salesovertime-tab').show();
                    $('#part_index_select').empty().append(result);
                    chart.draw(view, options); 
                }
            }            
        });  
    });
}   