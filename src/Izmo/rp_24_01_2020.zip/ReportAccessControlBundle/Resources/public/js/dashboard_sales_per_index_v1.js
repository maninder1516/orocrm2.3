require(['jquery', 'orolocale/js/formatter/number','orolocale/js/locale-settings','orotranslation/js/translator','oroconfig/js/configuration'], function ($, numberFormatter,localeSettings,_trans,config) {
    $(document).ready(function () {
        var isCurSymPrep =  config.get('is-currency-symbol-prepend');    
        var curSym = localeSettings.getCurrencySymbol();
        var tabl = $('.dashboard-sales-per-index-tab'); 
        tabl.hide(); 
        $('.salesperindex-loader').show();
        $.ajax({
            url: $('.dashboard_sales_per_index_url').val(),
            type: 'POST',
            success: function (resp) {
                ajaxCallFunction(resp);                  
            }
        });
        
        $('#dashboard_sales_per_index_select').on('change', function() {
            $('.salesperindex-loader').show();
            $.ajax({
                  type: "POST",
                  url: $('.dashboard_sales_per_index_url').val(),
                  data: {'salestype': $(this).val()}, 
                  success: function (resp)
                  {
                      ajaxCallFunction(resp); 
                  }
            });
        });
        
        function ajaxCallFunction(resp){
            var res;
               if ($.trim(resp) && (res = JSON.parse(resp)))
                {
                    if(res['err'] == 1){
                        $('.salesperindex-loader').hide();
                        tabl.hide();
                        $('.err-salesperindex').show();                                            
                    }else{ 
                        if(res != ''){
                            var rws = '';  
                            $.each(res, function (i, item) {                       
                            if(isCurSymPrep){
                                if(item.partindex == '05' || item.partindex == '15' || item.partindex == '25'){
                                    var actual = numberFormatter.formatInteger(item.actual);
                                    var projection = numberFormatter.formatInteger(item.projection);
                                    var actualprev = numberFormatter.formatInteger(item.actualprev);
                                    var actual_yearly = numberFormatter.formatInteger(item.actual_yearly);
                                    var projection_yearly = numberFormatter.formatInteger(item.projection_yearly);
                                }else{
                                    var actual = curSym + ''+ numberFormatter.formatInteger(item.actual);
                                    var projection = curSym + ''+ numberFormatter.formatInteger(item.projection);
                                    var actualprev = curSym + ''+ numberFormatter.formatInteger(item.actualprev);
                                    var actual_yearly = curSym + ''+ numberFormatter.formatInteger(item.actual_yearly);
                                    var projection_yearly = curSym + ''+ numberFormatter.formatInteger(item.projection_yearly);
                                }
                            }
                            else{
                                if(item.partindex == '05' || item.partindex == '15' || item.partindex == '25'){
                                    var actual = numberFormatter.formatInteger(item.actual);
                                    var projection = numberFormatter.formatInteger(item.projection); 
                                    var actualprev = numberFormatter.formatInteger(item.actualprev);
                                    var actual_yearly = numberFormatter.formatInteger(item.actual_yearly);
                                    var projection_yearly = numberFormatter.formatInteger(item.projection_yearly);
                                }else{
                                    var actual = numberFormatter.formatInteger(item.actual) + ' '+ curSym;
                                    var projection = numberFormatter.formatInteger(item.projection) + ' '+ curSym; 
                                    var actualprev = numberFormatter.formatInteger(item.actualprev) + ' '+ curSym;
                                    var actual_yearly = numberFormatter.formatInteger(item.actual_yearly) + ' '+ curSym;
                                    var projection_yearly = numberFormatter.formatInteger(item.projection_yearly) + ' '+ curSym;
                                }
                            }                        
                                rws += '<tr><td>'+item.partindex+'</td><td>'+item.index_description+'</td><td>'+actual+'</td><td>'+projection+'</td><td>'+actualprev+'</td><td>'+item.performance+'</td><td>'+actual_yearly+'</td><td>'+projection_yearly+'</td><td>'+item.performance_yearly+'</td></tr>';
                            });
                            $('.salesperindex-loader').hide();
                            $('.sales-per-index-res').empty().append(rws);                   
                            tabl.show();                  
                        }
                        else{
                            $('.salesperindex-loader').hide();
                            $('.sales-per-index-res').empty().append('<tr><td colspan="5">'+_trans('datatables.data.no_record_found.label')+'</td></tr>'); 
                            tabl.show();   
                        }
                        
                    }
                }    
        }
        
    });
});       