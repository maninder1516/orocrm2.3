 require(['jquery','orolocale/js/formatter/datetime'],function($,dateFormatter){
              $(document).ready(function () {
                        $("#appointment_date").datepicker({
                            changeMonth: true, 
                            changeYear: true,
                            showButtonPanel: true     
                        });
                        $('.filtrsrch').click(function () {
                            if($('#appointment_date').val() != ''){
                                $('.appointment_dat_flg').val(dateFormatter.convertDateToBackendFormat($('#appointment_date').val()));
                              }
                            return true;
                        });
                   });
            });