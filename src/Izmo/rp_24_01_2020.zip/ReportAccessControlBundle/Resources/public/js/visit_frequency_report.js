require(['jquery', 'orolocale/js/formatter/datetime'], function ($, dateFormatter) {
    $(document).ready(function () {

        $("#from_date").datepicker({
            changeMonth: true, //this option for allowing user to select month
            changeYear: true,
            showButtonPanel: true //this option for allowing user to select from year range    
        });

        $("#to_date").datepicker({
            changeMonth: true, //this option for allowing user to select month
            changeYear: true,
            showButtonPanel: true //this option for allowing user to select from year range    
        });

        $('.filtrsrch').click(function () {
            if ($('#from_date').val() !== '') {
                $('.from_dat_flg').val(dateFormatter.convertDateToBackendFormat($('#from_date').val()));
            }
            if ($('#to_date').val() !== '') {
                $('.to_dat_flg').val(dateFormatter.convertDateToBackendFormat($('#to_date').val()));
            }
            return true;
        });

        $('#export').click(function () {
            if ($('#from_date').val() !== '') {
                $('.from_dat_flg').val(dateFormatter.convertDateToBackendFormat($('#from_date').val()));
            }
            if ($('#to_date').val() !== '') {
                $('.to_dat_flg').val(dateFormatter.convertDateToBackendFormat($('#to_date').val()));
            }
            var client_name = $("#client_name").val();
            var salesman_name = $("#salesman_name").val();
            var client_code = $("#client_code").val();
            var from_dat_flg = $("#from_dat_flg").val();
            var to_dat_flg = $("#to_dat_flg").val();
            var url = $("#url").val();
            url += "?client_name=" + client_name + "&salesman_name=" + salesman_name + "&client_code=" + client_code + "&from_dat_flg=" + from_dat_flg + "&to_dat_flg=" + to_dat_flg;
            window.open(url, "_blank");
        });

    });
});