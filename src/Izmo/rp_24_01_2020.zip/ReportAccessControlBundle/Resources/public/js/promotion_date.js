require(['jquery','orolocale/js/formatter/datetime'],function($,dateFormatter){
              $(document).ready(function () {
                        $("#startdate").datepicker({
                            changeMonth: true, //this option for allowing user to select month
                            changeYear: true,
                            showButtonPanel: true //this option for allowing user to select from year range    
                        });
                        $('.filtrsrch').click(function () {
                            if($('#startdate').val() != ''){
                                $('.promo_dat_flg').val(dateFormatter.convertDateToBackendFormat($('#startdate').val()));
                             }
                            return true;
                        });
                   });
            });