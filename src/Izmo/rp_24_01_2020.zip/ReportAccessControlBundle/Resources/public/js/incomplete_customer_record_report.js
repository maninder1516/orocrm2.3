require(['jquery'], function ($) {
    $(document).ready(function() { 
        $('.loading_img_div').hide();  
        $('#next').click(function () { 
            var pre = parseInt($('#prevData').val());
            var next = parseInt($('#nextData').val());            
            var prev = pre + next;            
            var data = {'prev' : prev,'next' : next};
            getAjaxContent(data);
        });   
        $('#prev').click(function () { 
            var pre = parseInt($('#prevData').val());
            var next = parseInt($('#nextData').val());            
            var prev = pre - next;            
            var data = {'prev' : prev,'next' : next};
            getAjaxContent(data);
        });        
        function getAjaxContent(data){
            $('.loading_img_div').show();
            $.ajax({
                type: "POST",
                data: data,
                dataType: "json",
                url: $('.incomplete_customer_record_report').val(),
                success: function (response)
                {                       
                    var trHTML = '';
                    if(response['report'] != ''){
                        $.each(response['report'], function (i, item) {               
                            trHTML += '<tr><td>' + item.client + '</td><td>' + item.salesman + '</td><td>' + item.empty_fields + '</td></tr>';
                        });
                        $('#daf tbody').empty().append(trHTML);
                        $('#prevData').val(response['page']['lowerLimit']);
                    }
                    $('.loading_img_div').hide();
                }
            });
        }
    });
}); 