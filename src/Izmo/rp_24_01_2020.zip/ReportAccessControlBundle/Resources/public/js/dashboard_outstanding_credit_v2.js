require(['jquery','orotranslation/js/translator'], function ($,_trans) {
    $(document).ready(function () {
        var tabl = $('.dashboard-outstanding-tab'); 
        tabl.hide();
        $('.outstandingcredit-loader').show();
        $.ajax({
            url: $('.dashboard_outstanding_url').val(),
            type: 'POST',
            success: function (resp) {
                ajaxCallFunction(resp); 
            }
        });
        
        $('#dashboard_outstanding_select').on('change', function() {
            $('.outstandingcredit-loader').show();
            $.ajax({
                  type: "POST",
                  url: $('.dashboard_outstanding_url').val(),
                  data: {'salestype': $(this).val()}, 
                  success: function (resp){
                      ajaxCallFunction(resp); 
                  }
            });
        });
        
        function ajaxCallFunction(resp){
            var res;
            if ($.trim(resp) && (res = JSON.parse(resp)))
            {
                if(res['err'] == 1){
                    $('.outstandingcredit-loader').hide();
                    tabl.hide();
                    $('.err-outstandingcredit').show();                                            
                }else{
                    if(res != ''){
                        var rws = '';  
                        $.each(res, function (i, item) {
                            rws += '<tr><td>'+item.account_code+'</td><td>'+item.client+'</td><td>'+item.available+'</td><td>'+item.daysLeft+'</td></tr>';
                        });
                        $('.outstandingcredit-loader').hide();
                        $('.outstanding-res').empty().append(rws);
                        tabl.show();
                    }
                    else{
                        $('.outstandingcredit-loader').hide();
                        $('.outstanding-res').empty().append('<tr><td colspan="4">'+_trans('datatables.data.no_record_found.label')+'</td></tr>'); 
                        tabl.show();  
                    }                        
                }
            }
        }  
    });
});
        
