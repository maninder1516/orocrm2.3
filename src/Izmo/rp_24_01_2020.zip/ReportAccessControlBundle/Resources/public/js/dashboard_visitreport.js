        require(['jquery'], function ($) {
            $( document ).ready(function() {
                $('.visit-report-tab').hide();
                $('.visitreport-loader').show();               
                $.ajax({
                    url: $('.dashboard_visitreport_url').val(),
                    type: 'GET',
                    success: function (resp) {
                       var obj;
                       if ($.trim(resp) && (obj = JSON.parse(resp)))
                    {     
                        var accCnt = parseInt(obj['acc_cnt']);
                        var therticalCnt = parseInt(obj['theoretical_visits'])
                        var clientVisitCnt = parseInt(obj['client_visit_cnt']);
                        $('.visitreport-loader').hide();
                        $('.noofclients').html(parseInt(accCnt));
                        $('.clientsvisited').html(parseInt(clientVisitCnt));
                        $('.noofvisits').html(parseInt(obj['evnt_cnt']));
                        $('.noofvisitsmissed').html(parseInt(obj['missed_cnt']));
                        $('.noofreportscreated').html(parseInt(obj['report_cnt']));
                        $('.theoreticalvisited').html(parseInt(therticalCnt));
                        $('.performance').html((clientVisitCnt > 0 && therticalCnt > 0)? parseInt(Math.round((clientVisitCnt/therticalCnt)*100)):0);
                        $('.visit-report-tab').show();
                    }
                    else{
                        $('.visitreport-loader').hide();
                        $('.visit-report-tab').hide();
                        $('.no_visitreport').css({'display':'block'});
                    }
                    },
                    error: function(err){
                        console.log("error occured");
                    }
                });
            });
        });
        