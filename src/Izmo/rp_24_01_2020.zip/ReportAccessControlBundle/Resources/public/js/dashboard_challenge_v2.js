require(['jquery','orotranslation/js/translator',], function ($,_trans) {
    $(document).ready(function () {
        var tabl = $('.dashboard-challenge-tab'); 
        tabl.hide();
        var colsProp = [];
        var tabColsRef = $('.dashboard-challenge-thead-tr');
        tabColsRef.each(function () {
                $('th', this).each(function (i) {
                    colsProp[i] = $(this).attr('class');
                });
            });       
        $('.challenge-loader').show();
        $.ajax({
            url: $('.dashboard_challenge_url').val(),
            type: 'POST',
            success: function (resp) {
               var res;
               if ($.trim(resp) && (res = JSON.parse(resp)))
                {
                    if(res['err'] == 1){
                        $('.challenge-loader').hide();
                        tabl.hide();
                        $('.err-challenge').show();                                            
                    }else{                    
                    var rws = '';  
                    $.each(res, function (i, item) {
                        var tds = '';
                        var col = 0;
                        $.each(item, function (j, ir) {
                            ir = (ir == null)? '': ir;
                            var td = '<td class="'+colsProp[col]+'">';
                            tds += (j != 'ind') ? td+ir+"</td>" : td+"<span class='indicator " + ir + "'></span></td>";
                            col++;
                        });
                        rws += '<tr>'+tds+'</tr>';
                    });
                    $('.challenge-loader').hide();
                    $('.challenge-res').empty().append(rws);
                    tabl.show();
                }
            }
            else{
                $('.challenge-loader').hide();
                $('.challenge-res').empty().append('<tr><td colspan="6">'+_trans('datatables.data.no_record_found.label')+'</td></tr>'); 
                tabl.show(); 
            }
        },
        error: function(err){
            console.log("error occured");
        }
        });
    });
});   