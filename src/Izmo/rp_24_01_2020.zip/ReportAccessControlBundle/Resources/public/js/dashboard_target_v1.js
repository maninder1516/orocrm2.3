require(['jquery', 'orolocale/js/formatter/number','orolocale/js/locale-settings','orotranslation/js/translator','oroconfig/js/configuration'], function ($, numberFormatter,localeSettings,_trans,config) {
    $(document).ready(function () {
        var isCurSymPrep =  config.get('is-currency-symbol-prepend');    
        var curSym = localeSettings.getCurrencySymbol(); 
        var tabl = $('.dashboard-target-tab'); 
        tabl.hide(); 
        $('.target-loader').show();
        $.ajax({
            url: $('.dashboard_target_url').val(),
            type: 'POST',
            success: function (resp) {
               ajaxCallFunction(resp);
            }
        });
        
        $('#dashboard_target_select').on('change', function() {
            $('.target-loader').show();
            $.ajax({
                  type: "POST",
                  url: $('.dashboard_target_url').val(),
                  data: {'salestype': $(this).val()}, 
                  success: function (resp){
                      ajaxCallFunction(resp); 
                  }
            });
        });
        
        function ajaxCallFunction(resp){
           var res;
            if ($.trim(resp) && (res = JSON.parse(resp)))
             {
                 if(res['err'] == 1){
                     $('.target-loader').hide();
                     tabl.hide();
                     $('.err-target').show();                                            
                 }else{ 
                     var rws = '';  
                     $.each(res, function (i, item) {                        
                         if(isCurSymPrep){
                             var actual = curSym + ''+ numberFormatter.formatInteger(item.actual);
                             var projection = curSym + ''+ numberFormatter.formatInteger(item.projection);
                             var goalSales = curSym + ''+ numberFormatter.formatInteger(item.goalSales);
                         }
                         else{
                             var actual = numberFormatter.formatInteger(item.actual) + ' '+ curSym;
                             var projection = numberFormatter.formatInteger(item.projection) + ' '+ curSym;
                             var goalSales = numberFormatter.formatInteger(item.goalSales) + ' '+ curSym;
                         }
                         rws += '<tr><td>'+_trans(item.targetName)+'</td><td>'+actual+'</td><td>'+goalSales+'</td><td>'+item.projpercent+'</td><td>'+projection+'</td><td>'+item.indicator+'</td><td>'+item.history+'</td></tr>'; 
                     });
                     $('.target-loader').hide();
                     $('.target-res').empty().append(rws);
                     tabl.show();
                 }
             } 
        }    
    });
});        