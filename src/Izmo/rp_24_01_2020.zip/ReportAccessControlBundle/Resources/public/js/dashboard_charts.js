google.load("visualization", "1", {packages:["gauge"]});
        require(['jquery', 'orolocale/js/formatter/number','orolocale/js/locale-settings','orotranslation/js/translator','oroconfig/js/configuration'], function ($, numberFormatter,localeSettings,_trans,config) {
            $( document ).ready(function() {
                var curSym = localeSettings.getCurrencySymbol();
                var actualPRC, estimatedPRC, goalPRC, rafPRC, actualQTYPneu, estimatedQTYPneu, 
                goalQTYPneu, rafQTYPneu, actualQTYLub,res,
                 estimatedQTYLub, goalQTYLub, rafQTYLub, actualFL, estimatedFL, goalFL, rafFL,
                 guageValuePRC, guageValueQTYPneu, guageValueQTYLub, guageValueFL;
                var isCurSymPrep =  config.get('is-currency-symbol-prepend');
                  $('.main_chrt_tab').hide();
                 $.ajax({
                    url: $('.dashboard_chrt_url').val(),
                    type: 'GET',
                    success: function (response) {
                        var res;
                        if ($.trim(response) && (res = JSON.parse(response)))
                        {res = JSON.parse(response);
                        actualPRC = parseInt(res['actualPRC']);
                        estimatedPRC = parseInt(res['estimatedPRC']);
                        goalPRC = parseInt(res['goalPRC']);
                        actualQTYPneu = parseInt(res['actualQTYPneu']);
                        estimatedQTYPneu = parseInt(res['estimatedQTYPneu']);
                        goalQTYPneu = parseInt(res['goalQTYPneu']);
                        actualQTYLub = parseInt(res['actualQTYLub']);
                        estimatedQTYLub = parseInt(res['estimatedQTYLub']);
                        goalQTYLub = parseInt(res['goalQTYLub']);
                        actualFL = parseInt(res['actualFL']);
                        estimatedFL = parseInt(res['estimatedFL']);
                        goalFL = parseInt(res['goalFL']);
                        rafPRC = (actualPRC > goalPRC) ? 0 : goalPRC - actualPRC;
                        rafQTYPneu = (actualQTYPneu > goalQTYPneu) ? 0 : goalQTYPneu - actualQTYPneu;  
                        rafQTYLub = (actualQTYLub > goalQTYLub) ? 0 : goalQTYLub - actualQTYLub;                
                        rafFL = (actualFL > goalFL) ? 0 : goalFL - actualFL;
                        guageValuePRC = (goalPRC > 0) ? Math.round(((estimatedPRC / goalPRC) * 100)) : 0;
                        guageValueQTYPneu = (goalQTYPneu > 0) ? Math.round(((estimatedQTYPneu / goalQTYPneu) * 100)) : 0;
                        guageValueQTYLub = (goalQTYLub > 0) ? Math.round(((estimatedQTYLub / goalQTYLub) * 100)) : 0;
                        guageValueFL = (goalFL > 0) ? Math.round(((estimatedFL / goalFL) * 100)) : 0 ; 
                        $('.main_chrt_tab').show();
                        displaychart();
                    }
                    else{
                        $('.main_chrt_tab').hide();
                        $('.no_chrt_data').show();
                    }
                    },
                    error: function(err){
                        console.log("error occured");
                    }
                });
                function displaychart(){
                    var chrtProp = { width: 150, height: 150, redFrom: 0, redTo: 80, yellowFrom: 80.01, yellowTo: 99, greenFrom: 99.01, greenTo: 150, min: 0, max: 150, majorTicks: 15 }; 
                    var chrtHdr = ['Label', 'Value'];
                    var formatter = new google.visualization.NumberFormat({suffix: '%',pattern: '#'});                    
                    var chartPRC = new google.visualization.Gauge($('.prc_stat').get(0));
                    var chartQTYPneu = new google.visualization.Gauge($('.qty_tires_stat').get(0));
                    var chartQTYLub = new google.visualization.Gauge($('.qty_lub_stat').get(0));
                    var chartFL = new google.visualization.Gauge($('.flro_stat').get(0));
                    var dataPRC = google.visualization.arrayToDataTable([chrtHdr,
                        [_trans('izmo.reports.dashboard.quadchart.prclabel'), guageValuePRC]]);    
                    var dataQTYPneu = google.visualization.arrayToDataTable([chrtHdr,
                        [_trans('izmo.reports.dashboard.quadchart.qtypneulabel'), guageValueQTYPneu]
                      ]);
                    var dataQTYLub = google.visualization.arrayToDataTable([chrtHdr,
                        [_trans('izmo.reports.dashboard.quadchart.qtylublabel'), guageValueQTYLub]
                      ]); 
                    var dataFL = google.visualization.arrayToDataTable([chrtHdr,
                        [_trans('izmo.reports.dashboard.quadchart.fllabel'), guageValueFL]
                      ]);  
                    formatter.format(dataPRC, 1); 
                    formatter.format(dataQTYPneu, 1); 
                    formatter.format(dataQTYLub, 1); 
                    formatter.format(dataFL, 1); 
                    chartPRC.draw(dataPRC, chrtProp );
                    chartQTYPneu.draw(dataQTYPneu, chrtProp );
                    chartQTYLub.draw(dataQTYLub, chrtProp );
                    chartFL.draw(dataFL, chrtProp );
                     var cur = 1 , qty = 0;
                     formatNumCurrOrQty(actualPRC,cur,$('.actual_prc'));  
                     formatNumCurrOrQty(estimatedPRC,cur,$('.est_prc'));
                     formatNumCurrOrQty(goalPRC,cur,$('.goal_prc'));
                     formatNumCurrOrQty(rafPRC,cur,$('.raf_prc'));
                     formatNumCurrOrQty(actualQTYPneu,qty,$('.actual_qty_tires'));
                     formatNumCurrOrQty(estimatedQTYPneu,qty,$('.est_qty_tires'));
                     formatNumCurrOrQty(goalQTYPneu,qty,$('.goal_qty_tires'));
                     formatNumCurrOrQty(rafQTYPneu,qty,$('.raf_qty_tires'));
                     formatNumCurrOrQty(actualQTYLub,qty,$('.actual_qty_lub'));  
                     formatNumCurrOrQty(estimatedQTYLub,qty,$('.est_qty_lub'));
                     formatNumCurrOrQty(goalQTYLub,qty,$('.goal_qty_lub'));
                     formatNumCurrOrQty(rafQTYLub,qty,$('.raf_qty_lub'));
                     formatNumCurrOrQty(actualFL,cur,$('.actual_fl'));
                     formatNumCurrOrQty(estimatedFL,cur,$('.est_fl'));
                     formatNumCurrOrQty(goalFL,cur,$('.goal_fl'));
                     formatNumCurrOrQty(rafFL,cur,$('.raf_fl'));
                }
                function formatNumCurrOrQty(num,curr,el){
                    return (curr == 1) ? ((isCurSymPrep)? (el.html(curSym + ''+ numberFormatter.formatInteger(num))) : (el.html(numberFormatter.formatInteger(num)+ ' ' + curSym))) : (el.html(numberFormatter.formatInteger(num)));
                   }
            });
        });