var options = {packages: ['corechart'], callback : drawChart};
google.load('visualization', '1', options);
function drawChart() {
    require(['jquery','orotranslation/js/translator'], function ($,trans) {
        $(document).ready(function() {
            
            clickFlag=0;
            $.each(['show', 'hide'], function (i, ev) {
                var el = $.fn[ev];
                $.fn[ev] = function () {
                  this.trigger(ev);
                  return el.apply(this, arguments);
                };
            });
            $('#divLayout').hide();
           
            $('#loading').on('hide', function() {
               $('#divLayout').show();
            });
            
            $('#loading_chart').css('display','');
            salesman=$('.salesmanfilter').val();
            code=$('.codefilter').val();
            client=$('.clientfilter').val();
            urlPath=$('#urlPath').val();
            $.ajax({
                url: urlPath,
                type: 'POST',
                data: {'salesman':salesman,'code':code,'client':client},
                dataType: 'json',
                success: function (data) {
                    if(data.error==1){
                        $('#loading_chart').css('display','none');
                        $('.no_record_exist').show();
                    }else if(data.clientFidelityGraphRecord !=''){
                       var chartData = [];
                       recordData=data.clientFidelityGraphRecord;
                       
                       chartData.push(['Type', "'"+trans('izmo.reports.performance_reports.client_fidelity_report.faithful')+"'","'"+trans('izmo.reports.performance_reports.client_fidelity_report.toactivate')+"'",
                                        "'"+trans('izmo.reports.performance_reports.client_fidelity_report.toretain')+"'",{ role: 'annotation' }]);
                       
                        
                        for(var key in recordData){
                            month_name=trans(recordData[key]['month_name']);
                            chartData.push([month_name,parseInt(recordData[key]['Faithful']),parseInt(recordData[key]['To Activate']),parseInt(recordData[key]['To Retain']),'']);
                        }
                        
                        var reord = google.visualization.arrayToDataTable(chartData);
                        $('#loading_chart').css('display','none');
                        var options = {width: 1000,height: 400,legend: { position: 'top', maxLines: 3 },bar: { groupWidth: '75%' },isStacked: true,};
                        var chart = new google.visualization.ColumnChart(document.getElementById('chart_div')); 
                        chart.draw(reord, options);
                    }else{
                        $('#loading_chart').css('display','none');
                        $('.no_record_exist').show();
                    }
                }
            });
        });
    });
}