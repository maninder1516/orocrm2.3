require(['jquery'], function ($)
{
    $(document).ready(function () {
        $('.productsel').change(function () {
            var route_sel = $(this).val();
            var baseUrl = $('.dt-datatab-info').attr('base-url');
            if (route_sel != '') {
                $(location).attr('href', encodeURI(baseUrl + "?product_type=" + route_sel));
            }
        });
    });
});