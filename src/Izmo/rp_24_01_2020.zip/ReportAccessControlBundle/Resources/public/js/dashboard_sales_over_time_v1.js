var options = {packages: ['corechart'], callback : drawChart};
google.load('visualization', '1', options);
function drawChart() {
require(['jquery', 'orolocale/js/formatter/number','orolocale/js/locale-settings','orotranslation/js/translator','oroconfig/js/configuration'], function ($, numberFormatter,localeSettings,trans,config) {           
    $(function() {
        $('.salesovertime-loader').show();
        $.ajax({
            url: $('.dashboard_sales_over_time_url').val(),
            type: 'POST',
            success: function (response) {
                    ajaxCallFunction(response);  
                }
            });            
            $('#part_index_select').on('change', function() {  
                var data = {request : $(this).val()};
                $('.salesovertime-loader').show();
                $.ajax({
                    type: "POST",
                    url: $('.dashboard_sales_over_time_url').val(),
                    data: data, 
                    success: function (response)
                    {
                        ajaxCallFunction(response);
                    }
                });
            });   
            function ajaxCallFunction(response){
                obj = JSON.parse(response);
                if(obj['err'] == 1){
                    $('.salesovertime-loader').hide();
                    $('.dashboard-salesovertime-tab').hide();
                    $('.err-salesovertime').show();                     
                }
                else{
                    var decimalOptions = localeSettings.getNumberFormats('decimal');              
                    var decimal_separator = decimalOptions.decimal_separator_symbol;
                    var group_separator = decimalOptions.grouping_separator_symbol;
                    
                    stringToReplace = obj['sales_over_time_data'];
                    replace1 = stringToReplace.replace(/\[/gi, '["');
                    replace2 = replace1.replace(/\,/gi, '",');
                    finalString = replace2.replace(/\]",/gi, '],');

                    var data = new google.visualization.DataTable();  
                    var title = trans('izmo.reports.dashboard.salesovertime.label');
                    data.addColumn('string', 'Element');  
                    data.addColumn('number', title);
                    var stringData = '['+finalString+']';
                    data.addRows(JSON.parse(stringData));
                    var view = new google.visualization.DataView(data);
                    var curSym = localeSettings.getCurrencySymbol();
                    var isCurSymPrep =  config.get('is-currency-symbol-prepend');
                    var chart = new google.visualization.ColumnChart(document.getElementById("columnchart"));                   
                    if(isCurSymPrep == 'false'){
                        var formatter = new google.visualization.NumberFormat({
                            prefix: curSym,
                            decimalSymbol: decimal_separator, 
                            groupingSymbol: group_separator,
                            fractionDigits: 0
                        });                        
                    }
                    else{
                        var formatter = new google.visualization.NumberFormat({
                            suffix: curSym,
                            decimalSymbol: decimal_separator, 
                            groupingSymbol: group_separator,
                            fractionDigits: 0
                        });
                    }   
                    var columnRange = data.getColumnRange(1);    
                    var total = columnRange.max;
                    var divide = 5;
                    if(total === null)
                    {
                    var base = 100 / divide;
                    }
                    else{
                    var base = total / divide;    
                    }
                    var ticks = [];
                    for(var i = 0; i <= divide+2; i++) {
                        var x = Math.round(i * base);
                      ticks.push({
                        v: x,
                        f: formatter.formatValue(x)
                      });
                    }
                    var options = {
                        title: "",
                        width:600,
                        vAxis: {
                          ticks: ticks,
                        }                          
                    };
                    options.legend = 'none';    
                    formatter.format(data, 1);
                    var result = "<option value='0'>- "+trans('izmo.reports.dashboard.select.label')+" -</option>";
                    $.each(obj['part_index_data'], function(key, value) {
                        var sel = '';
                        if(obj['partIndexId'] == key){
                            var sel = 'selected';
                        }
                        result += "<option value="+key+" "+sel+">"+value+"</option>";
                    });
                    $('.salesovertime-loader').hide();
                    $('.dashboard-salesovertime-tab').show();
                    $('#part_index_select').empty().append(result);
                    chart.draw(view, options); 
                }
            }            
        });  
    });
}   