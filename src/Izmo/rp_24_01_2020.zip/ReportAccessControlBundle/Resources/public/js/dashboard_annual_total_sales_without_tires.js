var options = {packages: ['gauge'], callback : drawChart};
google.load('visualization', '1', options);
function drawChart() {
require(['jquery', 'orolocale/js/formatter/number','orolocale/js/locale-settings','orotranslation/js/translator','oroconfig/js/configuration'], function ($, numberFormatter,localeSettings,_trans,config) {            
    $(function() {
        var obj, goalValue, actualValue, estimatedValue, tmpActualValue; 
        $('.annual-loader').show();
        $.ajax({
            url: $('.annual_total_sales_without_tires').val(),
            type: 'POST',
            success: function (response) {
                    ajaxCallFunction(response); 
                }
        });
            
        $('#annual_total_sales_select').on('change', function() {
            $('.annual-loader').show();
            $.ajax({
                  type: "POST",
                  url: $('.annual_total_sales_without_tires').val(),
                  data: {'salestype': $(this).val()}, 
                  success: function (response)
                  {
                      ajaxCallFunction(response); 
                  }
            });
        }); 
                 
        function ajaxCallFunction(response){              
            obj = JSON.parse(response);
                if(obj['err'] == 1){
                    $('.annual-loader').hide();
                    $('#statisticsDiv').hide();
                    $('#legendsDiv').hide();
                    $('.dashboard-annual-tab').hide();
                    $('.err-annual').show();                        
                }else{                        
                    $('.err-annual').hide();
                    actualValue = parseInt(obj['actualVal']);
                    estimatedValue = parseInt(obj['estimationVal']);
                    goalValue = parseInt(obj['targetVal']);
                    tmpActualValue = (estimatedValue>0 && goalValue>0) ? parseInt(Math.round(((estimatedValue / goalValue) * 100))) : 0; 

                    var chrtProp = {width: 200, height: 200, redFrom: 0.00, redTo: 90.00, yellowFrom: 90.01, yellowTo: 99.99, greenFrom: 100.00, greenTo: 150, min: 0, max: 150, majorTicks: 15};
                    var chrtHdr = ['Label', 'Value'];
                    var formatter = new google.visualization.NumberFormat({suffix: '%',pattern: '#'});
                    var chartPRC = new google.visualization.Gauge(document.getElementById('statisticsDiv'));
                    var dataPRC = google.visualization.arrayToDataTable([chrtHdr,
                        ['', tmpActualValue]]);
                    formatter.format(dataPRC, 1); 
                    var cur = 1;
                    formatNumCurrOrQty(actualValue,cur,$('#actualValue'));  
                    formatNumCurrOrQty(estimatedValue,cur,$('#estimationValue'));
                    formatNumCurrOrQty(goalValue,cur,$('#goalValue'));  
                    $('.annual-loader').hide();
                    $('.dashboard-annual-tab').show();
                    chartPRC.draw(dataPRC, chrtProp);                     
                }
        };
           
    });
    function formatNumCurrOrQty(num,curr,el){
        var isCurSymPrep =  config.get('is-currency-symbol-prepend');
        var curSym = localeSettings.getCurrencySymbol();
        return (curr == 1) ? ((isCurSymPrep)? (el.html(curSym + ''+ numberFormatter.formatInteger(num))) : (el.html(numberFormatter.formatInteger(num)+ ' ' + curSym))) : (el.html(numberFormatter.formatInteger(num)));
    }   
 });
}                   