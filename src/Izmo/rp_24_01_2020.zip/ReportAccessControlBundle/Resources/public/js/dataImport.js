require(['orolocale/js/formatter/datetime','routing','orotranslation/js/translator','moment'],function(dateFormatter,routing,trans,moment){
     var date_sel_err = trans('izmo.custom_date_filter.date_sel_error.label');
     var six_month_error = trans('izmo.reports.dataimport_report.six_month_period_only_error');
     var diff;
     var export_button = 1;
     var default_from_date = '-1m';
     var default_date_difference = 6;
        jQuery(document).ready(function () {                    
            function dateDiff(startdate, enddate) {
                var startdateMoment = moment(startdate);
                var enddateMoment = moment(enddate);
                if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
                  var years = enddateMoment.diff(startdateMoment, 'years');
                  var months = enddateMoment.diff(startdateMoment, 'months') - (years * 12);
                  startdateMoment.add(years, 'years').add(months, 'months');
                  var days = enddateMoment.diff(startdateMoment, 'days')
                  return {
                    years: years,
                    months: months,
                    days: days
                  };
                }
                else {
                  return undefined;
                }
            }            
                var date2 = new Date();
                jQuery(".platform").focus();
                var date1 = jQuery('#from_date').datepicker('getDate');
                    jQuery("#from_date").datepicker({
                            changeMonth: true, 
                            changeYear: true,
                            showButtonPanel: true,
                            maxDate: new Date(),
                            defaultDate: default_from_date,
                            onSelect: function() {
                            jQuery("#to_date").datepicker('option',"minDate",jQuery('#from_date').datepicker('getDate'));
                            jQuery('#to_date').removeClass('error-fields');
                            jQuery('#from_date').removeClass('error-fields');
                            jQuery('.error_messages').html("");
                                date1 = jQuery('#from_date').datepicker('getDate');
                                date2 = jQuery('#from_date').datepicker('getDate');
                                date2.setMonth(date2.getMonth()+ default_date_difference)
                                var result = validateDate();
                            return result;
                            } //onSelect
                        }).datepicker('option',"defaultDate",date1)

                        jQuery("#to_date").datepicker({
                            changeMonth: true, 
                            changeYear: true,
                            showButtonPanel: true,
                            defaultDate: new Date()
                        }).datepicker('option',"maxDate",date2).datepicker('option',"minDate",jQuery('#from_date').datepicker('getDate'));//.datepicker('option',"defaultDate",date2);//.datepicker("setDate",date2).datepicker('option',"maxDate",date2);
                        if(jQuery('#from_date').val() != ''){
                            jQuery('#from_date').datepicker("setDate",jQuery('#from_date').val());                          
                        }
                        else
                        {
                            jQuery('#from_date').datepicker("setDate",default_from_date);
                        }
                        if(jQuery('#to_date').val() != ''){
                            jQuery('#to_date').datepicker("setDate",jQuery('#to_date').val()).datepicker('option',"minDate",jQuery('#from_date').datepicker('getDate'));                          
                        }
                        else
                        {
                            jQuery('#to_date').datepicker("setDate",new Date()).datepicker('option',"minDate",jQuery('#from_date').datepicker('getDate'));
                        }
                        jQuery('#to_date').change(function () {
                            var result = validateDate();
                            return result;
                        });                        
                        function validateDate(){
                            if (jQuery('#from_date').val() && jQuery('#from_date').val()!="") {
                                var to_dateChk = dateFormatter.convertDateToBackendFormat(jQuery('#to_date').val());
                                var from_dateChk = dateFormatter.convertDateToBackendFormat(jQuery('#from_date').val());
                                diff = dateDiff(jQuery('#from_date').datepicker('getDate'),jQuery('#to_date').datepicker('getDate'));
                                console.log(diff);  
                                if (Date.parse(from_dateChk) > Date.parse(to_dateChk)) {
                                    jQuery('.error_messages').html(date_sel_err);
                                    jQuery('#to_date').addClass('error-fields');
                                    jQuery('#from_date').addClass('error-fields');
                                    jQuery('.filtrsrch').attr('disabled','disabled');
                                    jQuery('#export_data_import').attr('disabled','disabled');
                                    jQuery('#export_data_import').removeAttr("href");  
                                    export_button = 0;
                                    return false;
                                }
                                if(diff.months > default_date_difference || diff.years > 0 || (diff.months == default_date_difference && diff.days > 0) )// not less than six months
                                {                                    
                                    jQuery('.error_messages').html(six_month_error);
                                    jQuery('#to_date').addClass('error-fields');
                                    jQuery('#from_date').addClass('error-fields');
                                    jQuery('.filtrsrch').attr('disabled','disabled');
                                    jQuery('#export_data_import').attr('disabled','disabled');
                                    jQuery('#export_data_import').removeAttr("href");
                                    export_button = 0;
                                    return false;
                                }
                                else
                                {
                                    jQuery('#to_date').removeClass('error-fields');
                                    jQuery('#from_date').removeClass('error-fields');
                                    jQuery('.error_messages').html("");
                                    jQuery('.filtrsrch').prop('disabled', false);
                                    jQuery('#export_data_import').removeAttr("disabled");
                                    export_button = 1;    
                                }
                            } 
                        }                        
                        jQuery('.filtrsrch').click(function () {
                               if(jQuery('#from_date').val() != '' && jQuery('#to_date').val() != ''){
                                jQuery('.from_date_flg').val(dateFormatter.convertDateToBackendFormat(jQuery('#from_date').val()));
                                jQuery('.to_date_flg').val(dateFormatter.convertDateToBackendFormat(jQuery('#to_date').val()));
                              }
                              if(jQuery('.status').val() != ''){
                                jQuery('.status_flg').val(jQuery('.status').val());
                              }
                              if(jQuery('.platform').val() != ''){
                                jQuery('.platform_flg').val(jQuery('.platform').val());
                              }  
                            return true;
			});
                        jQuery('.data-imp-export-btn').click(function () {
                            if(export_button == 1){
                                try{
                                    if(jQuery('#from_date').val() != '' && jQuery('#to_date').val() != ''){
                                    jQuery('.from_date_flg').val(dateFormatter.convertDateToBackendFormat(jQuery('#from_date').val()));

                                    jQuery('.to_date_flg').val(dateFormatter.convertDateToBackendFormat(jQuery('#to_date').val()));
                                  }
                                  var fromDat = jQuery('.from_date_flg').val();
                                  var toDat =  jQuery('.to_date_flg').val();
                                  var plaq = jQuery('.platform').val();
                                  var stat = jQuery('.status').val();
                                  var urlRef = routing.generate('data_import_export', {from_date: fromDat, to_date: toDat,platform: plaq,'status':stat}, true);
                                  jQuery(this).attr('href', urlRef);
                                    }
                                    catch(e){
                                        console.log(e);
                                    }
                                }
                            });
        });
});