require(['jquery','orotranslation/js/translator',], function ($,_trans) {
    $(document).ready(function () {
        var tabl = $('.dashboard-promo-tab'); 
        tabl.hide();
        var colsProp = [];
        var tabColsRef = $('.dashboard-promo-thead-tr');
        tabColsRef.each(function () {
                $('th', this).each(function (i) {
                    colsProp[i] = $(this).attr('class');
                });
            });
        
        $('.promotion-loader').show();
        $.ajax({
            url: $('.dashboard_promos_url').val(),
            type: 'POST',
            success: function (resp) {
               var res;
               if ($.trim(resp) && (res = JSON.parse(resp)))
                {
                    if(res['err'] == 1){
                        $('.promotion-loader').hide();
                        tabl.hide();
                        $('.err-promo').show();                                            
                    }else{                      
                        var rws = '';  
                        $.each(res, function (i, item) {
                            var tds = '';
                            var col = 0;
                            $.each(item, function (j, ir) {
                                ir = (ir == null)? '': ir;
                                var td = '<td class="'+colsProp[col]+'">';
                                tds += (j != 'ind') ? td+ir+"</td>" : td+"<span class='indicator " + ir + "'></span></td>";
                                col++;
                            });
                            rws += '<tr>'+tds+'</tr>';
                        });
                        $('.promotion-loader').hide();
                        $('.promo-res').empty().append(rws);
                        tabl.show();
                    }
                }                
                else{
                    $('.promotion-loader').hide();
                    $('.promo-res').empty().append('<tr><td colspan="7">'+_trans('datatables.data.no_record_found.label')+'</td></tr>'); 
                    tabl.show(); 
                }
            },
            error: function(err){
                console.log("error occured");
            }
        });
    });
});  