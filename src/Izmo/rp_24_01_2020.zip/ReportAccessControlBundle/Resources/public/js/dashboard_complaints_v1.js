require(['jquery','orotranslation/js/translator',], function ($,_trans) {
    $(document).ready(function () {
        var colsProp = [];
        var tabl = $('.complaints-tab');
        var tbody = $('.complaints-res');
        tabl.hide();
        var tabColsRef = $('.complaints-thead-tr');
        tabColsRef.each(function () {
                $('th', this).each(function (i) {
                    colsProp[i] = $(this).attr('class');
                });
            });
        $('.complaints-loader').show();    
        $.ajax({
            url: $('.dashboard_complaints_url').val(),
            type: 'GET',
            success: function (resp) {
                var res;
                if ($.trim(resp) && (res = JSON.parse(resp)))
                {
                    if(res['err'] == 1){
                        $('.complaints-loader').hide();
                        tabl.hide();
                        $('.err-complaints').show();                                            
                    }else{                    
                        var rws = '';
                        $.each(res, function (i, item) {
                           var tds = '';
                            var col = 0;
                            $.each(item, function (j, ir) {
                                ir = (ir == null)? '': ir;
                                tds += '<td class="' + colsProp[col] + '">'+ir+'</td>';
                                col++;
                            });
                            rws += '<tr>'+tds+'</tr>';
                        });
                        $('.complaints-loader').hide();
                        tbody.empty().append(rws);
                        tabl.show();
                    }
                }else{
                    $('.complaints-loader').hide();
                    $('.complaints-res').empty().append('<tr><td colspan="6">'+_trans('datatables.data.no_record_found.label')+'</td></tr>'); 
                    tabl.show(); 
                }
            },
            error: function(err){
                console.log("error occured");
            }
        });
    });
});
        