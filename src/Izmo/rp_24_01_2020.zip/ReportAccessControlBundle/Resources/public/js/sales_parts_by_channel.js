require(['jquery'],function($){
                $(document).ready(function(){
                    $('.ref_code').attr('ref-cod-flg',0);
                    chkRef();
                    $('.filtrsrch').click(function(e){
                        e.stopPropagation();
                       return chkRef();
                    });
                    $('.export-blk a').click(function(e){
                        e.stopPropagation();
                        $('.ref_code').attr('ref-cod-flg');
                       return ($('.ref_code').attr('ref-cod-flg') == 0)?  false: true;
                    });
                    function chkRef(){
                    var cod = $('.ref_code').val();
                    if(cod == ''){
                        $('.parts-sales-channel-tab-div').hide();
                        $('.ref_code').addClass('err-bdr');
                        $('.err-sel-cod').show();
                        return false;
                    }
                    else{
                        $('.ref_code').attr('ref-cod-flg',1);
                        $('.err-sel-cod').hide();
                        $('.ref_code').removeClass('err-bdr');
                        return true;
                    }
                }
                });
            });