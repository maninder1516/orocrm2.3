        require(['jquery'], function ($) {
            $( document ).ready(function() {
                var obj,accCnt,clientVisitCnt;
                $('.visit-summary-tab').hide();
                $.ajax({
                    url: $('.visit_summary_url').val(),
                    type: 'GET',
                    success: function (resp) {
                       var obj;
                       if ($.trim(resp) && (obj = JSON.parse(resp)))
                    {
                        
                        accCnt = parseInt(obj['acc_cnt']);
                        therticalCnt=parseInt(obj['theoretical_visits'])
                        clientVisitCnt = parseInt(obj['client_visit_cnt']);
                        $('.acc_cnt').html(accCnt);
                        $('.client_visit_cnt').html(clientVisitCnt);
                        $('.evnt_cnt').html(parseInt(obj['evnt_cnt']));
                        $('.report_cnt').html(parseInt(obj['report_cnt']));
                        $('.missed_cnt').html(parseInt(obj['missed_cnt']));
                        $('.not_visit_cnt').html(accCnt - clientVisitCnt);
                        $('.theoretical_visited').html(therticalCnt);
                        $('.perfrmnc').html((clientVisitCnt > 0 && therticalCnt > 0)? parseInt(clientVisitCnt/therticalCnt):0);
                        $('.visit-summary-tab').show();
                    }
                    else{
                        $('.visit-summary-tab').hide();
                        $('.no_visits_tab').show();
                    }
                    },
                    error: function(err){
                        console.log("error occured");
                    }
                });
            });
        });
        