<?php 
namespace IZMO\ReportAccessControlBundle\Provider;

class Indicator{
    protected $container;
     
    public function __construct($container) {
        $this->container = $container;
    }
    
    /**
     * this function returns the condition set required to get indicator class
     * @return array
     */
    public function getConditions()
    {
        return $this->container->get('ymlparser.service.provider')->parseYmlFiles('indicator_conditions.yml','/../../ReportAccessControlBundle/Resources/config/')['conditions'];
    }
    
    /**
     * this function takes value , computes for set of conditions & returns an class to display indicator
     * @param int $value
     * @return string
     */
    public function getIndicatorClassForVal($value){
        $conditionSet = $this->getConditions();
        $elemClass = $conditionSet['default_class'];
        unset($conditionSet['default_class']);
        foreach ($conditionSet as $key => $val) {
            if (((isset($val['start']))) && ((isset($val['end']))) && (!(empty($val['class'])))) {
                if (($value >= $val['start']) && ($value <= $val['end'])) {
                    $elemClass = $val['class'];
                    break;
                }
            } elseif ((isset($val['start'])) && (!(empty($val['class'])))) {
                if ($value >= $val['start']) {
                    $elemClass = $val['class'];
                    break;
                }
            } elseif ((isset($val['end'])) && (!(empty($val['class'])))) {
                if ($value <= $val['end']) {
                    $elemClass = $val['class'];
                    break;
                }
            }
        }
        return $elemClass;
    }
}
?>