<?php

namespace IZMO\ReportAccessControlBundle\Provider;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

class ReportsServiceProvider {
    
    const JAN = 'January';
    const FEB = 'February';
    const MAR = 'March';
    const APR = 'April';
    const MAY = 'May';
    const JUN = 'June';
    const JUL = 'July';
    const AUG = 'August';
    const SEP = 'September';
    const OCT = 'October';
    const NOV = 'November';
    const DEC = 'December';
    const ACCOUNT_FQCN = 'Oro\Bundle\AccountBundle\Entity\Account';
    const CALENDAR_EVNT_FQCN = 'Oro\Bundle\CalendarBundle\Entity\CalendarEvent';
    const GEOLOC_DISTANCE_THRESHOLD = 'GEOLOC_DISTANCE_THRESHOLD';
    const NET_TURNOVER = 'NET_TURNOVER';
    const USER_SALES_CATEGORIES = 'USER_SALES_CATEGORIES';
    const DEFAULT_SCHEDULER_PARAMETAR=24;
    const DEFAULT_RETENTION_DATE = 60;
    /**
     * @var ContainerInterface
     */
    protected $container;
    
    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container) {
        $this->container = $container;
    }

     public function getReportRepository() {
        return $this->container->get('doctrine')->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess');
    }
    
    public function getUserSalesCategoryTypes(){
        $orgId = $this->container->get('oro_security.security_facade')->getOrganization()->getId();
     return  $this->getReportRepository()->getUserSalesCategoryTypes($orgId);
    }
    
    public function getTranslation($label){
        return $this->container->get('translator')->trans($label);
    }

    
    /**
     * To format the result set to fit DataTables - for Salesman Performance By Index & Client Report
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForSalesmanByIndxClient($columns, $data) {
        return $this->formatResultSetToRenderDataForReports($columns, $data ,'sales_perf_by_idx_client_grnd_tot','salestotal');
    }
    
    public function calcSubTotal($colName, $data,$i, $subTotData, $prev, $prevSec ) {
        $monthPrev = (!(empty($data[$i - 2]))) ? $data[$i - 2] : '';
        $monthSecPrev = (!(empty($data[$i - 1]))) ? $data[$i - 1]: '';
        $subTotPrev = ((!(empty($monthPrev[$colName]))) && ($monthPrev['mon'] == $prev)) ? ($monthPrev[$colName]) : 0;
        $subTotSecPrev = ((!(empty($monthSecPrev[$colName]))) && (($monthSecPrev['mon'] == $prevSec) || (((empty($monthPrev['mon'])) || ($monthPrev['mon'] !=  $prev)) && ($monthSecPrev['mon'] == $prev)) )) ? ($monthSecPrev[$colName]) : 0;
        return $subTotData + $subTotPrev + $subTotSecPrev;
    }

    /**
     * To format the result set to fit DataTables
     * @param array $columns
     * @param array $data
     * @param string $sessionKeyId
     * @param string $sessionColumn
     * @return array
     */
    public function formatResultSetToRenderDataForReports($columns,$data,$sessionKeyId,$sessionColumn){
        $out = array();
        $session = $this->container->get('session');
        $reportTyp = isset($data[0]['report_lvl']) ? $data[0]['report_lvl'] : 1;
        $isStrt = isset($data[0]['is_start']) ? $data[0]['is_start'] : 1;
            if($reportTyp == 0 && $isStrt == 0){
                $session->set($sessionKeyId, (!(empty($data[0][$sessionColumn]))) ? $data[0][$sessionColumn] : 0);
            } 
            $grndTotl = (!(empty($session->get($sessionKeyId)))) ? $session->get($sessionKeyId) : 0;
            for ($i = 0, $ien = count($data); $i < $ien; $i++) {
            $resData = $data[$i];
            $row = array();
            for ($j = 0, $jen = count($columns); $j < $jen; $j++) {
                $column = $columns[$j];
                if ($column['db'] == 'mon') {
                    $mon = $resData['mon'];
                    if (in_array($mon, array(SELF::MAR, SELF::JUN, SELF::SEP, SELF::DEC))) {
                        if ($mon == SELF::MAR) {
                            $prev = SELF::JAN;
                            $prevSec = SELF::FEB;
                        } else if ($mon == SELF::JUN) {
                            $prev = SELF::APR;
                            $prevSec = SELF::MAY;
                        } else if ($mon == SELF::SEP) {
                            $prev = SELF::JUL;
                            $prevSec = SELF::AUG;
                        } else if ($mon == SELF::DEC) {
                            $prev = SELF::OCT;
                            $prevSec = SELF::NOV;
                        }
                        $resData['subtotal'] = $this->calcSubTotal($sessionColumn, $data, $i, $resData[$sessionColumn], $prev, $prevSec);
                    }
                    else{
                        $resData['subtotal'] = 0;
                    }
                }

                if($column['db']=='weight_of_line_for_total'){
                    $resData['weight_of_line_for_total'] =(!(empty($grndTotl))) ? ROUND((($data[$i][$sessionColumn]/$grndTotl)*100),2) : 0;
                }
                if (!(empty($column['formatter']))) {
                    $colFormatter = $column['formatter'];
                    if ($colFormatter == 'percent') {
                        if (!(empty($column['ref_col']))) {
                            $class = $this->container->get('display.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                            $resData[$column['ref_col']] = "<span class='indicator $class'></span>";
                        }
                        $resData[$column['db']] = (!(empty($resData[$column['db']]))) ? $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0).' %' : '0 %';
                    } else if ($colFormatter == 'ind' && ((!(empty($column['has_ref_col']))) && ($column['has_ref_col']=='none') )) {
                        $class = $this->container->get('display.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                        $resData[$column['db']] = "<span class='indicator $class'></span>";
                    } else if ($colFormatter == 'num') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0);
                    } else if ($colFormatter == 'curr') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 1);
                    }
                    else if($colFormatter == 'subtotal_curr'){
                        $resData[$column['db']] = (!(empty($resData[$column['db']]))) ? $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']],1) : '';
                    }
                    else if($colFormatter == 'subtotal_num'){
                        $resData[$column['db']] = (!(empty($resData[$column['db']]))) ? $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']],0) : '';
                    }
                }
                if (!(empty($column['is_translatable']))) {
                    $resData[$column['db']] = $this->getTranslation($resData[$column['db']]);
                }
                $row[$column['dt']] = $resData[$column['db']];
            }
            $out[] = $row;
        }
        return $out;
    }
    
    /**
     * This function format export data for Salesman Index By Client Report
     * @param type $qryResult
     * @return array
     */
    public function formatResultSetToRenderDataForSalesmanByIndxClientExport($qryResult){
        foreach ($qryResult as $key => $val) {
            if (!(empty($val['mon']))) {
               $mon = $val['mon'];
                    if (in_array($mon, array(SELF::MAR, SELF::JUN, SELF::SEP, SELF::DEC))) {
                        if ($mon == SELF::MAR) {
                            $prev = $this->getTranslation(SELF::JAN);
                            $prevSec = $this->getTranslation(SELF::FEB);
                        } else if ($mon == SELF::JUN) {
                            $prev = $this->getTranslation(SELF::APR);
                            $prevSec = $this->getTranslation(SELF::MAY);
                        } else if ($mon == SELF::SEP) {
                            $prev = $this->getTranslation(SELF::JUL);
                            $prevSec = $this->getTranslation(SELF::AUG);
                        } else if ($mon == SELF::DEC) {
                            $prev = $this->getTranslation(SELF::OCT);
                            $prevSec = $this->getTranslation(SELF::NOV);
                        }
                        $qryResult[$key]['subtotal'] = $this->calcSubTotal('salestotal', $qryResult, $key, $qryResult[$key]['salestotal'], $prev, $prevSec);
                    }
                    else{
                        $qryResult[$key]['subtotal'] = 0;
                    }
                
                $qryResult[$key]['mon'] = $this->getTranslation($val['mon']);
            }
        }
        return $qryResult;
    }
    
    /**
     * To format the result set to fit DataTables - for Salesman Performance By Channel Report
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForSalesByChannelForSalesman($columns, $data) {
        return $this->formatResultSetToRenderDataForReports($columns, $data ,'sales_perf_by_channel_salesman_tot','salestotal');
    }
    
    /**
     * To format the result set to fit DataTables - for Salesman Performance By Channel Report
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForSalesByChannelByClientForSalesman($columns, $data) {
        return $this->formatResultSetToRenderDataForReports($columns, $data ,'sales_perf_by_channel_by_client_for_salesman_tot','salestotal');
    }
    
    /**
     * To format the result set to fit DataTables - for Performance By Channel and Index Report
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForSalesByChannelForIndex($columns, $data) {
        return $this->formatResultSetToRenderDataForReports($columns, $data ,'sales_perf_by_channel_by_index_for_salesman_tot','salestotal');
    }
    
    
    /**
     * To format the result set to fit DataTables - for Salesman Performance By Index Report
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForSalesByIndexForSalesman($columns, $data) {
        return $this->formatResultSetToRenderDataForReports($columns, $data ,'sales_perf_by_index_salesman_tot','salestotal');
    }
    
    /**
     * To format the result set to fit DataTables - for Performance By Channel and Index Report
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForSalesByIndexForChannel($columns, $data) {
        return $this->formatResultSetToRenderDataForReports($columns, $data ,'sales_perf_by_index_by_channel_for_salesman_tot','salestotal');
    }
    
    /**
     * To format the result set to fit DataTables - for Performance By Index and platform Report
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForSalesByIndexForPlatform($columns, $data){
        return $this->formatResultSetToRenderDataForReports($columns, $data ,'sales_perf_by_index_for_platform_tot','salestotal');
    }
    
    /**
     * To format the result set to fit DataTables - for Performance By  platform Report
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForSalesForPlatform($columns, $data){
        return $this->formatResultSetToRenderDataForReports($columns, $data ,'sales_perf_by_platform_tot','salestotal');
    }
    
    /**
     * To format the result set to fit DataTables - for Performance By  platform Report
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForSalesByChannelForPlatform($columns, $data){
        return $this->formatResultSetToRenderDataForReports($columns, $data ,'sales_perf_by_channel_platform_tot','salestotal');
    }

    public function formatDate($date){
        $localeSettings = $this->container->get('oro_locale.settings');
        return $this->container->get('oro_locale.formatter.date_time')->formatDate($date,null, $localeSettings->getLocale(), $localeSettings->getTimeZone());
    }
    
    public function formatResultSetToRenderDataForPromotionsPerformance($columns, $data){
        $out = array();
        for ($i = 0, $ien = count($data); $i < $ien; $i++) {
            $resData = $data[$i];
            $row = array();
            for ($j = 0, $jen = count($columns); $j < $jen; $j++) {
                $column = $columns[$j];
                if (!(empty($column['formatter']))) {
                    $colFormatter = $column['formatter'];
                    if ($colFormatter == 'percent') {
                        if (!(empty($column['ref_col']))) {
                            $class = $this->container->get('display.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                            $resData[$column['ref_col']] = "<span class='indicator $class'></span>";
                        }
                        $resData[$column['db']] .= ' %';
                    } else if ($colFormatter == 'ind' && ((!(empty($column['has_ref_col']))) && ($column['has_ref_col']=='none') )) {
                        $class = $this->container->get('display.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                        $resData[$column['db']] = "<span class='indicator $class'></span>";
                    } else if ($colFormatter == 'num') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0);
                    } else if ($colFormatter == 'curr') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 1);
                    }
                     else if($colFormatter == 'date'){
                        $resData[$column['db']] = $this->container->get('reports.service_provider')->formatDate($resData[$column['db']]);
                    }
                    else if(($colFormatter == 'num_or_cur') && (!(empty($column['ref_col'])))){
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']],$resData[$column['ref_col']]);
                    }
                }
                if (!(empty($column['is_translatable']))) {
                    $resData[$column['db']] = $this->container->get('translator')->trans($resData[$column['db']]);
                }
                $row[$column['dt']] = $resData[$column['db']];
            }
            $out[] = $row;
        }
        return $out;
    }
    
    /**
     * 
     * @param type $columns
     * @param type $data
     * @return type
     */
    public function formatResultSetToRenderDataForPromotionsPerformanceVisitReport($columns, $data) {
        $out = array();
        for ($i = 0, $ien = count($data); $i < $ien; $i++) {
            $resData = $data[$i];
            $row = array();
            for ($j = 0, $jen = count($columns); $j < $jen; $j++) {
                $column = $columns[$j];              
                if (!(empty($column['formatter']))) {
                    $colFormatter = $column['formatter'];
                    if ($colFormatter == 'num') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0);
                    }
                }
                if($column['db'] == 'weight' && $_POST['lvl'] == 1){                  
                    $actual = (int) $resData['no_of_visits_done'];
                    if($actual !== 0){
                        $buId = $this->container->get('security.context')->getToken()->getUser()->getOwner()->getId();
                        $cal_acc_rel_table = $this->container->get('utility.helper')->getRelationTableName('Oro\Bundle\CalendarBundle\Entity\CalendarEvent','Oro\Bundle\AccountBundle\Entity\Account');
                        $grandTotal = $this->getReportRepository()->getTotalVisitsDoneForSalesman($buId,$cal_acc_rel_table);                       
                        $resData[$column['db']] = number_format((($grandTotal / $actual) * 100),2,'.','');
                    } else {
                        $resData[$column['db']] = number_format(0,2,'.','');
                    }               
                }
                if (!(empty($column['is_translatable']))) {
                    $resData[$column['db']] = $this->container->get('translator')->trans($resData[$column['db']]);
                }
                $row[$column['dt']] = $resData[$column['db']];
            } 
            $out[] = $row;
        } 
        return $out;
    }

    public function fetchCalendarEvntAccountMapperTable(){
       return $this->container->get('utility.helper')->getRelationTableName(SELF::CALENDAR_EVNT_FQCN,SELF::ACCOUNT_FQCN);
    }
    
    public function fetchGeolocationDistanceThreshold(){
        $orgId = $this->container->get('oro_security.security_facade')->getOrganization()->getId();
        $res = $this->container->get('doctrine')->getRepository('IZMOCustomConfigBundle:CustomConfig')->findOneBy(array('configLabel'=>SELF::GEOLOC_DISTANCE_THRESHOLD,'organization'=>$orgId));
         return (!(empty($res))) ? $res->getConfigValue() : 0;
    }
    
    public function getResolutionComplaintStatus(){
       return $this->container->get('doctrine')->getRepository('IZMOClientVisitBundle:VisitReport')->getComplaintStatus();
    }

    /**
     * 
     * @param string $reportName
     * @param string $configFile
     * 
     */
    public function getBaseReportSummaryDataForNonMultiLvlReports($reportName,$configFile = 'reports.yml') {
        $initialRepo = $rowsPerPageConfig = $isProductTypeReport = $errorFlag = 0;
        $baseUrl = $curUrl = $reportTitle = $orderCustomDef = '';
        $logger = $this->container->get('logger');
        $reportTitleKey = '';
        $isGrndTotal = $isSubGrndTotal = $isOrderable = $isCustomOrderableDef = 0;
        $hideColsForGrandTotal = $twigFilters = [];
        try {
            $reportConfig = $this->container->get('ymlparser.service.provider')->parseYmlFiles($configFile,'/../../ReportAccessControlBundle/Resources/config')['reports'][$reportName];
            if (!(empty($reportConfig))) {
                if (!(empty($reportConfig['twigPath']))) {
                    if((empty($_GET)) && (empty($_POST))){$initialRepo = 1;}
                    $twigPath = $reportConfig['twigPath'];
                    $rowsPerPageConfig = $this->container->get('izmo_user_security_info.user_security_provider')->getNoOfRowsForReportPerPageForUser();
                    $rowsPerPageConfig = (empty($rowsPerPageConfig)) ? $this->container->get('ymlparser.service.provider')->parseYmlFiles('reports_config.yml','/../../ReportAccessControlBundle/Resources/config')['report_config']['pagination']['no_of_rows_per_page'] : $rowsPerPageConfig;
                    $isGrndTotal = (!(empty($reportConfig['isGrandTotal']))) ? $reportConfig['isGrandTotal'] : 0;
                    $hideColsForGrandTotal = ((!(empty($isGrndTotal))) && (!(empty($reportConfig['hide_cols_for_grand_total'])))) ? $reportConfig['hide_cols_for_grand_total'] : [];
                    $isSubGrndTotal = (!(empty($reportConfig['isSubGrandTotal']))) ? $reportConfig['isSubGrandTotal'] : 0;
                    $filtersConfig = $reportConfig['filters']['index'];
                    foreach ($filtersConfig as $key => $val) {
                        if ((!(empty($_REQUEST))) && (!(empty($_REQUEST[$val['col']])))) {
                            $filter[$key] = $_REQUEST[$val['col']];
                        } else {
                            if ((!(empty($_REQUEST))) && (!(empty($val['can_be_zero']))) && ($val['can_be_zero'] == 'true') && isset($_REQUEST[$val['col']]) && (($_REQUEST[$val['col']]) == 0)) {
                                $filter[$key] = 0;
                            }
                            elseif((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])){
                                        $funcName = $val['function_name'];
                                        $serviceName = $val['service_name'];
                                        $filter[$key] = $this->container->get($serviceName)->$funcName();
                            }
                            else {
                                $filter[$key] = $val['default'];
                            }
                        }
                        $dataType[$key] = $val['data_type'];
                    } // filters index config provided
                    if (!(empty($reportConfig['product_type_report']))) {//FOR PRODUCT TYPE REPORT LOGIC
                        $isProductTypeReport = 1;
                        if (!(empty($_REQUEST['product_type']))) {
                            $productType = $_REQUEST['product_type'];
                        } else if (!(empty($reportConfig['product_type_report']['default']))) {
                            $productType = $reportConfig['product_type_report']['default'];
                        }
                    }
                    $reportConfigDetails = ((!(empty($isProductTypeReport))) && (!(empty($reportConfig['prod_type'][$productType])))) ? $reportConfig['prod_type'][$productType] : $reportConfig;
                    $baseUrl = (!(empty($reportConfigDetails['base_url'])))? $reportConfigDetails['base_url'] : '';
                    $reportConfigLvlDetails = $reportConfigDetails;
                    if (!(empty($reportConfigDetails['title']))) {
                        $reportTitle = $this->getTranslation($reportConfigDetails['title']);
                        $reportTitleKey = $reportConfigDetails['title'];
                    }
                    if (!(empty($reportConfigLvlDetails))) {
                        $userIds = $this->container->get('izmo_user_security_info.user_security_provider')->getUserIds();
                        if (!(empty($reportConfigLvlDetails['url']))) {
                            $curUrl = $reportConfigLvlDetails['url'];
                        }
                        if(isset($reportConfigLvlDetails['is_orderable'])){
                            $isOrderable = $reportConfigLvlDetails['is_orderable'];
                        }
                         if(isset($reportConfigLvlDetails['is_custom_orderable_def'])){
                        $isCustomOrderableDef = $reportConfigLvlDetails['is_custom_orderable_def'];
                         }
                         
                         if(!(empty($reportConfigLvlDetails['order_custom_def']))){
                             $orderCustomDef = $reportConfigLvlDetails['order_custom_def'];
                         }
                        if (!(empty($reportConfig['twig_filter_cols']))) {
                            $twigFilterConfig = $reportConfig['twig_filter_cols'];
                            foreach ($twigFilterConfig as $key => $val) {
                                if (!(empty($filter[$val]))) {
                                    $twigFilters[$val] = ($filter[$val] != 'none') ? $filter[$val] : '';
                                }
                                else if((isset($filter[$val])) && ($filter[$val] == 0)){
                                    $twigFilters[$val] = $filter[$val];
                                }
                            }
                        }
                    } else {
                        $errorFlag = 1;
                        $logger->crit(" No configuration found for report selected");
                    }
                }  // twig path defined
                else {
                    $errorFlag = 1;
                    $logger->crit(" No twig path defined in configuration for report selected");
                }
            }// config available
            else {
                $errorFlag = 1;
                $logger->crit(" No configuration details found for report selected");
            }
        }// try block
        catch (\Exception $e) {
            $errorFlag = 1;
            $logger->crit(" exception occured while retriving data with exception info below:");
            $logger->crit($e);
        } finally {
            if (!(empty($twigPath))) {
                $res['twigPath'] = $twigPath;
                $res['params'] = array('errorHandlr' => $errorFlag, 'report_hdr' => $reportTitle,'pageTitle'=>$reportTitle,'pageTitleKey'=>$reportTitleKey, 'cur_url' => $curUrl, 'is_orderable'=> $isOrderable ,'is_custom_orderable_def'=>$isCustomOrderableDef, 'filters' => $twigFilters,'rows_per_page'=>$rowsPerPageConfig,'is_grand_total'=>$isGrndTotal,'is_sub_grand_total'=>$isSubGrndTotal,'hid_cols_for_grand_sum'=>$hideColsForGrandTotal,'base_url'=>$baseUrl,'order_custom_def'=>$orderCustomDef,'init_report'=>$initialRepo);
                return $res;
            } else {
                return null;
            }
        }
    }
    
    /**
     * 
     * @param string $reportName
     * @param string $configFile
     * @return Response
     */
    public function getDataForBaseReportNonMultiLvl($reportName,$configFile = 'reports.yml') {
        $isSeperateServerSideForTypes = $isProductTypeReport = $errorFlag = 0;
        $logger = $this->container->get('logger');
        $url = '';
        $filter = [];
        try {
            $data = $_POST;
            if ((!empty($data))) {
                $reportConfig = $this->container->get('ymlparser.service.provider')->parseYmlFiles($configFile,'/../../ReportAccessControlBundle/Resources/config')['reports'][$reportName];
                 if (!(empty($reportConfig))) {
                    if (!(empty($reportConfig['filters']['index']))) {
                        $filtersConfig = $reportConfig['filters']['index'];
                        $filtersJson = $data['filters'];
                        $filtersData = json_decode($filtersJson);
                        foreach ($filtersConfig as $key => $val) {
                            if (empty($filter[$key])) {
                                $col = $val['col'];
                                if ((!(empty($filtersData))) && (!(empty($filtersData->$col)))) {
                                    $filter[$key] = $filtersData->$col;
                                }
                                else {
                                    if((!(empty($filtersData))) && (!(empty($val['can_be_zero']))) && ($val['can_be_zero'] == 'true') && isset($filtersData->$col) && ($filtersData->$col == 0)){
                                    $filter[$key] = 0;
                                    }
                                    elseif((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])){
                                          $funcName = $val['function_name'];
                                          $serviceName = $val['service_name'];
                                          $filter[$key] = $this->container->get($serviceName)->$funcName();
                                      }
                                      else {
                                          $filter[$key] = $val['default'];
                                      }
                                }
                            }
                            $dataType[$key] = $val['data_type'];
                        }
                    } // if not empty of filter configuration
                    else {
                        $logger->debug("filter configuration not found for given product type of report");
                    }
                    if (!(empty($reportConfig['product_type_report']))) { // FOR Product Type Logic
                    $productType = (!(empty($filter['product_type']))) ? $filter['product_type'] : $reportConfig['product_type_report']['default'];
                        $isProductTypeReport = 1;
                        $isSeperateServerSideForTypes = (!(empty($reportConfig['product_type_report']['serverside_disp_each_type']))) ? $reportConfig['product_type_report'] : 0;
                    }
                    $reportConfigDetails = ((!(empty($isProductTypeReport) )) && (!(empty($reportConfig['prod_type'][$productType])))) ? $reportConfig['prod_type'][$productType] : $reportConfig;
                        $reportwiseConfiguration = $reportConfigDetails;
                        $userIds = $this->container->get('izmo_user_security_info.user_security_provider')->getUserIds();
                        if (!(empty($reportwiseConfiguration['stored_proc']))) {
                            $storedProcName = $reportwiseConfiguration['stored_proc'];
                        } 
                        if (!(empty($reportwiseConfiguration['stored_proc_params']))) {
                            $storedProcParameters = $reportwiseConfiguration['stored_proc_params'];
                        } 
                        if ((!(empty($storedProcParameters))) && (!(empty($storedProcName)))) {
                            $spParametersLabelArray = explode(',', $storedProcParameters);
                            $spParametersArrayCount = count($spParametersLabelArray);
                            $spFilterParam = [];
                            for ($i = 0; $i < $spParametersArrayCount; $i++) { //to order filters & its data type based on sp_params order mentioned in yml
                                $spFilterParam[$i]['filter'] = $filter[$spParametersLabelArray[$i]];
                                $spFilterParam[$i]['data_type'] = $dataType[$spParametersLabelArray[$i]];
                            }
                            $filterParams = array();
                            $filterParams['usr_ids'] = $userIds;
                            $filterParams['sp_params'] = $spFilterParam;
                           $serverProcessConfig = ((!(empty($isSeperateServerSideForTypes))) && (!(empty($reportConfigDetails['serverside_processing_detail'])))) ? $reportConfigDetails['serverside_processing_detail'] : $reportConfig['serverside_processing_detail'];
                           return $this->container->get('izmo_datatables.server_side_processing')->processServerSideData($serverProcessConfig,$storedProcName,$_POST,$filterParams,$url);
                        } else {
                            $errorFlag = 1;
                            $logger->crit("stored procedure parameters or stored procedure name not found for prod_type field for report");
                        }
                } else {
                    $errorFlag = 1;
                    $logger->crit("No configuration details found for given report name");
                }
            } else {
                $errorFlag = 1;
                $logger->crit("No Parameters posted for ajax call in given report");
            }
       } catch (\Exception $e) {
            $errorFlag = 1;
            $logger->crit("Exception occured during fetching data with details below:");
            $logger->crit($e);
        } 
    }

    /**
     * 
     * @param string $reportName
     * @param string $configFile
     * @return Response
     */
    public function getDataForBaseReportNonMultiLvlForSalesType($reportName,$configFile = 'reports.yml',$turnoverType) {
        $isSeperateServerSideForTypes = $isProductTypeReport = $errorFlag = 0;
        $logger = $this->container->get('logger');
        $url = '';
        $filter = [];
        try {
            $data = $_POST;
            if ((!empty($data))) {
                $reportConfig = $this->container->get('ymlparser.service.provider')->parseYmlFiles($configFile,'/../../ReportAccessControlBundle/Resources/config')['reports'][$reportName];
                 if (!(empty($reportConfig))) {
                    if (!(empty($reportConfig['filters']['index']))) {
                        $filtersConfig = $reportConfig['filters']['index'];
                        $filtersJson = $data['filters'];
                        $filtersData = json_decode($filtersJson);
                        foreach ($filtersConfig as $key => $val) {
                            if (empty($filter[$key])) {
                                $col = $val['col'];
                                if ((!(empty($filtersData))) && (!(empty($filtersData->$col)))) {
                                    $filter[$key] = $filtersData->$col;
                                }
                                else {
                                    if((!(empty($filtersData))) && (!(empty($val['can_be_zero']))) && ($val['can_be_zero'] == 'true') && isset($filtersData->$col) && ($filtersData->$col == 0)){
                                    $filter[$key] = 0;
                                    }
                                    elseif((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])){
                                          $funcName = $val['function_name'];
                                          $serviceName = $val['service_name'];
                                          $filter[$key] = $this->container->get($serviceName)->$funcName();
                                      }
                                      else {
                                          $filter[$key] = $val['default'];
                                      }
                                }
                            }
                            $dataType[$key] = $val['data_type'];
                        }
                    } // if not empty of filter configuration
                    else {
                        $logger->debug("filter configuration not found for given product type of report");
                    }
                    if (!(empty($reportConfig['product_type_report']))) { // FOR Product Type Logic
                    $productType = (!(empty($filter['product_type']))) ? $filter['product_type'] : $reportConfig['product_type_report']['default'];
                        $isProductTypeReport = 1;
                        $isSeperateServerSideForTypes = (!(empty($reportConfig['product_type_report']['serverside_disp_each_type']))) ? $reportConfig['product_type_report'] : 0;
                    }
                    $reportConfigDetails = ((!(empty($isProductTypeReport) )) && (!(empty($reportConfig['prod_type'][$productType])))) ? $reportConfig['prod_type'][$productType] : $reportConfig;
                        $reportwiseConfiguration = $reportConfigDetails;
                        $userIds = $this->container->get('izmo_user_security_info.user_security_provider')->getUserIds();
                        if (!(empty($reportwiseConfiguration['stored_proc']))) {
                            $storedProcName = $reportwiseConfiguration['stored_proc'];
                        } 
                        if (!(empty($reportwiseConfiguration['stored_proc_params']))) {
                            $storedProcParameters = $reportwiseConfiguration['stored_proc_params'];
                        } 
                        if ((!(empty($storedProcParameters))) && (!(empty($storedProcName)))) {
                            $spParametersLabelArray = explode(',', $storedProcParameters);
                            $spParametersArrayCount = count($spParametersLabelArray);
                            $spFilterParam = [];
                            for ($i = 0; $i < $spParametersArrayCount; $i++) { //to order filters & its data type based on sp_params order mentioned in yml
                                $spFilterParam[$i]['filter'] = $filter[$spParametersLabelArray[$i]];
                                $spFilterParam[$i]['data_type'] = $dataType[$spParametersLabelArray[$i]];
                            }
                            $filterParams = array();
                            $filterParams['usr_ids'] = $userIds;
                            $filterParams['sp_params'] = $spFilterParam;
                            $filterParams['turnoverType'] = $turnoverType;
                           $serverProcessConfig = ((!(empty($isSeperateServerSideForTypes))) && (!(empty($reportConfigDetails['serverside_processing_detail'])))) ? $reportConfigDetails['serverside_processing_detail'] : $reportConfig['serverside_processing_detail'];
                           return $this->container->get('izmo_datatables.server_side_processing')->processServerSideDataForSalesType($serverProcessConfig,$storedProcName,$_POST,$filterParams,$url);
                        } else {
                            $errorFlag = 1;
                            $logger->crit("stored procedure parameters or stored procedure name not found for prod_type field for report");
                        }
                } else {
                    $errorFlag = 1;
                    $logger->crit("No configuration details found for given report name");
                }
            } else {
                $errorFlag = 1;
                $logger->crit("No Parameters posted for ajax call in given report");
            }
       } catch (\Exception $e) {
            $errorFlag = 1;
            $logger->crit("Exception occured during fetching data with details below:");
            $logger->crit($e);
        } 
    }
	
    
	/**
     * 
     * @param string $reportName
     * @param string $configFile
     * @return Response
     */
    public function getExportDataForReportForNonMultiLvl($reportName,$configFile = 'reports.yml') {
        $excelTitle = '';
        $logger = $this->container->get('logger');
        $filter = [];
        $serverErrorMsg = $this->getTranslation('datatables.data.server_error_occured.label');
        try {
            $resultArr = $this->container->get('ymlparser.service.provider')->parseYmlFiles($configFile,'/../../ReportAccessControlBundle/Resources/config')['reports'][$reportName];
            if (!(empty($resultArr))) {
                if (!(empty($resultArr['product_type_report']))) { //FOR PRODUCT TYPE REPORT LOGIC
                    $isProductTypeReport = 1;
                    if (!(empty($_REQUEST['product_type']))) {
                        $productType = $_REQUEST['product_type'];
                    } else if (!(empty($reportConfig['product_type_report']['default']))) {
                        $productType = $reportConfig['product_type_report']['default'];
                    }
                    if ((!(empty($productType))) && (!(empty($resultArr['prod_type'][$productType])))) {
                        $reportConfig = $resultArr['prod_type'][$productType];
                    }
                } else {
                    $reportConfig = $resultArr;
                }
                if (!(empty($reportConfig))) {
                    if (!(empty($reportConfig['title']))) {
                        $excelTitle = $this->getTranslation($reportConfig['title']);
                    }
                    if (!(empty($reportConfig['export']['stored_proc']))) {
                        $storedProcName = $reportConfig['export']['stored_proc'];
                    }
                    $filtersConfig = $reportConfig['export']['filters']['index'];
                    foreach ($filtersConfig as $key => $val) {
                        if ((!(empty($_REQUEST))) && (!(empty($_REQUEST[$val['col']])))) {
                            $filter[$key] = $_REQUEST[$val['col']];
                        } else {
         		if ((!(empty($_REQUEST))) && (!(empty($val['can_be_zero']))) && ($val['can_be_zero'] == 'true') && isset($_REQUEST[$val['col']]) && (($_REQUEST[$val['col']]) == 0)) {
                                $filter[$key] = 0;
                            }
                            elseif((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])){
                                        $funcName = $val['function_name'];
                                        $serviceName = $val['service_name'];
                                        $filter[$key] = $this->container->get($serviceName)->$funcName();
                            }
                            else {
                                $filter[$key] = $val['default'];
                            }
                        }
                        $dataType[$key] = $val['data_type'];
                    }
                    $userIds = $this->container->get('izmo_user_security_info.user_security_provider')->getUserIds();
                    if (!(empty($reportConfig['export']['stored_proc_params']))) {
                        $storedProcParameters = $reportConfig['export']['stored_proc_params'];
                    }
                    $spParametersLabelArray = explode(',', $storedProcParameters);
                    $spParametersArrayCount = count($spParametersLabelArray);
                    $spFilterParam = [];
                    for ($i = 0; $i < $spParametersArrayCount; $i++) {
                        $spFilterParam[$i]['filter'] = $filter[$spParametersLabelArray[$i]];
                        $spFilterParam[$i]['data_type'] = $dataType[$spParametersLabelArray[$i]];
                    }
                    $qryResult = $this->getReportRepository()->getReportExportDataForParameters($userIds, $storedProcName, $spFilterParam); 
                    if (!(empty($qryResult))) {
                        if(!(empty($qryResult['err']))){
                            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
                        }
                        else{
                         if((!(empty($reportConfig['export']['is_seperate_output']))) && (!(empty($reportConfig['export']['export_output_service']))) && (!(empty($reportConfig['export']['export_output_func_name'])))){
                            $funcName = $reportConfig['export']['export_output_func_name'];
                            $serviceName = $reportConfig['export']['export_output_service'];
                            $qryResult = $this->container->get($serviceName)->$funcName($qryResult);
                        }
                        else{   
                            foreach ($qryResult as $key => $val) {
                                if (!(empty($val['mon']))) {
                                    $qryResult[$key]['mon'] = $this->getTranslation($val['mon']);
                                }
                            }
                        }
                        $colHdrs = $reportConfig['export']['header'];
                        $res = $this->container->get('custom.excel.export.class')->generateExcelForReport($qryResult, $colHdrs, $excelTitle);
                        return new Response(
                                $res, 200, array(
                            'Content-Type' => 'application/vnd.ms-excel',
                            'Content-Disposition' => 'attachment; filename="doc.xls"',
                                )
                        );
                     }
                    } else {
                        $noDataFoundMsg = $this->getTranslation('datatables.data.no_record_found.label');
                        return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $noDataFoundMsg . '</p>');
                    }
                }//not empty $reportConfig
                else {
                    $logger->crit("No configuration found for given report");

                    return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
                }
            } else {
                $logger->crit("No configuration found for given report");

                return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured during fetching data with details below:");
            $logger->crit($e);
           
            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
        }
    }
    

    // END OF NON LVL
    /**
     * To format the DataTable result set  - FOR SUMMARY COMPLAINTS Report rendering
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForSummaryComplaints($columns, $data) {
        $out = array();
        for ($i = 0, $ien = count($data); $i < $ien; $i++) {
            $resData = $data[$i];
            $row = array();
            for ($j = 0, $jen = count($columns); $j < $jen; $j++) {
                $column = $columns[$j];
                if (!(empty($column['formatter']))) {
                    $colFormatter = $column['formatter'];
                    if ($colFormatter == 'percent') {
                        if (!(empty($column['ref_col']))) {
                            $class = $this->container->get('display.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                            $resData[$column['ref_col']] = "<span class='indicator $class'></span>";
                        }
                        $resData[$column['db']] .= ' %';
                    }
                    elseif($colFormatter == 'html'){
                       $baseurl =  $this->container->get('router')->getContext()->getBaseUrl();
                        $visitReportId = $resData[$column['db']];
                        if($column['html_type'] == 'view'){
                            $resData[$column['db']] = "<a target='_blank' href='$baseurl/clientvisit/visitreport/$visitReportId' class='view'><i class='icon-eye-open hide-text'>View</i></a>";
                        }
                        else if($column['html_type'] == 'edit'){
                            $resData[$column['db']] = "<a target='_blank' href='$baseurl/clientvisit/visitreport/update/$visitReportId' class='edit'><i class='icon-edit hide-text'>Edit</i></a>";
                        }
                    }
                    else if($colFormatter == 'date'){
                        $resData[$column['db']] = $this->container->get('reports.service_provider')->formatDate($resData[$column['db']]);
                    }
                    else if ($colFormatter == 'ind' && ((!(empty($column['has_ref_col']))) && ($column['has_ref_col']=='none') )) {
                        $class = $this->container->get('display.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                        $resData[$column['db']] = "<span class='indicator $class'></span>";
                    } else if ($colFormatter == 'num') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0);
                    } else if ($colFormatter == 'curr') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 1);
                    }
                }
                if (!(empty($column['is_translatable']))) {
                    $resData[$column['db']] = $this->container->get('translator')->trans($resData[$column['db']]);
                }
                $row[$column['dt']] = $resData[$column['db']];
            }
            $out[] = $row;
        }
        return $out;
       
    }
    
    /**
     * 
     */
    public function chkIfLoggedInUsrIsMgr(){
         $usr = $this->container->get('security.context')->getToken()->getUser();
          return (!(empty($usr))) ? (int)$usr->getIsManager(): 0;
    }
    
    public function formatResultSetToRenderDataForSummaryComplaintsExport($qryResult){
        foreach ($qryResult as $key => $val) {
            if (!(empty($val['mon']))) {
                $qryResult[$key]['mon'] = $this->getTranslation($val['mon']);
            }
            if(!(empty($val['complaintResolutionStatus']))){
            $qryResult[$key]['complaintResolutionStatus'] = $this->getTranslation($val['complaintResolutionStatus']);}
            if(isset($val['complaintStatus'])){
                $qryResult[$key]['complaintStatus'] = ($val['complaintStatus'] == 1) ? $this->getTranslation('izmo.reports.summary_complaints_report.options.yes.label') : $this->getTranslation('izmo.reports.summary_complaints_report.options.no.label');
            }
        }
        return $qryResult;
    }
    
    public function getCategoryType($type,$targetEntityType){
        $categoryConfigObj = $this->container->get('doctrine')->getRepository('IZMOCustomConfigBundle:CustomConfig')->findOneBy(array('configLabel' => $targetEntityType,'organization' => 1));
        $key='';
        if(!empty($categoryConfigObj)){
            $configVal = $categoryConfigObj->getConfigValue();
            $configValArr = json_decode($configVal,true);
            $key = array_search ($type, $configValArr);
        }
        return $key;
    }
    
    public function getCategoty(){
        $key=$this->getCategoryType(SELF::NET_TURNOVER,SELF::USER_SALES_CATEGORIES);
        return $key;
    }
    
    /**
     * To format the DataTable result set  - FOR Top Flop Report rendering
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForTopFlop($columns, $data) {
        $out = array();
        for ($i = 0, $ien = count($data); $i < $ien; $i++) {
            $resData = $data[$i];
            $row = array();
            for ($j = 0, $jen = count($columns); $j < $jen; $j++) {
                $column = $columns[$j];
                if (!(empty($column['formatter']))) {
                    $colFormatter = $column['formatter'];
                    if ($colFormatter == 'percent') {
                        $resData[$column['db']] .= ' %';
                    }
                    elseif ($colFormatter == 'number') {
                        if (!(empty($column['ref_col']))) {
                            $class = $this->getIndicatorsForTopFlopReports($resData[$column['db']]);                            
                            $resData[$column['ref_col']] = "<span class='indicator $class'></span>";
                        }
                    }
                    elseif($colFormatter == 'html'){
                       $baseurl =  $this->container->get('router')->getContext()->getBaseUrl();
                        $visitReportId = $resData[$column['db']];
                        if($column['html_type'] == 'view'){
                            $resData[$column['db']] = "<a target='_blank' href='$baseurl/clientvisit/visitreport/$visitReportId' class='view'><i class='icon-eye-open hide-text'>View</i></a>";
                        }
                        else if($column['html_type'] == 'edit'){
                            $resData[$column['db']] = "<a target='_blank' href='$baseurl/clientvisit/visitreport/update/$visitReportId' class='edit'><i class='icon-edit hide-text'>Edit</i></a>";
                        }
                    }
                    else if($colFormatter == 'date'){
                        $resData[$column['db']] = $this->container->get('reports.service_provider')->formatDate($resData[$column['db']]);
                    }
                    else if ($colFormatter == 'ind' && ((!(empty($column['has_ref_col']))) && ($column['has_ref_col']=='none') )) {
                        $class = $this->getIndicatorsForTopFlopReports($resData[$column['db']]);
                        $resData[$column['db']] = "<span class='indicator $class'></span>";
                    } else if ($colFormatter == 'num') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0);
                    } else if ($colFormatter == 'curr') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 1);
                    }
                }
                if (!(empty($column['is_translatable']))) {
                    $resData[$column['db']] = $this->container->get('translator')->trans($resData[$column['db']]);
                }
                $row[$column['dt']] = $resData[$column['db']];
            }
            $out[] = $row;
        }
        return $out;
       
    }
    
    public function getIndicatorsForTopFlopReports($value){
        $conditionSet =  $this->container->get('ymlparser.service.provider')->parseYmlFiles('topflop_indicator_conditions.yml','/../../ReportAccessControlBundle/Resources/config/')['conditions'];
        $elemClass = $conditionSet['default_class'];
        unset($conditionSet['default_class']);
        foreach ($conditionSet as $key => $val) {
            if (((isset($val['start']))) && ((isset($val['end']))) && (!(empty($val['class'])))) {
                if (($value >= $val['start']) && ($value <= $val['end'])) {
                    $elemClass = $val['class'];
                    break;
                }
            } elseif ((isset($val['start'])) && (!(empty($val['class'])))) {
                if ($value >= $val['start']) {
                    $elemClass = $val['class'];
                    break;
                }
            } elseif ((isset($val['end'])) && (!(empty($val['class'])))) {
                if ($value <= $val['end']) {
                    $elemClass = $val['class'];
                    break;
                }
            }
        }
        return $elemClass;
    }
    public function getAppointmentScheduleValue(){
        $usrObj=$this->container->get('security.context')->getToken()->getUser();
        $buId= $usrObj->getOwner()->getId();
        $orgId=$usrObj->getOrganization()->getId();
        $configObj=$this->container->get('doctrine')->getRepository('IZMOCustomConfigBundle:CustomConfig');
        $configValue=$configObj->findOneBy(array('configLabel' => 'appointment_schedule_hours','organization' => $orgId,'owner'=>$buId));
        if(!empty($configValue)){
            $value=$configValue->getConfigValue();
        }else{
            $configDefaultValue=$configObj->findOneBy(array('configLabel' => 'default_appointment_schedule_hours','organization' => $orgId));
            $value=(!empty($configDefaultValue))?$configDefaultValue->getConfigValue():(SELF::DEFAULT_SCHEDULER_PARAMETAR);
        }
        return $value;
    }  
    
    //
    public function getRelatedBuIds() {
        $res = null;
        $buArr = $this->container->get('izmo_user_security_info.user_security_provider')->getBuRelatedToLoggedUser();
        if (!(empty($buArr))) {
            foreach ($buArr as $key => $val) {
                $buIds[] = $val->getId();
            }
            $res = implode(',', $buIds);
        }
        return $res;
    }
    
    public function getOwnerBuIdOfUsrLoggedIn(){
       return $this->container->get('izmo_user_security_info.user_security_provider')->getLoggedInUsr()->getOwner()->getId();
    }
    
    /**
     * 
     * @param string $reportName
     * @param string $configFile
     * @return Response
     */
    public function getDataForBaseReportNonMultiLvlWithTranslation($reportName,$configFile = 'reports.yml') {
        $isSeperateServerSideForTypes = $isProductTypeReport = $errorFlag = 0;
        $logger = $this->container->get('logger');
        $url = '';
        $filter = [];
        try {
            $data = $_POST;
            if ((!empty($data))) {
                $reportConfig = $this->container->get('ymlparser.service.provider')->parseYmlFiles($configFile,'/../../ReportAccessControlBundle/Resources/config')['reports'][$reportName];
                 if (!(empty($reportConfig))) {
                    if (!(empty($reportConfig['filters']['index']))) {
                        $filtersConfig = $reportConfig['filters']['index'];
                        $filtersJson = $data['filters'];
                        $filtersData = json_decode($filtersJson);
                        foreach ($filtersConfig as $key => $val) {
                            if (empty($filter[$key])) {
                                $col = $val['col'];
                                if ((!(empty($filtersData))) && (!(empty($filtersData->$col)))) {
                                    $filter[$key] = $filtersData->$col;
                                }
                                else {
                                    if((!(empty($filtersData))) && (!(empty($val['can_be_zero']))) && ($val['can_be_zero'] == 'true') && isset($filtersData->$col) && ($filtersData->$col == 0)){
                                    $filter[$key] = 0;
                                    }
                                    elseif((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])){
                                          $funcName = $val['function_name'];
                                          $serviceName = $val['service_name'];
                                          $filter[$key] = $this->container->get($serviceName)->$funcName();
                                      }
                                      else {
                                          $filter[$key] = $val['default'];
                                      }
                                }
                            }
                            $dataType[$key] = $val['data_type'];
                        }
                    } // if not empty of filter configuration
                    else {
                        $logger->debug("filter configuration not found for given product type of report");
                    }
                    if (!(empty($reportConfig['product_type_report']))) { // FOR Product Type Logic
                    $productType = (!(empty($filter['product_type']))) ? $filter['product_type'] : $reportConfig['product_type_report']['default'];
                        $isProductTypeReport = 1;
                        $isSeperateServerSideForTypes = (!(empty($reportConfig['product_type_report']['serverside_disp_each_type']))) ? $reportConfig['product_type_report'] : 0;
                    }
                    $reportConfigDetails = ((!(empty($isProductTypeReport) )) && (!(empty($reportConfig['prod_type'][$productType])))) ? $reportConfig['prod_type'][$productType] : $reportConfig;
                        $reportwiseConfiguration = $reportConfigDetails;
                        $userIds = $this->container->get('izmo_user_security_info.user_security_provider')->getUserIds();
                        if (!(empty($reportwiseConfiguration['stored_proc']))) {
                            $storedProcName = $reportwiseConfiguration['stored_proc'];
                        } 
                        if (!(empty($reportwiseConfiguration['stored_proc_params']))) {
                            $storedProcParameters = $reportwiseConfiguration['stored_proc_params'];
                        } 
                        if ((!(empty($storedProcParameters))) && (!(empty($storedProcName)))) {
                            $spParametersLabelArray = explode(',', $storedProcParameters);
                            $spParametersArrayCount = count($spParametersLabelArray);
                            $spFilterParam = [];
                            for ($i = 0; $i < $spParametersArrayCount; $i++) { //to order filters & its data type based on sp_params order mentioned in yml
                                $spFilterParam[$i]['filter'] = $filter[$spParametersLabelArray[$i]];
                                $spFilterParam[$i]['data_type'] = $dataType[$spParametersLabelArray[$i]];
                            }
                            $filterParams = array();
                            $filterParams['usr_ids'] = $userIds;
                            $filterParams['sp_params'] = $spFilterParam;
                            $serverProcessConfig = ((!(empty($isSeperateServerSideForTypes))) && (!(empty($reportConfigDetails['serverside_processing_detail'])))) ? $reportConfigDetails['serverside_processing_detail'] : $reportConfig['serverside_processing_detail'];
                            $incompleteData = $this->container->get('izmo_datatables.server_side_processing')->processServerSideData($serverProcessConfig,$storedProcName,$_POST,$filterParams,$url);
                            $resultdata = json_decode($incompleteData->getContent());
                            $c = 0;
                            foreach($resultdata->data as $data)
                            {
                                $wordsArray = explode(",",$data[3]);
                                foreach($wordsArray as $word){
                                    $translateable[] = $this->getTranslation($word);
                                 }
                                 $resultdata->data[$c][3] = $wordsString = implode(",",$translateable);
                                 $dataArray[$c] = $wordsString; 
                                 $c++; unset($translateable) ;
                           }
                           return $incompleteData->setContent(json_encode($resultdata));
                        } else {
                            $errorFlag = 1;
                            $logger->crit("stored procedure parameters or stored procedure name not found for prod_type field for report");
                        }
                } else {
                    $errorFlag = 1;
                    $logger->crit("No configuration details found for given report name");
                }
            } else {
                $errorFlag = 1;
                $logger->crit("No Parameters posted for ajax call in given report");
            }
       } catch (\Exception $e) {
            $errorFlag = 1;
            $logger->crit("Exception occured during fetching data with details below:");
            $logger->crit($e);
        } 
    }
    
    /**
     * To format the DataTable result set  - FOR DATA IMPORT Report rendering
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderDataForDataImport($columns, $data) {
        
        $out = array();
        for ($i = 0, $ien = count($data); $i < $ien; $i++) {
            $resData = $data[$i];
            $row = array();
            for ($j = 0, $jen = count($columns); $j < $jen; $j++) {
                $column = $columns[$j];
                if (!(empty($column['formatter']))) {
                    $colFormatter = $column['formatter'];
                        if($colFormatter == 'date'){                     
                        $retentionPeriodDays = $this->getRetentionPeriodInDays()." days";
                        //check retention date
                        $date= new \DateTime(date('Y-m-d H:i:s'));
                        date_sub($date,date_interval_create_from_date_string($retentionPeriodDays));
                        $retention_period_start_date = date_format($date,"Y-m-d H:i:s");
                        $selected_date = $resData[$column['db']];
                        if ($selected_date < $retention_period_start_date) {
                            $resData['filename'] = $resData['filename'];
                        }
                        else
                        {
                            $filePath = $this->getFilePath($resData['id']);
                            if($filePath != "" && $filePath != null){
                                $resData['filename'] = "<a href='".$filePath."' download target='_blank'>".$resData['filename']."</a>";
                            }
                            else
                            {
                                $resData['filename'] = $resData['filename'];
                            }                           
                        }                        
                        $resData[$column['db']] = $this->container->get('reports.service_provider')->formatDate($resData[$column['db']]);                      
                    }
                    else if ($colFormatter == 'ind') {
                        $class = $this->getIndicatorsForDataImportReports($resData[$column['db']]);
                        $resData[$column['db']] = "<span class='indicator $class'></span>";
                    } else if ($colFormatter == 'num') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0);
                    } else if ($colFormatter == 'curr') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 1);
                    } else if ($colFormatter == 'err') {
                        //if string length is greater than 20 characters
                        if(strlen($resData[$column['db']]) > 20)
                        {
                            $resData[$column['db']] = substr($resData[$column['db']],0,20).'...  <abbr style="color:blue" title="'.$resData[$column['db']].'">more</abbr>';
                        }
                        else
                        {
                            $resData[$column['db']] = $resData[$column['db']];
                        }                        
                    }
                }
                if (!(empty($column['is_translatable']))) {
                    $resData[$column['db']] = $this->container->get('translator')->trans($resData[$column['db']]);
                }
                $row[$column['dt']] = $resData[$column['db']];
            }
            $out[] = $row;
        }
        return $out;       
    } 
    
    public function getIndicatorsForDataImportReports($value){
        $conditionSet =  $this->container->get('ymlparser.service.provider')->parseYmlFiles('data_import_indicator_conditions.yml','/../../ReportAccessControlBundle/Resources/config/')['conditions'];
        $elemClass = $conditionSet['default_class'];
        unset($conditionSet['default_class']);
        foreach ($conditionSet as $key => $val) {
            if ((!(empty($val['class'])))) {
                if ((isset($val['start'])) && (!(empty($val['class'])))) {
                    if($value == 0 && $val['start']==0)
                    {
                        $elemClass = $val['class'];
                        break;  
                    }
                    if($value == 1 && $val['start']==1)
                    {
                        $elemClass = $val['class'];
                        break;  
                    }
                    
                }
            } 
        }
        return $elemClass;
    }
    
    public function getFilePath($id)
    {
        $filepathObj = $this->container->get('doctrine')->getRepository('IZMOReportAccessControlBundle:DataImportReport')->getFilepath($id);
        if(!empty($filepathObj)){
            return $filepathObj[0]['filepath'];
        }
    }
    
    public function getRetentionPeriodInDays()
    {
        $buId = $this->getOwnerBuIdOfUsrLoggedIn();
        $categoryConfigObj = $this->container->get('doctrine')->getRepository('IZMOCustomConfigBundle:CustomConfig')->findOneBy(array('configLabel' => 'retention_date','organization' => 1,'owner' => $buId));
        $key='';
        if(!empty($categoryConfigObj)){
            $key = $categoryConfigObj->getConfigValue();
        }
        else
        {
            $categoryConfigObj = $this->container->get('doctrine')->getRepository('IZMOCustomConfigBundle:CustomConfig')->findOneBy(array('configLabel' => 'default_retention_date','organization' => 1));
            if(!empty($categoryConfigObj)){
                $key = $categoryConfigObj->getConfigValue();
            }
            else{
                $key = SELF::DEFAULT_RETENTION_DATE ;
            }
        }
        return $key;
    }
}
