<?php

namespace IZMO\ReportAccessControlBundle\EventListener;
use Oro\Bundle\DataGridBundle\Event\BuildAfter;
use Doctrine\ORM\EntityManager;


class DashboardChannelListener {
    /**
     * @var EntityManager
     */
    protected $entityManager;
    
    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
        
    }
    
     /**
     * @param BuildAfter $event
     */
    public function onBuildAfter(BuildAfter $event)
    {
        $datagrid   = $event->getDatagrid();
        $datasource = $datagrid->getDatasource();
        $parameters = $datagrid->getParameters();        
        $resultSet = $this->entityManager->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getSalesPerChannel($parameters);
        $source=[];
        foreach($resultSet as $key=>$val){
            $data = [
                    'channelName' => $val['channelName'],
                    'Actual'=>$val['actual'],
                    'projection'=>$val['projection'],
                    'projectionper'=>$val['projectionper'],
                    'prevActual'=>$val['actualprev'],
            ];
            array_push($source,$data); 
        }       
       $datasource->setArraySource($source);           
    }
      public function getSalesRepository(){
       return $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess');
    }
}