<?php

namespace IZMO\ReportAccessControlBundle\EventListener;
use Oro\Bundle\DataGridBundle\Event\BuildAfter;
use Doctrine\ORM\EntityManager;


class DashboardComplaintSummaryListener {
     /**
     * @var EntityManager
     */
    protected $entityManager;
    
    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
        
    }
    
     /**
     * @param BuildBefore $event
     */
    public function onBuildAfter(BuildAfter $event)
    {
        $datagrid   = $event->getDatagrid();
        $datasource = $datagrid->getDatasource();
        $parameters = $datagrid->getParameters();
        
        $resultset = $this->entityManager->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getDashboardCompalintSummary($parameters);
        $source=[];
        foreach($resultset as $key=>$val){
            $data = [
                    'createdate' => $val['createdate'],
                    'client_name'=>$val['client_name'],
                    'clientnumber'=>$val['clientnumber'],
                    'complaint'=>$val['complaint'],
                    'complaint_comments'=>$val['complaint_comments'],
                    'comments'=>$val['comments'],
                    'resolutionComments'=>$val['resolutionComments'],
                    'resolutionDate'=>$val['resolutionDate'],
                    'salesman'=>$val['salesman'],
            ];
            array_push($source,$data); 
        }
       $datasource->setArraySource($source);
    }
      public function getSalesRepository(){
       return $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess');
    }

}