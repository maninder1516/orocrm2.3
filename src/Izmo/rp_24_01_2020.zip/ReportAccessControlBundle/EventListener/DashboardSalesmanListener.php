<?php

namespace IZMO\ReportAccessControlBundle\EventListener;
use Oro\Bundle\DataGridBundle\Event\BuildAfter;
use Doctrine\ORM\EntityManager;


class DashboardSalesmanListener {
     /**
     * @var EntityManager
     */
    protected $entityManager;
    
    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
        
    }
    
     /**
     * @param BuildBefore $event
     */
    public function onBuildAfter(BuildAfter $event)
    {
        $datagrid   = $event->getDatagrid();
        $datasource = $datagrid->getDatasource();
        $parameters = $datagrid->getParameters();
        
        $resultset = $this->entityManager->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getSalesPerSalesman($parameters);
        $source=[];
        foreach($resultset as $key=>$val){
            $data = [
                    'salesman' => $val['salesman'],
                    'Actual'=>$val['actual'],
                    'projection'=>$val['projection'],
                    'projections'=>$val['projectionper'],
                    'target'=>$val['target'],
                    'prevActual'=>$val['targetprev'],
                    'indicator'=>$val['indicator'],
            ];
            array_push($source,$data); 
        }
       $datasource->setArraySource($source);
    }
      public function getSalesRepository(){
       return $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess');
    }

}