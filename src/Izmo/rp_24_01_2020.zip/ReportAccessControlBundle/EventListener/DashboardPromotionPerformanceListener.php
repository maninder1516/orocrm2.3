<?php

namespace IZMO\ReportAccessControlBundle\EventListener;
use Oro\Bundle\DataGridBundle\Event\BuildAfter;
use Doctrine\ORM\EntityManager;


class DashboardPromotionPerformanceListener {
     /**
     * @var EntityManager
     */
    protected $entityManager;
    
    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
        
    }
    
     /**
     * @param BuildBefore $event
     */
    public function onBuildAfter(BuildAfter $event)
    {
        $datagrid   = $event->getDatagrid();
        $datasource = $datagrid->getDatasource();
        $parameters = $datagrid->getParameters();
        
        $resultset = $this->entityManager->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getPromotionPerformence($parameters);
        $source=[];
        foreach($resultset as $key=>$val){
            $data=[
                'name' => $val['name'],
                'promotionName'=>$val['promotionName'],
                'goalTotal'=>$val['goalTotal'],
                'totalSales'=>$val['totalSales'],
                'delta'=>$val['delta'],
                'indicator'=>$val['delta']
            ];
           array_push($source,$data); 
        }

        $datasource->setArraySource($source);
    }
      public function getSalesRepository(){
       return $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess');
    }

}