<?php

namespace IZMO\ReportAccessControlBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\Config;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\ConfigField;
use Oro\Bundle\OrganizationBundle\Entity\Organization;

/**
 * DataImportReport
 *
 * @ORM\Table(name="izmo_data_report_info")
 * @ORM\Entity(repositoryClass="IZMO\ReportAccessControlBundle\Entity\Repository\DataImportReportRepository")
 * @Config(
 *      defaultValues={
 *          "entity"={
 *              "icon"="",
 *          },
 *          "ownership"={
 *              "owner_type"="ORGANIZATION",
 *              "owner_field_name"="owner",
 *              "owner_column_name"="owner_id"
 *          },
 *          "security"={
 *              "type"="ACL",
 *              "group_name"=""
 *          },
 *          "dataaudit"={
 *              "auditable"=true
 *          },
 *      }
 * )
 */
class DataImportReport
{
    /**
     * @var bigint
     *
     * @ORM\Column(name="id", type="bigint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="filename", type="string", length=100)
     */
    private $filename;

    /**
     * @var int
     *
     * @ORM\Column(name="actual_records", type="integer", nullable=true)
     */
    private $actualRecords;

    /**
     * @var int
     *
     * @ORM\Column(name="available_records", type="integer", nullable=true)
     */
    private $availableRecords;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="createdat", type="datetime", nullable=true)
     */
    private $createdat;
    
    /**
     * @var float
     *
     * @ORM\Column(name="actual_turnover", type="float", nullable=true)
     */
    private $actualTurnover;
    
    /**
     * @var float
     *
     * @ORM\Column(name="available_turnover", type="float", nullable=true)
     */
    private $availableTurnover;
    
    /**
     * @var string
     *
     * @ORM\Column(name="platform", type="string", length=100)
     */
    private $platform;

    /**
     * @var string
     *
     * @ORM\Column(name="filepath", type="string", length=500)
     */
    private $filepath;
    
    /**
     * @var string
     *
     * @ORM\Column(name="error_message", type="string", length=1000)
     */
    private $errorMessage;
    
    /**
     * @var text
     *
     * @ORM\Column(name="error_message_details", type="text")
     */
    private $errorMessageDetails;
    
    /**
     * @var int
     *
     * @ORM\Column(name="business_unit_id", type="integer", nullable=true)
     */
    private $businessUnitId;
        
    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set filename
     *
     * @param string $filename
     *
     * @return DataImportReport
     */
    public function setFilename($filename)
    {
        $this->filename = $filename;

        return $this;
    }

    /**
     * Get filename
     *
     * @return string
     */
    public function getFilename()
    {
        return $this->filename;
    }

    /**
     * Set actualRecords
     *
     * @param integer $actualRecords
     *
     * @return DataImportReport
     */
    public function setActualRecords($actualRecords)
    {
        $this->actualRecords = $actualRecords;

        return $this;
    }

    /**
     * Get actualRecords
     *
     * @return int
     */
    public function getActualRecords()
    {
        return $this->actualRecords;
    }

    /**
     * Set availableRecords
     *
     * @param integer $availableRecords
     *
     * @return DataImportReport
     */
    public function setAvailableRecords($availableRecords)
    {
        $this->availableRecords = $availableRecords;

        return $this;
    }

    /**
     * Get availableRecords
     *
     * @return int
     */
    public function getAvailableRecords()
    {
        return $this->availableRecords;
    }

    /**
     * Set createdat
     *
     * @param \DateTime $createdat
     *
     * @return DataImportReport
     */
    public function setCreatedat($createdat)
    {
        $this->createdat = $createdat;

        return $this;
    }
    
    /**
     * Get createdat
     *
     * @return \DateTime
     */
    public function getCreatedat()
    {
        return $this->createdat;
    }

    /**
     * Get actualTurnover
     *
     * @return float
     */
    public function getActualTurnover()
    {
        return $this->actualTurnover;
    }
    
    /**
     * Set actualTurnover
     *
     * @param float $actualTurnover
     *
     * @return DataImportReport
     */
    public function setActualTurnover($actualTurnover)
    {
        $this->actualTurnover = $actualTurnover;

        return $this;
    }
    
    /**
     * Get availableTurnover
     *
     * @return float
     */
    public function getAvailableTurnover()
    {
        return $this->availableTurnover;
    }
    
    /**
     * Set availableTurnover
     *
     * @param float $availableTurnover
     *
     * @return DataImportReport
     */
    public function setAvailableTurnover($availableTurnover)
    {
        $this->availableTurnover = $availableTurnover;

        return $this;
    }
    
    /**
     * Set platform
     *
     * @param string $platform
     *
     * @return DataImportReport
     */
    public function setPlatform($platform)
    {
        $this->platform = $platform;

        return $this;
    }

    /**
     * Get platform
     *
     * @return string
     */
    public function getPlatform()
    {
        return $this->platform;
    }
    
    /**
     * Set filepath
     *
     * @param string $filepath
     *
     * @return DataImportReport
     */
    public function setFilepath($filepath)
    {
        $this->filepath = $filepath;

        return $this;
    }

    /**
     * Get filepath
     *
     * @return string
     */
    public function getFilepath()
    {
        return $this->filepath;
    }
    
    /**
     * Set errorMessage
     *
     * @param string $errorMessage
     *
     * @return DataImportReport
     */
    public function setErrorMessage($errorMessage)
    {
        $this->errorMessage = $errorMessage;

        return $this;
    }

    /**
     * Get errorMessage
     *
     * @return string
     */
    public function getErrorMessage()
    {
        return $this->errorMessage;
    }
    
    /**
     * Set errorMessageDetails
     *
     * @param text $errorMessageDetails
     *
     * @return DataImportReport
     */
    public function setErrorMessageDetails($errorMessageDetails)
    {
        $this->errorMessageDetails = $errorMessageDetails;

        return $this;
    }

    /**
     * Get errorMessageDetails
     *
     * @return text
     */
    public function getErrorMessageDetails()
    {
        return $this->errorMessageDetails;
    }
    
    /**
     * Set businessUnitId
     *
     * @param integer $businessUnitId
     *
     * @return DataImportReport
     */
    public function setBusinessUnitId($businessUnitId)
    {
        $this->businessUnitId = $businessUnitId;

        return $this;
    }

    /**
     * Get businessUnitId
     *
     * @return int
     */
    public function getBusinessUnitId()
    {
        return $this->businessUnitId;
    }
}
