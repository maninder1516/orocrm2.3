<?php
namespace IZMO\ReportAccessControlBundle\Entity\Repository;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;
use Oro\Bundle\SecurityBundle\ORM\Walker\AclHelper;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use IZMO\ReportAccessControlBundle\Exception\CustomException;

class DataImportReportRepository extends EntityRepository{
    
    public function getEnitityMgrPrepareHandler($qry){
        return $this->getEntityManager()->getConnection()->prepare($qry);
    }
    
    /**
     * 
     * @return type
     */
    public function getImportDataResult($userIds,$fromDate,$toDate,$platform,$uploadStatus)
    {    
        try{
            $qryRows = "call getImportDataExport('$userIds','$fromDate','$toDate','$platform','$uploadStatus')";
            $qryRowsPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRows);
            $qryRowsPrepareStmt->execute();
            $result = $qryRowsPrepareStmt->fetchAll();
            return $result;
        }
        catch(\Exception $e){
            return array('err'=>1);
        }
    }
    
    public function getFilepath($id)
    {
        try{
            $qryRows = "call getFilepathById($id)";
            $qryRowsPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRows);
            $qryRowsPrepareStmt->execute();
            $result = $qryRowsPrepareStmt->fetchAll();
            return $result;
        }
        catch(\Exception $e){
            return array('err'=>1);
        }
    }

}
