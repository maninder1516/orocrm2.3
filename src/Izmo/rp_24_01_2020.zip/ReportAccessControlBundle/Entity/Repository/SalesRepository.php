<?php
namespace IZMO\ReportAccessControlBundle\Entity\Repository;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;
use Oro\Bundle\SecurityBundle\ORM\Walker\AclHelper;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;

class SalesRepository extends EntityRepository implements ContainerAwareInterface{
       
    /**
     * @var ContainerInterface
     */
    private $container;

    public function setContainer(ContainerInterface $container = null){
        $this->container = $container;
    }
    
    public function getContainer(){
        return $this->container;
    }
    
    public function getEnitityMgrPrepareHandler($qry){
        return $this->getEntityManager()->getConnection()->prepare($qry);
    }
    
    /**
     * This function returs no. of week days present between start till previous day of cur month
     * @return int
     */
    public function getWorkingDaysCurrentDay(){
        $workingDaysTillCurrentDay = $this->getWorkingDaysCount(date("Y-m-01"), date("Y-m-d"));
        return ($workingDaysTillCurrentDay - 1);
    }
    
    /**
     * This function returs no. of week days present between start & end of present month
     * @return int
     */
    public function getWorkingDaysCurrentMonth(){
        return $this->getWorkingDaysCount(date('Y-m-01'), date("Y-m-t"));
    }
    
    /**
     * This function returs no. of week days present between start & end dates
     * @param DATE $start
     * @param DATE $end
     * @return int
     */
    public function getWorkingDaysCount($start,$end){
        $weekdaysCount = $this->getEnitityMgrPrepareHandler("call getTotalWeekDaysForDates('$start','$end')");
        $weekdaysCount->execute();
        $resultsArr = $weekdaysCount->fetch();
        return $resultsArr['WeekDays'];
    }
    
     /**
     * This function returs no. of week days present between start till previous day of cur month
     * @return int
     */
    public function getWorkingDaysCurrentDayForBu($buId){
        $workingDaysTillCurrentDay = $this->getWorkingDaysCountForBu(date("Y-m-01"), date("Y-m-d",strtotime("-1 days")),$buId);
        return $workingDaysTillCurrentDay;       
    }
    
    /**
     * This function returs no. of week days present between start & end of present month
     * @return int
     */
    public function getWorkingDaysCurrentMonthForBu($buId){
        return $this->getWorkingDaysCountForBu(date('Y-m-01'), date("Y-m-t"),$buId);
    }
    
    /**
     * This function returs no. of week days present between start & end dates
     * @param DATE $start
     * @param DATE $end
     * @return int
     */
    public function getWorkingDaysCountForBu($start,$end,$buId){
        $weekdaysCount = $this->getEnitityMgrPrepareHandler("call getTotalWeekDaysForDateBu('$start','$end',$buId)");
        $weekdaysCount->execute();
        $resultsArr = $weekdaysCount->fetch();
        return $resultsArr['WeekDays'];
    }
    
    /**
     * This function provides data related to sales done with respect to users
     * @param int $curYr
     * @param DATE $start
     * @param DATE $end
     * @param int $workingDaysTillCurrentDay
     * @param int $workingDaysTillCurrentMonth
     * @param string $userIds
     * @return Array
     */
    public function getQuadSpeedometerWidgetData($curYr,$start,$end, $workingDaysTillCurrentDay, $workingDaysTillCurrentMonth, $userIds){
        $qryRows = "call getQuadSpeedometerWidgetData($curYr,'$start','$end',$workingDaysTillCurrentDay, $workingDaysTillCurrentMonth, '$userIds')";
        $qryRowsPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRows);
        $qryRowsPrepareStmt->execute();
        return $qryRowsPrepareStmt->fetch();
    }
    
    /**
     * This function returns Acl helper object required for Data Security between users
     * @return object
     */
    public function getAclSecurityHelper(){
        return $this->container->get('oro_security.acl_helper');
    }
    
    /**
     * This function provides no. of Accounts related to Salesman either directly or under him (if mgr)
     * @return int
     */
    public function getAccountCount(){
        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb->select("COUNT(DISTINCT a.id) as accountcounts","SUM(a.frequency_of_visit) as theoretical_visits")
            ->from("OroAccountBundle:Account","a")
            ->join("OroUserBundle:User","b")
            ->where("b.multiplecodes not like '%dummy%'");
        $result = $qb->getQuery()->getScalarResult();
        return $result;
    }
    
    public function getAccountTheoreticalVisitCount($usrIds){
        try{
        $logger = $this->container->get('logger');
        $qryStatement = "call getAccountAndTheoreticalVisitsCount('$usrIds')";
        $qryPrepareStmt = $this->getEnitityMgrPrepareHandler($qryStatement);
        $qryPrepareStmt->execute();
        $result = $qryPrepareStmt->fetch();
        $qryPrepareStmt->closeCursor();
        return $result;
        }
        catch(\Exception $e){
            $logger->crit(" exception occured while retriving data with exception in getAccountTheoreticalVisitCount info below:");
            $logger->crit($e);
            return null;
        }
    }
    
    /**
     * This function is used for getting Visit Report & Calendar Event Counts
     * @param DATE $start
     * @param DATE $end
     * @param ids $usrIds
     * @return Array
     */
    public function getClientVisitAndEventCounts($start,$end,$usrIds){
        try{
        $logger = $this->container->get('logger');
        $accCalRelTable =  $this->container->get('reports.service_provider')->fetchCalendarEvntAccountMapperTable();
        $qryStatement = "call getClientVisitAndEventCount(:start,:end,:rel_tab,:usr_ids)";
        $qryPrepareStmt = $this->getEnitityMgrPrepareHandler($qryStatement);
        $qryPrepareStmt->bindValue(':start',$start);
        $qryPrepareStmt->bindValue(':end',$end);
        $qryPrepareStmt->bindValue(':rel_tab',$accCalRelTable);
        $qryPrepareStmt->bindValue(':usr_ids',$usrIds);
        $qryPrepareStmt->execute();
        $result = $qryPrepareStmt->fetch();
        $qryPrepareStmt->closeCursor();
        return $result;
        }
        catch(\Exception $e){
            $logger->crit(" exception occured while retriving data with exception in getClientVisitAndEventCounts info below:");
            $logger->crit($e);
            return null;
        }
    }
    
    /**
     * This function is used for getting Missed Client visits & total reports Counts
     * @param DATE $start
     * @param DATE $end
     * @return Array
     */
    public function getMissedAndReportsCounts($start,$end,$usrIds,$appointmentHours){
        try{
        $logger = $this->container->get('logger');
        $qryStatement = "call getMissedAndReportsCounts(:start,:end,:usr_ids,:appointment_hours)";
        $qryPrepareStmt = $this->getEnitityMgrPrepareHandler($qryStatement);
        $qryPrepareStmt->bindValue(':start',$start);
        $qryPrepareStmt->bindValue(':end',$end);
        $qryPrepareStmt->bindValue(':usr_ids',$usrIds);
        $qryPrepareStmt->bindValue(':appointment_hours',$appointmentHours);
        $qryPrepareStmt->execute();
        $result = $qryPrepareStmt->fetch();
        $qryPrepareStmt->closeCursor();
        return $result;
        }
        catch(\Exception $e){
            $logger->crit(" exception occured while retriving data with exception in getMissedAndReportsCounts info below:");
            $logger->crit($e);
            return null;
        }
    }
    
    /**
     * This function is used for getting complaints summary data
     * @param string $usrIds
     * @param DATE $start
     * @param DATE $end
     * @return Array
     */
    public function getDashboardComplaints($usrIds,$start,$end){
        try{
            $calendarAccountRelTableName = $this->container->get('utility.helper')->getRelationTableName('Oro\Bundle\CalendarBundle\Entity\CalendarEvent', 'Oro\Bundle\AccountBundle\Entity\Account');
            $qryStatement = "call dashboardComplaints('$usrIds','$start','$end','$calendarAccountRelTableName')";
            $qryPrepareStmt = $this->getEnitityMgrPrepareHandler($qryStatement);
            $qryPrepareStmt->execute();
            $resultSet = $qryPrepareStmt->fetchAll();
            return $resultSet;
        }
        catch(\Exception $e){
            return array('err'=>1);
        }         
    }
    /**
     * 
     * 
     * @param type $organizationId
     * @param type $workingDaysTillCurrentDay
     * @param type $workingDaysTillCurrentMonth
     * @param type $userIds
     * @param type $startDate
     * @param type $endDate
     * @param type $prevStartDate
     * @param type $prevEndDate
     * @return type
     */
    public function getsalesPerIndexData($organizationId,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,$userIds,$startDate, $endDate,$prevStartDate,$prevEndDate,$buIds,$ownrBuIdLgnUsr,$turnoverType,$workingDaysTillCurrentYear,$startDayOfCurYr,$endDayOfCurYr){
        try{
            $qryRowsSalesPerIndex = "call getsalesPerIndexData($organizationId,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,'$userIds','$startDate', '$endDate','$prevStartDate','$prevEndDate','$buIds',$ownrBuIdLgnUsr,$turnoverType,$workingDaysTillCurrentYear,'$startDayOfCurYr','$endDayOfCurYr')";
            $qryRowsSalesPerIndexPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsSalesPerIndex);
            $qryRowsSalesPerIndexPrepareStmt->execute();
            return $qryRowsSalesPerIndexPrepareStmt->fetchAll();  
        }
        catch(\Exception $e){
            return array('err'=>1);
        }        
    } 

    /**
     * This function is used for dashboard chart
     * @param string procName
     * @param int selYear
     * @param DATE $start
     * @param DATE $end
     * @param int $cmpdate1
     * @param int $cmpdate2
     * @param int $categoryId
     * @param string $userIds
     * @param int $isMgr
     * @param string $buIds
     * @return Array
     */
    public function getDashboardManagerWidgetData($storedProcSelected,$selYear, $startDate, $endDate, $cmpdate1, $cmpdate2, $categoryId,$userIds,$isMgr,$buIds,$ownrBuIdLgnUsr,$turnoverType)
    {
        try{
            $qryRows = "call ".$storedProcSelected."($selYear,'$startDate','$endDate',$cmpdate1, $cmpdate2, $categoryId,'$userIds',$isMgr,'$buIds',$ownrBuIdLgnUsr,$turnoverType)";
            $qryRowsPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRows);
            $qryRowsPrepareStmt->execute();
            return $qryRowsPrepareStmt->fetch();
        }
        catch(\Exception $e){
            return array('err'=>1);
        }
    }
    
    /**
     * 
     * @param type $organizationId
     * @param type $workingDaysTillCurrentDay
     * @param type $workingDaysTillCurrentMonth
     * @param type $getUserIds
     * @param type $start_date
     * @param type $end_date
     * @return type
     */
    public function getSalesPerSalesman($parameters){
        $organizationId = $parameters->get('organizationId');
        $currentStartDate = $parameters->get('currentStartDate');
        $currentEndDate =   $parameters->get('currentEndDate');
        $prevStartdate = $parameters->get('prevStartdate');
        $prevEndDate =   $parameters->get('prevEndDate');
        $userIds = $parameters->get('userIds');
        $workingDaysTillCurrentDay = $parameters->get('workingDaysTillCurrentDay');
        $workingDaysTillCurrentMonth = $parameters->get('workingDaysTillCurrentMonth');
        
        foreach($_REQUEST as $key=>$val){
            if(!(empty($val['organizationId']))){
                $keyVal = $key;
                break;
            }
        }
        if(!(empty($keyVal))){
         if(!(empty($_REQUEST[$keyVal]['organizationId'])))
        {$organizationId = $_REQUEST[$keyVal]['organizationId'];}
        if(!(empty($_REQUEST[$keyVal]['currentStartDate'])))
        {$currentStartDate = $_REQUEST[$keyVal]['currentStartDate'];}
        if(!(empty($_REQUEST[$keyVal]['currentEndDate'])))
        {$currentEndDate = $_REQUEST[$keyVal]['currentEndDate'];}
        if(!(empty($_REQUEST[$keyVal]['prevStartdate'])))
        {$prevStartdate = $_REQUEST[$keyVal]['prevStartdate'];}
        if(!(empty($_REQUEST[$keyVal]['prevEndDate'])))
        {$prevEndDate = $_REQUEST[$keyVal]['prevEndDate'];}
        if(!(empty($_REQUEST[$keyVal]['userIds'])))
        {$userIds = $_REQUEST[$keyVal]['userIds'];}
        if(!(empty($_REQUEST[$keyVal]['workingDaysTillCurrentDay'])))
        {$workingDaysTillCurrentDay = $_REQUEST[$keyVal]['workingDaysTillCurrentDay'];}
        if(!(empty($_REQUEST[$keyVal]['workingDaysTillCurrentMonth'])))
        {$workingDaysTillCurrentMonth = $_REQUEST[$keyVal]['workingDaysTillCurrentMonth'];}
        }
       
        $qryRows = "call getSalesPerSalesman($organizationId,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,'$userIds','$currentStartDate', '$currentEndDate','$prevStartdate','$prevEndDate')";
        $qryRowsPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRows);
        $qryRowsPrepareStmt->execute();
        $resultset = $qryRowsPrepareStmt->fetchAll();
        return $resultset;    
    }
    
    /**
     * 
     * @param type $userId
     * @param type $currentDate
     * @param type $businessUnit
     * @return array
     */
    public function getPromotionPerformence($parameters){
        $usrIds = $parameters->get('userIds');
        $startDate =   $parameters->get('currentDate');
        $buIds = $parameters->get('businessUnit');
        
        foreach($_REQUEST as $key=>$val){
            if(!(empty($val['userIds']))){
                $keyVal = $key;
                break;
            }
        }
        
        if(!(empty($keyVal))){
         if(!(empty($_REQUEST[$keyVal]['userIds'])))
        {$usrIds = $_REQUEST[$keyVal]['userIds'];}
        if(!(empty($_REQUEST[$keyVal]['currentDate'])))
        {$startDate = $_REQUEST[$keyVal]['currentDate'];}
        if(!(empty($_REQUEST[$keyVal]['businessUnit'])))
        {$buIds = $_REQUEST[$keyVal]['businessUnit'];}
        }
        
        
        $qryRows = "call getPerformancePromotions('$usrIds','$buIds','$startDate')";
        $qryRowsPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRows);
        $qryRowsPrepareStmt->execute();
        $resultset = $qryRowsPrepareStmt->fetchAll();
        return $resultset;
    }
    
    /**
     * 
     * @param type $userId
     * @param type $currentDate
     * @param type $businessUnit
     * @return array
     */
    public function getDashboardCompalintSummary($parameters){
        $usrIds = $parameters->get('userIds');
        $startDate =   $parameters->get('currentStartDate');
        $endDate =   $parameters->get('currentEndDate');
        $relTableName = $parameters->get('relTableName');
        
        foreach($_REQUEST as $key=>$val){
            if(!(empty($val['userIds']))){
                $keyVal = $key;
                break;
            }
        }
        
        if(!(empty($keyVal))){
         if(!(empty($_REQUEST[$keyVal]['userIds'])))
        {$usrIds = $_REQUEST[$keyVal]['userIds'];}
        if(!(empty($_REQUEST[$keyVal]['currentStartDate'])))
        {$startDate = $_REQUEST[$keyVal]['currentStartDate'];}
        if(!(empty($_REQUEST[$keyVal]['currentEndDate'])))
        {$endDate = $_REQUEST[$keyVal]['currentEndDate'];}
        if(!(empty($_REQUEST[$keyVal]['relTableName'])))
        {$relTableName = $_REQUEST[$keyVal]['relTableName'];}
        }
        
        
        $qryStatement = "call dashboardComplaints('$usrIds','$startDate','$endDate','$relTableName')";
        $qryPrepareStmt = $this->getEnitityMgrPrepareHandler($qryStatement);
        $qryPrepareStmt->execute();
        $resultSet = $qryPrepareStmt->fetchAll();
        return $resultSet;
    }
    
    /**
     * 
     * @param Date $curStartDate
     * @param Date $curEndDate
     * @param Date $prevStartDate
     * @param Date $prevEndDate
     * @param string $userIds
     * @return array
     */
    public function getTopFlopReportData($curStartDate,$curEndDate,$prevStartDate,$prevEndDate,$userIds,$buIds,$ownrBuIdLgnUsr,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,$turnoverType){ 
         try {
            $qryRowsTopFlop = "call getTopFlopReportData('$curStartDate','$curEndDate','$prevStartDate','$prevEndDate','$userIds','$buIds',$ownrBuIdLgnUsr,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,$turnoverType)";
            $qryRowsTopFlopPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsTopFlop);
            $qryRowsTopFlopPrepareStmt->execute();
            return $qryRowsTopFlopPrepareStmt->fetchAll();
        } catch (\Exception $e) {
            return array('err' => 1);
        }
    }
    
    /**
     * 
     * @param Date $curStartDate
     * @param Date $curEndDate
     * @param int $curYr
     * @param string $userIds
     * @param int $workingDaysTillCurrentDay
     * @param int $workingDaysTillCurrentMonth
     * @param int $categoryId
     * @param int $isMgr
     * @param string $buIds
     * @return array
     */
    public function getNetSalesSpeedometerDataForManager($curStartDate, $curEndDate,$curYr , $userIds, $workingDaysTillCurrentDay, $workingDaysTillCurrentMonth,$categoryId,$isMgr,$buIds,$ownrBuIdLgnUsr,$turnoverType){
        try{
        $qryRowsNetSales = "call getNetSalesExcludingTireSalesWidgetDataForManager('$curStartDate','$curEndDate',$curYr, '$userIds', $workingDaysTillCurrentDay, $workingDaysTillCurrentMonth,$categoryId,$isMgr,'$buIds',$ownrBuIdLgnUsr,$turnoverType)";
        $qryRowsNetSalesPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsNetSales);
        $qryRowsNetSalesPrepareStmt->execute();
        return $qryRowsNetSalesPrepareStmt->fetch();
        }
        catch(\Exception $e){
            return array('err'=>1);
        }
    }
    
    /**
     * 
     * @param int $year
     * @param int $organization
     * @param string $userIds
     * @param type $workingDaysTillCurrentDay
     * @param int $workingDaysTillCurrentYear
     * @param int $categoryId
     * @param int $isMgr
     * @param string $buIds
     * @return array
     */
    public function getAnnualTotalSalesWithoutTiresData($year, $organization, $userIds, $workingDaysTillCurrentDay, $workingDaysTillCurrentYear ,$catgoryId,$isMgr,$buIds,$ownrBuIdLgnUsr, $turnoverType){
        try{
        $qryRowsAnnualTotalSales = "call getAnnualTotalSalesWithoutTiresData($year,$organization, '$userIds', $workingDaysTillCurrentDay, $workingDaysTillCurrentYear,$catgoryId,$isMgr,'$buIds',$ownrBuIdLgnUsr,$turnoverType)";
        $qryRowsAnnualTotalSalesPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsAnnualTotalSales);
        $qryRowsAnnualTotalSalesPrepareStmt->execute();
        return $qryRowsAnnualTotalSalesPrepareStmt->fetch();
        }
        catch(\Exception $e){
            return array('err'=>1);
        }
    }
    
    /**
     * This function lists the Year values present in sales history table
     * @return array
     */
    public function getYearsForSalesHistoryData() {
        $qryStmt = $this->getEnitityMgrPrepareHandler("call fetchSalesDataYears()");
        $qryStmt->execute();
        $years = [];
        $qryResult = $qryStmt->fetchAll();
        if (!(empty($qryResult))) {
            foreach ($qryResult as $res) {
                $years[] = $res['year'];
            }
        }
        return $years;
    }

    /**
     * This function returns array required for Excel Export 
     * @param string $getUserIds
     * @param string $procedureSelected
     * @param array $params
     * @return array
     */
    public function getReportExportDataForParameters($getUserIds, $procedureSelected, $params) {
        try{
        return $this->getQueryResultForParamsToExport("call $procedureSelected ('$getUserIds'", $params);
        }
        catch(\Exception $e){
          return array('err'=>1);
        }
    }
    
    public function getQueryResultForParamsToExport($qry,$params){
        if(!(empty($params)))
        {  
            $paramCnt = count($params);
            for($i =0;$i < $paramCnt;$i++){
                $parameterizedStrArr[$i] = ':filter'.$i;
            }
            $qry .= ",".implode(',',$parameterizedStrArr) . ")";
            $qryHandler = $this->getEnitityMgrPrepareHandler($qry);
            $j = 0;
            foreach ($params as $key => $val) {
             $filtr = $val['filter'];
             if ((!(empty($val['data_type']))) && ($val['data_type'] == 'string')) {
                  $filtr = addslashes($val['filter']);
             }
             $qryHandler->bindValue(':filter'.$j,$filtr);
             $j++;
            }
            $qryHandler->execute();
            $res = $qryHandler->fetchAll();
            $qryHandler->closeCursor();
            return $res;
        }
    }

    /**
     * This function is used to prepare query based on params
     * @param string $qry
     * @param array $params
     * @return array
     */
    public function getQueryStringForParam($qry, $params) {
        $paramCnt = count($params);
        $i = 0;
        $parameterizedStr = '';
        foreach ($params as $key => $val) {
            if ((!(empty($val['data_type']))) && ($val['data_type'] == 'string')) {
                $parameterizedStr = $parameterizedStr . '"'.str_replace("'","''",addslashes($val['filter'])).'"';
            } else {
                $parameterizedStr = $parameterizedStr . $val['filter'];
            }
            if ($i < $paramCnt - 1) {
                $parameterizedStr = $parameterizedStr . ',';
            }
            $i++;
        }
        return $this->getQueryResult($qry . "," . $parameterizedStr . ")");
    }
    
    /**
     * 
     * @param string $qry
     * @return array
     */
    public function getQueryResult($qry){
        $qryHandler = $this->getEnitityMgrPrepareHandler($qry);
        $qryHandler->execute();
        $qryHandlerResult = $qryHandler->fetchAll();
        $qryHandler->closeCursor();
        return $qryHandlerResult;
    }
    
    /**
     * This returns User Sales Category Details
     * @param id $orgId
     * @return array
     */
    public function getUserSalesCategoryTypes($orgId){
        return $this->getEntityManager()->createQuery("SELECT iusct.id,iusct.type from IZMOUserTargetBundle:UserSalesCategoryType  iusct where iusct.owner = $orgId")->getResult();
    }
    
    /**
     * 
     * @param type $buIds
     * @param type $cal_acc_rel_table
     * @return type
     */
    public function getTotalVisitsDoneForSalesman($buIds, $cal_acc_rel_table) {
        try {
            $usr_ids = $_POST['id'];
            $filters = json_decode($_POST['filters'], true);
            $client_name = ($filters['client_name'] == '') ? 'none' : $filters['client_name'];
            $client_code = ($filters['client_code'] == '') ? 'none' : $filters['client_code'];
            $from_dat_flg = $filters['from_dat_flg'];
            $to_dat_flg = $filters['to_dat_flg'];
            $qry = "SELECT config_value FROM custom_config where config_label = 'appointment_schedule_hours' AND business_unit_owner_id = $buIds";
            $qryPrepareStmt = $this->getEnitityMgrPrepareHandler($qry);
            $qryPrepareStmt->execute();
            $resultSet = $qryPrepareStmt->fetchAll();
            $interval_config_hrs = $resultSet[0]['config_value'];
            $qryRowsChallenges = "call getTotalVisitsDoneForSalesman('" . $usr_ids . "','" . $client_name . "','" . $client_code . "','" . $from_dat_flg . "','" . $to_dat_flg . "','" . $cal_acc_rel_table . "','" . $interval_config_hrs . "')";
            $qryRowsStmt = $this->getEnitityMgrPrepareHandler($qryRowsChallenges);
            $qryRowsStmt->execute();
            $result = $qryRowsStmt->fetchAll();
            $qryRowsStmt->closeCursor();
            return $result[0]['no_of_visits_done'];
        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * 
     * @param type $dateSel
     * @param type $userIds
     * @return type
     */
    public function getCurActiveChallenges($userIds, $buIds, $dateSelected,$relatedBuIds,$ownrBuIdLgnUsr){
        try{
        $qryRowsChallenges = "call getCurActiveChallengesData('$userIds', '$buIds', '$dateSelected','$relatedBuIds',$ownrBuIdLgnUsr)";
        $qryRowsChallengesPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsChallenges);
        $qryRowsChallengesPrepareStmt->execute();
        $resultSet = $qryRowsChallengesPrepareStmt->fetchAll();
        $qryRowsChallengesPrepareStmt->closeCursor();
        return $resultSet;
        }
        catch(\Exception $e){
            return array('err'=>1);
        }        
    }
    /**
     * 
     * @param type $userIds
     * @param type $curStartDate
     * @param type $curEndDate
     * @param type $workingDaysTillCurrentDay
     * @return type
     */
    public function outStandingCreditReport($userIds,$curStartDate,$curEndDate,$workingDaysTillCurrentDay,$relatedBuIds,$ownrBuIdLgnUsr,$turnoverType){
        try{
        $qryRowsOutStandingCredit = "call getOutStandingCreditReportData('$userIds','$curStartDate','$curEndDate',$workingDaysTillCurrentDay,'$relatedBuIds',$ownrBuIdLgnUsr,$turnoverType)";
        $qryRowsOutStandingCreditPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsOutStandingCredit);
        $qryRowsOutStandingCreditPrepareStmt->execute();
        $resultSet = $qryRowsOutStandingCreditPrepareStmt->fetchAll();
        $qryRowsOutStandingCreditPrepareStmt->closeCursor();
        return $resultSet;
        }
        catch(\Exception $e){
            return array('err'=>1);
        }        
    }

    /**
     * 
     * @param type $organizationId
     * @param type $workingDaysTillCurrentDay
     * @param type $workingDaysTillCurrentMonth
     * @param type $getUserIds
     * @param type $start_date
     * @param type $end_date
     * @return type
     */
    public function getSalesPerChannel($parameters){
        
        $currentStartDate = $parameters->get('currentStartDate');
        $currentEndDate =   $parameters->get('currentEndDate');
        $prevStartdate = $parameters->get('prevStartdate');
        $prevEndDate =   $parameters->get('prevEndDate');
        $userIds = $parameters->get('userIds');
        $workingDaysTillCurrentDay = $parameters->get('workingDaysTillCurrentDay');
        $workingDaysTillCurrentMonth = $parameters->get('workingDaysTillCurrentMonth');
        
        foreach($_REQUEST as $key=>$val){
            if(!(empty($val['currentStartDate']))){
                $keyVal = $key;
                break;
            }
        }
        if(!(empty($keyVal))){
            if(!(empty($_REQUEST[$keyVal]['currentStartDate'])))
            {$currentStartDate = $_REQUEST[$keyVal]['currentStartDate'];}
            if(!(empty($_REQUEST[$keyVal]['currentEndDate'])))
            {$currentEndDate = $_REQUEST[$keyVal]['currentEndDate'];}
            if(!(empty($_REQUEST[$keyVal]['prevStartdate'])))
            {$prevStartdate = $_REQUEST[$keyVal]['prevStartdate'];}
            if(!(empty($_REQUEST[$keyVal]['prevEndDate'])))
            {$prevEndDate = $_REQUEST[$keyVal]['prevEndDate'];}
            if(!(empty($_REQUEST[$keyVal]['userIds'])))
            {$userIds = $_REQUEST[$keyVal]['userIds'];}
            if(!(empty($_REQUEST[$keyVal]['workingDaysTillCurrentDay'])))
            {$workingDaysTillCurrentDay = $_REQUEST[$keyVal]['workingDaysTillCurrentDay'];}
            if(!(empty($_REQUEST[$keyVal]['workingDaysTillCurrentMonth'])))
            {$workingDaysTillCurrentMonth = $_REQUEST[$keyVal]['workingDaysTillCurrentMonth'];}
        }
       
        $qryRows = "call getSalesPerChannel($workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,'$userIds','$currentStartDate', '$currentEndDate','$prevStartdate','$prevEndDate')";
        $qryRowsPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRows);
        $qryRowsPrepareStmt->execute();
        $resultset = $qryRowsPrepareStmt->fetchAll();
        return $resultset;    
    }
    /**
     * 
     * @param type $userIds
     * @param type $curStartDate
     * @param type $curEndDate
     * @param type $workingDaysTillCurrentDay
     * @param type $lowerLimit
     * @param type $pageLimit
     * @param type $isExport
     * @return type
     */
    public function outStandingCreditReportCustomer($userIds,$curStartDate,$curEndDate,$workingDaysTillCurrentDay,$lowerLimit,$pageLimit,$isExport){
        try{
        $qryRowsOutStandingCredit = "call getOutStandingCreditReportCustomerData('$userIds','$curStartDate','$curEndDate',$workingDaysTillCurrentDay,$lowerLimit,$pageLimit,$isExport)";
        $qryRowsOutStandingCreditPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsOutStandingCredit);
        $qryRowsOutStandingCreditPrepareStmt->execute();
        $resultSet = $qryRowsOutStandingCreditPrepareStmt->fetchAll();
        $qryRowsOutStandingCreditPrepareStmt->closeCursor();
        return $resultSet;
        }
        catch(\Exception $e){
            return array('err'=>1);
        }        
    }
    /**
     * 
     * @param type $curStartDate
     * @param type $curEndDate
     * @param type $prevStartDate
     * @param type $prevEndDate
     * @param type $userIds
     * @param type $curYearStartDate
     * @param type $curYearEndDate
     * @param type $prevYearStartDate
     * @param type $prevYearEndDate
     * @param type $workingDaysTillCurrentDay
     * @param type $workingDaysTillCurrentMonth
     * @param type $salesmanSearchData
     * @param type $channelSearchData
     * @param type $categoryId
     * @param type $lowerLimit
     * @param type $upperLimit
     * @param type $isExport
     * @return type
     */
    public function getTopFlopReportCustomerData($curStartDate,$curEndDate,$prevStartDate,$prevEndDate,$userIds,$curYearStartDate,$curYearEndDate,$prevYearStartDate,$prevYearEndDate,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,$salesmanSearchData,$channelSearchData,$categoryId,$lowerLimit,$upperLimit,$isExport){ 
         try {
            $qryRowsTopFlop = "call getTopFlopReportCustomerData('$curStartDate','$curEndDate','$prevStartDate','$prevEndDate','$userIds','$curYearStartDate','$curYearEndDate','$prevYearStartDate','$prevYearEndDate',$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,'$salesmanSearchData','$channelSearchData',$categoryId,$lowerLimit,$upperLimit,$isExport)";
            $qryRowsTopFlopPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsTopFlop);
            $qryRowsTopFlopPrepareStmt->execute();
            return $qryRowsTopFlopPrepareStmt->fetchAll();
        } catch (\Exception $e) {
            return array('err' => 1);
        }
    }
    public function getPageLimit($pageLimit){   
        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb->select("cc.configValue as pageLimit")
            ->from('IZMOCustomConfigBundle:CustomConfig','cc')
            ->where("cc.configLabel = :pageLimit")
            ->setParameter('pageLimit',$pageLimit);
        $qryResult = $qb->getQuery()->getScalarResult();        
        return isset($qryResult[0]['pageLimit'])?$qryResult[0]['pageLimit']:0; 
    }  
    /**
     * 
     * @param type $id
     * @param type $userIds
     * @param type $yearStartDate
     * @param type $curEndDate
     * @return type
     */
    public function getSalesOverTimeData($id,$userIds,$yearStartDate, $curEndDate,$relatedBuIds,$ownrBuIdLgnUsr){
        try{
            $qryRowsSalesOverTime = "call getSalesOverTimeData('$id','$userIds','$yearStartDate', '$curEndDate','$relatedBuIds',$ownrBuIdLgnUsr)";
            $qryRowsSalesOverTimePrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsSalesOverTime);
            $qryRowsSalesOverTimePrepareStmt->execute();
            return $qryRowsSalesOverTimePrepareStmt->fetchAll();
        } catch (\Exception $e) {
            return ['err' => 1];
        }        
    }      
    /**
     * 
     * @return type
     */
    public function getPartIndexData($envIds)
    {        
        $qryRowsPartIndex = "call getPartIndexData('$envIds')";
        $qryRowsPartIndexPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsPartIndex);
        $qryRowsPartIndexPrepareStmt->execute();
        return $qryRowsPartIndexPrepareStmt->fetchAll();
    }     
    /**
     * Function to get incomplete customer record using the user IDS
     * @param type $user_owner_ids
     * @param type $lowerLimit
     * @param type $upperLimit
     * @return type
     */
    public function getIncompleteCustomerRecord($user_owner_ids,$lowerLimit,$upperLimit){ 
        try {
            $qryRowsTopFlop = "call getIncompleteCustomerRecord('$user_owner_ids','$lowerLimit','$upperLimit')";
            $qryRowsTopFlopPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsTopFlop);
            $qryRowsTopFlopPrepareStmt->execute();
            return $qryRowsTopFlopPrepareStmt->fetchAll();
        } catch (\Exception $e) {
            return ['err' => 1];
        }
    }
    
    /**
     * Function to get client fidelity records
     * @param type $minAmount
     * @param type $days
     * @param type $lowerLimit
     * @param type $upperLimit
     * @return type
     */
    public function getClientFidelityRecord($months,$lowerLimit,$upperLimit,$user_owner_ids){ 
        
        try {
            $qryRowsTopFlop = "call clientFidelity($months,$lowerLimit,$upperLimit,'$user_owner_ids')";
            $qryRowsTopFlopPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsTopFlop);
            $qryRowsTopFlopPrepareStmt->execute();
            return $qryRowsTopFlopPrepareStmt->fetchAll();
        } catch (\Exception $e) {
            return ['err' => 1];
        }
    }  

   /**
    * 
    * @param type $curr_month
    * @param type $months
    * @param type $user_owner_ids
    * @param type $salesman
    * @param type $client
    * @param type $code
    * @return type
    */
    public function getClientFidelityGraphRecord($curr_month, $months,$user_owner_ids,$salesman,$client,$code,$buIds,$ownerBu,$isManager){ 
        try {
            $qryRowsTopFlop = "call clientFidelityChartNew($curr_month, $months,'$user_owner_ids','$salesman','$client','$code','$buIds',$ownerBu,$isManager)";
            $qryRowsTopFlopPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsTopFlop);
            $qryRowsTopFlopPrepareStmt->execute();
            return $qryRowsTopFlopPrepareStmt->fetchAll();
        } catch (\Exception $e) {
            return ['err' => 1];
        }
    }
    /**
     * 
     * @param type $curYr
     * @param type $curStartDate
     * @param type $curEndDate
     * @param type $prevStartDate
     * @param type $prevEndDate
     * @param type $workingDaysTillCurrentDay
     * @param type $workingDaysTillCurrentMonth
     * @param type $userIds
     * @param int $isMgr
     * @param string $buIds
     * @return array
     */
    public function getDashboardTargetWidgetData($curYr,$curStartDate,$curEndDate,$prevStartDate,$prevEndDate,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,$userIds,$isMgr,$buIds,$ownrBuIdLgnUsr,$turnoverType){
        try {
            $qryRowsCustomerTarget = "call getDashboardTargetWidgetData($curYr,'$curStartDate','$curEndDate','$prevStartDate','$prevEndDate',$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,'$userIds',$isMgr,'$buIds',$ownrBuIdLgnUsr,$turnoverType)";
            $qryRowsCustomerTargetPrepareStmt = $this->getEnitityMgrPrepareHandler($qryRowsCustomerTarget);
            $qryRowsCustomerTargetPrepareStmt->execute();
            return $qryRowsCustomerTargetPrepareStmt->fetchAll();
        } catch (\Exception $e) {
            return ['err' => 1];
        }
    }   
}