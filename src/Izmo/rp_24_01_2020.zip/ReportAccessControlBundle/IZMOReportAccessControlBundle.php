<?php

namespace IZMO\ReportAccessControlBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IZMOReportAccessControlBundle extends Bundle
{
}
