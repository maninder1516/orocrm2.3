<?php
namespace IZMO\ReportAccessControlBundle\Controller;

use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query;
use Doctrine\ORM\EntityRepository;

class ReportController extends Controller{
    
    const DEFAULT_GET_RELATED_BU_FLAG_FOR_DATA_IMPORT = 0;
    
    public function getReportRepository() {
        return $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess');
    }
    
    /**
     * 
     * @param string $name
     * @return string
     */
    public function getTranslation($name) {
        return $this->get('translator')->trans($name);
    }
    
    /**
     * 
     * @param string $reportName
     * @param string $configFile
     * @return Response
     */
    public function getBaseReportSummaryData($reportName,$configFile = 'reports.yml') {        
        $initialRepo = $rowsPerPageConfig = $isProductTypeReport = $errorFlag = 0;
        $baseUrl = $curUrl = $lvlWisePrimarykeyCols = $lvlWiseExpndrCols = $reportTitle = '';
        $logger = $this->get('logger');
        $yearsList = $this->getReportRepository()->getYearsForSalesHistoryData(); 
        $isGrndTotal = $isSubGrndTotal = 0;
        $reportTitleKey = '';
        if (empty($yearsList)) {
            $yearsList[0] = date("Y");
        }
        $hideColsForGrandTotal = $twigFilters = [];
        $reportType = 0;
        try {
            $reportConfig = $this->get('ymlparser.service.provider')->parseYmlFiles($configFile,'/../../ReportAccessControlBundle/Resources/config')['reports'][$reportName];
            $turnoverFlag = filter_input(INPUT_POST, 'chk_show_client_with_turnover'); 
            if(!empty($_POST) && $turnoverFlag == '') { 
                $reportConfig['filters']['index']['show_client_with_turnover']['default'] = 'off';
            } 
            if (!(empty($reportConfig))) {
                if (!(empty($reportConfig['twigPath']))) {
                    $twigPath = $reportConfig['twigPath'];
                    $rowsPerPageConfig = $this->get('izmo_user_security_info.user_security_provider')->getNoOfRowsForReportPerPageForUser();
                    $rowsPerPageConfig = (empty($rowsPerPageConfig)) ? $this->get('ymlparser.service.provider')->parseYmlFiles('reports_config.yml','/../../ReportAccessControlBundle/Resources/config')['report_config']['pagination']['no_of_rows_per_page'] : $rowsPerPageConfig;
                    $isGrndTotal = (!(empty($reportConfig['isGrandTotal']))) ? $reportConfig['isGrandTotal'] : 0;
                    $hideColsForGrandTotal = ((!(empty($isGrndTotal))) && (!(empty($reportConfig['hide_cols_for_grand_total'])))) ? $reportConfig['hide_cols_for_grand_total'] : [];
                    $isSubGrndTotal = (!(empty($reportConfig['isSubGrandTotal']))) ? $reportConfig['isSubGrandTotal'] : 0;
                    $filtersConfig = $reportConfig['filters']['index'];
                    foreach ($filtersConfig as $key => $val) {                                            
                        if ((!(empty($_REQUEST))) && (!(empty($_REQUEST[$val['col']])))) {
                            $filter[$key] = $_REQUEST[$val['col']];
                        } else {                                                     
                            if ($val['default'] == 'cur_yr') {
                                $filter[$key] = date("Y");
                            } elseif ((!(empty($_REQUEST))) && (!(empty($val['can_be_zero']))) && ($val['can_be_zero'] == 'true') && isset($_REQUEST[$val['col']]) && (($_REQUEST[$val['col']]) == 0)) {
                                $filter[$key] = 0;
                            }
                            elseif((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])){
                                        $funcName = $val['function_name'];
                                        $serviceName = $val['service_name'];
                                        $filter[$key] = $this->get($serviceName)->$funcName();
                            }
                            else {
                                $filter[$key] = $val['default'];
                            }
                        }
                        $dataType[$key] = $val['data_type'];
                    } // filters index config provided                    
                    if (!(empty($reportConfig['product_type_report']))) {//FOR PRODUCT TYPE REPORT LOGIC
                        $isProductTypeReport = 1;
                        if (!(empty($_REQUEST['product_type']))) {
                            $productType = $_REQUEST['product_type'];
                        } else if (!(empty($reportConfig['product_type_report']['default']))) {
                            $productType = $reportConfig['product_type_report']['default'];
                        }
                    }
                    $reportConfigDetails = ((!(empty($isProductTypeReport))) && (!(empty($reportConfig['prod_type'][$productType])))) ? $reportConfig['prod_type'][$productType] : $reportConfig;
                    $baseUrl = (!(empty($reportConfigDetails['base_url'])))? $reportConfigDetails['base_url'] : '';
                    $reportConfigLvlDetails = $reportConfigDetails['levels'];
                    if (!(empty($reportConfigDetails['title']))) {
                        $reportTitle = $this->getTranslation($reportConfigDetails['title']);
                        $reportTitleKey = $reportConfigDetails['title'];
                    }
                    if (!(empty($reportConfigLvlDetails))) {
                        $userIds = $this->get('izmo_user_security_info.user_security_provider')->getUserIds();
                        if (!(empty($reportConfigLvlDetails[$reportType]['url']))) {
                            $curUrl = $reportConfigLvlDetails[$reportType]['url'];
                        }
                        foreach ($reportConfigLvlDetails as $key => $val) {
                            if ($key > -1) {
                                if ((!(empty($val['lvl_output_primary_key']))) || ($val['lvl_output_primary_key'] == 0)) {
                                    if (($val['lvl_output_primary_key'] != 'none')) {
                                        $lvlWisePrimarykeyCols .= $val['lvl_output_primary_key'] . ',';
                                    }
                                }
                                if ((!(empty($val['expander_output_col']))) || ($val['expander_output_col'] == 0)) {
                                    if ($val['expander_output_col'] != 'none') {
                                        $lvlWiseExpndrCols .= $val['expander_output_col'] . ',';
                                    }
                                }
                            }
                        }
                        $lvlWisePrimarykeyCols = rtrim($lvlWisePrimarykeyCols, ',');
                        $lvlWiseExpndrCols = rtrim($lvlWiseExpndrCols, ',');
                        if (!(empty($reportConfig['twig_filter_cols']))) {
                            $twigFilterConfig = $reportConfig['twig_filter_cols'];
                            foreach ($twigFilterConfig as $key => $val) {
                                if (!(empty($filter[$val]))) {
                                    $twigFilters[$val] = ($filter[$val] != 'none') ? $filter[$val] : '';
                                }
                                else if((isset($filter[$val])) && ($filter[$val] == 0)){
                                    $twigFilters[$val] = $filter[$val];
                                }
                            }
                        }
                    } else {
                        $errorFlag = 1;
                        $logger->crit(" No level configuration found for report selected");
                    }
                }  // twig path defined
                else {
                    $errorFlag = 1;
                    $logger->crit(" No twig path defined in configuration for report selected");
                }
            }// config available
            else {
                $errorFlag = 1;
                $logger->crit(" No configuration details found for report selected");
            }
        }// try block
        catch (\Exception $e) {
            $errorFlag = 1;
            $logger->crit(" exception occured while retriving data with exception info below:");
            $logger->crit($e);
        } finally {
            if (!(empty($twigPath))) {
                if((empty($_GET)) && (empty($_POST))){$initialRepo = 1;}
                if($reportName == 'salesman_targets_performance'){
                    $loggedUserId = $this->get('izmo_user_security_info.user_security_provider')->getLoggedInUsr()->getId();
                    if(isset($_COOKIE[$loggedUserId . '_sales_turnover_type']) && empty($_POST['turnover_type'])){
                        $twigFilters['turnover_type'] = $_COOKIE[$loggedUserId . '_sales_turnover_type'];
                    }
                } 
                return $this->render($twigPath, array('errorHandlr' => $errorFlag, 'years_list' => $yearsList, 'report_hdr' => $reportTitle,'pageTitle'=>$reportTitle,'pageTitleKey'=>$reportTitleKey, 'cur_url' => $curUrl, 'filters' => $twigFilters, 'lvl_wise_pk_col' => $lvlWisePrimarykeyCols, 'lvl_wise_expndr_cols' => $lvlWiseExpndrCols,'rows_per_page'=>$rowsPerPageConfig,'is_grand_total'=>$isGrndTotal,'is_sub_grand_total'=>$isSubGrndTotal,'hid_cols_for_grand_sum'=>$hideColsForGrandTotal,'base_url'=>$baseUrl,'init_report'=>$initialRepo));
            } else {
                $serverErrorMsg = $this->getTranslation('datatables.data.server_error_occured.label');
                return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
            }
        }
    }
    
    /**
     * 
     * @param string $reportName
     * @param string $configFile
     * @return Response
     */
    public function getSubLvlForBaseReportData($reportName,$configFile = 'reports.yml') {         
        $isSeperateServerSideForTypes = $isProductTypeReport = $errorFlag = 0;
        $logger = $this->get('logger');
        $url = '';
        $filter = [];
        try {
            $data = $_POST;
            if ((!empty($data))) {
                $reportType = $data['lvl'];
                $reportConfig = $this->get('ymlparser.service.provider')->parseYmlFiles($configFile,'/../../ReportAccessControlBundle/Resources/config')['reports'][$reportName];
                 if (!(empty($reportConfig))) {
                    if (!(empty($reportConfig['filters']['index']))) {
                        $filtersConfig = $reportConfig['filters']['index'];
                        $filtersJson = $data['filters'];
                        $filtersData = json_decode($filtersJson);
                        foreach ($filtersConfig as $key => $val) {
                            if (empty($filter[$key])) {
                                $col = $val['col'];
                                if ((!(empty($filtersData))) && (!(empty($filtersData->$col)))) {
                                    $filter[$key] = $filtersData->$col;
                                } else {
                                    if ($val['default'] == 'cur_yr') {
                                        $filter[$key] = date("Y");
                                    } elseif ((!(empty($_REQUEST))) && (!(empty($val['can_be_zero']))) && ($val['can_be_zero'] == 'true') && isset($_REQUEST[$val['col']]) && (($_REQUEST[$val['col']]) == 0)) {
                                        $filter[$key] = 0;
                                    }
                                   elseif((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])){
                                        $funcName = $val['function_name'];
                                        $serviceName = $val['service_name'];
                                        $filter[$key] = $this->get($serviceName)->$funcName();
                                    }
                                    else {
                                        $filter[$key] = $val['default'];
                                    }
                                }
                            }
                            $dataType[$key] = $val['data_type'];
                        }
                    } // if not empty of filter configuration
                    else {
                        $logger->debug("filter configuration not found for given product type of report");
                    }
                    if (!(empty($reportConfig['product_type_report']))) { // FOR Product Type Logic
                    $productType = (!(empty($filter['product_type']))) ? $filter['product_type'] : $reportConfig['product_type_report']['default'];
                        $isProductTypeReport = 1;
                        $isSeperateServerSideForTypes = (!(empty($reportConfig['product_type_report']['serverside_disp_each_type']))) ? $reportConfig['product_type_report'] : 0;
                    }
                    $reportConfigDetails = ((!(empty($isProductTypeReport) )) && (!(empty($reportConfig['prod_type'][$productType])))) ? $reportConfig['prod_type'][$productType] : $reportConfig;
                    if (!(empty($reportConfigDetails['levels'][$reportType]))) {
                         $reportwiseConfiguration = $reportConfigDetails['levels'][$reportType];
                        if($reportType > 0)
                        { $pkEvalConfig = explode(',', $reportwiseConfiguration['request_parameters']);
                        $pk_values_cnt = count($pkEvalConfig);
                        $pk = explode('_', $data['id']);
                        for ($i = 0; $i < $pk_values_cnt; $i++) {
                            $filter[$pkEvalConfig[$i]] = $pk[$i];
                        }
                        }
                        $userIds = $this->get('izmo_user_security_info.user_security_provider')->getUserIds();
                        if (!(empty($reportwiseConfiguration['stored_proc']))) {
                            $storedProcName = $reportwiseConfiguration['stored_proc'];
                        } else if (!(empty($reportConfigDetails['levels'][0]['stored_proc']))) {
                            $storedProcName = $reportConfigDetails['levels'][0]['stored_proc'];
                        }
                        if (!(empty($reportwiseConfiguration['stored_proc_params']))) {
                            $storedProcParameters = $reportwiseConfiguration['stored_proc_params'];
                        } else if (!(empty($reportConfigDetails['levels'][0]['stored_proc_params']))) {
                            $storedProcParameters = $reportConfigDetails['levels'][0]['stored_proc_params'];
                        }
                        if (!(empty($reportConfigDetails['levels'][$reportType + 1]['url']))) {
                            $url = $reportConfigDetails['levels'][$reportType + 1]['url'];
                        }
                        if ((!(empty($storedProcParameters))) && (!(empty($storedProcName)))) {
                            $spParametersLabelArray = explode(',', $storedProcParameters);
                            $spParametersArrayCount = count($spParametersLabelArray);
                            $spFilterParam = [];
                            for ($i = 0; $i < $spParametersArrayCount; $i++) { //to order filters & its data type based on sp_params order mentioned in yml
                                $spFilterParam[$i]['filter'] = $filter[$spParametersLabelArray[$i]];
                                $spFilterParam[$i]['data_type'] = $dataType[$spParametersLabelArray[$i]];
                            }
                            $filterParams = array();
                            $filterParams['report_type'] = $reportType;
                            $filterParams['usr_ids'] = $userIds;
                            $filterParams['sp_params'] = $spFilterParam;
                            $serverProcessConfig = ((!(empty($isSeperateServerSideForTypes))) && (!(empty($reportConfigDetails['serverside_processing_detail'])))) ? $reportConfigDetails['serverside_processing_detail'] : $reportConfig['serverside_processing_detail'];                            
                           return $this->get('izmo_datatables.server_side_processing_lvl_wise')->processServerSideData($serverProcessConfig,$storedProcName,$_POST,$filterParams,$url);
                        } else {
                            $errorFlag = 1;
                            $logger->crit("stored procedure parameters or stored procedure name not found for prod_type field for report");
                        }
                    }//for level selected for given prod type
                    else {
                        $errorFlag = 1;
                        $logger->crit("No level information found for selected for report");
                    }
                } else {
                    $errorFlag = 1;
                    $logger->crit("No configuration details found for given report name");
                }
            } else {
                $errorFlag = 1;
                $logger->crit("No Parameters posted for ajax call in given report");
            }
       } catch (\Exception $e) {
            $errorFlag = 1;
            $logger->crit("Exception occured during fetching data with details below:");
            $logger->crit($e);
        } 
    }

    /**
     * 
     * @param string $reportName
     * @param string $configFile
     * @return Response
     */
    public function getExportDataForReport($reportName,$configFile = 'reports.yml') {
        $excelTitle = '';
        $logger = $this->get('logger');
        $filter = [];
        $serverErrorMsg = $this->getTranslation('datatables.data.server_error_occured.label');
        try {
            $resultArr = $this->get('ymlparser.service.provider')->parseYmlFiles($configFile,'/../../ReportAccessControlBundle/Resources/config')['reports'][$reportName];
            if (!(empty($resultArr))) {
                if (!(empty($resultArr['product_type_report']))) { //FOR PRODUCT TYPE REPORT LOGIC
                    $isProductTypeReport = 1;
                    if (!(empty($_REQUEST['product_type']))) {
                        $productType = $_REQUEST['product_type'];
                    } else if (!(empty($reportConfig['product_type_report']['default']))) {
                        $productType = $reportConfig['product_type_report']['default'];
                    }
                    if ((!(empty($productType))) && (!(empty($resultArr['prod_type'][$productType])))) {
                        $reportConfig = $resultArr['prod_type'][$productType];
                    }
                } else {
                    $reportConfig = $resultArr;
                }
                if (!(empty($reportConfig))) {
                    if (!(empty($reportConfig['title']))) {
                        $excelTitle = $this->getTranslation($reportConfig['title']);
                    }
                    if (!(empty($reportConfig['export']['stored_proc']))) {
                        $storedProcName = $reportConfig['export']['stored_proc'];
                    }
                    $filtersConfig = $reportConfig['export']['filters']['index'];
                    foreach ($filtersConfig as $key => $val) {
                        if ((!(empty($_REQUEST))) && (!(empty($_REQUEST[$val['col']])))) {
                            $filter[$key] = $_REQUEST[$val['col']];
                        } else {
                            if ($val['default'] == 'cur_yr') {
                                $filter[$key] = date("Y");
                            } elseif ((!(empty($_REQUEST))) && (!(empty($val['can_be_zero']))) && ($val['can_be_zero'] == 'true') && isset($_REQUEST[$val['col']]) && (($_REQUEST[$val['col']]) == 0)) {
                                $filter[$key] = 0;
                            }
                            elseif((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])){
                                        $funcName = $val['function_name'];
                                        $serviceName = $val['service_name'];
                                        $filter[$key] = $this->get($serviceName)->$funcName();
                            }
                            else {
                                $filter[$key] = $val['default'];
                            }
                        }
                        $dataType[$key] = $val['data_type'];
                    }
                    $userIds = $this->get('izmo_user_security_info.user_security_provider')->getUserIds();
                    if (!(empty($reportConfig['export']['stored_proc_params']))) {
                        $storedProcParameters = $reportConfig['export']['stored_proc_params'];
                    }
                    $spParametersLabelArray = explode(',', $storedProcParameters);
                    $spParametersArrayCount = count($spParametersLabelArray);
                    $spFilterParam = [];
                    for ($i = 0; $i < $spParametersArrayCount; $i++) {
                        $spFilterParam[$i]['filter'] = $filter[$spParametersLabelArray[$i]];
                        $spFilterParam[$i]['data_type'] = $dataType[$spParametersLabelArray[$i]];
                    }
                    $qryResult = $this->getReportRepository()->getReportExportDataForParameters($userIds, $storedProcName, $spFilterParam); 
                    if (!(empty($qryResult))) {
                        if(!(empty($qryResult['err']))){
                            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
                        }
                        else{
                         if((!(empty($reportConfig['export']['is_seperate_output']))) && (!(empty($reportConfig['export']['export_output_service']))) && (!(empty($reportConfig['export']['export_output_func_name'])))){
                            $funcName = $reportConfig['export']['export_output_func_name'];
                            $serviceName = $reportConfig['export']['export_output_service'];
                            $qryResult = $this->get($serviceName)->$funcName($qryResult);
                        }
                        else{   
                            foreach ($qryResult as $key => $val) {
                                if (!(empty($val['mon']))) {
                                    $qryResult[$key]['mon'] = $this->getTranslation($val['mon']);
                                }
                            }
                        }
                        $colHdrs = $reportConfig['export']['header'];
                        $res = $this->get('custom.excel.export.class')->generateExcelForReport($qryResult, $colHdrs, $excelTitle);
                        return new Response(
                                $res, 200, array(
                            'Content-Type' => 'application/vnd.ms-excel',
                            'Content-Disposition' => 'attachment; filename="doc.xls"',
                                )
                        );
                     }
                    } else {
                        $noDataFoundMsg = $this->getTranslation('datatables.data.no_record_found.label');
                        return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $noDataFoundMsg . '</p>');
                    }
                }//not empty $reportConfig
                else {
                    $logger->crit("No configuration found for given report");

                    return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
                }
            } else {
                $logger->crit("No configuration found for given report");

                return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured during fetching data with details below:");
            $logger->crit($e);
           
            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
        }
    }

    /**
     *@Route("/salesman-targets-performance",name="salesman_targets_performance")
     * @Acl(
     *     id="sales_report_target_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesmanTargetSummaryReportAction() {
        return $this->getBaseReportSummaryData('salesman_targets_performance','salesman_targets_performance.yml');
    }
   
    /**
     *@Route("/salesman-targets-sub-lvl-performance-detail",name="salesman_targets_sub_lvl_performance_detail") 
     * @Acl(
     *     id="sales_report_target_performance_sub_lvl",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesmanTargetSummarySubLvlDetails() {
        $jsonData=json_decode($_POST['filters']);
        $turnoverType = $jsonData->turnover_type;
        $loggedUserId = $this->get('izmo_user_security_info.user_security_provider')->getLoggedInUsr()->getId();
        if($turnoverType!=''){
            if(isset($_COOKIE[$loggedUserId . '_sales_turnover_type'])){
                unset($_COOKIE[$loggedUserId . '_sales_turnover_type']);
            }
            setcookie($loggedUserId . '_sales_turnover_type', $turnoverType,time() + (86400), "/");
        }  
        return $this->getSubLvlForBaseReportData('salesman_targets_performance','salesman_targets_performance.yml');
    }
    
    /**
     * @Route("/salesman-targets-export", name="salesman_targets_export")
     * @Acl(
     *     id="sales_report_target_performance_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesmanTargetExcelExport() {
        return $this->getExportDataForReport('salesman_targets_performance','salesman_targets_performance.yml');
    }
    
    /**
     *@Route("/parts-sales-performance",name="parts_sales_performance") 
     * @Acl(
     *     id="parts_sales_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformancePartsSalesSummaryReportAction() {
        return $this->getBaseReportSummaryData('parts_sales_report','parts_sales_report_performance.yml');
    }

    /**
     *@Route("/parts-sales-sub-lvl-performance-detail",name="parts_sales_sub_lvl_performance_detail")
     * @Acl(
     *     id="parts_sales_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformancePartsSalesSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('parts_sales_report','parts_sales_report_performance.yml');
    }
    
    /**
     *@Route("/parts-sales-performance-report-export",name="parts_sales_performance_report_export")
     * @Acl(
     *     id="parts_sales_performance_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformancePartsSalesForExcelExport(){
        return $this->getExportDataForReport('parts_sales_report','parts_sales_report_performance.yml');
    }
    
    /**
     *@Route("/salesman-by-index-client-performance",name="salesman_by_index_client_performance") 
     * @Acl(
     *     id="salesman_by_index_client_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesmanByIndexClientSummaryReportAction() {
        return $this->getBaseReportSummaryData('salesman_performance_by_index_client','salesman_performance_by_index_client.yml');
    }

    /**
     *@Route("/salesman-by-index-client-sub-lvl-performance-detail",name="salesman_by_index_client_sub_lvl_performance_detail")
     * @Acl(
     *     id="salesman_by_index_client_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesmanByIndexClientSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('salesman_performance_by_index_client','salesman_performance_by_index_client.yml');
    }
    
    /**
     *@Route("/salesman-by-index-client-performance-report-export",name="salesman_by_index_client_performance_report_export")
     * @Acl(
     *     id="salesman_by_index_client_performance_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesmanByIndexClientForExcelExport(){
        return $this->getExportDataForReport('salesman_performance_by_index_client','salesman_performance_by_index_client.yml');
    }
    
    /**
     *@Route("/sales-by-channel-salesman-performance",name="sales_by_channel_salesman_performance") 
     * @Acl(
     *     id="sales_by_channel_salesman_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByChannelBySalesmanSummaryReportAction() {
        return $this->getBaseReportSummaryData('sales_performance_by_channel_salesman','sales_performance_by_channel_salesman.yml');
    }

    /**
     *@Route("/sales-by-channel-salesman-sub-lvl-performance-detail",name="sales_by_channel_salesman_sub_lvl_performance_detail")
     * @Acl(
     *     id="sales_by_channel_salesman_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByChannelBySalesmanSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('sales_performance_by_channel_salesman','sales_performance_by_channel_salesman.yml');
    }
    
    /**
     *@Route("/sales-by-channel-salesman-report-export",name="sales_by_channel_salesman_report_export")
     * @Acl(
     *     id="sales_by_channel_salesman_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByChannelBySalesmanForExcelExport(){
        return $this->getExportDataForReport('sales_performance_by_channel_salesman','sales_performance_by_channel_salesman.yml');
    }
    
    /**
     *@Route("/sales-by-salesman-channel-client-performance",name="sales_by_salesman_channel_client_performance") 
     * @Acl(
     *     id="sales_by_salesman_channel_client_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceBySalesmanChannelByClientSummaryReportAction() {
        return $this->getBaseReportSummaryData('sales_performance_by_salesman_channel_client','sales_performance_by_salesman_channel_client.yml');
    }

    /**
     *@Route("/sales-by-salesman-channel-client-sub-lvl-performance-detail",name="sales_by_salesman_channel_client_sub_lvl_performance_detail")
     * @Acl(
     *     id="sales_by_salesman_channel_client_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceBySalesmanChannelByClientSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('sales_performance_by_salesman_channel_client','sales_performance_by_salesman_channel_client.yml');
    }
    
    /**
     *@Route("/sales-by-salesman-channel-client-report-export",name="sales_by_salesman_channel_client_report_export")
     * @Acl(
     *     id="sales_by_channel_salesman_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceBySalesmanChannelByIndexForExcelExport(){
        return $this->getExportDataForReport('sales_performance_by_salesman_channel_client','sales_performance_by_salesman_channel_client.yml');
    }
    
    
    /**
     *@Route("/sales-by-channel-index-performance",name="sales_by_channel_index_performance") 
     * @Acl(
     *     id="sales_by_channel_index_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByChannelByIndexSummaryReportAction() {
        return $this->getBaseReportSummaryData('sales_performance_by_channel_index','sales_performance_by_channel_index.yml');
    }

    /**
     *@Route("/sales-by-channel-index-sub-lvl-performance-detail",name="sales_by_channel_index_sub_lvl_performance_detail")
     * @Acl(
     *     id="sales_by_channel_index_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByChannelByIndexSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('sales_performance_by_channel_index','sales_performance_by_channel_index.yml');
    }
    
    /**
     *@Route("/sales-by-channel-index-report-export",name="sales_by_channel_index_report_export")
     * @Acl(
     *     id="sales_by_channel_index_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByChannelByIndexForExcelExport(){
        return $this->getExportDataForReport('sales_performance_by_channel_index','sales_performance_by_channel_index.yml');
    }
    
    /**
     *@Route("/sales-by-index-salesman-performance",name="sales_by_index_salesman_performance") 
     * @Acl(
     *     id="sales_by_index_salesman_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByIndexForSalesmanSummaryReportAction() {
        return $this->getBaseReportSummaryData('sales_performance_by_index_salesman','sales_performance_by_index_salesman.yml');
    }

    /**
     *@Route("/sales-by-index-salesman-sub-lvl-performance-detail",name="sales_by_index_salesman_sub_lvl_performance_detail")
     * @Acl(
     *     id="sales_by_index_salesman_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByIndexForSalesmanSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('sales_performance_by_index_salesman','sales_performance_by_index_salesman.yml');
    }
    
    /**
     *@Route("/sales-by-index-salesman-report-export",name="sales_by_index_salesman_report_export")
     * @Acl(
     *     id="sales_by_index_salesman_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByIndexForSalesmanForExcelExport(){
        return $this->getExportDataForReport('sales_performance_by_index_salesman','sales_performance_by_index_salesman.yml');
    }
    
    /**
     *@Route("/parts-sales-by-client-performance",name="parts_sales_by_client_performance") 
     * @Acl(
     *     id="parts_sales_by_client_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformancePartsSalesByClientSummaryReportAction() {
        return $this->getBaseReportSummaryData('parts_sales_by_client_report','parts_sales_by_client_report.yml');
    }

    /**
     *@Route("/parts-sales-by-client-sub-lvl-performance-detail",name="parts_sales_by_client_sub_lvl_performance_detail")
     * @Acl(
     *     id="parts_sales_by_client_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformancePartsSalesByClientSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('parts_sales_by_client_report','parts_sales_by_client_report.yml');
    }
    
    /**
     *@Route("/parts-sales-by-client-performance-report-export",name="parts_sales_by_client_performance_report_export")
     * @Acl(
     *     id="parts_sales_by_client_performance_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformancePartsSalesByClientForExcelExport(){
        return $this->getExportDataForReport('parts_sales_by_client_report','parts_sales_by_client_report.yml');
    }
    
    /**
     *@Route("/sales-by-index-channel-performance",name="sales_by_index_channel_performance") 
     * @Acl(
     *     id="sales_by_index_channel_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByIndexByChannelSummaryReportAction() {
        return $this->getBaseReportSummaryData('sales_performance_by_index_channel','sales_performance_by_index_channel.yml');
    }

    /**
     *@Route("/sales-by-index-channel-sub-lvl-performance-detail",name="sales_by_index_channel_sub_lvl_performance_detail")
     * @Acl(
     *     id="sales_by_index_channel_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByIndexByChannelSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('sales_performance_by_index_channel','sales_performance_by_index_channel.yml');
    }
    
    /**
     *@Route("/sales-by-index-channel-report-export",name="sales_by_index_channel_report_export")
     * @Acl(
     *     id="sales_by_index_channel_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByIndexByChannelForExcelExport(){
        return $this->getExportDataForReport('sales_performance_by_index_channel','sales_performance_by_index_channel.yml');
    }
    
    /**
     *@Route("/sales-by-index-platform-performance",name="sales_by_index_platform_performance") 
     * @Acl(
     *     id="sales_by_index_platform_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByIndexByPlatformSummaryReportAction() {
        return $this->getBaseReportSummaryData('sales_performance_by_index_platform','sales_performance_by_index_platform.yml');
    }

    /**
     *@Route("/sales-by-index-platform-sub-lvl-performance-detail",name="sales_by_index_platform_sub_lvl_performance_detail")
     * @Acl(
     *     id="sales_by_index_platform_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByIndexByPlatformSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('sales_performance_by_index_platform','sales_performance_by_index_platform.yml');
    }

    /**
     *@Route("/sales-by-index-platform-report-export",name="sales_by_index_platform_report_export")
     * @Acl(
     *     id="sales_by_index_platform_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByIndexByPlatformForExcelExport(){
        return $this->getExportDataForReport('sales_performance_by_index_platform','sales_performance_by_index_platform.yml');
    }
    
    public function getUserCategoryType($type){
        $categoryConfigObj = $this->getDoctrine()->getRepository('IZMOCustomConfigBundle:CustomConfig')->findOneBy(array('configLabel' => 'USER_SALES_CATEGORIES','organization' => 1));
        $key='';
        if(!empty($categoryConfigObj)){
            $configVal = $categoryConfigObj->getConfigValue();
            $configValArr = json_decode($configVal,true);
            $key = array_search ($type, $configValArr);
        }
        return $key;
    }
    
    /**
     * @Route("/outStandingCreditReportCustomer", name="out_standing_credit_report_customer")
     * @Template("IZMOReportAccessControlBundle:Report:dashboardoutstandingcreditreport.html.twig")
     * @Acl(
     *     id="out_standing_credit_report_customer",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function outStandingCreditReportCustomerAction(Request $request) 
    { 
        $nonInternalUsers = 1;
        $userIds = $this->get('izmo_user_security_info.user_security_provider')->getUserIds($nonInternalUsers);                              
        $curStartDate = date("Y-m-01");
        $curEndDate = date("Y-m-d"); 
        $workingDaysTillCurrentDay = $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getWorkingDaysCurrentDay();                
        $upperLimitVal = $this->getReportRepository()->getPageLimit('PAGE_LIMIT');       
        $next = $request->request->get('next');
        $prev = $request->request->get('prev');        
        $lowerLimit = isset($prev)?$prev:0;
        $upperLimit = isset($next)?$next:$upperLimitVal;
        $outStandingCreditReportData = $this->getReportRepository()->outStandingCreditReportCustomer($userIds,$curStartDate,$curEndDate,$workingDaysTillCurrentDay,$lowerLimit,$upperLimit,1);                
        $outStandingCnt = $this->getReportRepository()->outStandingCreditReportCustomer($userIds,$curStartDate,$curEndDate,$workingDaysTillCurrentDay,0,0,0);                
        $outStandingCntVal = count($outStandingCnt);
        if(isset($next) && isset($prev)){        
            $data = array();
            $data['report'] = $outStandingCreditReportData;
            $data['page'] = array('lowerLimit' => $lowerLimit);                             
            return new Response(json_encode($data));  
        }
        else{        
            return $this->render('IZMOReportAccessControlBundle:Report:dashboardoutstandingcreditreport.html.twig',array('outStandingCreditReportData' => $outStandingCreditReportData,'pageLimit' => $upperLimit,'outStandingCntVal' => $outStandingCntVal));
        }
    }
  
    /**
     * @Route("/top-flop-report-customer", name="top_flop_report_customer",requirements={"widget"="[\w_-]+"})
     * @Template("IZMOReportAccessControlBundle:Report:dashboardtopflopreport.html.twig")
     * @Acl(
     *     id="top_flop_report_customer",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function topFlopReportAction(Request $request) 
    { 
        $salesmanData = 'none';
        $channelData = 'none';
        $topFlopReportData = array();       
        $curYr = date('Y'); 
        $curMonthVal = date("m");
        $curStartDate = date("Y-m-01");
        $curEndDate = date("Y-m-d");        
        if ($curStartDate == $curEndDate) {
            $curStartDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal - 1, 1, $curYr));
            $curEndDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal, 0, $curYr));
        }
        $prevStartDate = date("Y-m-d", strtotime('-1 year', strtotime($curStartDate)));
        $prevEndDate = date("Y-m-d", strtotime('-1 year', strtotime($curEndDate)));        
        $curYearStartDate = date("Y-01-01");
        $curYearEndDate = date("Y-m-d");
        if ($curYearStartDate == $curYearEndDate) {
            $curYearStartDate = date("Y-m-d", mktime(0, 0, 0, 01 - 1, 1, $curYr));
            $curYearEndDate = date("Y-m-d", mktime(0, 0, 0, 01, 0, $curYr));
        }
        $prevYearStartDate = date("Y-m-d", strtotime('-1 year', strtotime($curYearStartDate)));
        $prevYearEndDate = date("Y-m-d", strtotime('-1 year', strtotime($curYearEndDate)));                      
        $nonInternalUsers = 1;
        $userIds = $this->get('izmo_user_security_info.user_security_provider')->getUserIds($nonInternalUsers);
        $workingDaysTillCurrentDay = $this->getReportRepository()->getWorkingDaysCurrentDay();
        if (empty($workingDaysTillCurrentDay)) {           
            $workingDaysTillCurrentDay = 1;
        }
        $workingDaysTillCurrentMonth = $this->getReportRepository()->getWorkingDaysCurrentMonth();
        if (empty($workingDaysTillCurrentMonth)) {           
            $workingDaysTillCurrentMonth = 1;
        }    
        $categoryId = $this->getUserCategoryType('NET_TURNOVER');        
        $upperLimitVal = $this->getReportRepository()->getPageLimit('PAGE_LIMIT');
        $salesmanData = $request->request->get('requestSalesman');
        $channelData = $request->request->get('requestChannel');
        $next = $request->request->get('next');
        $prev = $request->request->get('prev');        
        $lowerLimit = isset($prev)?$prev:0;
        $upperLimit = isset($next)?$next:$upperLimitVal; 
        $topFlopReportData = $this->getReportRepository()->getTopFlopReportCustomerData($curStartDate,$curEndDate,$prevStartDate,$prevEndDate,$userIds,$curYearStartDate,$curYearEndDate,$prevYearStartDate,$prevYearEndDate,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,$salesmanData,$channelData,$categoryId,$lowerLimit,$upperLimit,1); 
        
        $topFlopReportDataCnt = $this->getReportRepository()->getTopFlopReportCustomerData($curStartDate,$curEndDate,$prevStartDate,$prevEndDate,$userIds,$curYearStartDate,$curYearEndDate,$prevYearStartDate,$prevYearEndDate,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,$salesmanData,$channelData,$categoryId,0,0,0);         
        $topFlopCntVal = count($topFlopReportDataCnt);
        if(isset($channelData) || isset($salesmanData) || isset($next) || isset($prev)){
            $data = array();
            $data['report'] = $topFlopReportData;
            $data['page'] = array('lowerLimit' => $lowerLimit); 
            $data['salesmanData'] = $salesmanData;
            $data['channelData'] = $channelData;
            return new Response(json_encode($data)); 
        } 
        else
        {
            return $this->render('IZMOReportAccessControlBundle:Report:dashboardtopflopreport.html.twig',array('topFlopReportData' => $topFlopReportData,'pageLimit' => $upperLimit,'salesmanData' => $salesmanData,'topFlopCntVal' => $topFlopCntVal));
        }
    }
    
    /**
     *@Route("/sales-by-platform-performance",name="sales_by_platform_performance") 
     * @Acl(
     *     id="sales_by_platform_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByPlatformSummaryReportAction() {
        return $this->getBaseReportSummaryData('sales_performance_by_platform','sales_performance_by_platform.yml');
    }

    /**
     *@Route("/sales-by-platform-sub-lvl-performance-detail",name="sales_by_platform_sub_lvl_performance_detail")
     * @Acl(
     *     id="sales_by_platform_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByPlatformSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('sales_performance_by_platform','sales_performance_by_platform.yml');
    }
    
    /**
     *@Route("/sales-by-platform-report-export",name="sales_by_platform_report_export")
     * @Acl(
     *     id="sales_by_platform_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByPlatformForExcelExport(){
        return $this->getExportDataForReport('sales_performance_by_platform','sales_performance_by_platform.yml');
    }
    
    /**
     *@Route("/sales-by-channel-platform-performance",name="sales_by_channel_platform_performance") 
     * @Acl(
     *     id="sales_by_channel_platform_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByChannelByplatformSummaryReportAction() {
        return $this->getBaseReportSummaryData('sales_performance_by_channel_platform','sales_performance_by_channel_platform.yml');
    }

    /**
     *@Route("/sales-by-channel-platform-sub-lvl-performance-detail",name="sales_by_channel_platform_sub_lvl_performance_detail")
     * @Acl(
     *     id="sales_by_channel_platform_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByChannelByplatformSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('sales_performance_by_channel_platform','sales_performance_by_channel_platform.yml');
    }
    
    /**
     *@Route("/sales-by-channel-platform-report-export",name="sales_by_channel_platform_report_export")
     * @Acl(
     *     id="sales_by_channel_platform_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByChannelByplatformForExcelExport(){
        return $this->getExportDataForReport('sales_performance_by_channel_platform','sales_performance_by_channel_platform.yml');
    }
    
    /**
     *@Route("/sales-by-promotions-performance",name="sales_by_promotions_performance") 
     * @Acl(
     *     id="sales_by_promotions_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByPromotionsSummaryReportAction() {
        return $this->getBaseReportSummaryData('sales_performance_by_promotions','sales_performance_by_promotions.yml');
    }
        
    /**
     *@Route("/sales-by-promotions-sub-lvl-performance-detail",name="sales_by_promotions_sub_lvl_performance_detail")
     * @Acl(
     *     id="sales_by_promotions_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByPromotionsSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('sales_performance_by_promotions','sales_performance_by_promotions.yml');
    }        
    
    /**
     *@Route("/sales-by-promotions-report-export",name="sales_by_promotions_report_export")
     * @Acl(
     *     id="sales_by_promotions_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByPromotionsForExcelExport(){
        return $this->getExportDataForReport('sales_performance_by_promotions','sales_performance_by_promotions.yml');
    }

    /**
     *@Route("/parts-sales-by-channel-performance",name="parts_sales_by_channel_performance") 
     * @Acl(
     *     id="parts_sales_by_channel_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformancePartsSalesByChannelSummaryReportAction() {
        return $this->getBaseReportSummaryData('parts_sales_by_channel','parts_sales_by_channel.yml');
    }

    /**
     *@Route("/parts-sales-by-channel-sub-lvl-performance-detail",name="parts_sales_by_channel_sub_lvl_performance_detail")
     * @Acl(
     *     id="parts_sales_by_channel_sub_lvl_performance_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformancePartsSalesByChannelSummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('parts_sales_by_channel','parts_sales_by_channel.yml');
    }
    
    /**
     *@Route("/parts-sales-by-channel-performance-report-export",name="parts_sales_by_channel_performance_report_export")
     * @Acl(
     *     id="parts_sales_by_channel_performance_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformancePartsSalesByChannelForExcelExport(){
        return $this->getExportDataForReport('parts_sales_by_channel','parts_sales_by_channel.yml');
    }
    
    /**
     *@Route("/geolocation-anomoly-report",name="geolocation_anomoly_report") 
     * @Acl(
     *     id="geolocation_anomoly_report",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function geoLocationAnomolySummaryReportAction() {
        return $this->getBaseReportSummaryData('geolocation_anomoly_report','geolocation_anomoly_report.yml');
    }

    /**
     *@Route("/geolocation-anomoly-report-sub-lvl-detail",name="geolocation_anomoly_report_sub_lvl_detail")
     * @Acl(
     *     id="geolocation_anomoly_report_sub_lvl_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function geoLocationAnomolySummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('geolocation_anomoly_report','geolocation_anomoly_report.yml');
    }
    
    /**
     *@Route("/geolocation-anomoly-report-export",name="geolocation_anomoly_report_export")
     * @Acl(
     *     id="geolocation_anomoly_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function geoLocationAnomolyReportForExcelExport(){
        return $this->getExportDataForReport('geolocation_anomoly_report','geolocation_anomoly_report.yml');
    }
    
     /**
     * @Route("/incompleteCustomerRecordReport", name="incomplete_customer_record_report")
     * @Template("IZMOReportAccessControlBundle:Report:incomplete_customer_record_report.html.twig")
     * @Acl(
     *     id="incomplete_customer_record_report",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function incompleteCustomerRecordReportAction(Request $request) {
        $user_owner_ids = $this->get('izmo_user_security_info.user_security_provider')->getUserIds();
        $upperLimitVal = $this->get('izmo_user_security_info.user_security_provider')->getNoOfRowsForReportPerPageForUser();
        $upperLimitVal = ( $upperLimitVal != '' && $upperLimitVal>0 ) ? $upperLimitVal : 20;
        $next = $request->request->get('next');
        $prev = $request->request->get('prev');        
        $lowerLimit = isset($prev)?$prev:0;
        $upperLimit = isset($next)?$next:$upperLimitVal;
        $incompleteCustomerRecordReportData = $this->getReportRepository()->getIncompleteCustomerRecord($user_owner_ids,$lowerLimit,$upperLimit);
        if(isset($next) && isset($prev)){        
            $data = [];
            $data['report'] = $incompleteCustomerRecordReportData;
            $data['page'] = ['lowerLimit' => $lowerLimit];                             
            return new Response(json_encode($data));  
        } else {        
            return $this->render('IZMOReportAccessControlBundle:Report:incomplete_customer_record_report.html.twig',
                ['incompleteCustomerRecordReportData' => $incompleteCustomerRecordReportData,'pageLimit' => $upperLimit]
            );
        }
    }
    
    /**
     * @Route("/clientFidelityReport", name="client_fidelity_report")
     * @Template("IZMOReportAccessControlBundle:Report:client_fidelity_report.html.twig")
     * @Acl(
     *     id="client_fidelity_report",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function clientFidelityReportAction(Request $request) {
        
        $arr = [];
        $months = 6;
        $curr_month = date('m');
        $upperLimitVal = $this->get('izmo_user_security_info.user_security_provider')->getNoOfRowsForReportPerPageForUser();
        $upperLimitVal = ( $upperLimitVal != '' && $upperLimitVal>0 ) ? $upperLimitVal : 20;
        $next = $request->request->get('next');
        $prev = $request->request->get('prev');        
        $lowerLimit = isset($prev)?$prev:0;
        $upperLimit = isset($next)?$next:$upperLimitVal;
        $user_owner_ids = $this->get('izmo_user_security_info.user_security_provider')->getUserIds();
        $clientFidelityReportData = $this->getReportRepository()->getClientFidelityRecord($months,$lowerLimit,$upperLimit,$user_owner_ids); 
        $clientFidelityGraphRecordData = $this->getReportRepository()->getClientFidelityGraphRecord($curr_month,$months,$user_owner_ids); 
        foreach($clientFidelityGraphRecordData as $k=>$v){
            $arr[$v['month']][$v['type']] = $v['type_count'];
            $arr[$v['month']]['month_name'] = date('F', mktime(0, 0, 0, $v['month'], 10));
        }
        foreach($arr as $k2=>$v2){
            if(!array_key_exists('To Activate', $v2)){ 
                $arr[$k2]['To Activate']=0;
            }
            if(!array_key_exists('To Retain', $v2)){ 
                $arr[$k2]['To Retain']=0;
            }
            if(!array_key_exists('Faithful', $v2)){
                $arr[$k2]['Faithful']=0;
            }
        }
        if(isset($next) && isset($prev)){        
            $data = [];
            $data['report'] = $clientFidelityReportData;
            $data['page'] = ['lowerLimit' => $lowerLimit];                             
            return new Response(json_encode($data));  
        } else {        
            return $this->render('IZMOReportAccessControlBundle:Report:client_fidelity_report.html.twig',
                [
                    'clientFidelityReport' => $clientFidelityReportData,
                    'clientFidelityGraphRecord'=>$arr,
                    'pageLimit' => $upperLimit
                ]
            );
        }
    }
    
    /**
     *@Route("/visit-frequency-report",name="visit_frequency_report") 
     * @Acl(
     *     id="visit_frequency_report",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function visitFrequencySummaryReportAction() {
        return $this->getBaseReportSummaryData('visit_frequency_report','visit_frequency_report.yml');
    }

    /**
     *@Route("/visit-frequency-report-sub-lvl-detail",name="visit_frequency_report_sub_lvl_detail")
     * @Acl(
     *     id="visit_frequency_report_sub_lvl_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function visitFrequencySummarySubLvlDetails() {
        return $this->getSubLvlForBaseReportData('visit_frequency_report','visit_frequency_report.yml');
    }
    
    /**
     *@Route("/visit-frequency-report-export",name="visit_frequency_report_export")
     * @Acl(
     *     id="visit_frequency_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function visitFrequencyReportForExcelExport(){
        return $this->getExportDataForReport('visit_frequency_report','visit_frequency_report.yml');
    }
    /**
     * @Route("/export/top-flop-report-export", name="top_flop_report_export")
     * @Acl(
     *      id="top_flop_report_export",
     *      type="entity",     
     *      class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *      permission="VIEW"
     * )
     */
    public function topFlopReportExportAction() {
        $salesmanData = isset($_GET['salesmanData'])?$_GET['salesmanData']:'none';
        $channelData = isset($_GET['channelData'])?$_GET['channelData']:'none';              
        $topFlopReportData = array();       
        $curYr = date('Y'); 
        $curMonthVal = date("m");
        $curStartDate = date("Y-m-01");
        $curEndDate = date("Y-m-d");        
        if ($curStartDate == $curEndDate) {
            $curStartDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal - 1, 1, $curYr));
            $curEndDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal, 0, $curYr));
        }
        $prevStartDate = date("Y-m-d", strtotime('-1 year', strtotime($curStartDate)));
        $prevEndDate = date("Y-m-d", strtotime('-1 year', strtotime($curEndDate)));        
        $curYearStartDate = date("Y-01-01");
        $curYearEndDate = date("Y-m-d");
        if ($curYearStartDate == $curYearEndDate) {
            $curYearStartDate = date("Y-m-d", mktime(0, 0, 0, 01 - 1, 1, $curYr));
            $curYearEndDate = date("Y-m-d", mktime(0, 0, 0, 01, 0, $curYr));
        }
        $prevYearStartDate = date("Y-m-d", strtotime('-1 year', strtotime($curYearStartDate)));
        $prevYearEndDate = date("Y-m-d", strtotime('-1 year', strtotime($curYearEndDate)));                      
        $nonInternalUsers = 1;
        $userIds = $this->get('izmo_user_security_info.user_security_provider')->getUserIds($nonInternalUsers);
        $workingDaysTillCurrentDay = $this->getReportRepository()->getWorkingDaysCurrentDay();
        if (empty($workingDaysTillCurrentDay)) {           
            $workingDaysTillCurrentDay = 1;
        }
        $workingDaysTillCurrentMonth = $this->getReportRepository()->getWorkingDaysCurrentMonth();
        if (empty($workingDaysTillCurrentMonth)) {           
            $workingDaysTillCurrentMonth = 1;
        }    
        $categoryId = $this->getUserCategoryType('NET_TURNOVER');               
        $topFlopReportData = $this->getReportRepository()->getTopFlopReportCustomerData($curStartDate,$curEndDate,$prevStartDate,$prevEndDate,$userIds,$curYearStartDate,$curYearEndDate,$prevYearStartDate,$prevYearEndDate,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,$salesmanData,$channelData,$categoryId,0,0,0);         
        $hdr_array = array("h1" => "izmo.reports.performance_reports.topflop_report.client", "h2" => "izmo.reports.performance_reports.topflop_report.salesman", "h3" => "izmo.reports.performance_reports.topflop_report.channel", "h4" => "izmo.reports.performance_reports.topflop_report.salestotal", "h5" => "izmo.reports.performance_reports.topflop_report.salestotalhistorical", "h6" => "izmo.reports.performance_reports.topflop_report.variation", "h7" => "izmo.reports.performance_reports.topflop_report.projection", "h8" => "izmo.reports.performance_reports.topflop_report.salestotal", "h9" => "izmo.reports.performance_reports.topflop_report.salestotalhistorical", "h10" => "izmo.reports.performance_reports.topflop_report.variation", "h11" => "izmo.reports.performance_reports.topflop_report.projection");
        $exceltitle = $this->getTranslation('izmo.reports.performance_reports.topflop_report.export');
        $res = $this->get('custom.excel.export.class')->generateExcelForReport($topFlopReportData, $hdr_array, $exceltitle);
        return new Response(
            $res, 200, array(
            'Content-Type' => 'application/vnd.ms-excel',
            'Content-Disposition' => 'attachment; filename="doc.xls"',
            )
        );
    }   
    /**
     * @Route("/out-standing-credit-report-customer-export", name="out_standing_credit_report_customer_export")
     * @Template("IZMOReportAccessControlBundle:Report:dashboardoutstandingcreditreport.html.twig")
     * @Acl(
     *     id="out_standing_credit_report_customer_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function outStandingCreditReportCustomerExportAction(Request $request) 
    { 
        $nonInternalUsers = 1;
        $userIds = $this->get('izmo_user_security_info.user_security_provider')->getUserIds($nonInternalUsers);                              
        $curStartDate = date("Y-m-01");
        $curEndDate = date("Y-m-d"); 
        $workingDaysTillCurrentDay = $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getWorkingDaysCurrentDay();                
        $outStandingCreditReportData = $this->getReportRepository()->outStandingCreditReportCustomer($userIds,$curStartDate,$curEndDate,$workingDaysTillCurrentDay,0,0,0);                
        $hdr_array = array("h1" => "izmo.reports.performance_reports.outstanding_credit_report.client", "h2" => "izmo.reports.performance_reports.outstanding_credit_report.salesman", "h3" => "izmo.reports.performance_reports.outstanding_credit_report.available", "h4" => "izmo.reports.performance_reports.outstanding_credit_report.creditblocked", "h5" => "izmo.reports.performance_reports.outstanding_credit_report.incidentcode", "h6" => "izmo.reports.performance_reports.outstanding_credit_report.daysleft");
        $exceltitle = $this->getTranslation('izmo.reports.performance_reports.outstanding_credit_report.title.label');

        $res = $this->get('custom.excel.export.class')->generateExcelForReport($outStandingCreditReportData, $hdr_array, $exceltitle);

        return new Response(
                $res, 200, array(
            'Content-Type' => 'application/vnd.ms-excel',
            'Content-Disposition' => 'attachment; filename="doc.xls"',
                )
        );
    }
    
    /**
     *@Route("/top-flop-cust-report",name="top_flop_cust_report")
     * @Acl(
     *     id="top_flop_cust_report",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function topFlopCustomerReportAction() {
        $res = $this->get('reports.service_provider')->getBaseReportSummaryDataForNonMultiLvlReports('top_flop_report','top_flop_report.yml');
        $loggedUserId = $this->get('izmo_user_security_info.user_security_provider')->getLoggedInUsr()->getId(); 
        if(isset($_COOKIE[$loggedUserId . '_sales_type']) && empty($_POST['turnover_type'])){
            $res['params']['filters']['turnover_type'] = $_COOKIE[$loggedUserId . '_sales_type'];
        }
       
        if((!(empty($res['twigPath']))) && (!(empty($res['params'])))){
             return $this->render($res['twigPath'],$res['params']);
        }
        else{
            $serverErrorMsg = $this->getTranslation('datatables.data.server_error_occured.label');
            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
        }
    }
    
    /**
     * @Route("/top-flop-report-detail", name="top_flop_report_detail")
     * @Acl(
     *     id="top_flop_report_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function topFlopReportDetails() {
        $jsonData=json_decode($_POST['filters']);
        $turnoverType = $jsonData->turnover_type;
        $loggedUserId = $this->get('izmo_user_security_info.user_security_provider')->getLoggedInUsr()->getId();
        if($turnoverType!=''){
            if(isset($_COOKIE[$loggedUserId . '_sales_type'])){
                unset($_COOKIE[$loggedUserId . '_sales_type']);
            }
            setcookie($loggedUserId . '_sales_type', $turnoverType,time() + (86400), "/");
        } 
        return $this->get('reports.service_provider')->getDataForBaseReportNonMultiLvl('top_flop_report','top_flop_report.yml');
    }
    
    /**
     *@Route("/top-flop-report-export",name="top_flop_report_export")      
     * @Acl(
     *     id="top_flop_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function topFlopReportForExport(){
        return $this->get('reports.service_provider')->getExportDataForReportForNonMultiLvl('top_flop_report','top_flop_report.yml');
    }
    
    
    
    /**
     *@Route("/sales-by-promotions-performance-challenge",name="sales_by_promotions_performance_challenge") 
     * @Acl(
     *     id="sales_by_promotions_performance_challenge",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByPromotionsSummaryChallengeReportAction() {
        return $this->getBaseReportSummaryData('sales_performance_by_promotions_challenge','sales_performance_by_promotions_challenge.yml');
    }

    /**
     *@Route("/sales-by-promotions-sub-lvl-performance-detail-challenge",name="sales_by_promotions_sub_lvl_performance_detail_challenge")
     * @Acl(
     *     id="sales_by_promotions_sub_lvl_performance_detail_challenge",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByPromotionsSummaryChallengeSubLvlDetails() {
        return $this->getSubLvlForBaseReportData('sales_performance_by_promotions_challenge','sales_performance_by_promotions_challenge.yml');
    }
    
    /**
     *@Route("/sales-by-promotions-challenge-report-export",name="sales_by_promotions_challenge_report_export")
     * @Acl(
     *     id="sales_by_promotions_challenge_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getPerformanceSalesByPromotionsChallengeForExcelExport(){
        return $this->getExportDataForReport('sales_performance_by_promotions_challenge','sales_performance_by_promotions_challenge.yml');
    }
    
    
    /**
     *@Route("/out-standing-credit-cust-report",name="out_standing_credit_cust_report")
     * @Acl(
     *     id="out_standing_credit_cust_report",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function outstandingCreditReportAction() {
        $res = $this->get('reports.service_provider')->getBaseReportSummaryDataForNonMultiLvlReports('out-standing-credit-report','out-standing-credit-report.yml');
        if((!(empty($res['twigPath']))) && (!(empty($res['params'])))){
             return $this->render($res['twigPath'],$res['params']);
        }
        else{
            $serverErrorMsg = $this->getTranslation('datatables.data.server_error_occured.label');
            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
        }
    }
    
    /**
     * @Route("/out-standing-credit-report-detail", name="out_standing_credit_report_detail")
     * @Acl(
     *     id="out_standing_credit_report_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function outstandingCreditReportDetails() {
        return $this->get('reports.service_provider')->getDataForBaseReportNonMultiLvl('out-standing-credit-report','out-standing-credit-report.yml');
    }
    
    /**
     *@Route("/out-standing-credit-report-export",name="out_standing_credit_report_export")      
     * @Acl(
     *     id="out_standing_credit_report_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function outstandingCreditReportForExport(){
        return $this->get('reports.service_provider')->getExportDataForReportForNonMultiLvl('out-standing-credit-report','out-standing-credit-report.yml');
    }  
    /**
     *@Route("/client-fidelity",name="client_fidelity")
     * @Acl(
     *     id="client_fidelity",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function clientFidelityAction() {
        $res = $this->get('reports.service_provider')->getBaseReportSummaryDataForNonMultiLvlReports('client_fidelity','client_fidelity.yml');
        if((!(empty($res['twigPath']))) && (!(empty($res['params'])))){
            return $this->render($res['twigPath'],$res['params']);
        }else{
            $serverErrorMsg = $this->getTranslation('datatables.data.server_error_occured.label');
            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
        }   
    }
    
    /**
     * @Route("/client-fidelity-detail", name="client_fidelity_detail")
     * @Acl(
     *     id="client_fidelity_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function clientFidelityDetails() {
        return $this->get('reports.service_provider')->getDataForBaseReportNonMultiLvl('client_fidelity','client_fidelity.yml');
    } 
    
    /**
     *@Route("/client-fidelity-export",name="client_fidelity_export")      
     * @Acl(
     *     id="client_fidelity_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function clientFidelityExport(){
        return $this->get('reports.service_provider')->getExportDataForReportForNonMultiLvl('client_fidelity','client_fidelity.yml');
    }    
        
    /**
     *@Route("/incomplete-customer-record-reports",name="incomplete_customer_record_reports")
     * @Acl(
     *     id="incomplete_customer_record_reports",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function incompleteCustomerRecordAction() {
        $res = $this->get('reports.service_provider')->getBaseReportSummaryDataForNonMultiLvlReports('incomplete_customer_record_report','incomplete_customer_record_report.yml');
        if((!(empty($res['twigPath']))) && (!(empty($res['params'])))){
             return $this->render($res['twigPath'],$res['params']);
        }
        else{
            $serverErrorMsg = $this->getTranslation('datatables.data.server_error_occured.label');
            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
        }
    }
    
    /**
     * @Route("/incomplete-customer-record-report-detail", name="incomplete_customer_record_report_detail")
     * @Acl(
     *     id="incomplete_customer_record_report_detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function incompleteCustomerRecordDetailsAction() {
        return $this->get('reports.service_provider')->getDataForBaseReportNonMultiLvlWithTranslation('incomplete_customer_record_report','incomplete_customer_record_report.yml');
    }       
    
    /**
     * @Route("/salesman-target-all-categories-export", name="salesman_target_all_categories_export")
     * @Acl(
     *     id="sales_report_target_performance_export",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function getAllCategoriesSalesmanTargetExportAction(){
        $excelTitle = '';
        $logger = $this->get('logger');
        $filter = [];
        $serverErrorMsg = $this->getTranslation('datatables.data.server_error_occured.label');
        try {
            $resultArr = $this->get('ymlparser.service.provider')->parseYmlFiles('salesman_targets_performance.yml','/../../ReportAccessControlBundle/Resources/config')['reports']['salesman_targets_performance'];
            if (!(empty($resultArr))) {
                $reportConfig = $resultArr;
                if (!(empty($reportConfig))) {
                    if(!(empty($reportConfig['all_export']))){
                        $allExportConfig = $reportConfig['all_export'];
                    if(!(empty($allExportConfig['title']))){
                        $excelTitle = $this->getTranslation($allExportConfig['title']);
                    }
                    if (!(empty($allExportConfig['stored_proc']))) {
                        $storedProcName = $allExportConfig['stored_proc'];
                    }
                    $filtersConfig = $allExportConfig['filters']['index'];
                    foreach ($filtersConfig as $key => $val) {
                        if ((!(empty($_REQUEST))) && (!(empty($_REQUEST[$val['col']])))) {
                            $filter[$key] = $_REQUEST[$val['col']];
                        } else {
                            if ($val['default'] == 'cur_yr') {
                                $filter[$key] = date("Y");
                            }
                            elseif((!(empty($val['type']))) && ($val['type'] == 'function') && (!(empty($val['function_name']))) && ($val['service_name'])){
                                        $funcName = $val['function_name'];
                                        $serviceName = $val['service_name'];
                                        $filter[$key] = $this->get($serviceName)->$funcName();
                            }
                            else {
                                $filter[$key] = $val['default'];
                            }
                        }
                        $dataType[$key] = $val['data_type'];
                    }
                    $userIds = $this->get('izmo_user_security_info.user_security_provider')->getUserIds();
                    if (!(empty($allExportConfig['stored_proc_params']))) {
                        $storedProcParameters = $allExportConfig['stored_proc_params'];
                    }
                    $spParametersLabelArray = explode(',', $storedProcParameters);
                    $spParametersArrayCount = count($spParametersLabelArray);
                    $spFilterParam = [];
                    for ($i = 0; $i < $spParametersArrayCount; $i++) {
                        $spFilterParam[$i]['filter'] = $filter[$spParametersLabelArray[$i]];
                        $spFilterParam[$i]['data_type'] = $dataType[$spParametersLabelArray[$i]];
                    }
                    $qryResult = $this->getReportRepository()->getReportExportDataForParameters($userIds, $storedProcName, $spFilterParam); 
                    if (!(empty($qryResult))) {
                        if(!(empty($qryResult['err']))){
                            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
                        }
                        else{
                          foreach ($qryResult as $key => $val) {
                                if (!(empty($val['mon']))) {
                                    $qryResult[$key]['mon'] = $this->getTranslation($val['mon']);
                                }
                                if(!(empty($val['category_type']))){
                                    $qryResult[$key]['category_type'] = $this->getTranslation($val['category_type']);
                                }
                            }
                        $colHdrs = $allExportConfig['header'];
                        $res = $this->get('custom.excel.export.class')->generateExcelForReport($qryResult, $colHdrs, $excelTitle);
                        return new Response(
                                $res, 200, array(
                            'Content-Type' => 'application/vnd.ms-excel',
                            'Content-Disposition' => 'attachment; filename="doc.xls"',
                                )
                        );
                     }
                    } else {
                        $noDataFoundMsg = $this->getTranslation('datatables.data.no_record_found.label');
                        return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $noDataFoundMsg . '</p>');
                    }
                 } //not empty of all_export
                }//not empty $reportConfig
                else {
                    $logger->crit("No configuration found for given report");
                    return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
                }
            } else {
                $logger->crit("No configuration found for given report");
                return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured during fetching data with details below:");
            $logger->crit($e);
            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
        }
    }
    
    /**
     *@Route("/data-import-report", name="data-import-report")
     * @Acl(
     *     id="data-import-report",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:DataImportReport",
     *     permission="VIEW"
     * )
     */
    public function dataImportReportAction(Request $request) { 
        $bu=[];
        
        $buId = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
        $categoryConfigObj = $this->get('doctrine')->getRepository('IZMOCustomConfigBundle:CustomConfig')->findOneBy(array('configLabel' => 'GET_RELATED_BU_FLAG_FOR_DATA_IMPORT','organization' => 1,'owner' => $buId));
        $isRelatedBuFlgSet = 0;
        if(!empty($categoryConfigObj)){
            $isRelatedBuFlgSet = $categoryConfigObj->getConfigValue();
        }
        else
        {
            $categoryConfigObj = $this->get('doctrine')->getRepository('IZMOCustomConfigBundle:CustomConfig')->findOneBy(array('configLabel' => 'DEFAULT_GET_RELATED_BU_FLAG_FOR_DATA_IMPORT','organization' => 1));
            if(!empty($categoryConfigObj)){
                $isRelatedBuFlgSet = $categoryConfigObj->getConfigValue();
            }
            else{
                $isRelatedBuFlgSet = SELF::DEFAULT_GET_RELATED_BU_FLAG_FOR_DATA_IMPORT ;
            }
        }
        
        $buIds = ($isRelatedBuFlgSet == 1)? $this->get('izmo_user_security_info.user_security_provider')->getBusinessUnits(): $buId;
        
        $platformInfo = $this->getDoctrine()->getRepository('IZMOClientTargetBundle:ClientTarget')->getBuDetailsForIds($buIds);
        foreach ($platformInfo as $key => $val) {
                $bu[$val['bu_id']] = $val['bu_name'];
        }
        $res = $this->get('reports.service_provider')->getBaseReportSummaryDataForNonMultiLvlReports('data_import','data_import.yml');
        $res['params']['bu'] = $bu;
        if((!(empty($res['twigPath']))) && (!(empty($res['params'])))){
             return $this->render($res['twigPath'],$res['params']);
        }
        else{
            $serverErrorMsg = $this->getTranslation('datatables.data.server_error_occured.label');
            return new Response('<p style="color:red;font-family:Helvetica, Arial, sans-serif;font-weight: bold">' . $serverErrorMsg . '</p>');
        }    
    }
    
    /**
     * @Route("/data-import-report-detail", name="data-import-report-detail")
     * @Acl(
     *     id="data-import-report-detail",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:DataImportReport",
     *     permission="VIEW"
     * )
     */
    public function dataImportReportDetailsAction() {
        return $this->get('reports.service_provider')->getDataForBaseReportNonMultiLvl('data_import','data_import.yml');
    }
    
    /**
     * @Route("/data_import_export", name="data_import_export",options={"expose"=true})
     * @Acl(
     *     id="data-import-report",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:DataImportReport",
     *     permission="VIEW"
     * ) 
     */
    public function dataImportExport()
    {
        return $this->getExportDataForReport('data_import','data_import.yml');
    }
    
    /**
     * @Route("/getChartDetails", name="get_chart_details")
     */
    public function getChartDetails(Request $request){
        try{
            $curr_month = date('m');
            $months = 6;
            $arr=[];
            $user_owner_ids = $this->get('izmo_user_security_info.user_security_provider')->getUserIds();
            $isManager=($this->get('izmo_user_security_info.user_security_provider')->getLoggedInUsr()->getIsManager())? 1: 0;
            $buIds = $this->get('reports.service_provider')->getRelatedBuIds();
            $ownerBu = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();

            $salesman = (!empty($_POST['salesman']))?$_POST['salesman']:'none';
            $client = (!empty($_POST['code']))?$_POST['code']:'none';
            $code = (!empty($_POST['client']))?$_POST['client']:'none';
            $clientFidelityGraphRecordData = $this->getReportRepository()->getClientFidelityGraphRecord($curr_month,$months,$user_owner_ids,$salesman,$client,$code,$buIds,$ownerBu,$isManager); 
            if(count($clientFidelityGraphRecordData)>1){
                foreach($clientFidelityGraphRecordData as $k=>$v){
                    $arr[$v['month']][$v['type']] = $v['type_count'];
                    $arr[$v['month']]['month_name'] = date('F', mktime(0, 0, 0, $v['month'], 10));
                }
                foreach($arr as $k2=>$v2){
                    if(!array_key_exists('To Activate', $v2)){ 
                        $arr[$k2]['To Activate']=0;
                    }
                    if(!array_key_exists('To Retain', $v2)){ 
                        $arr[$k2]['To Retain']=0;
                    }
                    if(!array_key_exists('Faithful', $v2)){
                        $arr[$k2]['Faithful']=0;
                    }
                }                        
                $data['clientFidelityGraphRecord']=$arr;
            }else{
                $data['clientFidelityGraphRecord']='';
            }
        }catch(\Exception $e){
            $data['error']=1;
        }
        
        $resArray = json_encode($data);
        return new Response($resArray); 
    }
}