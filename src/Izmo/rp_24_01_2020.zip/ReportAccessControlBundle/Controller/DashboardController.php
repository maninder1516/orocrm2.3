<?php

namespace IZMO\ReportAccessControlBundle\Controller;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Collections\ArrayCollection;
use IZMO\UtilityBundle\Util\Codes;
use Symfony\Component\HttpFoundation\Session\Session;

class DashboardController extends Controller {
    
    const NON_DUMMY_USR_TYPE = 1;
    const ZERO_VALUE = 0;
    
    public function getSalesRepository(){
      $salesRepo =  $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess');
      if(empty($salesRepo->getContainer()))
      { 
          $salesRepo->setContainer($this->container);
       }
      return $salesRepo;
    }
    
    /**
     * This translates the given input based on locale
     * @param string $label
     * @return string
     */
    public function getTranslation($label){
        return $this->get('translator')->trans($label);
    }

    /**
     * This contains Sales json data for Parts for Users
     * @Route("/dashboard-chart", name="dashboard_chart")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardchart.html.twig")
     * @Acl(
     *     id="sales_reports_dashboard_chart",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardReportChartAction(){
        $curStartDate = date("Y-m-01");
        $curEndDate = date("Y-m-d");
        $curYr = date('Y');
        $curMonthVal = date("m");
        if ($curStartDate == $curEndDate) {
            $curStartDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal - 1, 1, $curYr));
            $curEndDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal, 0, $curYr));
        }
        $nonInternalUsers = Codes::NON_INTERNAL_USER;
        $getUserIds = $this->get('izmo_user_security_info.user_security_provider')->getUserIds($nonInternalUsers); // need to do for non dummy users
        $logger = $this->get('logger');
        $workingDaysTillCurrentDay = $this->getSalesRepository()->getWorkingDaysCurrentDay();
        if (empty($workingDaysTillCurrentDay)) {
            $logger->debug(" workingDaysTillCurrentDay  is empty. Default chosen as 1");
            $workingDaysTillCurrentDay = 1;
        }
        $workingDaysTillCurrentMonth = $this->getSalesRepository()->getWorkingDaysCurrentMonth();
        if (empty($workingDaysTillCurrentMonth)) {
            $logger->debug(" workingDaysTillCurrentMonth  is empty. Default chosen as 1");
            $workingDaysTillCurrentMonth = 1;
        }
        $chartData = $this->getSalesRepository()->getQuadSpeedometerWidgetData($curYr, $curStartDate, $curEndDate, $workingDaysTillCurrentDay, $workingDaysTillCurrentMonth, $getUserIds);
        return new Response ((!(empty($chartData))) ? (json_encode($chartData)) : null);
    }
    
    /**
     * This returns json data of client visit reports counts based on different conditions
     * @Route("/dashboard-client-visits-summary", name="dashboard_client_visits_summary")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardvisitssummary.html.twig")
     * @Acl(
     *     id="dashboard_client_visits_summary",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardClientVisitsSummaryReportAction(){
        $curStartDate = date("Y-m-01");
        $curEndDate = date("Y-m-d", strtotime('+1 day'));
        if ($curStartDate == date("Y-m-d")) { $curStartDate = date("Y-m-01", strtotime('-1 month')); }
        $salesRepo = $this->getSalesRepository();
        $resultSet = $salesRepo->getAccountCount();
        if(!empty($resultSet)){
           $res['acc_cnt']=$resultSet[0]['accountcounts'];
           $res['theoretical_visits'] = $resultSet[0]['theoretical_visits']; 
        }else{
            $res['acc_cnt']=0;
            $res['theoretical_visits']=0;
        }
        $resultVisit = $salesRepo->getClientVisitAndEventCounts($curStartDate, $curEndDate);
        $res['client_visit_cnt'] = $resultVisit['clientvisitcounts'];
        $res['evnt_cnt'] = $resultVisit['eventcounts'];
        $missedReportCnt = $salesRepo->getMissedAndReportsCounts($curStartDate, $curEndDate);
        $res['missed_cnt'] = $missedReportCnt['missedcounts'];
        $res['report_cnt'] = $missedReportCnt['reportcounts'];
        return new Response ((!(empty($res))) ? (json_encode($res)) : null);
    }
    
    /**
     * This returns Salesman Performance based on his target & his sales
     * @Route("/dashboard-salesman-performance", name="dashboard_salesman_performance", requirements={"widget"="[\w_-]+"})
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardsalesmanperformance.html.twig")
     * @Acl(
     *     id="dashboard_salesman_performance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardSalesmanPerformanceAction(){
        $curStartDate = date("Y-m-01");
        $curEndDate = date("Y-m-d");
        $curLastDate = date("Y-m-t");
        if($curStartDate == $curEndDate){
            $curStartDate = date("Y-m-01", strtotime('-1 month'));
            $curEndDate = date("Y-m-d", mktime(0, 0, 0, date("m"), 0, date("Y"))); //end of prev month
            $curLastDate = $curEndDate;
       }
        $curYr = date("Y");
        $salesRepo = $this->getSalesRepository();
        $weekDaysTillDay = $salesRepo->getWorkingDaysCount($curStartDate,$curEndDate);
        $weekDaysTillDay = $weekDaysTillDay -1;
        $weekDaysTillMonth = $salesRepo->getWorkingDaysCount($curStartDate,$curLastDate);
        return array('weekdaystilldate' => $weekDaysTillDay, 'weekdaystillmonth' =>
            $weekDaysTillMonth, 'widgetTitle' => $this->getTranslation('izmo.reports.dashboard.salesman_performance'), 'widgetName' => 'salesman_performance', 'currentYear' => $curYr, 'currentStartDate' => $curStartDate, 'currentEndDate' => $curEndDate, 'currentLastDate' => $curLastDate);
    }
    
    /**
     * This gets the Indicator class for condition matching given parameter & returns as response for twig to read it
     * @param number $cmpVal
     * @return Response
     */
    public function indicatorsConditionAction($cmpVal){
       //param $cmpVal name recieved & that sent of param -cmpVal sent from template has to match . i.e twig ref: render(controller('IZMOReportAccessControlBundle:Dashboard:indicatorsCondition', {'cmpVal': record.getValue('indicator')}))
       return new Response($this->getIndicatorClass($cmpVal));
    }
    
    /**
     * This returns the class Name for a given number based on condition
     * @param number $cmpVal
     * @return string
     */
    public function getIndicatorClass($cmpVal) {
        return $this->get('display.indicator')->getIndicatorClassForVal($cmpVal);
    }
    
    /**
     * report for promotions performance
     * returns Response Object
     * 
     * @Route("/dashboard-promotions-performance", name="dashboardpromotionsperformance")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardpromotionsperformance.html.twig")
     * @Acl(
     *     id="dashboardpromotionsperformance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardPromotionsPerformanceWidgetAction(){
        $logger = $this->get('logger');
        try{	
            //$buIds = $this->get('izmo_user_security_info.user_security_provider')->getBusinessUnits();
            $usrIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $dateSelected = date("Y-m-d"); 
            $buIds = $this->get('reports.service_provider')->getRelatedBuIds();
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $resultSet = $this->getDoctrine()->getRepository('IZMOPromotionsBundle:Promotion')->getDashboardPromotionsPerformance($usrIds,$buIds, $dateSelected,$ownrBuIdLgnUsr);
            $arr = array();
            if(!(empty($resultSet))){
                foreach ($resultSet as $k => $val) {
                    foreach ($val as $subKey => $subVal) {
                        $numType = $val['targetType'];
                        $deltaVal = $val['delta'];
                        if ($subKey != 'targetType') { 
                           $arr[$k][$subKey] =  (in_array($subKey, array('goalTotal', 'totalSales'))) ? $this->getNumOrCurrency($subVal,$numType) : (($subKey == 'ind') ? $this->getIndicatorClass($deltaVal) : (($subKey == 'delta') ? $this->getNumOrCurrency($subVal,0):$subVal));
                        }
                    }
                }
            }
            if(!(empty($resultSet['err']))){
                $logger->crit("Exception occured while calling stored Procedure getCurrentActivePromotions");
                return new Response(json_encode(array('err'=>1)));
            }
            return new Response ((!(empty($arr))) ? (json_encode($arr)) : null);   
        }
        catch(\Exception $e){
            $logger->crit("Exception occured in dashboardPromotionsPerformanceWidgetAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err'=>1)));
        } 
    }
    
    /**
     * This gets number formatted by currency or qty
     * @param type $num
     * @param type $curr
     * @return string or number
     */
    public function getNumOrCurrency($num,$curr){
        return $this->get('reports.number_formatter')->formatNumberOrCurrency($num,$curr);
    }
    
    /**
     * report for complaints summary
     * returns json
     * 
     * @Route("/dashboard-complaints", name="dashboardcomplaints")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardcomplaints.html.twig")
     * @Acl(
     *     id="dashboardcomplaints",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardComplaintsReportAction(){
        $this->get('session')->set('random', "dashboardComplaint");
        $this->get('session')->save();     
        $logger = $this->get('logger');
        try{         
            $curStartDate = date("Y-m-01");
            $curEndDate = date("Y-m-d",strtotime('+1 day'));
            $usrIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $result = $this->getSalesRepository()->getDashboardComplaints($usrIds,$curStartDate,$curEndDate);
            if(!(empty($result))){
                foreach($result as $key=>$val){
                    $result[$key]['statusLabel'] = $this->reportTranslator('complaint_status', $val['statusLabel']);
                    $result[$key]['resolutionDate'] = (!(empty($val['resolutionDate']))) ? $this->getDateFormatByLocale($val['resolutionDate']): '';
                    $result[$key]['createdate'] = (!(empty($val['createdate']))) ? $this->getDateFormatByLocale($val['createdate']) : '';
                }
            }
            if(!(empty($result['err']))){
                $logger->crit("Exception occured while calling stored Procedure dashboardComplaints");
                return new Response(json_encode(array('err'=>1)));
            }
            return new Response ((!(empty($result))) ? (json_encode($result)) : null);   
        }
        catch(\Exception $e){
            $logger->crit("Exception occured in dashboardComplaintsReportAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err'=>1)));
        }          
    }
    
    /**
     * This provides the translation label for a given value in a section defined in report_val_translators.yml
     * @param string $section
     * @param string or num $val
     * @return string
     */
    public function reportTranslator($section, $val) {
    // since $val can even contain 0 as value not using empty for comparision & checking with isset
       return (isset($val))? $this->getTranslation($this->get('ymlparser.service.provider')->parseYmlFiles('report_val_translators.yml', '/../../ReportAccessControlBundle/Resources/config/')[$section][$val]) : $val;
    }
    
    /**
     * This is to format Date from DB format to locale specific format 
     * @param DATE $data
     * @return date
     */
    public function getDateFormatByLocale($data) {
        return $this->get('oro_locale.formatter.date_time')->formatDate(new \DateTime($data));
    }
    /**
     * Description:For get the CategoryId
     * @param type $type label categoryType input parametar
     * @return id
     */
    public function getUserCategoryType($type){
        $categoryConfigObj = $this->getDoctrine()->getRepository('IZMOCustomConfigBundle:CustomConfig')->findOneBy(array('configLabel' => 'USER_SALES_CATEGORIES','organization' => 1));
        $key='';
        if(!empty($categoryConfigObj)){
            $configVal = $categoryConfigObj->getConfigValue();
            $configValArr = json_decode($configVal,true);
            $key = array_search ($type, $configValArr);
        }
        return $key;
    }    
   /**
     * @Route("/dashboard-sales-per-index", name="dashboardsalesperindex", requirements={"widget"="[\w_-]+"})
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardsalesperindex.html.twig")
     * @Acl(
     *     id="dashboardsalesperindex",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function salesPerIndexAction(Request $request) 
    { 
        $this->get('session')->set('random', "salesPerIndex");
        $this->get('session')->save();     
        $logger = $this->get('logger');
        try{        
            $curStartDate = date("Y-m-01");
            $curEndDate = date("Y-m-d");
            $curYr = date('Y');
            $startDayOfCurYr = date('Y-m-d', strtotime('first day of january this year')); //2020-01-01
            $endDayOfCurYr = date("Y-m-d",strtotime("last day of December this year")); //2020-12-31
            $curMonthVal = date("m");
            if ($curStartDate == $curEndDate) {
                $curStartDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal - 1, 1, $curYr));
                $curEndDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal, 0, $curYr));
            }     
            $prevStartDate = date("Y-m-d", mktime(0, 0, 0, date("m"), 1, (date("Y") - 1)));
            $prevEndDate = date("Y-m-t", strtotime('-1 year', strtotime($curEndDate)));
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $workingDaysTillCurrentDay = $this->getSalesRepository()->getWorkingDaysCurrentDayForBu($ownrBuIdLgnUsr);
            $workingDaysTillCurrentMonth = $this->getSalesRepository()->getWorkingDaysCurrentMonthForBu($ownrBuIdLgnUsr); 
            $workingDaysTillCurrentYear = $this->getSalesRepository()->getWorkingDaysCountForBu($startDayOfCurYr,$endDayOfCurYr,$ownrBuIdLgnUsr);
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $userIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $organizationId = $this->get('oro_security.security_facade')->getOrganization()->getId();
            $buIds = $this->get('reports.service_provider')->getRelatedBuIds();
            //Turnover sales Type
            $turnoverType = $request->request->get('salestype');
            $turnoverType = isset($turnoverType)?$turnoverType:0;
            
            $salesPerIndexData = $this->getSalesRepository()->getsalesPerIndexData($organizationId,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,$userIds,$curStartDate,$curEndDate,$prevStartDate,$prevEndDate,$buIds,$ownrBuIdLgnUsr,$turnoverType,$workingDaysTillCurrentYear,$startDayOfCurYr,$endDayOfCurYr);
            if(!(empty($salesPerIndexData['err']))){
                $logger->crit("Exception occured while calling stored Procedure getsalesPerIndexData");
                return new Response(json_encode(array('err'=>1)));
            }
            $salesPerIndexDataArray = json_encode($salesPerIndexData);
            return new Response($salesPerIndexDataArray);    
        }
        catch(\Exception $e){
            $logger->crit("Exception occured in salesPerIndexAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err'=>1)));
        }    
    }
    /**
     * @Route("/dashboard-visit-report", name="dashboardvisitreport")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardvisitreport.html.twig")
     * @Acl(
     *     id="dashboardvisitreport",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function visitReportAction() 
    {
        $this->get('session')->save();     
        $logger = $this->get('logger');
        try{   
            $this->get('session')->set('random', "visitReport");
            $this->get('session')->save();         
            $curYr = date('Y');
            $curMonthVal = date("m");
            $curStartDate = date("Y-m-01");
            $curEndDate = date("Y-m-d");
            $appointmentHours=$this->get('reports.service_provider')->getAppointmentScheduleValue();

            if ($curStartDate == $curEndDate) {
                $curStartDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal - 1, 1, $curYr));
                $curEndDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal, 0, $curYr));
            }
            $curStartDate .= ' 00:00:00';
            $curEndDate .= ' 23:59:59';
            $usrIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets(SELF::NON_DUMMY_USR_TYPE);
            $resultSet = $this->getSalesRepository()->getAccountTheoreticalVisitCount($usrIds);
            if(!empty($resultSet)){
                $res['acc_cnt'] = (!(empty($resultSet['accountcounts']))) ? $resultSet['accountcounts'] : SELF::ZERO_VALUE;
                $res['theoretical_visits'] = (!(empty($resultSet['theoretical_visits']))) ? $resultSet['theoretical_visits'] : SELF::ZERO_VALUE;
            }else{
                $res['acc_cnt'] = SELF::ZERO_VALUE;
                $res['theoretical_visits'] = SELF::ZERO_VALUE;
            }
            $resultVisit = $this->getSalesRepository()->getClientVisitAndEventCounts($curStartDate, $curEndDate, $usrIds);
            if(!empty($resultVisit)){
                $res['client_visit_cnt'] = $resultVisit['clientvisitcounts'];
                $res['evnt_cnt'] = $resultVisit['eventcounts'];
            }
            else{
                $res['client_visit_cnt'] = SELF::ZERO_VALUE;
                $res['evnt_cnt'] = SELF::ZERO_VALUE;
            }
            $startDateTime= $this->get('utility.helper')->UTCformatDate($curStartDate);
            $endDateTime= $this->get('utility.helper')->UTCformatDate($curEndDate);
            
            $missedReportCnt = $this->getSalesRepository()->getMissedAndReportsCounts($startDateTime, $endDateTime, $usrIds,$appointmentHours);
            if(!empty($missedReportCnt)){
                $res['missed_cnt'] = $missedReportCnt['missedcounts'];
                $res['report_cnt'] = $missedReportCnt['reportcounts'];
            }
            else{
                $res['missed_cnt'] = SELF::ZERO_VALUE;
                $res['report_cnt'] = SELF::ZERO_VALUE;            
            }
            return new Response ((!(empty($res))) ? (json_encode($res)) : null);
        }catch(\Exception $e){
            $logger->crit("Exception occured in visitReportAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err'=>1)));
        } 
    }
    
    /**
     * @Route("/managerdashboardgrosssales", name="dashboardManagerGrossSales")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardManagerGrossSales.html.twig")
     * @Acl(
     *     id="dashboardManagerGrossSales",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardManagerGrossSalesAction(Request $request) {
        $logger = $this->get('logger');
        try {
            $mgrFlgAndBuInfo = $this->getIsMgrFlgAndRelatedBUIds();
            if(!(empty($mgrFlgAndBuInfo))){
            list($curStartDate, $curEndDate,,, $curYr) = $this->getCurrentAndPrevDate();
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $getUserIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $workingDaysTillCurrentDay = $this->getSalesRepository()->getWorkingDaysCurrentDayForBu($ownrBuIdLgnUsr);
            if (empty($workingDaysTillCurrentDay)) {
                $logger->debug(" workingDaysTillCurrentDay  is empty. Default chosen as 1");
                $workingDaysTillCurrentDay = 1;
            }            
            //Turnover sales Type
            $turnoverType = $request->request->get('salestype');
            $turnoverType = isset($turnoverType)?$turnoverType:0;
            $workingDaysTillCurrentMonth = $this->getSalesRepository()->getWorkingDaysCurrentMonthForBu($ownrBuIdLgnUsr);
            if (empty($workingDaysTillCurrentMonth)) {
                $logger->debug(" workingDaysTillCurrentMonth  is empty. Default chosen as 1");
                $workingDaysTillCurrentMonth = 1;
            }
            $categoryId = $this->getUserCategoryType('NET_TURNOVER');
            $isMgr = (!(empty($mgrFlgAndBuInfo['is_mgr']))) ? $mgrFlgAndBuInfo['is_mgr'] : 0;
            $buIds = (!(empty($mgrFlgAndBuInfo['bu_info']))) ? $mgrFlgAndBuInfo['bu_info'] : '';
            $chartData = $this->getSalesRepository()->getDashboardManagerWidgetData('getManagerGrossSalesTotal', $curYr, $curStartDate, $curEndDate, $workingDaysTillCurrentDay, $workingDaysTillCurrentMonth, $categoryId, $getUserIds, $isMgr, $buIds,$ownrBuIdLgnUsr, $turnoverType);
            if (!(empty($chartData['err']))) {
                $logger->crit("Exception occured while calling stored Procedure getManagerGrossSalesTotal");
                return new Response(json_encode(array('err' => 1)));
            }
            $chartDataArray = json_encode($chartData);
            return new Response($chartDataArray);
            }
            else{
                $logger->crit("No info for Mgr flag and Bu Ids in dashboardManagerGrossSalesAction ");
                return new Response(json_encode(array('err' => 1)));
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured in dashboardManagerGrossSalesAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err' => 1)));
        }
    }
    
    /**
     * @Route("/managerdashboardgrosstiresales", name="dashboardManagerGrossTireSales")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardManagerGrossTireSales.html.twig")
     * @Acl(
     *     id="dashboardManagerGrossTireSales",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardManagerGrossTireSalesAction(Request $request) {
        $logger = $this->get('logger');
        try {
            $mgrFlgAndBuInfo = $this->getIsMgrFlgAndRelatedBUIds();
            if(!(empty($mgrFlgAndBuInfo))){
            list($curStartDate, $curEndDate,,, $curYr) = $this->getCurrentAndPrevDate();
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $getUserIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $workingDaysTillCurrentDay = $this->getSalesRepository()->getWorkingDaysCurrentDayForBu($ownrBuIdLgnUsr);
            if (empty($workingDaysTillCurrentDay)) {
                $logger->debug(" workingDaysTillCurrentDay  is empty. Default chosen as 1");
                $workingDaysTillCurrentDay = 1;
            }
            $workingDaysTillCurrentMonth = $this->getSalesRepository()->getWorkingDaysCurrentMonthForBu($ownrBuIdLgnUsr);
            if (empty($workingDaysTillCurrentMonth)) {
                $logger->debug(" workingDaysTillCurrentMonth  is empty. Default chosen as 1");
                $workingDaysTillCurrentMonth = 1;
            }
            $categoryId = $this->getUserCategoryType('NET_TURNOVER_OF_TIRES');
            $isMgr = (!(empty($mgrFlgAndBuInfo['is_mgr']))) ? $mgrFlgAndBuInfo['is_mgr'] : 0;
            $buIds = (!(empty($mgrFlgAndBuInfo['bu_info']))) ? $mgrFlgAndBuInfo['bu_info'] : '';
            //Turnover sales Type
            $turnoverType = $request->request->get('salestype');
            $turnoverType = isset($turnoverType)?$turnoverType:0;
            
            $chartData = $this->getSalesRepository()->getDashboardManagerWidgetData('getManagerGrossTireSalesTotal', $curYr, $curStartDate, $curEndDate, $workingDaysTillCurrentDay, $workingDaysTillCurrentMonth, $categoryId, $getUserIds, $isMgr, $buIds,$ownrBuIdLgnUsr,$turnoverType);
            if (!(empty($chartData['err']))) {
                $logger->crit("Exception occured while calling stored Procedure getManagerGrossTireSalesTotal");
                return new Response(json_encode(array('err' => 1)));
            }
            $chartDataArray = json_encode($chartData);
            return new Response($chartDataArray);
            }
            else{
                $logger->crit("No info for Mgr flag and Bu Ids in dashboardManagerGrossTireSalesAction ");
                return new Response(json_encode(array('err' => 1)));
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured in dashboardManagerGrossTireSalesAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err' => 1)));
        }
    }
    
    /**
     * @Route("/managerdashboardnetsales", name="dashboardManagerNetSales")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardManagerNetSales.html.twig")
     * @Acl(
     *     id="dashboardManagerNetSales",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardManagerNetSalesAction(Request $request) {
        $logger = $this->get('logger');
        try {
            $mgrFlgAndBuInfo = $this->getIsMgrFlgAndRelatedBUIds();
            if(!(empty($mgrFlgAndBuInfo))){
            list($curStartDate, $curEndDate,,, $curYr) = $this->getCurrentAndPrevDate();
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $getUserIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $workingDaysTillCurrentDay = $this->getSalesRepository()->getWorkingDaysCurrentDayForBu($ownrBuIdLgnUsr);
            if (empty($workingDaysTillCurrentDay)) {
                $logger->debug(" workingDaysTillCurrentDay  is empty. Default chosen as 1");
                $workingDaysTillCurrentDay = 1;
            }
            $workingDaysTillCurrentMonth = $this->getSalesRepository()->getWorkingDaysCurrentMonthForBu($ownrBuIdLgnUsr);
            if (empty($workingDaysTillCurrentMonth)) {
                $logger->debug(" workingDaysTillCurrentMonth  is empty. Default chosen as 1");
                $workingDaysTillCurrentMonth = 1;
            }
            $categoryId = $this->getUserCategoryType('NET_TURNOVER');
            $isMgr = (!(empty($mgrFlgAndBuInfo['is_mgr']))) ? $mgrFlgAndBuInfo['is_mgr'] : 0;
            $buIds = (!(empty($mgrFlgAndBuInfo['bu_info']))) ? $mgrFlgAndBuInfo['bu_info'] : '';
            //Turnover sales Type
            $turnoverType = $request->request->get('salestype');
            $turnoverType = isset($turnoverType)?$turnoverType:0;
            
            $chartData = $this->getSalesRepository()->getDashboardManagerWidgetData('getManagerNetSalesTotal', $curYr, $curStartDate, $curEndDate, $workingDaysTillCurrentDay, $workingDaysTillCurrentMonth, $categoryId, $getUserIds, $isMgr, $buIds,$ownrBuIdLgnUsr,$turnoverType);
            if (!(empty($chartData['err']))) {
                $logger->crit("Exception occured while calling stored Procedure getManagerNetSalesTotal");
                return new Response(json_encode(array('err' => 1)));
            }
            $chartDataArray = json_encode($chartData);
            return new Response($chartDataArray);
            }
            else{
                $logger->crit("No info for Mgr flag and Bu Ids in dashboardManagerNetSalesAction ");
                return new Response(json_encode(array('err' => 1)));
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured in dashboardManagerNetSalesAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err' => 1)));
        }
    }
    
    /**
     * @Route("/managerdashboardsalesqtytires", name="dashboardManagerSalesQtyTires")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardManagerSalesQtyTires.html.twig")
     * @Acl(
     *     id="dashboardManagerSalesQtyTires",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardManagerSalesQtyTiresAction(Request $request) {
        $logger = $this->get('logger');
        try {
            $mgrFlgAndBuInfo = $this->getIsMgrFlgAndRelatedBUIds();
            if(!(empty($mgrFlgAndBuInfo))){
            list($curStartDate, $curEndDate,,, $curYr) = $this->getCurrentAndPrevDate();
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $getUserIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $logger = $this->get('logger');
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $workingDaysTillCurrentDay = $this->getSalesRepository()->getWorkingDaysCurrentDayForBu($ownrBuIdLgnUsr);
            if (empty($workingDaysTillCurrentDay)) {
                $logger->debug(" workingDaysTillCurrentDay  is empty. Default chosen as 1");
                $workingDaysTillCurrentDay = 1;
            }

            $workingDaysTillCurrentMonth = $this->getSalesRepository()->getWorkingDaysCurrentMonthForBu($ownrBuIdLgnUsr);
            if (empty($workingDaysTillCurrentMonth)) {
                $logger->debug(" workingDaysTillCurrentMonth  is empty. Default chosen as 1");
                $workingDaysTillCurrentMonth = 1;
            }

            $categoryId = $this->getUserCategoryType('NET_TURNOVER_OF_TIRES');
            $isMgr = (!(empty($mgrFlgAndBuInfo['is_mgr']))) ? $mgrFlgAndBuInfo['is_mgr'] : 0;
            $buIds = (!(empty($mgrFlgAndBuInfo['bu_info']))) ? $mgrFlgAndBuInfo['bu_info'] : '';
            //Turnover sales Type
            $turnoverType = $request->request->get('salestype');
            $turnoverType = isset($turnoverType)?$turnoverType:0;
            
            $chartData = $this->getSalesRepository()->getDashboardManagerWidgetData('getManagerSaleQuantityOfTire', $curYr, $curStartDate, $curEndDate, $workingDaysTillCurrentDay, $workingDaysTillCurrentMonth, $categoryId, $getUserIds,$isMgr,$buIds,$ownrBuIdLgnUsr,$turnoverType);
            if (!(empty($chartData['err']))) {
                $logger->crit("Exception occured while calling stored Procedure getManagerSalesQtyTires");
                return new Response(json_encode(array('err' => 1)));
            }
            $chartDataArray = json_encode($chartData);
            return new Response($chartDataArray);
            }
            else{
                 $logger->crit("No info for Mgr flag and Bu Ids in dashboardManagerSalesQtyTiresAction ");
                return new Response(json_encode(array('err' => 1)));
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured in dashboardManagerSalesQtyTiresAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err' => 1)));
        }
    }
    
    /**
     * Description:For get the date
     * @param type $type label categoryType input parametar
     * @return currentstart,currentent,prvstart and prvend date
     */
    public function getCurrentAndPrevDate(){
        $curStartDate = date("Y-m-01");
        $curEndDate = date("Y-m-d");
        $prvStartDate = date((date("Y")-1)."-m-01");
        $prvEndDate = date((date("Y")-1)."-m-d");
        $curYr = date('Y');
        $curMonthVal = date("m");
        
        
        
        if ($curStartDate == $curEndDate) {
            $curStartDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal - 1, 1, $curYr));
            $curEndDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal, 0, $curYr));
            $prvStartDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal - 1, 1, $curYr - 1));
            $prvEndDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal, 0, $curYr - 1));
        }
        return array($curStartDate,$curEndDate,$prvStartDate,$prvEndDate,$curYr);
    }
    
    /**
     * @Route("/salesmanwidget", name="dashboardSalesPerSalesmanWidget",requirements={"widget"="[\w_-]+"})
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardSalesPerSalesmanWidget.html.twig")
     * @Acl(
     *     id="dashboardSalesPerSalesmanWidget",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardSalesPerSalesmanWidgetAction() {
        list($curStartDate,$curEndDate,$prvStartDate,$prvEndDate,)=$this->getCurrentAndPrevDate();
        
        $logger = $this->get('logger');
        $workingDaysTillCurrentDay = $this->getSalesRepository()->getWorkingDaysCurrentDay();
        if (empty($workingDaysTillCurrentDay)) {
            $logger->debug(" workingDaysTillCurrentDay  is empty. Default chosen as 1");
            $workingDaysTillCurrentDay = 1;
        }
        $workingDaysTillCurrentMonth = $this->getSalesRepository()->getWorkingDaysCurrentMonth();
        if (empty($workingDaysTillCurrentMonth)) {
            $logger->debug(" workingDaysTillCurrentMonth  is empty. Default chosen as 1");
            $workingDaysTillCurrentMonth = 1;
        }
        $organizationId = $this->get('oro_security.security_facade')->getOrganization()->getId();
        $nonInternalUsers = Codes::NON_INTERNAL_USER;
        $getUserIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
        $widgetTitle = $this->getTranslation('izmo.reports.dashboard.salesman.label');
        return array('cmpdate' => $workingDaysTillCurrentDay, 'cmpdate1' => $workingDaysTillCurrentMonth, 'widgetTitle' => $widgetTitle, 'widgetName' => 'target_widget', 'organizationId' => $organizationId, 'currentStartDate' => $curStartDate, 'currentEndDate' => $curEndDate,'prevStartdate'=>$prvStartDate,'prevEndDate'=>$prvEndDate,'userIds'=>$getUserIds);
    }
    
    /**
     * @Route("/visitcomplaints", name="visitreport_complaints", requirements={"widget"="[\w_-]+"})
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardComplaintsSummary.html.twig")
     * @Acl(
     *     id="visitreport_complaints",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardComplaintsWidgetAction() {
        list($currentStartDate,$currentEndDate,,,)=$this->getCurrentAndPrevDate();
        $nonInternalUsers = Codes::NON_INTERNAL_USER;
        $getUserIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
        $relTablName = $this->get('utility.helper')->getRelationTableName('Oro\Bundle\CalendarBundle\Entity\CalendarEvent', 'Oro\Bundle\AccountBundle\Entity\Account');
        $widgetTitle = $this->getTranslation('izmo.reports.dashboard.complaint'); 
        return array('widgetTitle' => $widgetTitle, 'widgetName' => 'dashboard_complaints', 'userIds'=>$getUserIds,'currentStartDate' => $currentStartDate, 'currentEndDate' => $currentEndDate,'relTableName' => $relTablName);
    }
    
    
    /**
     * @Route("/promotionsperformance", name="promotionsPerformance",requirements={"widget"="[\w_-]+"})
     * @Template("IZMOReportAccessControlBundle:Dashboard:promotionsPerformance.html.twig")
     * @Acl(
     *     id="promotionsPerformance",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:CentralRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardPromotionsPerfWidgetAction() {
        
        $nonInternalUsers = Codes::NON_INTERNAL_USER;
        $getBusinessUnit = $this->get('izmo_user_security_info.user_security_provider')->getBusinessUnits();
        $usrIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
        $dateSelected = date("Y-m-d"); 
        
        $widgetTitle = $this->getTranslation('izmo.promotions.promotion.promotionstitle');
        return array('widgetTitle' => $widgetTitle, 'widgetName' => 'promotions_performance', 'currentDate' => $dateSelected,'userIds'=>$usrIds,'businessUnit'=>$getBusinessUnit);
    }

    /**
     * @Route("/top-flop-report", name="dashboardtopflopreport",requirements={"widget"="[\w_-]+"})
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardtopflopreport.html.twig")
     * @Acl(
     *     id="dashboardtopflopreport",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function topFlopReportAction(Request $request) 
    {   
        $this->get('session')->set('random', "topFlopReport");
        $this->get('session')->save(); 
        $logger = $this->get('logger');
        try{        
            $curYr = date('Y'); 
            $curMonthVal = date("m");
            $curStartDate = date("Y-m-01");
            $curEndDate = date("Y-m-d");
            if ($curStartDate == $curEndDate) {
                $curStartDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal - 1, 1, $curYr));
                $curEndDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal, 0, $curYr));
            }
            $prevStartDate = date("Y-m-d", strtotime('-1 year', strtotime($curStartDate)));
            $prevEndDate = date("Y-m-t", strtotime('-1 year', strtotime($curEndDate)));                        
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $userIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $buIds = $this->get('reports.service_provider')->getRelatedBuIds();
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $workingDaysTillCurrentDay = $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getWorkingDaysCurrentDayForBu($ownrBuIdLgnUsr);
            $workingDaysTillCurrentMonth = $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getWorkingDaysCurrentMonthForBu($ownrBuIdLgnUsr);
            //Turnover sales Type
            $turnoverType = $request->request->get('salestype');
            $turnoverType = isset($turnoverType)?$turnoverType:0;
            
            $topFlopReportData = $this->getSalesRepository()->getTopFlopReportData($curStartDate,$curEndDate,$prevStartDate,$prevEndDate,$userIds,$buIds,$ownrBuIdLgnUsr,$workingDaysTillCurrentDay,$workingDaysTillCurrentMonth,$turnoverType); 
            if(!(empty($topFlopReportData['err']))){
                $logger->crit("Exception occured while calling stored Procedure getTopFlopReportData");
                return new Response(json_encode(array('err'=>1)));
            }
            $topFlopReportDataArray = json_encode($topFlopReportData);
            return new Response($topFlopReportDataArray);  
        }
        catch(\Exception $e){
            $logger->crit("Exception occured in topFlopReportAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err'=>1)));
        }
    }
	
    /**
     * @Route("/net-sales-excluding-tire-sales-for-manager", name="netsalesexcludingtiresalesformanager",requirements={"widget"="[\w_-]+"})
     * @Template("IZMOReportAccessControlBundle:Dashboard:netsalesexcludingtiresalesformanager.html.twig")
     * @Acl(
     *     id="netSalesExcludingTireSalesForManager",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function netSalesExcludingTireSalesForManagerAction(Request $request) {
        $logger = $this->get('logger');
        try {
            $mgrFlgAndBuInfo = $this->getIsMgrFlgAndRelatedBUIds();
            if(!(empty($mgrFlgAndBuInfo))){
            $curYr = date('Y');
            $curMonthVal = date("m");
            $curStartDate = date("Y-m-01");
            $curEndDate = date("Y-m-d");
            if ($curStartDate == $curEndDate) {
                $curStartDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal - 1, 1, $curYr));
                $curEndDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal, 0, $curYr));
            }
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $workingDaysTillCurrentDay = $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getWorkingDaysCurrentDayForBu($ownrBuIdLgnUsr);
            $workingDaysTillCurrentMonth = $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getWorkingDaysCurrentMonthForBu($ownrBuIdLgnUsr);
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $userIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $categoryId = $this->getUserCategoryType('NET_TURNOVER_WITHOUT_TIRES');
            $isMgr = (!(empty($mgrFlgAndBuInfo['is_mgr']))) ? $mgrFlgAndBuInfo['is_mgr'] : 0;
            $buIds = (!(empty($mgrFlgAndBuInfo['bu_info']))) ? $mgrFlgAndBuInfo['bu_info'] : '';
            //Turnover sales Type
            $turnoverType = $request->request->get('salestype');
            $turnoverType = isset($turnoverType)?$turnoverType:0;
            
            $chartData = $this->getSalesRepository()->getNetSalesSpeedometerDataForManager($curStartDate, $curEndDate, $curYr, $userIds, $workingDaysTillCurrentDay, $workingDaysTillCurrentMonth, $categoryId, $isMgr, $buIds,$ownrBuIdLgnUsr,$turnoverType);
            if (!(empty($chartData['err']))) {
                $logger->crit("Exception occured while calling stored Procedure getNetSalesExcludingTireSalesWidgetDataForManager");
                return new Response(json_encode(array('err' => 1)));
            }
            $resultArray = json_encode($chartData);
            return new Response($resultArray);
            }
            else{
                $logger->crit("No info for Mgr flag and Bu Ids in netSalesExcludingTireSalesForManagerAction ");
                return new Response(json_encode(array('err' => 1)));
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured in netSalesExcludingTireSalesForManagerAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err' => 1)));
        }
    } 
	
    /**
     * @Route("/annual-total-sales-without-tires", name="dashboardannualtotalsaleswithouttires",requirements={"widget"="[\w_-]+"})
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardannualtotalsaleswithouttires.html.twig")
     * @Acl(
     *     id="dashboardannualtotalsaleswithouttires",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function annualTotalSalesWithoutTiresAction(Request $request) {
        $logger = $this->get('logger');
        try {
            $mgrFlgAndBuInfo = $this->getIsMgrFlgAndRelatedBUIds();
            if(!(empty($mgrFlgAndBuInfo))){
            $curYr = date('Y');
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $userIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $organizationId = $this->get('oro_security.security_facade')->getOrganization()->getId();
            $curYearStartDate = date("Y-01-01");
            $prvDate = date('Y-m-d', strtotime('-1 day'));
            $curYearEndDate = date('Y-m-d', strtotime('12/31'));
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $workingDaysTillCurrentDay = $this->getSalesRepository()->getWorkingDaysCountForBu($curYearStartDate, $prvDate,$ownrBuIdLgnUsr);
            $workingDaysTillCurrentYear = $this->getSalesRepository()->getWorkingDaysCountForBu($curYearStartDate, $curYearEndDate,$ownrBuIdLgnUsr);
            $categoryId = $this->getUserCategoryType('NET_TURNOVER_WITHOUT_TIRES');
            $isMgr = (!(empty($mgrFlgAndBuInfo['is_mgr']))) ? $mgrFlgAndBuInfo['is_mgr'] : 0;
            $buIds = (!(empty($mgrFlgAndBuInfo['bu_info']))) ? $mgrFlgAndBuInfo['bu_info'] : '';
            //Turnover Sales Type
            $turnoverType = $request->request->get('salestype');
            $turnoverType = isset($turnoverType)?$turnoverType:0;
            $annualTotalSalesWithoutTiresData = $this->getSalesRepository()->getAnnualTotalSalesWithoutTiresData($curYr, $organizationId, $userIds, $workingDaysTillCurrentDay, $workingDaysTillCurrentYear, $categoryId, $isMgr, $buIds,$ownrBuIdLgnUsr, $turnoverType);
            if (!(empty($annualTotalSalesWithoutTiresData['err']))) {
                $logger->crit("Exception occured while calling stored Procedure getAnnualTotalSalesWithoutTiresAction");
                return new Response(json_encode(array('err' => 1)));
            }
            $annualTotalSalesWithoutTiresDataArray = json_encode($annualTotalSalesWithoutTiresData);
            return new Response($annualTotalSalesWithoutTiresDataArray);
            }
            else{
                $logger->crit("No info for Mgr flag and Bu Ids in annualTotalSalesWithoutTiresAction ");
                return new Response(json_encode(array('err' => 1)));
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured in annualTotalSalesWithoutTiresAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err' => 1)));
        }
    }    
    /**
     * @Route("/challengelist", name="dashboardchallengelist")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardchallengelist.html.twig")
     * @Acl(
     *     id="dashboardchallengelist",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function challengeListAction() 
    {   
        $this->get('session')->set('random', "challengeList");
        $this->get('session')->save();         
        $logger = $this->get('logger');
        try{         
            $buIds = $this->get('izmo_user_security_info.user_security_provider')->getBusinessUnits();
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $userIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $dateSelected = date("Y-m-d");
            $relatedBuIds = $this->get('reports.service_provider')->getRelatedBuIds();
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $activeChallengesData = $this->getSalesRepository()->getCurActiveChallenges($userIds, $buIds, $dateSelected,$relatedBuIds,$ownrBuIdLgnUsr);          
            $arr = array();
            if(!(empty($activeChallengesData))){
                foreach ($activeChallengesData as $k => $val) {
                    foreach ($val as $subKey => $subVal) {
                        $numType = $val['targetType'];
                        $deltaVal = $val['delta'];
                        if ($subKey != 'targetType') { 
                           $arr[$k][$subKey] =  (in_array($subKey, array('goalTotal', 'totalSales'))) ? $this->getNumOrCurrency($subVal,$numType) : (($subKey == 'ind') ? $this->getIndicatorClass($deltaVal) : (($subKey == 'delta') ? $this->getNumOrCurrency($subVal,0):$subVal));
                        }
                    }
                }
            }     
            if(!(empty($activeChallengesData['err']))){
                $logger->crit("Exception occured while calling stored Procedure getCurActiveChallengesData");
                return new Response(json_encode(array('err'=>1)));
            }
            return new Response ((!(empty($arr))) ? (json_encode($arr)) : null);   
        }
        catch(\Exception $e){
            $logger->crit("Exception occured in challengeListAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err'=>1)));
        }   
    } 
    /**
     * @Route("/outStandingCreditReport", name="dashboardoutstandingcreditreport")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardoutstandingcreditreport.html.twig")
     * @Acl(
     *     id="dashboardoutstandingcreditreport",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function outStandingCreditReportAction(Request $request) 
    { 
        $this->get('session')->set('random', "outStandingCreditReport");
        $this->get('session')->save();        
        $logger = $this->get('logger');
        try{         
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $userIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $curStartDate = date("Y-m-01");
            $curEndDate = date("Y-m-d");
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $workingDaysTillCurrentDay = $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getWorkingDaysCurrentDayForBu($ownrBuIdLgnUsr);                
            $relatedBuIds = $this->get('reports.service_provider')->getRelatedBuIds();
            //Turnover sales Type
            $turnoverType = $request->request->get('salestype');
            $turnoverType = isset($turnoverType)?$turnoverType:0;
            $outStandingCreditReportData = $this->getSalesRepository()->outStandingCreditReport($userIds,$curStartDate,$curEndDate,$workingDaysTillCurrentDay,$relatedBuIds,$ownrBuIdLgnUsr,$turnoverType);  
            if(!(empty($outStandingCreditReportData['err']))){
                $logger->crit("Exception occured while calling stored Procedure getOutStandingCreditReportData");
                return new Response(json_encode(array('err'=>1)));
            }
            $outStandingCreditReportDataArray = json_encode($outStandingCreditReportData);
            return new Response($outStandingCreditReportDataArray);  
        }
        catch(\Exception $e){
            $logger->crit("Exception occured in outStandingCreditReport with details");
            $logger->crit($e);
            return new Response(json_encode(array('err'=>1)));
        }
    }  
    
    /**
     * @Route("/channelwidget", name="dashboardChannelWidget",requirements={"widget"="[\w_-]+"})
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardChannelWidget.html.twig")
     * @Acl(
     *     id="dashboardChannelWidget",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardChannelWidgetAction() {
        list($curStartDate,$curEndDate,,,)=$this->getCurrentAndPrevDate();
        $logger = $this->container->get('logger');
        
        $prevStartDate = date("Y-m-d", mktime(0, 0, 0, date("m"), 1, (date("Y") - 1)));
        $prevEndDate = date("Y-m-t", strtotime('-1 year', strtotime($curEndDate)));
        
        $usrIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
        $workingDaysTillCurrentDay = $this->getSalesRepository()->getWorkingDaysCurrentDay();
        if (empty($workingDaysTillCurrentDay)) {
            $logger->debug(" workingDaysTillCurrentDay  is empty. Default chosen as 1");
            $workingDaysTillCurrentDay = 1;
        }
        $workingDaysTillCurrentMonth = $this->getSalesRepository()->getWorkingDaysCurrentMonth();
        if (empty($workingDaysTillCurrentMonth)) {
            $logger->debug(" workingDaysTillCurrentMonth  is empty. Default chosen as 1");
            $workingDaysTillCurrentMonth = 1;
        }       
        $widgetTitle = $this->getTranslation('izmo.reports.dashboard.channelwidget.label');
        return array('cmpdate' => $workingDaysTillCurrentDay, 'cmpdate1' => $workingDaysTillCurrentMonth, 'widgetTitle' => $widgetTitle, 'widgetName' => 'channel_widget',  'currentStartDate' => $curStartDate, 'currentEndDate' => $curEndDate,'prevStartdate'=>$prevStartDate,'prevEndDate'=>$prevEndDate,'userIds'=>$usrIds);
    }
    /**
     * @Route("/sales-over-time", name="dashboardsalesovertime")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardsalesovertime.html.twig")
     * @Acl(
     *     id="dashboardsalesovertime",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function salesOverTimeAction(Request $request) 
    {   
        $this->get('session')->set('random', "salesOverTime");
        $this->get('session')->save();       
        $logger = $this->get('logger');
        try{ 
            $businessUnitId = $this->get('izmo_user_security_info.user_security_provider')->getBusinessUnits();
            $envIds = $this->getDoctrine()->getRepository('IZMOClientVisitBundle:VisitReport')->getEnvironmentId($businessUnitId);
            $envIds = implode(',',$envIds); 
            $yearStartDate = date("Y-01-01");
            $curEndDate = date("Y-m-d");
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $userIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            $pid = $request->request->get('request');        
            $partIndexId = isset($pid)?$pid:0;
            $relatedBuIds = $this->get('reports.service_provider')->getRelatedBuIds();
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $salesOverTimeData = $this->getSalesRepository()->getSalesOverTimeData($partIndexId,$userIds,$yearStartDate, $curEndDate,$relatedBuIds,$ownrBuIdLgnUsr); 
            $salesOverTimeArr = $salesOverTimeResult = array();
            $salesOverTimeResultData = '';
            if(count($salesOverTimeData) > 0){
                foreach ($salesOverTimeData as $result){
                    $salesOverTimeArr[$result['month']] = $result['actual'];
                }
                foreach ($salesOverTimeArr as $key => $val){
                    $salesOverTimeResult[] = '['.$key.','.$val.']';
                }
                $salesOverTimeResultData = implode(',',$salesOverTimeResult);
            }        
            $partIndexData = $this->getSalesRepository()->getPartIndexData($envIds);
            $partIndexDataCnt = count($partIndexData);
            $partIndexDataArr = array();
            if($partIndexDataCnt > 0){
                foreach($partIndexData as $partIndexResult){
                    $partIndexDataArr[$partIndexResult['id']] = $partIndexResult['partindexlabel'];
                }
            }  
            $res['sales_over_time_data'] = $salesOverTimeResultData;
            $res['part_index_data'] = $partIndexDataArr;
            $res['partIndexId'] = $partIndexId;         
            if(!(empty($salesOverTimeData['err']))){
                $logger->crit("Exception occured while calling stored Procedure getSalesOverTimeData");
                return new Response(json_encode(array('err'=>1)));
            }
            $resArray = json_encode($res);
            return new Response($resArray);             
        }
        catch(\Exception $e){
            $logger->crit("Exception occured in salesOverTimeAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err'=>1)));
        }    
    }  
    /**
     * @Route("/dashboardTarget", name="dashboardTarget")
     * @Template("IZMOReportAccessControlBundle:Dashboard:dashboardTarget.html.twig")
     * @Acl(
     *     id="dashboardTarget",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:SalesRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function dashboardTargetAction(Request $request) {
        $this->get('session')->set('random', "dashboardTarget");
        $this->get('session')->save();
        $logger = $this->get('logger');
        try {
            $mgrFlgAndBuInfo = $this->getIsMgrFlgAndRelatedBUIds();
            if(!(empty($mgrFlgAndBuInfo))){
            $curYr = date('Y');
            $curMonthVal = date("m");
            $curStartDate = date("Y-m-01");
            $curEndDate = date("Y-m-d");
            if ($curStartDate == $curEndDate) {
                $curStartDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal - 1, 1, $curYr));
                $curEndDate = date("Y-m-d", mktime(0, 0, 0, $curMonthVal, 0, $curYr));
            }
            $prevStartDate = date("Y-m-d", mktime(0, 0, 0, date("m"), 1, (date("Y") - 1)));
            $prevEndDate = date("Y-m-t", strtotime('-1 year', strtotime($curEndDate)));
            $ownrBuIdLgnUsr = $this->get('reports.service_provider')->getOwnerBuIdOfUsrLoggedIn();
            $workingDaysTillCurrentDay = $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getWorkingDaysCurrentDayForBu($ownrBuIdLgnUsr);
            $workingDaysTillCurrentMonth = $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess')->getWorkingDaysCurrentMonthForBu($ownrBuIdLgnUsr);
            $nonInternalUsers = Codes::NON_INTERNAL_USER;
            $isMgr = (!(empty($mgrFlgAndBuInfo['is_mgr']))) ? $mgrFlgAndBuInfo['is_mgr'] : 0;
            $buIds = (!(empty($mgrFlgAndBuInfo['bu_info']))) ? $mgrFlgAndBuInfo['bu_info'] : '';
            $userIds = $this->get('izmo_user_security_info.user_security_provider')->getAllUserIdsForDashboardWidgets();
            //Turnover sales Type
            $turnoverType = $request->request->get('salestype');
            $turnoverType = isset($turnoverType)?$turnoverType:0;
            
            $targetData = $this->getSalesRepository()->getDashboardTargetWidgetData($curYr, $curStartDate, $curEndDate, $prevStartDate, $prevEndDate, $workingDaysTillCurrentDay, $workingDaysTillCurrentMonth, $userIds, $isMgr, $buIds,$ownrBuIdLgnUsr,$turnoverType);
            if (!(empty($targetData['err']))) {
                $logger->crit("Exception occured while calling stored Procedure getDashboardTargetWidgetData");
                return new Response(json_encode(array('err' => 1)));
            }
            $targetDataArray = json_encode($targetData);
            return new Response($targetDataArray);
            }
            else{
                $logger->crit("No info for Mgr flag and Bu Ids in dashboardTargetAction ");
                return new Response(json_encode(array('err' => 1)));
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured in dashboardTargetAction with details");
            $logger->crit($e);
            return new Response(json_encode(array('err' => 1)));
        }
    }

    /**
     * @Route("/sales-per-channel", name="dashboardSalesPerChannel")
     * @Acl(
     *     id="sales_per_channel_report",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function salesPerChannelAction(Request $request) {
        //Turnover sales Type
        $turnoverType = $request->request->get('salestype');
        $turnoverType = isset($turnoverType)?$turnoverType:0;   
        $this->get('session')->set('random', "salesPerChannel");
        $this->get('session')->save();          
        return $this->get('reports.service_provider')->getDataForBaseReportNonMultiLvlForSalesType('sales-per-channel-report','dashboard_channel_widget.yml',$turnoverType);
    }
    /**
     * @Route("/sales-per-salesman", name="dashboardSalesPerSalesman")
     * @Acl(
     *     id="sales_per_salesman",
     *     type="entity",
     *     class="IZMOReportAccessControlBundle:GroupRoleAccess",
     *     permission="VIEW"
     * )
     */
    public function salesPerSalesmanAction(Request $request) {
        //Turnover sales Type
        $turnoverType = $request->request->get('salestype');
        $turnoverType = isset($turnoverType)?$turnoverType:0;
        $this->get('session')->set('random', "salesPerSalesman");
        $this->get('session')->save();         
        return $this->get('reports.service_provider')->getDataForBaseReportNonMultiLvlForSalesType('sales_per_saleman_report','dashboard_salespersalesman_widget.yml',$turnoverType);
    }

    public function getIsMgrFlgAndRelatedBUIds() {
        $res = [];
        $res['is_mgr'] = $this->get('izmo_user_security_info.user_security_provider')->getLoggedInUsr()->getIsManager();
        $buArr = $this->get('izmo_user_security_info.user_security_provider')->getBuRelatedToLoggedUser();
        if (!(empty($buArr))) {
            foreach ($buArr as $key => $val) {
                $buIds[] = $val->getId();
            }
            $res['bu_info'] = implode(',', $buIds);
        }
        return $res;
    }  
}
?>