<?php
namespace IZMO\ExtendSecurityBundle\Utils;

class ExtendSecurityConstants {
    const PERM_ARR = ['VIEW', 'CREATE', 'EDIT', 'DELETE', 'ASSIGN'];
    const VIRTUAL_CLASS = 'virtual';
    const VIRTUAL_LEVEL_INFO = ['levels' => [
            0 => 'NONE',
            4 => 'GLOBAL'
    ]];

}
