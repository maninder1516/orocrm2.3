<?php

namespace IZMO\ExtendSecurityBundle\DependencyInjection\CompilerPass;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OverrideCompilerPass implements CompilerPassInterface
{
    public function process(ContainerBuilder $container)
    {
        $definition = $container->getDefinition('oro_security.acl.privilege_repository');
        $definition->setClass('IZMO\ExtendSecurityBundle\Acl\AclPrivilegeRepository');
    }
}