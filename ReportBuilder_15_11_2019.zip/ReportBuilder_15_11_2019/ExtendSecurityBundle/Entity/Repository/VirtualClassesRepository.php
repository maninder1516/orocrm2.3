<?php
namespace IZMO\ExtendSecurityBundle\Entity\Repository;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;
use Oro\Bundle\SecurityBundle\ORM\Walker\AclHelper;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use IZMO\CustomReportDisplayConfigBundle\Entity\CustomReportDisplayConfigurator;
use IZMO\ExtendSecurityBundle\Entity\VirtualAclRoleInfo;
class VirtualClassesRepository extends EntityRepository{
    
//    public function getEnitityMgrPrepareHandler($qry){
//        return $this->getEntityManager()->getConnection()->prepare($qry);
//    }
    
    public function loadVirtualEntities($roleId = NULL) {
        /*
          if($roleId)
          {
          $qry = "select iac.class_type,iac.class_name,view_perm,create_perm,edit_perm,delete_perm,assign_perm from izmo_virtual_acl_classes iac left join izmo_virtual_acl_role_info icabr on iac.id = icabr.acl_class_id and
          icabr.role_id = $roleId ";
          }
          else{
          $qry = "select iac.class_type,iac.class_name from izmo_virtual_acl_classes iac";
          } */
        $roleIdParam = (!(empty($roleId))) ? $roleId : 0;
        $qry = "call getCustomAclClassesDetails($roleIdParam)";
        $em = $this->getDBConnection();
        $virtualClassesInfo = $em->prepare($qry);
        $virtualClassesInfo->execute();
        $virtualClasses = $virtualClassesInfo->fetchAll();
        return $virtualClasses;
    }

    public function getDBConnection(){
         
        return  $this->getEntityManager()->getConnection(); 
    }
    
    public function handlePermissionForVirtualClasses($privilege,$sid){
        // check for id from izmo_virtual_acl_classes comparing class name with $privilege->getIdentity()->getId()
                    // this id mapping has to be done with a role & CRUD Permission for the same in table - izmo_virtual_acl_role_info
        $perm = [];
        $virtualClassRef = $privilege->getIdentity()->getId();
        $em = $this->getEntityManager();
        $virtualClassId = $em->getRepository('IZMOExtendSecurityBundle:VirtualAclClasses')->findOneBy(array('classType' => addslashes($virtualClassRef)))->getId();
          $roleId = NULL;
          $roleObj = $em->getRepository('OroUserBundle:Role')->findOneBy(array('role' => $sid->getRole()));
          if(!(empty($roleObj))){
          $roleId = $roleObj->getId();
          }
         
          $virtualPerm = $privilege->getPermissions();
                            foreach ($virtualPerm as $permission) {
                    $perm[$permission->getName()] = $permission->getAccessLevel();
			}
                    $viewPerm = (!(empty($perm['VIEW']))) ? 1 : 0;   
                    $createPerm = (!(empty($perm['CREATE']))) ? 1 : 0;
                    $editPerm = (!(empty($perm['EDIT']))) ? 1 : 0;
                    $deletePerm = (!(empty($perm['DELETE']))) ? 1 : 0;
                    $assignPerm = (!(empty($perm['ASSIGN']))) ? 1 : 0;
                    
         // check if has to update based on role id , bu id , acl_class_id
          
         $existingAclRoleInfoObj = $em->getRepository("IZMOExtendSecurityBundle:VirtualAclRoleInfo")->findOneBy(array('roleId'=>$roleId,'aclClassId'=>$virtualClassId));
         
         if ((empty($existingAclRoleInfoObj))) {
            if (!((empty($viewPerm)) && (empty($createPerm)) && (empty($editPerm)) && (empty($deletePerm)) && (empty($assignPerm)))) {
                $virtualClassObj = $em->getRepository('IZMOExtendSecurityBundle:VirtualAclClasses')->find($virtualClassId);
                $buObj = $em->getRepository('OroOrganizationBundle:BusinessUnit')->find(1);
                $virtualAclRoleInfo = new VirtualAclRoleInfo();
                $virtualAclRoleInfo->setAclClassId($virtualClassObj);
                $virtualAclRoleInfo->setRoleId($roleObj);
               // $virtualAclRoleInfo->setBuId($buObj);
                $virtualAclRoleInfo->setCreate($createPerm);
                $virtualAclRoleInfo->setView($viewPerm);
                $virtualAclRoleInfo->setEdit($editPerm);
                $virtualAclRoleInfo->setDelete($deletePerm);
                 $virtualAclRoleInfo->setAssign($assignPerm);
                 $em->persist($virtualAclRoleInfo);
                 $em->flush();
            }
        } else {
            if ((empty($viewPerm)) && (empty($createPerm)) && (empty($editPerm)) && (empty($deletePerm)) && (empty($assignPerm))) {
              $em->remove($existingAclRoleInfoObj); 
              $em->flush();
            } else {
                 $existingAclRoleInfoObj->setCreate($createPerm);
                $existingAclRoleInfoObj->setView($viewPerm);
                $existingAclRoleInfoObj->setEdit($editPerm);
                $existingAclRoleInfoObj->setDelete($deletePerm);
                 $existingAclRoleInfoObj->setAssign($assignPerm);
                 $em->persist($existingAclRoleInfoObj);
                 $em->flush();
            }
        }
    }
    
    public function getRoleIdForSidRole($sid){
         $roleObj = $this->getEntityManager()->getRepository('OroUserBundle:Role')->findOneBy(array('role' => $sid->getRole()));
         return (!(empty($roleObj))) ? $roleObj->getId() : NULL;
        
    }
}
