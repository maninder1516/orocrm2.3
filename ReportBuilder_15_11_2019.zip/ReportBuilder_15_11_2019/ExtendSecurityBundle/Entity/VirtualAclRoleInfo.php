<?php

namespace IZMO\ExtendSecurityBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\Config;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\ConfigField;
use Oro\Bundle\OrganizationBundle\Entity\Organization;

/**
 *
 * @ORM\Table(name="izmo_virtual_acl_role_info") 
 * @ORM\Entity
 * @Config(
 *      defaultValues={
 *          "entity"={
 *              "icon"="",
 *          },
 *          "ownership"={
 *              "owner_type"="ORGANIZATION",
 *              "owner_field_name"="owner",
 *              "owner_column_name"="owner_id",
 *          },
 *          "security"={
 *              "type"="ACL",
 *              "group_name"=""
 *          },
 *          "dataaudit"={
 *              "auditable"=true
 *          },
 *      }
 * )
 */

class VirtualAclRoleInfo
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var Organization
     *
     * @ORM\ManyToOne(targetEntity="Oro\Bundle\OrganizationBundle\Entity\Organization")
     * @ORM\JoinColumn(name="owner_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $owner; 
    
    /**
     * @var Role
     *
     * @ORM\ManyToOne(targetEntity="Oro\Bundle\UserBundle\Entity\Role")
     * @ORM\JoinColumn(name="role_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $roleId; 
	
	/**
     * @var VirtualAclClasses
     *
     * @ORM\ManyToOne(targetEntity="IZMO\ExtendSecurityBundle\Entity\VirtualAclClasses")
     * @ORM\JoinColumn(name="acl_class_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $aclClassId; 
    
	/**
     * @var boolean
     *
     * @ORM\Column(name="view_perm", type="boolean")
     */
    private $view;
	
	/**
     * @var boolean
     *
     * @ORM\Column(name="create_perm", type="boolean")
     */
    private $create;
	
	/**
     * @var boolean
     *
     * @ORM\Column(name="edit_perm", type="boolean")
     */
    private $edit;
	
	/**
     * @var boolean
     *
     * @ORM\Column(name="delete_perm", type="boolean")
     */
    private $delete;
	
	/**
     * @var boolean
     *
     * @ORM\Column(name="assign_perm", type="boolean")
     */
    private $assign;
	
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set Organization
     *
     * @param int $owner
     *
     * @return VirtualAclRoleInfo
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;

        return $this;
    }

    /**
     * Get Organization
     *
     * @return int
     */
    public function getOwner()
    {
        return $this->owner;
    }
    
    /**
     * Set Role Id
     *
     * @param int $roleId
     *
     * @return VirtualAclRoleInfo
     */
    public function setRoleId($roleId)
    {
        $this->roleId = $roleId;

        return $this;
    }

    /**
     * Get Role Id
     *
     * @return int
     */
    public function getRoleId()
    {
        return $this->roleId;
    }
   
    /**
     * Set Role Id
     *
     * @param int $roleId
     *
     * @return VirtualAclRoleInfo
     */
    public function setAclClassId($aclClassId)
    {
        $this->aclClassId = $aclClassId;

        return $this;
    }

    /**
     * Get Role Id
     *
     * @return int
     */
    public function getAclClassId()
    {
        return $this->aclClassId;
    }
	
	/**
     * Set Route Name
     *
     * @param boolean $view
     *
     * @return VirtualAclRoleInfo
     */
    public function setView($view)
    {
        $this->view = $view;

        return $this;
    }

    /**
     * Get Category
     *
     * @return boolean
     */
    public function getView()
    {
        return $this->view;
    }
	
	/**
     * Set Route Name
     *
     * @param boolean $create
     *
     * @return VirtualAclRoleInfo
     */
    public function setCreate($create)
    {
        $this->create = $create;

        return $this;
    }

    /**
     * Get Category
     *
     * @return boolean
     */
    public function getCreate()
    {
        return $this->create;
    }
	
	/**
     * Set edit
     *
     * @param boolean $edit
     *
     * @return VirtualAclRoleInfo
     */
    public function setEdit($edit)
    {
        $this->edit = $edit;

        return $this;
    }

    /**
     * Get edit
     *
     * @return boolean
     */
    public function getEdit()
    {
        return $this->edit;
    }
	
	/**
     * Set delete perm
     *
     * @param boolean $create
     *
     * @return VirtualAclRoleInfo
     */
    public function setDelete($delete)
    {
        $this->delete = $delete;

        return $this;
    }

    /**
     * Get delete perm
     *
     * @return boolean
     */
    public function getDelete()
    {
        return $this->delete;
    }
	
	/**
     * Set assign perm
     *
     * @param boolean $assign
     *
     * @return VirtualAclRoleInfo
     */
    public function setAssign($assign)
    {
        $this->assign = $assign;

        return $this;
    }

    /**
     * Get assign perm
     *
     * @return boolean
     */
    public function getAssign()
    {
        return $this->assign;
    }
}