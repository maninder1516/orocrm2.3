<?php

namespace IZMO\ExtendSecurityBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\Config;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\ConfigField;
use Oro\Bundle\OrganizationBundle\Entity\Organization;

/**
 *
 * @ORM\Table(name="izmo_virtual_acl_classes") 
 * @ORM\Entity(repositoryClass="IZMO\ExtendSecurityBundle\Entity\Repository\VirtualClassesRepository")
 * @Config(
 *      defaultValues={
 *          "entity"={
 *              "icon"="",
 *          },
 *          "ownership"={
 *              "owner_type"="ORGANIZATION",
 *              "owner_field_name"="owner",
 *              "owner_column_name"="owner_id",
 *          },
 *          "security"={
 *              "type"="ACL",
 *              "group_name"=""
 *          },
 *          "dataaudit"={
 *              "auditable"=true
 *          },
 *      }
 * )
 */

class VirtualAclClasses
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var Organization
     *
     * @ORM\ManyToOne(targetEntity="Oro\Bundle\OrganizationBundle\Entity\Organization")
     * @ORM\JoinColumn(name="owner_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $owner; 
    
    /**
     * @var string
     *
     * @ORM\Column(name="class_type", type="string", unique=true)
     */
    private $classType;

    /**
     * @var string
     *
     * @ORM\Column(name="class_name", type="string", unique=true)
     */
    private $className;
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set Bu Id
     *
     * @param int $owner
     *
     * @return VirtualAclClasses
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;

        return $this;
    }

    /**
     * Get Bu Id
     *
     * @return int
     */
    public function getOwner()
    {
        return $this->owner;
    }
    
    
    /**
     * Set Category
     *
     * @param string $className
     *
     * @return VirtualAclClasses
     */
    public function setClassName($className)
    {
        $this->className = $className;

        return $this;
    }

    /**
     * Get Category
     *
     * @return string
     */
    public function getClassName()
    {
        return $this->className;
    }
    
    /**
     * Set Route Name
     *
     * @param string $classType
     *
     * @return VirtualAclClasses
     */
    public function setClassType($classType)
    {
        $this->classType = $classType;

        return $this;
    }

    /**
     * Get Category
     *
     * @return string
     */
    public function getClassType()
    {
        return $this->classType;
    }
    
}