<?php
namespace IZMO\ExtendSecurityBundle\Acl;

use Doctrine\Common\Collections\ArrayCollection;

use Symfony\Component\Security\Acl\Domain\ObjectIdentity;
use Symfony\Component\Security\Acl\Exception\NotAllAclsFoundException;
use Symfony\Component\Security\Acl\Model\SecurityIdentityInterface as SID;
use Symfony\Component\Security\Acl\Domain\ObjectIdentity as OID;
use Symfony\Component\Security\Acl\Model\EntryInterface;
use Symfony\Component\Security\Acl\Model\AclInterface;

use Oro\Bundle\SecurityBundle\Acl\AccessLevel;
use Oro\Bundle\SecurityBundle\Acl\Domain\ObjectIdentityFactory;
use Oro\Bundle\SecurityBundle\Acl\Extension\ObjectIdentityHelper;
use Oro\Bundle\SecurityBundle\Acl\Extension\AclExtensionInterface;
use Oro\Bundle\SecurityBundle\Acl\Extension\AclClassInfo;
use Oro\Bundle\SecurityBundle\Acl\Permission\MaskBuilder;
use Oro\Bundle\SecurityBundle\Metadata\FieldSecurityMetadata;
use Oro\Bundle\SecurityBundle\Model\AclPrivilege;
use Oro\Bundle\SecurityBundle\Model\AclPrivilegeIdentity;
use Oro\Bundle\SecurityBundle\Model\AclPermission;
use Oro\Bundle\SecurityBundle\Acl\Persistence\AclManager;
use Oro\Bundle\SecurityBundle\Acl\Persistence\AclPrivilegeRepository as BaseRepository;
use IZMO\ExtendSecurityBundle\Utils\ExtendSecurityConstants;
/**
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 */
class AclPrivilegeRepository extends BaseRepository
{
    const ROOT_PRIVILEGE_NAME = '(default)';
    
    /**
     * @var AclManager
     */
    protected $manager;

    /**
     * @param AclManager $manager
     */
    public function __construct(AclManager $manager)
    {
        $this->manager = $manager;
    }

    
    /**
     * Gets all privileges associated with the given security identity.
     *
     * @param SID $sid
     * @param string|null $aclGroup
     *
     * @return ArrayCollection|AclPrivilege[]
     */
    public function getPrivileges(SID $sid, $aclGroup = null)
    {
        $privileges = new ArrayCollection();
        foreach ($this->manager->getAllExtensions() as $extension) {
            $extensionKey = $extension->getExtensionKey();
            // fill a list of object identities;
            // the root object identity is added to the top of the list (for performance reasons)
            /** @var OID[] $oids */
            $classes = [];
            $oids = [];
            $extensionClasses = $extension->getClasses();
            foreach ($extensionClasses as $class) {
                $className = $class->getClassName();
                $oids[] = new OID($extensionKey, $className);
                $classes[$className] = $class;
            }

            $rootOid = $this->manager->getRootOid($extensionKey);
            array_unshift($oids, $rootOid);

            // load ACLs for all object identities
            $acls = $this->findAcls($sid, $oids);

            // find ACL for the root object identity
            $rootAcl = $this->findAclByOid($acls, $rootOid);
            foreach ($oids as $oid) {
                if ($oid->getType() === ObjectIdentityFactory::ROOT_IDENTITY_TYPE) {
                    continue;
                } else {
                    /** @var AclClassInfo $class */
                    $class = $classes[$oid->getType()];
                    $name = $class->getLabel();
                    if (empty($name)) {
                        $name = substr($class->getClassName(), strpos($class->getClassName(), '\\'));
                    }
                    $group = $class->getGroup();
                    $description = $class->getDescription();
                    $category = $class->getCategory();
                }

                $privilege = new AclPrivilege();
                $privilege
                    ->setIdentity(
                        new AclPrivilegeIdentity(
                            ObjectIdentityHelper::encodeIdentityString($oid->getIdentifier(), $oid->getType()),
                            $name
                        )
                    )
                    ->setGroup($group)
                    ->setExtensionKey($extensionKey)
                    ->setDescription($description)
                    ->setCategory($category);

                $this->addPermissions($sid, $privilege, $oid, $acls, $extension, $rootAcl, $aclGroup);

                // add fields in case if class metadata has not empty fields array
                if ($class->getFields()) {
                    $privilege->setFields($this->getFieldsPrivileges($sid, $class, $extension));
                }
                $privileges->add($privilege);
            }
        }

        $this->sortPrivileges($privileges);
        //
        //VIRTUAL ENTITIES:   
        $roleId = NULL;
         $roleId = $this->getVirtualClassesRepository()->getRoleIdForSidRole($sid);
         
         $virtualEntities = $this->getVirtualClassesRepository()->loadVirtualEntities($roleId);
         if (!(empty($virtualEntities))) {
            foreach ($virtualEntities as $key => $val) {
                $virtualEnt = new AclPrivilege();
                //here while populating class_name translations are required.
                $virtualEnt->setIdentity(new AclPrivilegeIdentity(
                                $val['class_type'], $this->getTranslation()->trans($val['class_name'])
                        ))
                        ->setExtensionKey('entity')
                ;
                foreach (ExtendSecurityConstants::PERM_ARR as $idx => $permName) {
                    $virtualEnt->addPermission(new AclPermission($permName, $this->retrievePermissions($val, $permName)));
                }
                $privileges->add($virtualEnt);
            }
        }
        //
        return $privileges;
    }
    
    public function getTranslation(){
        return $GLOBALS['kernel']->getContainer()->get('translator');
    }

    public function retrievePermissions($val,$permName){
        $permCol = strtolower($permName).'_perm'; // this will compare for column values in DB related to view_perm , create_perm , edit_perm ...
        return (!(empty($val[$permCol]))) ? AccessLevel::GLOBAL_LEVEL : AccessLevel::NONE_LEVEL;
    }
    
    /**
     * Associates privileges with the given security identity.
     *
     * @param SID                            $sid
     * @param ArrayCollection|AclPrivilege[] $privileges
     *
     * @throws \RuntimeException
     *
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function savePrivileges(SID $sid, ArrayCollection $privileges)
    {
        /**
         * @var $rootKeys
         * key = ExtensionKey
         * value = a key in $privilege collection
         */
        $rootKeys = [];
        // find all root privileges
        foreach ($privileges as $key => $privilege) {
            $identity = $privilege->getIdentity()->getId();
            if (strpos($identity, ObjectIdentityFactory::ROOT_IDENTITY_TYPE)) {
                $extensionKey = ObjectIdentityHelper::getExtensionKeyFromIdentityString($identity);
                $rootKeys[$extensionKey] = $key;
            }
        }

        /**
         * @var $context
         * key = ExtensionKey
         * value = array
         *      'extension' => extension
         *      'maskBuilders' => array
         *              key = permission name
         *              value = MaskBuilder (the same instance for all permissions supported by the builder)
         *      'rootMasks' => array of integer
         */
        // init the context
        $context = [];
        $this->initSaveContext($context, $rootKeys, $sid, $privileges);

        // set permissions for all root objects and remove all root privileges from $privileges collection
        foreach ($context as $extensionKey => $contextItem) {
            /** @var AclExtensionInterface $extension */
            $extension = $contextItem['extension'];
            if (isset($rootKeys[$extensionKey])) {
                $privilegeKey = $rootKeys[$extensionKey];
                $privilege = $privileges[$privilegeKey];
                unset($privileges[$privilegeKey]);
                $identity = $privilege->getIdentity()->getId();
                $oid = $extension->getObjectIdentity($identity);
            } else {
                $oid = $this->manager->getRootOid($extensionKey);
            }
            $rootMasks = $context[$extensionKey]['rootMasks'];
            foreach ($rootMasks as $mask) {
                $this->manager->setPermission($sid, $oid, $mask);
            }
        }

        // set permissions for other objects
        foreach ($privileges as $privilege) {
            $identity = $privilege->getIdentity()->getId();
            $extensionKey = $this->getExtensionKeyByIdentity($identity);
            if ($extensionKey != ExtendSecurityConstants::VIRTUAL_CLASS) {
            /** @var AclExtensionInterface $extension */
            $extension = $context[$extensionKey]['extension'];
            $oid = $extension->getObjectIdentity($identity);
            $maskBuilders = $context[$extensionKey]['maskBuilders'];
            $masks = $this->getPermissionMasks($privilege->getPermissions(), $extension, $maskBuilders);
            $rootMasks = $context[$extensionKey]['rootMasks'];
            foreach ($this->manager->getAces($sid, $oid) as $ace) {
                if (!$ace->isGranting()) {
                    // denying ACE is not supported
                    continue;
                }
                $mask = $this->updateExistingPermissions($sid, $oid, $ace->getMask(), $masks, $rootMasks, $extension);
                // as we have already processed $mask, remove it from $masks collection
                if ($mask !== false) {
                    $this->removeMask($masks, $mask);
                }
            }
            // check if we have new masks so far, and process them if any
            foreach ($masks as $mask) {
                $rootMask = $this->findSimilarMask($rootMasks, $mask, $extension);
                if ($rootMask === false || $mask !== $extension->adaptRootMask($rootMask, $oid)) {
                    $this->manager->setPermission($sid, $oid, $mask);
                }
            }

            if ($privilege->getFields()) {
                $this->saveFieldPrivileges($sid, $oid, $privilege->getFields());
            }
            }
            else{
			$this->getVirtualClassesRepository()->handlePermissionForVirtualClasses($privilege, $sid);
        }
        }

        $this->manager->flush();
    }

    //
    
    public function getVirtualClassesRepository(){
        return $GLOBALS['kernel']->getContainer()->get('doctrine')->getRepository('IZMOExtendSecurityBundle:VirtualAclClasses');
        
    }
    
    
    
    
}