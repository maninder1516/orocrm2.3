define(function(require) {
    'use strict';

    var CustomSecurityAccessLevelsComponent;
    var BaseSecurityAccessComponent = require('orosecurity/js/app/components/security-access-levels-component');

    CustomSecurityAccessLevelsComponent = BaseSecurityAccessComponent.extend({
        defaultOptions: {
            accessLevelFieldSelector: '.access_level_value',
            accessLevelLinkSelector: '.access_level_value a',
            selectDivSelector: '.access_level_value_choice',
            linkDivSelector: 'access_level_value_link',
            accessLevelRoute: 'custom_security_access_levels',
            objectIdentityAttribute: 'data-identity',
            selectorNameAttribute: 'data-selector-name',
            selectorIdAttribute: 'data-selector-id',
            valueAttribute: 'data-value'
        },
        initialize: function(options) {
            var self = this;
            this.dataCache = {};
            this.options = _.extend({}, this.defaultOptions, options);
            this.element = options._sourceElement;
            this.element.find(this.options.accessLevelFieldSelector).each(function() {
                var $field = $(this);
                var $input = $field.find('input');
                var permissionName = $field.siblings('input').val();
                var oid = $field.attr(self.options.objectIdentityAttribute);
                var url = routing.generate(self.options.accessLevelRoute, {oid: oid.replace(/\\/g, '_'), permission: permissionName});
                $input.inputWidget('create', 'select2', {
                    initializeOptions: {
                        initSelection: function(element, callback) {
                            callback({id: $input.val(), text: $input.data('valueText')});
                        },
                        query: _.bind(self._select2Query, self, url),
                        minimumResultsForSearch: -1
                    }
                }).on('change.' + self.cid, function(e) {
                    mediator.trigger('securityAccessLevelsComponent:link:click', {
                        accessLevel: e.val,
                        identityId: oid,
                        permissionName: permissionName
                    });
                });
            });
        }
    });

    return CustomSecurityAccessLevelsComponent;
});
