<?php

namespace IZMO\ExtendSecurityBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

use Oro\Bundle\UserBundle\Entity\User;
use Oro\Bundle\OrganizationBundle\Entity\Organization;
use Oro\Bundle\SecurityBundle\Acl\Extension\ObjectIdentityHelper;
use Oro\Bundle\SecurityBundle\Acl\Domain\ObjectIdentityFactory;
use Oro\Bundle\SecurityBundle\Event\OrganizationSwitchAfter;
use Oro\Bundle\SecurityBundle\Event\OrganizationSwitchBefore;
use Oro\Bundle\SecurityBundle\Authentication\Token\OrganizationContextTokenInterface;
use Oro\Bundle\SecurityBundle\Controller\AclPermissionController as BaseController;
use IZMO\ExtendSecurityBundle\Utils\ExtendSecurityConstants;

class AclPermissionController extends BaseController
{
    /**
     * @Route(
     *  "/acl-access-levels/{oid}/{permission}",
     *  name="custom_security_access_levels",
     *  requirements={"oid"="[\w]+:[\w\:\(\)\|]+", "permission"="[\w/]+"},
     *  defaults={"_format"="json", "permission"=null}
     * )
     * @Template
     *
     * @param string $oid
     * @param string $permission
     *
     * @return array
     */
    public function aclAccessLevelsAction($oid, $permission = null)
    {
        if (ObjectIdentityHelper::getExtensionKeyFromIdentityString($oid) === 'entity') {
            $entity = ObjectIdentityHelper::getClassFromIdentityString($oid);
            if ($entity !== ObjectIdentityFactory::ROOT_IDENTITY_TYPE) {
                if (ObjectIdentityHelper::isFieldEncodedKey($entity)) {
                    list($className, $fieldName) = ObjectIdentityHelper::decodeEntityFieldInfo($entity);
                    $oid = ObjectIdentityHelper::encodeIdentityString(
                        'entity',
                        ObjectIdentityHelper::encodeEntityFieldInfo(
                            $this->get('oro_entity.routing_helper')->resolveEntityClass($className),
                            $fieldName
                        )
                    );
                } else {
                    $oid = ObjectIdentityHelper::encodeIdentityString(
                        'entity',
                        $this->get('oro_entity.routing_helper')->resolveEntityClass($entity)
                    );
                }
            }
        }
         elseif(ObjectIdentityHelper::getExtensionKeyFromIdentityString($oid) === ExtendSecurityConstants::VIRTUAL_CLASS){
            return ExtendSecurityConstants::VIRTUAL_LEVEL_INFO;  
        }

        $levels = $this
            ->get('oro_security.acl.manager')
            ->getAccessLevels($oid, $permission);

        return ['levels' => $levels];
    }
    
}