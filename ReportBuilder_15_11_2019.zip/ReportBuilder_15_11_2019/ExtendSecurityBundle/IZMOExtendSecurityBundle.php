<?php

namespace IZMO\ExtendSecurityBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;
use IZMO\ExtendSecurityBundle\DependencyInjection\CompilerPass\OverrideCompilerPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class IZMOExtendSecurityBundle extends Bundle
{
    public function getParent() {
        return 'OroSecurityBundle';
    }
    public function build(ContainerBuilder $container)
    {
        parent::build($container);
 
        $container->addCompilerPass(new OverrideCompilerPass());
    }
}
