<?php

namespace IZMO\DataTablesBundle\Provider;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

class DatatableServerProcessingMultiLevelReports {
    
    /**
     * @var ContainerInterface
     */
    protected $container;
    
    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container) {
        $this->container = $container;
    }
    
    public function getLogger(){
        return $this->container->get('logger');
    }

    /**
     * Paging
     *
     * Construct the LIMIT clause for server-side processing SQL query
     *
     *  @param  array $request Data sent to server by DataTables
     *  @return string SQL limit clause
     */
    public function limit ($request){
       return ( isset($request['start']) && $request['length'] != -1 ) ? "LIMIT ".intval($request['start']).", ".intval($request['length']) : '';
    }


    /**
     * Ordering
     *
     * Construct the ORDER BY clause for server-side processing SQL query
     *
     *  @param  array $request Data sent to server by DataTables
     *  @param  array $columns Column information array
     *  @return string SQL order by clause
     */
    public function order ( $request, $columns ){
            $order = '';
            if ( isset($request['order']) && count($request['order']) ) {
                    $orderBy = array();
                    $dtColumns = $this->pluck( $columns, 'dt' );
                    for ( $i=0, $ien=count($request['order']) ; $i<$ien ; $i++ ) {
                            // Convert the column index into the column data property
                            $columnIdx = intval($request['order'][$i]['column']);
                            $requestColumn = $request['columns'][$columnIdx];
                            $columnIdx = array_search( $requestColumn['data'], $dtColumns );
                            $column = $columns[ $columnIdx ];
                            if ( $requestColumn['orderable'] == 'true' ) {
                                    $dir = $request['order'][$i]['dir'] === 'asc' ? 'ASC' : 'DESC';
                                    $orderBy[] = (!(empty($column['tab_alias']))) ? $column['tab_alias'].'.'.$column['db'].' '.$dir : $column['db'].' '.$dir;
                            }
                    }
                    $order = 'ORDER BY '.implode(', ', $orderBy);
            }
            return $order;
    }

    /**
     * 
     * @param object $request
     * @param string $storedProcName
     * @param array $columns
     * @param boolean $storedProcContainsWhere
     * @param string $primaryKeyColForCnt
     * @param string $repoClass
     * @param string $dataOutputFunc
     * @param array $params
     * @return array
     */
    public function getTableDataRendered($request, $storedProcName, $columns, $storedProcContainsWhere, $primaryKeyColForCnt, $dataOutputServiceRef, $dataOutputFunc, $params,$url) {
    try{
        $resultset = $binding = array();
        $flg = 0;
        $limit = $this->limit($request);
        $order = $this->order($request, $columns);
        $doctrine = $this->container->get('doctrine');
        $whereCond = (!(empty($where))) ? $where : '';
        $orderCond = (!(empty($order))) ? $order : '';
        $binding['where'] = $whereCond;
        $binding['order'] = $orderCond;
        $binding['limit'] = $limit;
        $result = $this->container->get('izmo_datatables.repository.service')->fetchResultForQueryParams($binding,$storedProcName,$primaryKeyColForCnt,$flg ,$params,$request['start']);
        if(!(empty($result))){
        if (!(empty($result['res'])) && (!(empty($result['cnt'])))) {
            $data = $result['res'];
            $resFilterLength = $result['cnt'];
            if($dataOutputFunc == 'default'){
                $resultset = $this->formatResultSetToRenderData($columns,$data);
            }
            else{
                $resultset = $this->container->get($dataOutputServiceRef)->$dataOutputFunc($columns,$data);
            }
            $recordsFiltered = $resFilterLength['cnt'];
            return array(
                "draw" => isset($request['draw']) ? intval($request['draw']) : 0,
                "recordsFiltered" => intval($recordsFiltered), //needed for pagination to work
                "data" => $resultset,
                "url" => $url,
                "err" => 0
            );
        }
        else if(!(empty($result['err_flg']))){
            return array('draw'=>0 ,"recordsFiltered" => 0,"data" => array(),"err"=>1);
        }
        else {//no data found
            return array(
                "draw" => isset($request['draw']) ? intval($request['draw']) : 0,
                "recordsFiltered" => 0, 
                "data" => array(),
                'no_data' => 1
            );
        }
        }
    }
        catch(\Exception $e){
            $logger = $this->getLogger();
            $logger->crit("Error Occured in getTableDataRendered with exception details below");
            $logger->crit($e);
            return array('draw'=>0 ,"recordsFiltered" => 0,"data" => array(),"err"=>1);
        }
    }

    public function pluck($a, $prop) {
        $out = array();
        for ($i = 0, $len = count($a); $i < $len; $i++) {
            $out[] = (($prop == 'db') && (!(empty($a[$i]['tab_alias'])))) ? $a[$i]['tab_alias'] . '.' . $a[$i][$prop] : $a[$i][$prop];
        }
        return $out;
    }
    
    /**
     * 
     * @param array $ymlConfig
     * @param string $storedProcName
     * @param array $requestObj
     * @param array $params
     * @param string $url
     * @return Response
     */
    public function processServerSideData($ymlConfig ,$storedProcName, $requestObj,$params,$url){ 
        $columns = $ymlConfig['columns'];
        $primaryKeyColForCnt = $ymlConfig['col_for_count'];
        $containsWhere = $ymlConfig['stored_procedure_contains_where'];
        $dataOutputServiceRef = $ymlConfig['data_out_service_id'];
        $dataOutputFunc = $ymlConfig['data_output_func_name'];
        return new Response(json_encode($this->getTableDataRendered($requestObj,$storedProcName,$columns,$containsWhere,$primaryKeyColForCnt,$dataOutputServiceRef,$dataOutputFunc,$params,$url)));
    }

    /**
     * To format the result set to fit DataTables
     * @param array $columns
     * @param array $data
     * @return array
     */
    public function formatResultSetToRenderData($columns, $data) {
        $out = array();
        for ($i = 0, $ien = count($data); $i < $ien; $i++) {
            $resData = $data[$i];
            $row = array();
            for ($j = 0, $jen = count($columns); $j < $jen; $j++) {
                $column = $columns[$j];
                if (!(empty($column['formatter']))) {
                    $colFormatter = $column['formatter'];
                    if ($colFormatter == 'percent') {
                        if (!(empty($column['ref_col']))) {
                            $class = $this->container->get('display.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                            $resData[$column['ref_col']] = "<span class='indicator $class'></span>";
                        }
                        $resData[$column['db']] .= ' %';
                    } else if ($colFormatter == 'ind' && ((!(empty($column['has_ref_col']))) && ($column['has_ref_col']=='none') )) {
                        $class = $this->container->get('display.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                        $resData[$column['db']] = "<span class='indicator $class'></span>";
                    } else if ($colFormatter == 'num') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0);
                    } else if ($colFormatter == 'curr') {
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 1);
                    }
                    else if(($colFormatter == 'num_or_cur') && (!(empty($column['ref_col'])))){
                        $resData[$column['db']] = $this->container->get('reports.number_formatter')->formatNumberOrCurrency($resData[$column['db']],$resData[$column['ref_col']]);
                    }
                }
                if (!(empty($column['is_translatable']))) {
                    $resData[$column['db']] = $this->container->get('translator')->trans($resData[$column['db']]);
                }
                $row[$column['dt']] = $resData[$column['db']];
            }
            $out[] = $row;
        }
        return $out;
    }

}

