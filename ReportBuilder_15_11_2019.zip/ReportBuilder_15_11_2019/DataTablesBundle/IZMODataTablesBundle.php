<?php

namespace IZMO\DataTablesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IZMODataTablesBundle extends Bundle
{
}
