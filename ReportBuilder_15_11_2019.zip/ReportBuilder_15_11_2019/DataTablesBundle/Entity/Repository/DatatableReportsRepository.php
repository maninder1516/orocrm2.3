<?php

namespace IZMO\DataTablesBundle\Entity\Repository;
use Doctrine\ORM\EntityRepository;
use Symfony\Component\DependencyInjection\ContainerInterface;

class DatatableReportsRepository extends EntityRepository{
    
    protected $container;
    
    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container) {
        $this->container = $container;
    }
    
    public function getLogger(){
        return $this->container->get('logger');
    }
    
    public function getEnitityMgrPrepareHandler($qry){
        return $this->container->get('doctrine')->getManager()->getConnection()->prepare($qry);
    }
    
    /**
     * 
     * @param array $binding
     * @param string $storedProcName
     * @param string $primaryKeyColForCnt
     * @param boolean $flg
     * @param array $params
     * @param int $isStart
     * @return boolean
     */
    public function fetchResultForQueryParams($binding,$storedProcName,$primaryKeyColForCnt,$flg,$params,$isStart){
        $result = array();
        $result['err_flg'] = 0;
        try {
                $usrId = $params['usr_ids'];
                $reportType = $params['report_type'];
                $spParams = $params['sp_params'];
                $sql = $this->prepareQry("call $storedProcName($reportType,'$usrId',", $spParams);
                $sql = $sql."'$primaryKeyColForCnt',$flg,$isStart)";
                $stmt = $this->getEnitityMgrPrepareHandler($sql);
                $stmt = $this->prepareParams($stmt,$binding,$spParams);
                $stmt->execute();
	    }
	    catch (\Exception $e) {
                    $logger = $this->getLogger();
                    $logger->crit("Error Occured while executing stored procedure with exception details below");
                    $logger->crit($e);
                    $result['err_flg'] = 1;
                    return $result;
	    }
		$res = $stmt->fetchAll();
                $stmt->closeCursor();
                $cntQry = $this->getEnitityMgrPrepareHandler("SELECT FOUND_ROWS() as cnt");
                $cntQry->execute();
                $cnt = $cntQry->fetch();
                $cntQry->closeCursor();
                $result['res'] = (!(empty($res)))? $res : null;
                $result['cnt'] = (!(empty($cnt)))? $cnt : 0;
                return $result;
    }
    
    /**
     * Build Query string with params[] 
     * @param string $qry
     * @param array $params
     * @return string
     */
    public function prepareQry($qry,$params){
        if(!(empty($params)))
        {  
            for($i =0;$i < count($params);$i++){
                $parameterizedStrArr[$i] = ':filter'.$i;
            }
             $qry .= implode(',',$parameterizedStrArr) .",";
        }
           return $qry .= ":binding_where,:binding_order,:binding_limit,";
    }
    
    public function prepareParams($stmt,$binding,$params){
         $i = 0;
         foreach ($params as $key => $val) {
             $filtr = $val['filter'];
             if ((!(empty($val['data_type']))) && ($val['data_type'] == 'string')) {
                  $filtr = addslashes($val['filter']);
             }
             $stmt->bindValue(':filter'.$i,$filtr);
             $i++;
         }
         $stmt->bindValue(':binding_where',$binding['where']);
         $stmt->bindValue(':binding_order',$binding['order']);
         $stmt->bindValue(':binding_limit',$binding['limit']);
         return $stmt;
    }

    /**
     * 
     * @param array $binding
     * @param string $storedProcName
     * @param string $primaryKeyColForCnt
     * @param boolean $flg
     * @param array $params
     * @return boolean
     */
    public function fetchResultForNonMultiReportsQueryParams($binding,$storedProcName,$primaryKeyColForCnt,$flg,$params){
        $result = array();
        $result['err_flg'] = 0;
        try {
                $usrId = $params['usr_ids'];
                $spParams = $params['sp_params'];
                $sql = $this->prepareQry("call $storedProcName('$usrId',", $spParams);
                $sql = $sql."'$primaryKeyColForCnt',$flg)";
                $stmt = $this->getEnitityMgrPrepareHandler($sql);
                $stmt = $this->prepareParams($stmt, $binding, $spParams);
                $stmt->execute();
                $res = $stmt->fetchAll();
                $stmt->closeCursor();
                $cntQry = $this->getEnitityMgrPrepareHandler("SELECT FOUND_ROWS() as cnt");
                $cntQry->execute();
                $cnt = $cntQry->fetch();
                $cntQry->closeCursor();
                $result['res'] = (!(empty($res)))? $res : null;
                $result['cnt'] = (!(empty($cnt)))? $cnt : 0;
                return $result;
	    }
	    catch (\Exception $e) {
                    $logger = $this->getLogger();
                    $logger->crit("Error Occured while executing stored procedure with exception details below");
                    $logger->crit($e);
                    $result['err_flg'] = 1;
                    return $result;
	    }
    }
    
}
