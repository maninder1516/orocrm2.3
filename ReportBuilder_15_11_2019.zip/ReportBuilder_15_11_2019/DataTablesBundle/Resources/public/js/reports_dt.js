 require(['jquery', 'izmodatatables/js/datatables.min','orotranslation/js/translator'], function ($,cd,trans) {
     $(document).ready(function () {
            var tabInfoOb = $('.dt-datatab-info');
            var url = tabInfoOb.attr('data-geturl');
            var tabBdy = $(tabInfoOb.attr('tbdyref'));
            var theadRef = tabInfoOb.attr('theadref');
            var ordrFlg = 0;
            ordrFlg = parseInt(tabInfoOb.attr('is-ordering'));
            var custOrder = parseInt(tabInfoOb.attr('custom-ordering-col-def'));
            var customOrderDef = (custOrder == 1) ? JSON.parse(tabInfoOb.attr('ordering-col-def')): null;
            var loadr = $('#loading');
            var errBlk = $('.err_msg');
            var cnt = 0;
            var colProp = [];
            $(theadRef + ' th', this).each(function (i) {
            colProp[i] = $(this).attr('class');
            cnt++;
            });
            var rowsToDisplay = (($('#no_of_rows').val() == undefined) || ($('#no_of_rows').val() == '')) ? 50 : parseInt($('#no_of_rows').val());
            function baseErr(tabEl){
                        errBlk.show();
                        $('.scrollable-container').animate({scrollTop: $(".err_msg_blk")},'slow');
                        loadr.hide();
                        $(tabEl+'_wrapper').hide();
            }   
            function initDT(tabEl){
                      loadr.show();     
                      var ordering = ordrFlg;
                      var table = $(tabEl).DataTable({
            "preDrawCallback": function () {
                loadr.show();
            },
            "language": {
                "paginate": {
                    "previous": trans('prev.label'),
                    "next": trans('next.label')
                },
                "zeroRecords": trans('datatables.data.no_record_found.label')
            },
                "serverSide": true,
                "searching": false,
                "ordering": ordering,
                "aoColumnDefs": customOrderDef,
                "pagingType": "simple",
                "deferRender": true,
                "pageLength" : rowsToDisplay,
                "ajax": {
                    "url": encodeURI(url),
                    "type": "POST",
                    "data": {'filters': $('#filter-info').val()},
                    dataSrc: function (json) {
                        if(json.err == 1){
                            baseErr(tabEl);
                            console.log("error getting data");
                            return false;
                        }
                        else if (json.no_data) {
                             return false;
                        } else {
                            if (json.url != '') {
                                $(tabEl).find('tbody').attr('data-url', json.url);
                            }
                            (!(errBlk.is(':hidden'))) ? errBlk.hide() : '';
                            return json.data;
                        }
                    },
                    complete: function () {
                        loadr.hide();
                        $('span.hide-col').parent().css('cursor','default');
                    },
                    error: function (e) {
                        baseErr(tabEl);
                        return false;
                    }
                },
                "fnDrawCallback": function (oSettings) {
                    if(oSettings.aoData.length > 0){
                    tabBdy.find('tr').each(function () {
                        $('td', this).each(function (i) {
                            $(this).addClass(colProp[i]);
                        });
                    });
                    var tabObjWrap = $(tabEl+'_wrapper'); 
                     if((tabObjWrap.find('a.previous').hasClass('disabled')) && (tabObjWrap.find('a.next').hasClass('disabled'))) { tabObjWrap.find('div.dataTables_paginate').hide()}
                    this.find('thead tr th').css('width', 'auto');
                }
                }
            });
        }
        $.initDTabl = function(tablElem){
            initDT(tablElem);
        }
        $.initDTabl('#l-0-tab-id-0'); 
        });
            });