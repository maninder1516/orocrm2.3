 require(['jquery', 'izmodatatables/js/datatables.min','orotranslation/js/translator'], function ($,cd,trans) {
     $(document).ready(function () {
            var colrCod = ['#FFFFFF', '#FBF8EC', '#EBEBE0','#ECF4E1','#F9EBD4'];
            var hdrColor = ['#F2F2F2'];        
            var tabInfoOb = $('.dt-datatab-info');
            var url = tabInfoOb.attr('data-geturl');
            var tabBdy = $(tabInfoOb.attr('tbdyref'));
            var theadRef = tabInfoOb.attr('theadref');
            var theadOb = $(tabInfoOb.attr('theadref'));
            var loadr = $('#loading');
            var errBlk = $('.err_msg');
            var isSubGrnd = 0 ,isGrnd = 0 , cnt = 0;
            isSubGrnd = tabInfoOb.attr('is-sub-grand-tot');
            isGrnd = tabInfoOb.attr('is-grand-tot');
            var colProp = [] , hidColByLvl = [] , hidSumCol = []  , hidGrandCol = [];
            $(theadRef + ' th', this).each(function (i) {
            colProp[i] = $(this).attr('class');
            if ($(this).attr('hid_lvl') != '')
            {
                try
                {
                    hidColByLvl[i] = JSON.parse($(this).attr('hid_lvl'));

                } catch (e) {
                    console.log("error in hid_lvl parse");
                }
            }
            if (isSubGrnd == 1)
            {
                if ($(this).attr('hid_sum_lvl') != '') {
                    try
                    {
                        hidSumCol[i] = JSON.parse($(this).attr('hid_sum_lvl'));
                    } catch (e) {
                        console.log("error in hid_lvl parse");
                    }
                }
            }
            cnt++;
            });
            if (theadOb.attr('pk_lvl') != '')
            {
                try
                {
                    var lvlPk = JSON.parse(theadOb.attr('pk_lvl'));
                } catch (e) {
                    console.log("error in pk_lvl parse");
                }
            }
            if (theadOb.attr('expndr_col') != '')
            {
                try
                {
                    var lvlExpndr = JSON.parse(theadOb.attr('expndr_col'));
                } catch (e) {
                    console.log("error in expndr_col parse");
                }
            }
            if (isGrnd == 1) {
                if (theadOb.attr('hid_col_grand_sum') != '') {
                    try {
                        var hidGrandCol = JSON.parse(theadOb.attr('hid_col_grand_sum'));
                    } catch (e) {
                        console.log("err in hid_col_grand_sum parse");
                    }
                }
            }
            var rowsToDisplay = (($('#no_of_rows').val() == undefined) || ($('#no_of_rows').val() == '')) ? 50 : parseInt($('#no_of_rows').val());
            var level = 0;
            var expndIdx = ((lvlExpndr != undefined) && (lvlExpndr[level] != undefined)) ? lvlExpndr[level] : null;
            function baseErr(tabEl){
                        errBlk.show();
                        $('.scrollable-container').animate({scrollTop: $(".err_msg_blk")},'slow');
                        loadr.hide();
                        $(tabEl+'_wrapper').hide();
            }   
            function childEr(curTd, tabRf) {
                errBlk.show();
                $('.scrollable-container').animate({scrollTop: $(".err_msg_blk")}, 'slow');
                curTd.attr('data-err', 1);
                $(tabRf + '_wrapper').hide();
            }
            function initDT(tabEl){
                      $(".multilvl-div-blk").hide();
                      loadr.show();      
                      var table = $(tabEl).DataTable({
            "preDrawCallback": function () {
                loadr.show();
            },
            "language": {
                "paginate": {
                    "previous": trans('prev.label'),
                    "next": trans('next.label')
                },
                "zeroRecords": trans('datatables.data.no_record_found.label')
            },
                "serverSide": true,
                "searching": false,
                "ordering": false,
                "pagingType": "simple",
                "deferRender": true,
                "pageLength" : rowsToDisplay,
                "ajax": {
                    "url": encodeURI(url),
                    "type": "POST",
                    "data": {'lvl': level, 'filters': $('#filter-info').val()},
                    dataSrc: function (json) {
                        if(json.err == 1){
                            baseErr(tabEl);
                            return false;
                        }
                        else if (json.no_data) {
                             return false;
                        } else {
                            if (json.url != '') {
                                $(tabEl).find('tbody').attr('data-url', json.url);
                            }
                            (!(errBlk.is(':hidden'))) ? errBlk.hide() : '';
                            return  dispInitialTablData(json.data, level, expndIdx, lvlPk, hidColByLvl, hidSumCol);
                        }
                    },
                    complete: function () {
                        loadr.hide();
                        $('span.hide-col').parent().css('cursor','default');
                    },
                    error: function (e) {
                        baseErr(tabEl);
                        return false;
                    }
                },
                "fnDrawCallback": function (oSettings) {
                    if(oSettings.aoData.length > 0){
                        $(".multilvl-div-blk").show();
                    tabBdy.find('tr').each(function () {
                        $('td', this).each(function (i) {
                            $(this).addClass(colProp[i]);
                        });
                    });
                    $('tbody.dt-res tr').find('td:eq(' + expndIdx + ')').addClass('details-control');
                        if (isGrnd == 1)
                        {
                            if (oSettings._iDisplayStart == 0) {
                                var tbdyTr0 = $('tbody.dt-res tr:eq(0)');
                                tbdyTr0.find('td:eq(0)').html('<b>' + trans('datatables.data.report.grand_total.label') + '<span class="hide-col"></span></b>'); 
                                tbdyTr0.find('td:eq(0)').css('cursor','default');
                                for (var i = 0; i < hidGrandCol.length; i++) {
                                    tbdyTr0.find('td:eq(' + hidGrandCol[i] + ')').children().addClass('hide-col');
                                }
                            }
                        }
                   
                }
                else{
                    $(".multilvl-div-blk").hide();
                        if(errBlk.is(':hidden')){
                            $('.report_no_rec').show();}
                }
                 var tabObjWrap = $(tabEl+'_wrapper'); 
                 if((tabObjWrap.find('a.previous').hasClass('disabled')) && (tabObjWrap.find('a.next').hasClass('disabled'))) { tabObjWrap.find('div.dataTables_paginate').hide()}
                 this.find('thead tr th').css('width', 'auto');
                }
            });  
                   $(tabEl+' tbody').on('click', 'td.details-control', function () {
                          (!($(this).find('span').hasClass('hide-col'))) ? getReportInfo($(this), table) : '';
                    });
                }
            function dispInitialTablData(res, lvl, expndIdx ,lvlPk,hidColByLvl,hidSumCol) {
            var pkIdx = ((lvlPk != undefined) && (lvlPk[lvl] != undefined) && (lvlPk[lvl] != '')) ? lvlPk[lvl] : null;
            for (var i = 0, ien = res.length; i < ien; i++) {
                for (var j = 0; j < cnt; j++) {
                    if ((pkIdx == '' || pkIdx == undefined) && (expndIdx == '' || expndIdx == undefined))
                    {
                        if (($.inArray(lvl, hidColByLvl[j])) > -1) {
                            res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";
                        }
                    } else {
                        if ((j == expndIdx) && (res[i][pkIdx])) {
                            res[i][j] = "<span class='drilldown-control' id='" + res[i][pkIdx] + "'></span><span class='expndr-col'>" + res[i][j] + "</span>";
                        }
                        else if ((($.inArray(lvl, hidColByLvl[j])) > -1) && (res[i][pkIdx])){
                             res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";
                        }
                        else if(isGrnd == 1){
                            if((($.inArray(lvl, hidSumCol[j])) > -1) && (res[i][pkIdx] == '')){res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";}
                            else if(((!($.inArray(lvl, hidSumCol[j]))) > -1) && (res[i][pkIdx] == '')){res[i][j] = "<b>" + res[i][j] + "<b>";}
                        }
                    }
                }
            }
            return res;
        }
        $.initDTabl = function(tablElem){
            initDT(tablElem);
        }
        function init_child_table(id, level,url,_thisTd) {
            var childTabRefId = "#l-" + level + "-tab-id-" + id;
            var filtersUsed = $('#filter-info').val();
            rowsToDisplay = (($('#no_of_rows').val() == undefined) || ($('#no_of_rows').val() == '')) ? 50 : parseInt($('#no_of_rows').val()); 
            var expndIdx = ((lvlExpndr != undefined) && (lvlExpndr[level] != undefined)) ? lvlExpndr[level] : null;
            var tab = $(childTabRefId).DataTable({
                "preDrawCallback": function(){
                   loadr.show();
                              },
                "language": {
                 "paginate": {
                        "previous": trans('prev.label'),
                        "next": trans('next.label')
                      },
                 "zeroRecords": trans('datatables.data.no_record_found.label') 
                    },
                "serverSide": true,
                "searching": false,
                "ordering": false,
                "pagingType": "simple",
                "pageLength" : rowsToDisplay,
                "deferRender": true,
                "ajax": {
                    "url": encodeURI(url),
                    "type": "POST",
                    "data": {'id': id,'lvl':level,'filters': filtersUsed},
                    dataSrc: function (json)
                    {   _thisTd.attr('data-err',0);
                        if(json.err == 1){
                            childEr(_thisTd,childTabRefId);
                            return false;
                        }
                        else if(json.no_data){
                            return false;
                        }
                        else{
                            if(json.url !=''){$(childTabRefId).find('tbody').attr('data-url',json.url);}
                            (!(errBlk.is(':hidden'))) ? errBlk.hide() : '';
                        return renderTabData(id,json.data,level,expndIdx);
                    }
                    },
                    complete: function () {
                        loadr.hide();
                        $('span.hide-col').parent().css('cursor','default');
                    },
                    error: function (e) {
                        childEr(_thisTd,childTabRefId);
                        return false;
                    }
                },
                "fnDrawCallback": function (oSettings) {
                    $("span.expndr-col").parent().css({"cursor": "pointer"});
                    if(oSettings.aoData.length > 0){
                    var childOb = $(childTabRefId);
                    childOb.find('tbody').find('tr').each(function () {
                        $('td', this).each(function (i) {
                            $(this).addClass(colProp[i]);
                        });
                    });
                     $(childOb).find('tbody tr').find('td:eq('+expndIdx+')').addClass('details-'+level+'-control');
                    this.find('thead tr th').css('width', 'auto');
                }
                var chldObWrap = $(childTabRefId+'_wrapper');
                if((chldObWrap.find('a.previous').hasClass('disabled')) && (chldObWrap.find('a.next').hasClass('disabled'))) { chldObWrap.find('div.dataTables_paginate').hide()}
                }
            });
            $(childTabRefId + " tbody").on('click', 'td.details-' + level + '-control', function () {
                (!($(this).find('span').hasClass('hide-col'))) ? getReportInfo($(this), tab) : '';
            });
        }
        function renderTabData(id,res,lvl,expndIdx){
                var pkIdx = ((lvlPk != undefined) && (lvlPk[lvl] != undefined) && (lvlPk[lvl] != '')) ? lvlPk[lvl] : null;
                for (var i = 0, ien = res.length; i < ien; i++) {
                    for (var j = 0; j < cnt; j++) {
                        if ((pkIdx == '' || pkIdx == undefined) && (expndIdx == '' || expndIdx == undefined))
                        {
                            if (($.inArray(lvl, hidColByLvl[j])) > -1) {
                                res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";
                            }
                        } else {
                            if ((j == expndIdx) && (res[i][pkIdx])) {
                                var uniqId = id + "_" + res[i][pkIdx];
                                res[i][j] = "<span class='drilldown-control' id='" + uniqId + "'></span><span class='expndr-col'>" + res[i][j] + "</span>";
                            } else if ((($.inArray(lvl, hidColByLvl[j])) > -1) && (res[i][pkIdx])) {
                                res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";
                            }
                            else if(isGrnd == 1){
                            if((($.inArray(lvl, hidSumCol[j])) > -1) && (res[i][pkIdx] == '')){res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";}
                            else if(((!($.inArray(lvl, hidSumCol[j]))) > -1) && (res[i][pkIdx] == '')){res[i][j] = "<b>" + res[i][j] + "<b>";}
                            }   
                        }
                    }
                }
                return res;
            }
        function formatTab(chldLvl,id){
             var el = '<div class="slider' + chldLvl + ' other-scroll-container child-el-blk"><table class="grid table-hover table table-condensed res datatab-blk" id="l-' + chldLvl + '-tab-id-' + id + '" cellspacing="0" style="table-layout: fixed;background-color:' + colrCod[chldLvl] + '" width="100%"><thead>';
                for (var i = 0; i < cnt; i++) { el += '<th></th>';}
                el += '</thead><tbody level=' + chldLvl + ' >';
				 el += '</tbody></table></div>';
                return el;
        }
        function getReportInfo(_this, tabl) {
            var id = _this.find('span.drilldown-control').attr('id');
            var _thisParent = _this.closest('tbody');
            var lvl = _thisParent.attr('level');
            var url = _thisParent.attr('data-url');
            var tr = _this.closest('tr');
            var chldLvL = parseInt(lvl) + 1;
            var row = tabl.row(tr);
            if ((tr.data('child-created') == undefined) || (_this.attr('data-err') == 1)) {
                    row.child(formatTab(chldLvL,id), 'no-padding').show(); 
                    init_child_table(id, chldLvL,url,_this); 
                    tr.data('child-created', true);
                    tr.addClass('shown');
                    tr.css({'background-color': hdrColor[0], 'font-weight': 'bold'});
            } else {
                    if (!(tr.next().is(':hidden'))) {
                       tr.next().slideUp();
                       tr.removeClass('shown');
                       tr.css({'background-color': colrCod[lvl], 'font-weight': 'normal'});
                    } else {
                          tr.next().slideDown(); 
                          tr.css({'background-color': hdrColor[0], 'font-weight': 'bold'});
                          tr.addClass('shown');
                    }
            }
        }
        $.initDTabl('#l-0-tab-id-0'); 
        });
            });