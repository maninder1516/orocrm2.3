CREATE PROCEDURE `getStoredProcedureDetailsForReport` (IN report_id INT)
BEGIN
select reportbuilderstoredprocedure_id as id,stored_procedure as sp_name from izmo_report_builder_report_stored_proc_mapper irsp inner join izmo_report_builder_stored_procedures isp on irsp.reportbuilderstoredprocedure_id = isp.id where irsp.reportconfig_id = report_id;
END
