CREATE PROCEDURE `addStoredProcedureForReport`(IN stored_proc_id INT,IN report_id INT)
BEGIN
insert into izmo_report_builder_report_stored_proc_mapper values (stored_proc_id,report_id);
END