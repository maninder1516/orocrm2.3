CREATE DEFINER=`root`@`%` PROCEDURE `getYearOptionsFilter`()
BEGIN
SELECT *
FROM (
    SELECT 2018 as `key` , '2018' as val
    UNION SELECT 2019 ,'2019'
) as years_datasrc;
END