CREATE PROCEDURE `updateStoredProcedureForReport`(IN stored_proc_id INT,IN report_id INT)
BEGIN
update izmo_report_builder_report_stored_proc_mapper set reportbuilderstoredprocedure_id = stored_proc_id where reportconfig_id = report_id;
END