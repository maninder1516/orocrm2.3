
CREATE DEFINER=`root`@`%` PROCEDURE `getStoredProceduresDetails`()
BEGIN
SET @sql_query = CONCAT("
SELECT sp.id,sp.display_name from  izmo_report_builder_stored_procedures sp 
");


   	PREPARE stmt FROM @sql_query; 
    EXECUTE stmt; 
	DEALLOCATE PREPARE stmt;

END