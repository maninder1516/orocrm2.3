CREATE PROCEDURE `getReportParamMappedToStoredProcedure`(IN sp_id INT,IN report_id INT)
BEGIN
select group_concat(report_param_map) as yml_param_map from izmo_report_builder_report_stored_procedure_param_mapper where report_config_id = report_id and stored_procedure_param_id in (select id from izmo_report_builder_stored_procedure_params where stored_procedure_id = sp_id);
END