CREATE PROCEDURE `checkReportAccessByRoles`(IN role_ids VARCHAR(200),IN perm_type VARCHAR(20), IN acl_class_id_param INT,IN multi_roles_flg INT)
BEGIN

IF multi_roles_flg = 1 THEN
set @sql_qry =  CONCAT("SELECT id FROM `izmo_virtual_acl_role_info` WHERE FIND_IN_SET(role_id,'",role_ids,"') AND ",perm_type," = 1 AND acl_class_id = ",acl_class_id_param," LIMIT 1");
ELSE
set @sql_qry =  CONCAT("SELECT id FROM `izmo_virtual_acl_role_info` WHERE role_id = ",role_ids," AND ",perm_type," = 1 AND acl_class_id = ",acl_class_id_param," LIMIT 1");
END IF;
PREPARE stmt FROM @sql_qry; 
EXECUTE stmt; 
DEALLOCATE PREPARE stmt;
END