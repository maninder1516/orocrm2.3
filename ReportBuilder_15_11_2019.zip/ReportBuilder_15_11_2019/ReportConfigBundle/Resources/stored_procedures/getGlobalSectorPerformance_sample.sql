CREATE DEFINER=`root`@`%` PROCEDURE `getGlobalSectorPerformance`(IN usr_id_sel INT,IN sel_year INT,IN salesmanCode VARCHAR(200),IN salesmanName VARCHAR(200), IN usr_ids VARCHAR(1500),IN category_type varchar(1500), IN bu_ids VARCHAR(500), IN owner_bu_id INT, IN report_type INT, IN is_start INT, IN page_limit VARCHAR(30))
BEGIN
	DECLARE currentYear, previousYear INT;
    DECLARE currentStartDate, currentEndDate, previousYearStartDate, previousYearEndDate DATE;
    
    SET currentYear = YEAR(current_date());
    IF sel_year <> currentYear THEN
		SET currentStartDate = concat_ws('-', sel_year, 01, 01);
        SET currentEndDate = concat_ws('-', sel_year, 12, 31);
        SET previousYearStartDate = concat_ws('-', sel_year - 1, 01, 01);
        SET previousYearEndDate = concat_ws('-', sel_year - 1, 12, 31);
	ELSE
		SET previousYear = currentYear - 1;
		SET currentStartDate = concat_ws('-', currentYear, 01, 01);
		SET currentEndDate = subdate(current_date(), 1);
        SET previousYearStartDate = concat_ws('-', previousYear, 01, 01);
		SET previousYearEndDate = date_sub(currentEndDate, interval 1 year);
    END IF;
    
    set @@sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
    
    IF report_type = 0 THEN
		SET @sql_query = CONCAT("
			SELECT  STRAIGHT_JOIN SQL_CALC_FOUND_ROWS
			salesman_name as agentCode,
            salesman_name as salesmanName,
            '' as reportMonth,
            ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) as totalSales,");
		IF salesmanName !='none' THEN
			SET @sql_query = CONCAT(@sql_query, "
            ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (", usr_ids,") and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '", salesmanName,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0) as target,
            (((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",salesmanName,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0)) / ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",salesmanName,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0)) * 100) as targetPerformance,
			");
        ELSEIF salesmanCode != 'none' THEN
			SET @sql_query = CONCAT(@sql_query, "
            ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (", usr_ids,") and ou.multiplecodes like CONCAT('%', '", salesmanCode,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0) as target,
            (((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",salesmanName,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0)) / ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",salesmanName,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0)) * 100) as targetPerformance,
			");
        ELSE
			SET @sql_query = CONCAT(@sql_query, "
            ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.usr_sales_category_id in (", category_type,")),0) as target,
            (((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.usr_sales_category_id in (",category_type,")),0)) / ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.usr_sales_category_id in (",category_type,")),0)) * 100) as targetPerformance,
			");
        END IF;
        
        SET @sql_query = CONCAT(@sql_query, "
			IFNULL((((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', netturnover, 0)), 0), 0)) / ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', netturnover, 0)), 0), 0)) * 100), 0) as historicalPerformance, 
            ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', grossmargin, 0)), 0), 0) as grossMargin,
            IFNULL((((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', grossmargin, 0)), 0), 0) - ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', grossmargin, 0)), 0), 0)) / ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', grossmargin, 0)), 0), 0)) * 100), 0) as historicalMarginPerformance,
            IFNULL(ROUND(((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', grossmargin, 0)), 0), 0) / ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0)) * 100), 0), 0) as marginRate,
            '' as salesmanID,",report_type," as report_lvl,",is_start," as is_start
            FROM
				sales_report_mv
			WHERE 
				business_unit_id IN (", bu_ids,") AND owner_id IN (", usr_ids, ") AND 
                report_date BETWEEN '", previousYearStartDate,"' and '", currentEndDate,"' 
			");
		
        IF salesmanCode <> 'none' THEN
			SET @sql_query = CONCAT(@sql_query, "
				AND agent_code LIKE CONCAT('%', '", salesmanCode,"' , '%')
            ");
        END IF;
        
        IF salesmanName <> 'none' THEN
			SET @sql_query = CONCAT(@sql_query, "
				AND salesman_name LIKE CONCAT('%', '", salesmanName,"' , '%')
            ");
        END IF;
        
        SET @sql_query = CONCAT(@sql_query, "
			UNION ALL
        ");
        
    END IF;
    
	IF report_type = 0 THEN
		SET @sql_query = CONCAT(@sql_query,"
			( 
            SELECT  STRAIGHT_JOIN 
		");
	ELSE 
		SET @sql_query = CONCAT("
			SELECT  STRAIGHT_JOIN SQL_CALC_FOUND_ROWS
		");
	END IF;
    
    IF report_type < 1 THEN
		SET @sql_query = CONCAT(@sql_query, "
			salesman_name as agentCode,
            salesman_name as salesmanName,
            report_month as reportMonth,
            ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) as totalSales,");
		IF salesmanName !='none' THEN
			SET @sql_query = CONCAT(@sql_query, "
            ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (", usr_ids,") and istcd.month = report_month and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '", salesmanName,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0) as target,
            (((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = report_month and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",salesmanName,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0)) / ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = report_month and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",salesmanName,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0)) * 100) as targetPerformance,
			");
        ELSEIF salesmanCode != 'none' THEN
			SET @sql_query = CONCAT(@sql_query, "
            ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (", usr_ids,") and istcd.month = report_month and ou.multiplecodes like CONCAT('%', '", salesmanCode,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0) as target,
            (((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = report_month and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",salesmanName,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0)) / ROUND((select SUM(istcd.net) from izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id inner join oro_user ou on iut.salesman_id = ou.id where iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = report_month and concat_ws(' ', ou.first_name,ou.last_name) like CONCAT('%', '",salesmanName,"' , '%') and istcd.usr_sales_category_id in (",category_type,")),0)) * 100) as targetPerformance,
			");
        ELSE
			SET @sql_query = CONCAT(@sql_query, "
            ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = report_month and istcd.usr_sales_category_id in (", category_type,")),0) as target,
            (((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = report_month and istcd.usr_sales_category_id in (",category_type,")),0)) / ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id IN (",usr_ids,") and istcd.month = report_month and istcd.usr_sales_category_id in (",category_type,")),0)) * 100) as targetPerformance,
			");
        END IF;
        
        SET @sql_query = CONCAT(@sql_query, "
			IFNULL((((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', netturnover, 0)), 0), 0)) / ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', netturnover, 0)), 0), 0)) * 100), 0) as historicalPerformance, 
            ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', grossmargin, 0)), 0), 0) as grossMargin,
            IFNULL((((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', grossmargin, 0)), 0), 0) - ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', grossmargin, 0)), 0), 0)) / ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', grossmargin, 0)), 0), 0)) * 100), 0) as historicalMarginPerformance,
            IFNULL(ROUND(((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', grossmargin, 0)), 0), 0) / ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0)) * 100), 0), 0) as marginRate,
            '' as salesmanID,",report_type," as report_lvl,",is_start," as is_start
            FROM
				sales_report_mv
			WHERE 
				business_unit_id IN (", bu_ids,") AND 
                report_date BETWEEN '", previousYearStartDate,"' and '", currentEndDate,"' 
			");
		
        IF salesmanCode <> 'none' THEN
			SET @sql_query = CONCAT(@sql_query, "
				AND agent_code LIKE CONCAT('%', '", salesmanCode,"' , '%')
            ");
        END IF;
        
        IF salesmanName <> 'none' THEN
			SET @sql_query = CONCAT(@sql_query, "
				AND salesman_name LIKE CONCAT('%', '", salesmanName,"' , '%')
            ");
        END IF;

		IF report_type > 0 THEN
			SET @sql_query = CONCAT(@sql_query, "
				AND owner_id = ",usr_id_sel,"
			");
		ELSE
			SET @sql_query = CONCAT(@sql_query, "
				AND owner_id IN (", usr_ids, ") 
			");
		END IF ;
        
        SET @sql_query = CONCAT(@sql_query, "
			GROUP BY report_month
        ");
    
		IF report_type = 0 THEN
			SET @sql_query = CONCAT(@sql_query, "
			) 
            ");
		END IF;
    
		SET @sql_query = CONCAT(@sql_query, " 
			UNION ALL 
			( 
            SELECT  STRAIGHT_JOIN 
		");
    END IF;
    
	SET @sql_query = CONCAT(@sql_query, "
		salesman_name as agentCode,
		salesman_name as salesmanName,
	");
    
    IF report_type = 0 THEN
		SET @sql_query = CONCAT(@sql_query, "
			'' as reportMonth,
		");
    ELSE
		SET @sql_query = CONCAT(@sql_query, "
			report_month as reportMonth,
		");
    END IF;
    
	SET @sql_query = CONCAT(@sql_query, "
		ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) as totalSales,");
	
    IF report_type = 0 THEN
			SET @sql_query = CONCAT(@sql_query, "
			IFNULL(ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = owner_id and istcd.usr_sales_category_id in (", category_type,")),0),0) as target,
			IFNULL((((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = owner_id and istcd.usr_sales_category_id in (",category_type,")),0)) / ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = owner_id and istcd.usr_sales_category_id in (",category_type,")),0)) * 100), 0) as targetPerformance,
			");
	ELSEIF report_type = 1 THEN
			SET @sql_query = CONCAT(@sql_query, "
            IFNULL(ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = ", usr_id_sel," and istcd.month = report_month and istcd.usr_sales_category_id in (", category_type,")),0),0) as target,
            IFNULL((((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = ", usr_id_sel," and istcd.month = report_month and istcd.usr_sales_category_id in (",category_type,")),0)) / ROUND((select SUM(istcd.net) from  izmo_user_sales_target_category_detail istcd inner join izmo_user_target iut on iut.id = istcd.target_id  where  iut.year = ",sel_year," and iut.salesman_id = ", usr_id_sel," and istcd.month = report_month and istcd.usr_sales_category_id in (",category_type,")),0)) * 100),0) as targetPerformance,
			");
	END IF;
	
	SET @sql_query = CONCAT(@sql_query, "
		IFNULL((((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0) - ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', netturnover, 0)), 0), 0)) / ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', netturnover, 0)), 0), 0)) * 100), 0) as historicalPerformance, 
		ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', grossmargin, 0)), 0), 0) as grossMargin,
		IFNULL((((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', grossmargin, 0)), 0), 0) - ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', grossmargin, 0)), 0), 0)) / ROUND(IFNULL(SUM(IF(report_date between '", previousYearStartDate, "' and '", previousYearEndDate, "', grossmargin, 0)), 0), 0)) * 100), 0) as historicalMarginPerformance,
		IFNULL(ROUND(((ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', grossmargin, 0)), 0), 0) / ROUND(IFNULL(SUM(IF(report_date between '", currentStartDate, "' and '", currentEndDate, "', netturnover, 0)), 0), 0)) * 100), 0), 0) as marginRate,
		owner_id as salesmanID,",report_type," as report_lvl,",is_start," as is_start
		FROM
			sales_report_mv
		WHERE 
			business_unit_id IN (", bu_ids,") AND 
			report_date BETWEEN '", previousYearStartDate,"' and '", currentEndDate,"' 
		");
	
	IF salesmanCode <> 'none' THEN
		SET @sql_query = CONCAT(@sql_query, "
			AND agent_code LIKE CONCAT('%', '", salesmanCode,"' , '%')
		");
	END IF;
	
	IF salesmanName <> 'none' THEN
		SET @sql_query = CONCAT(@sql_query, "
			AND salesman_name LIKE CONCAT('%', '", salesmanName,"' , '%')
		");
	END IF;

	IF report_type > 0 THEN
		SET @sql_query = CONCAT(@sql_query, "
			AND owner_id = ",usr_id_sel," 
		GROUP BY owner_id, report_month
		");
	ELSE
		SET @sql_query = CONCAT(@sql_query, "
			AND owner_id IN (",usr_ids,")
			GROUP BY owner_id
            )
		");
	END IF ;
    
	IF page_limit != '' THEN
		SET @sql_query = CONCAT(@sql_query, ' ', page_limit);
    END IF;
    
    /*SELECT @sql_query;*/
    
  	PREPARE stmt FROM @sql_query; 
    EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
END