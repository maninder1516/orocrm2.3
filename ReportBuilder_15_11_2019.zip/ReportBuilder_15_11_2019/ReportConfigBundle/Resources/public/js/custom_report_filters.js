 require(['jquery', 'jquery-ui', 'orolocale/js/formatter/datetime', 'oroui/js/messenger'], function ($, jui, dateFormatter, Messenger)
            {
                $(document).ready(function () {
                    var default_properties = {};
                    var defaultDateProperties = document.getElementsByClassName("dt-datatab-info")[0].getAttribute('date-default-properties');
                    if(defaultDateProperties != ''){
                      default_properties = JSON.parse(defaultDateProperties);
                    }
                    function prepareDatesByPropRules(prop, field) {  // for default value sett for from & to var
                        if (prop.type == 'dynamic') {
                            if (prop.expression) {
                                return prop.expression;
                            } else if (prop.ref_date) {
                                var refCol = prop.ref_date;
                                var refColName = field + '_' + refCol;
                                var refEl = document.getElementsByClassName(refColName)[0];
                                if ($(refEl).val() != '') {
                                    return prepareDate(prop.condition, getDate($(refEl).val()), prop.offset, prop.operation);
                                } else {
                                    return null;
                                }
                            }
                        } else if (prop.type == 'fixed') {
                            if (prop.val == 'cur_date')
                            {
                                return new Date();
                            } else {
                                return new Date(prop.val); // setting value depends on min and max conditions.
                            }
                        }
                    }
                    
                    function prepareMaxMinDate(prop,fieldName,conditiontype,obj){
                     var datVal = prepareDatesByPropRules(prop, fieldName);
                            if(datVal){
			   obj.datepicker("option", conditiontype, datVal);
                            }
                }

                    function prepareDate(type, dateParam, x, symbl) {
                        if (symbl == '+') {
                            switch (type) {
                                case "m":
                                {
                                    dateParam.setMonth(dateParam.getMonth() + x);
                                    console.log("Date after " + x + " months:", dateParam);
                                    return dateParam;
                                    break;
                                }
                                case "y":
                                {
                                    console.log("current Year is:");
                                    console.log(dateParam);
                                    dateParam.setFullYear(dateParam.getFullYear() + x);
                                    console.log("Date after " + x + " yr:", dateParam);
                                    return dateParam;
                                    break;
                                }
                                case "d":
                                {
                                    dateParam.setDate(dateParam.getDate() + x);
                                    console.log("Date after " + x + " days :", dateParam);
                                    return dateParam;
                                    break;
                                }
                            }
                        } else if (symbl == '-') {
                            switch (type) {
                                case "m":
                                {
                                    dateParam.setMonth(dateParam.getMonth() - x);
                                    console.log("Date BEFORE " + x + " months:", dateParam);
                                    return dateParam;
                                    break;
                                }
                                case "y":
                                {
                                    console.log("current Year is:");
                                    console.log(dateParam);
                                    dateParam.setFullYear(dateParam.getFullYear() - x);
                                    console.log("Date BEFORE " + x + " yr:", dateParam);
                                    return dateParam;
                                    break;
                                }
                                case "d":
                                {
                                    dateParam.setDate(dateParam.getDate() - x);
                                    console.log("Date BEFORE " + x + " days :", dateParam);
                                    return dateParam;
                                    break;
                                }
                            }
                        }
                    }
                    var calendarEl = document.getElementsByClassName('calendar-col');
                    for (var i = 0; i < calendarEl.length; i++) {
                        var propAttr = null;
                        var calEl = calendarEl[i];
                        if (calendarEl[i].getAttribute('date_properties')) {
                            var dateProp = calendarEl[i].getAttribute('date_properties');
                            if (dateProp && (dateProp != 'null')) {
                                var propAttr = JSON.parse(dateProp); // prop details
                            }
                        }
                        $(calendarEl[i]).datepicker(default_properties);
                        if (propAttr != null) {
                            if ((propAttr.default) && (propAttr.default != 'null')) {
                                $(calendarEl[i]).datepicker('setDate', prepareDatesByPropRules(propAttr.default, calRangeFieldName))
                            }
                            if ((propAttr.maxDate) && (propAttr.maxDate != 'null')) {
                             prepareMaxMinDate(propAttr.maxDate,calRangeFieldName,'maxDate',$(calendarEl[i]));
                            }
                            if ((propAttr.minDate) && (propAttr.minDate != 'null')) {
                                 prepareMaxMinDate(propAttr.minDate,calRangeFieldName,'minDate',$(calendarEl[i]));
                            }
                        }
                    }
                    
                    // date range
                    var calendarRangeEl = document.getElementsByClassName('calendar-range-col');
                    for (var i = 0; i < calendarRangeEl.length; i++) {
                        var calRangeFieldName = calendarRangeEl[i].getAttribute('name');
                        var calendarRangeElFrmClass = calRangeFieldName + '_from';
                        var calendarRangeElToClass = calRangeFieldName + '_to';
                        var calendarRangeElFrm = document.getElementsByClassName(calendarRangeElFrmClass)[0];
                        var calendarRangeElTo = document.getElementsByClassName(calendarRangeElToClass)[0];
                        var calRangeFrmElObj = $(calendarRangeElFrm);
                        var calRangeToElObj = $(calendarRangeElTo);
                        var calRangeObj = $(calendarRangeEl[i]);
                        var prop = calendarRangeEl[i].getAttribute('date_properties');
                        var frmProp, toProp = null;
                        if (prop && prop != 'null') {
                            var propAttr = JSON.parse(prop);
                            if (typeof (propAttr.from) != 'undefined') {
                                frmProp = propAttr.from;
                            }
                            if (typeof (propAttr.to) != 'undefined') {
                                toProp = propAttr.to;
                            }

                            if (calRangeObj.hasClass(calendarRangeElFrmClass)) {
                                if (frmProp && (typeof (frmProp.default) != 'undefined')) {
                                    var frmDefaultVal = prepareDatesByPropRules(frmProp.default, calRangeFieldName);
                                }
                                calRangeFrmElObj.datepicker(default_properties);
                                calRangeFrmElObj.datepicker("option", "onSelect", function (selectedDate) {
                                    calRangeToElObj.datepicker("option", "minDate", selectedDate); // setting min date of To with from date
                                    if (toProp && ((typeof (toProp.maxDate)) != 'undefined')) {
                                        prepareMaxMinDate(toProp.maxDate,calRangeFieldName,'maxDate',calRangeToElObj);
                                    }
                                    if(frmProp && (typeof(frmProp.minDate) != 'undefined')){
                                        prepareMaxMinDate(frmProp.minDate,calRangeFieldName,'minDate',calRangeFrmElObj);
                                    }
                                });

                                if (frmDefaultVal) {
                                    calRangeToElObj.datepicker(default_properties);
                                    calRangeFrmElObj.datepicker('setDate', frmDefaultVal);
                                    if(frmProp && (typeof (frmProp.minDate) != 'undefined')){
                                        prepareMaxMinDate(frmProp.minDate,calRangeFieldName,'minDate',calRangeFrmElObj);
                                    }
                                    calRangeToElObj.datepicker("option", "minDate", calRangeFrmElObj.datepicker('getDate'));
                                    if ((toProp) && (typeof (toProp.maxDate) != 'undefined')) {
                                       prepareMaxMinDate(toProp.maxDate,calRangeFieldName,'maxDate',calRangeToElObj);
                                    }
                                }
                                // if default is 1 month span
                            } else if (calRangeObj.hasClass(calendarRangeElToClass)) {
                                if (toProp) {
                                    var toDefaultVal = null;
                                    if (typeof (toProp.default) != 'undefined') {
                                        toDefaultVal = prepareDatesByPropRules(toProp.default, calRangeFieldName);
                                    } else {
                                        calRangeToElObj.datepicker(default_properties);
                                    }
                                    if (typeof (toProp.maxDate) != 'undefined') {
                                         prepareMaxMinDate(toProp.maxDate,calRangeFieldName,'maxDate',calRangeToElObj);
                                    }
                                }
                                calRangeToElObj.datepicker("option", "onSelect", function (selectedDate) {
                                    if ((frmProp) && (typeof (frmProp.minDate) != 'undefined')) {
                                        prepareMaxMinDate(frmProp.minDate,calRangeFieldName,'minDate',calRangeFrmElObj);
                                    }
                                    calRangeFrmElObj.datepicker("option", "maxDate", selectedDate);  // setting MAX of from-date with To-date
                                });

                                if (toDefaultVal) {
                                    calRangeToElObj.datepicker('setDate', toDefaultVal);
                                }
                            }
                        } else {
                            calRangeObj.datepicker();
                        }
                    }

                    function getDate(date) {
                        var date;
                        try {
                            date = $.datepicker.parseDate('yy-mm-dd', dateFormatter.convertDateToBackendFormat(date));
                        } catch (error) {
                            date = null;
                        }
                        return date;
                    }

                    function validateRequiredFields(formName) {
                        var elements = document.forms[formName].elements;
                        var err = 0;
                        for (i in elements) {
                            var el = elements[i];
                            if (typeof (el) == 'object') {
                                var fieldType = el.getAttribute('data-fieldType');
                                            if (el.getAttribute('required') == true) {

                                                switch (fieldType) {
                                                    case "select":
                                                    {
                                                        if (el.options[el.selectedIndex].value == '') {
                                                            $(el).parent().addClass('required-flg');
                                                            err = 1;
                                                        } else {
                                                            $(el).parent().removeClass('required-flg');
                                                        }
                                                        break;
                                                    }
                                                    case "text":
                                                    {
                                                        if (el.value == '') {
                                                            $(el).addClass('required-flg');
                                                            err = 1;

                                                        } else {
                                                            $(el).removeClass('required-flg');
                                                        }
                                                        break;
                                                    }
                                                    case "date-range":
                                                    {
                                                        if (!(validateCalendarRangeFilters(el, 1))) {
                                                            err = 1;
                                                        }
                                                        break;
                                                    }
                                                    default:
                                                    {
                                                        if (el.value == '') {
                                                            $(el).addClass('required-flg');
                                                            err = 1;

                                                        } else {
                                                            $(el).removeClass('required-flg');
                                                        }
                                                        break;
                                                    }
                                                }
                                            } else {
                                                if (fieldType == 'date-range') {
                                                    if (!(validateCalendarRangeFilters(el, 0))) {  // for comparision of to & from dates.
                                                        err = 1;
                                                    }
                                                    break;
                                                }

                                            }


                                        }
                                    }
                                    if (err == 1) {
                                        $('.filters-err-msg').show();
                                        return false;
                                    } else {
                                        $('.filters-err-msg').hide();
                                        return true;
                                    }
                                }
                    
                   function validateCalendarRangeFilters(el,isRequired){
                        var dateRangeField = el.getAttribute('name');
                        var dateRangeFromFieldClass = dateRangeField+'_from';
                                            var dateRangeToFieldClass = dateRangeField+'_to';
                                            if(($('.'+dateRangeFromFieldClass).val() != '') && ($('.' + dateRangeToFieldClass).val() == '')) {
                                       $('.' + dateRangeToFieldClass).addClass('required-flg');
                                       $('.' + dateRangeFromFieldClass).removeClass('required-flg');
                                       return false;
                                   } else if (($('.' + dateRangeToFieldClass).val() != '') && ($('.' + dateRangeFromFieldClass).val() == '')) {
                                       $('.' + dateRangeFromFieldClass).addClass('required-flg');
                                       $('.' + dateRangeToFieldClass).removeClass('required-flg');
                                       return false;
                                   } else if ((isRequired) && ($('.' + dateRangeFromFieldClass).val() == '') && ($('.' + dateRangeToFieldClass).val() == '')) {
                                        $('.' + dateRangeFromFieldClass).addClass('required-flg');
                                       $('.' + dateRangeToFieldClass).addClass('required-flg');
                                       return false;
                                   } else {
                                       $('.' + dateRangeFromFieldClass).removeClass('required-flg');
                                       $('.' + dateRangeToFieldClass).removeClass('required-flg');
                                       return true;
                                   }

                               }
                    
                   var formName = document.getElementsByClassName("dt-datatab-info")[0].getAttribute('form-name');
                  // $("form[name='"+formName+"']").submit(function(e){
                  //document.forms[formName].onsubmit = function(e){
                  $('.filtr-srch-btn').click(function (e) {
                        if(!(validateRequiredFields(formName))){
                            return false;
                        }
                        else{
                            return true;
                        }
                        
                    });
                   
                 
                    //
                });
            });