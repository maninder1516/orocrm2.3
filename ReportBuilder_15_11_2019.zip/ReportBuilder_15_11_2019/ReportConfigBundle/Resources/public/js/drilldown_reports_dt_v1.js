require(['jquery', 'izmodatatables/js/datatables.min', 'orotranslation/js/translator', 'orolocale/js/formatter/datetime'], function ($, cd, trans, dateFormatter) {
    $(document).ready(function () {
        console.log("IN Report Config - Drilldown");
        var colrCod = ['#FFFFFF', '#FBF8EC', '#EBEBE0', '#ECF4E1', '#F9EBD4'];
        var hdrColor = ['#F2F2F2'];
        var tabInfoOb = $('.dt-datatab-info');
        var url = tabInfoOb.attr('report-id');
        var tabBdy = $(tabInfoOb.attr('tbdyref'));
        var theadRef = tabInfoOb.attr('theadref');
        var theadOb = $(tabInfoOb.attr('theadref'));
        var loadr = $('#loading');
        var errBlk = $('.err_msg');
        var isSubGrnd = 0, isGrnd = 0, cnt = 0;
        isSubGrnd = tabInfoOb.attr('is-sub-grand-tot');
        isGrnd = tabInfoOb.attr('is-grand-tot');
        var colProp = [], hidColByLvl = [], hidSumCol = [], hidGrandCol = [];
        $(theadRef + ' th', this).each(function (i) {
            colProp[i] = $(this).attr('class');
            if ($(this).attr('hid_lvl') != '')
            {
                try
                {
                    hidColByLvl[i] = JSON.parse($(this).attr('hid_lvl'));

                } catch (e) {
                    console.log("error in hid_lvl parse");
                }
            }
            if (isSubGrnd == 1)
            {
                if ($(this).attr('hid_sum_lvl') != '') {
                    try
                    {
                        hidSumCol[i] = JSON.parse($(this).attr('hid_sum_lvl'));
                    } catch (e) {
                        console.log("error in hid_lvl parse");
                    }
                }
            }
            cnt++;
        });
        if (theadOb.attr('pk_lvl') != '')
        {
            try
            {
                var lvlPk = JSON.parse(theadOb.attr('pk_lvl'));
            } catch (e) {
                console.log("error in pk_lvl parse");
            }
        }
        if (theadOb.attr('expndr_col') != '')
        {
            try
            {
                var lvlExpndr = JSON.parse(theadOb.attr('expndr_col'));
            } catch (e) {
                console.log("error in expndr_col parse");
            }
        }
        if (isGrnd == 1) {
            if (theadOb.attr('hid_col_grand_sum') != '') {
                try {
                    var hidGrandCol = JSON.parse(theadOb.attr('hid_col_grand_sum'));
                } catch (e) {
                    console.log("err in hid_col_grand_sum parse");
                }
            }
        }
        var rowsToDisplay = (($('#no_of_rows').val() == undefined) || ($('#no_of_rows').val() == '')) ? 50 : parseInt($('#no_of_rows').val());
        var level = 0;
        var expndIdx = ((lvlExpndr != undefined) && (lvlExpndr[level] != undefined)) ? lvlExpndr[level] : null;
        function baseErr(tabEl) {
            errBlk.show();
            $('.scrollable-container').animate({scrollTop: $(".err_msg_blk")}, 'slow');
            loadr.hide();
            $(tabEl + '_wrapper').hide();
        }
        function childEr(curTd, tabRf) {
            errBlk.show();
            $('.scrollable-container').animate({scrollTop: $(".err_msg_blk")}, 'slow');
            curTd.attr('data-err', 1);
            $(tabRf + '_wrapper').hide();
        }
        function initDT(tabEl) {
            $(".multilvl-div-blk").hide();
            loadr.show();
            var table = $(tabEl).DataTable({
                "preDrawCallback": function () {
                    loadr.show();
                },
                "language": {
                    "paginate": {
                        "previous": trans('prev.label'),
                        "next": trans('next.label')
                    },
                    "zeroRecords": trans('datatables.data.no_record_found.label')
                },
                "serverSide": true,
                "searching": false,
                "ordering": false,
                "pagingType": "simple",
                "deferRender": true,
                "pageLength": rowsToDisplay,
                "bDestroy": true,
                "ajax": {
                    "url": encodeURI(url),
                    "type": "POST",
                    "data": {'level': level, 'filters': $('#filter-info').val()},
                    dataSrc: function (json) {
                        if (json.err == 1) {
                            baseErr(tabEl);
                            return false;
                        } else if (json.no_data) {
                            return false;
                        } else {
                            if (json.url != '') {
                                $(tabEl).find('tbody').attr('data-url', json.url);
                            }
                            if (json.report_title != undefined && json.report_title.title != undefined) {
                                console.log(json.report_title.title);
                                $(".report_title_hdr").html(json.report_title.title);
                            }
                            (!(errBlk.is(':hidden'))) ? errBlk.hide() : '';
                            return dispInitialTablData(json.data, level, expndIdx, lvlPk, hidColByLvl, hidSumCol);
                        }
                    },
                    complete: function () {
                        loadr.hide();
                        $('span.hide-col').parent().css('cursor', 'default');
                    },
                    error: function (e) {
                        console.log("error occured");
                        console.log(e);
                        baseErr(tabEl);
                        return false;
                    }
                },
                "fnDrawCallback": function (oSettings) {
                    if (oSettings.aoData.length > 0) {
                        $(".multilvl-div-blk").show();
                        tabBdy.find('tr').each(function () {
                            $('td', this).each(function (i) {
                                $(this).addClass(colProp[i]);
                            });
                        });
                        $('tbody.dt-res tr').find('td:eq(' + expndIdx + ')').addClass('details-control');
                        if (isGrnd == 1)
                        {
                            if (oSettings._iDisplayStart == 0) {
                                var tbdyTr0 = $('tbody.dt-res tr:eq(0)');
                                tbdyTr0.find('td:eq(0)').html('<b>' + trans('datatables.data.report.grand_total.label') + '<span class="hide-col"></span></b>');
                                tbdyTr0.find('td:eq(0)').css('cursor', 'default');
                                for (var i = 0; i < hidGrandCol.length; i++) {
                                    tbdyTr0.find('td:eq(' + hidGrandCol[i] + ')').children().addClass('hide-col');
                                }
                            }
                        }

                    } else {
                        $(".multilvl-div-blk").hide();
                        if (errBlk.is(':hidden')) {
                            $('.report_no_rec').show();
                        }
                    }
                    var tabObjWrap = $(tabEl + '_wrapper');
                    if ((tabObjWrap.find('a.previous').hasClass('disabled')) && (tabObjWrap.find('a.next').hasClass('disabled'))) {
                        tabObjWrap.find('div.dataTables_paginate').hide()
                    }
                    this.find('thead tr th').css('width', 'auto');
                }
            });

            $(tabEl + ' tbody').on('click', 'td.details-control', function () {
                (!($(this).find('span').hasClass('hide-col'))) ? getReportInfo($(this), table) : '';
            });
        }
        function dispInitialTablData(res, lvl, expndIdx, lvlPk, hidColByLvl, hidSumCol) {
            var pkIdx = ((lvlPk != undefined) && (lvlPk[lvl] != undefined) && (lvlPk[lvl] != '')) ? lvlPk[lvl] : null;
            for (var i = 0, ien = res.length; i < ien; i++) {
                for (var j = 0; j < cnt; j++) {
                    if ((pkIdx == '' || pkIdx == undefined) && (expndIdx == '' || expndIdx == undefined))
                    {
                        if (($.inArray(lvl, hidColByLvl[j])) > -1) {
                            res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";
                        }
                    } else {
                        if ((j == expndIdx) && (res[i][pkIdx])) {
                            res[i][j] = "<span class='drilldown-control' id='" + res[i][pkIdx] + "'></span><span class='expndr-col'>" + res[i][j] + "</span>";
                        } else if ((($.inArray(lvl, hidColByLvl[j])) > -1) && (res[i][pkIdx])) {
                            res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";
                        } else if (isGrnd == 1) {
                            if ((($.inArray(lvl, hidSumCol[j])) > -1) && (res[i][pkIdx] == '')) {
                                res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";
                            } else if (((!($.inArray(lvl, hidSumCol[j]))) > -1) && (res[i][pkIdx] == '')) {
                                res[i][j] = "<b>" + res[i][j] + "<b>";
                            }
                        }
                    }
                }
            }
            return res;
        }
        $.initDTabl = function (tablElem) {
            var formName = document.getElementsByClassName("dt-datatab-info")[0].getAttribute('form-name');
            initFormProperties(formName, tablElem);
        }
        function initFormProperties(formName, tablElem) {

            document.forms[formName].onsubmit = function (e) {
                e.preventDefault();
                e.stopPropagation();
                $(tablElem + ' tbody').off('click');
                initFilters(formName);
                initDT(tablElem);
                return false;
            }

        }

        function initFilters(formName) {  // JS way
            var filterArr = {};
//           
            var elements = document.forms[formName].elements;
            for (i in elements) {
                var el = elements[i];
                if (typeof (el) == 'object') {
                    var fieldType = el.getAttribute('data-fieldType');
                    var fieldName = el.getAttribute('name');
                    var fieldVal = el.value;

                    switch (fieldType) {
                        case "select":
                        {
                            filterArr[fieldName] = el.options[el.selectedIndex].value;
                            break;
                        }
                        case "text":
                        {
                            filterArr[fieldName] = fieldVal;
                            break;
                        }
                        case "calendar":
                        {
                            if (fieldVal != '') {
                                filterArr[fieldName] = dateFormatter.convertDateToBackendFormat(fieldVal);
                            } else {
                                filterArr[fieldName] = '';
                            }
                            break;
                        }
                        case "date-range":
                        {
                            if (filterArr[fieldName] != undefined) {
                                var nxtIndx = filterArr[fieldName].length;
                                filterArr[fieldName][nxtIndx] = (fieldVal != '') ? dateFormatter.convertDateToBackendFormat(fieldVal) : '';
                            } else {
                                filterArr[fieldName] = [];
                                filterArr[fieldName][0] = (fieldVal != '') ? dateFormatter.convertDateToBackendFormat(fieldVal) : '';

                            }
                        }
                    }
                }

            }
            document.getElementById("filter-info").value = JSON.stringify(filterArr);
        }

        function init_child_table(id, level, url, _thisTd) {
            console.log("inside child table");
            var childTabRefId = "#l-" + level + "-tab-id-" + id;
            var filtersUsed = $('#filter-info').val();
            rowsToDisplay = (($('#no_of_rows').val() == undefined) || ($('#no_of_rows').val() == '')) ? 50 : parseInt($('#no_of_rows').val());
            var expndIdx = ((lvlExpndr != undefined) && (lvlExpndr[level] != undefined)) ? lvlExpndr[level] : null;
            var tab = $(childTabRefId).DataTable({
                "preDrawCallback": function () {
                    loadr.show();
                },
                "language": {
                    "paginate": {
                        "previous": trans('prev.label'),
                        "next": trans('next.label')
                    },
                    "zeroRecords": trans('datatables.data.no_record_found.label')
                },
                "serverSide": true,
                "searching": false,
                "ordering": false,
                "pagingType": "simple",
                "pageLength": rowsToDisplay,
                "deferRender": true,
                "ajax": {
                    "url": encodeURI(url + '/' + level),
                    "type": "POST",
                    "data": {'id': id, 'level': level, 'filters': filtersUsed},
                    dataSrc: function (json)
                    {   //debugger;
                        _thisTd.attr('data-err', 0);
                        if (json.err == 1) {
                            childEr(_thisTd, childTabRefId);
                            return false;
                        } else if (json.no_data) {
                            return false;
                        } else {
                            if (json.url != '') {
                                $(childTabRefId).find('tbody').attr('data-url', json.url);
                            }
                            (!(errBlk.is(':hidden'))) ? errBlk.hide() : '';
                            return renderTabData(id, json.data, level, expndIdx);
                            //return true;
                        }
                    },
                    complete: function () {
                        loadr.hide();
                        $('span.hide-col').parent().css('cursor', 'default');
                    },
                    error: function (e) {
                        console.log("error occured");
                        console.log(e);
                        childEr(_thisTd, childTabRefId);
                        return false;
                    }
                },
                "fnDrawCallback": function (oSettings) {
                    $("span.expndr-col").parent().css({"cursor": "pointer"});
                    if (oSettings.aoData.length > 0) {
                        var childOb = $(childTabRefId);
                        childOb.find('tbody').find('tr').each(function () {
                            $('td', this).each(function (i) {
                                $(this).addClass(colProp[i]);
                            });
                        });
                        $(childOb).find('tbody tr').find('td:eq(' + expndIdx + ')').addClass('details-' + level + '-control');
                        this.find('thead tr th').css('width', 'auto');
                    }
                    var chldObWrap = $(childTabRefId + '_wrapper');
                    if ((chldObWrap.find('a.previous').hasClass('disabled')) && (chldObWrap.find('a.next').hasClass('disabled'))) {
                        chldObWrap.find('div.dataTables_paginate').hide()
                    }
                }
            });
            //debugger;
            $(childTabRefId + " tbody").on('click', 'td.details-' + level + '-control', function () {
                (!($(this).find('span').hasClass('hide-col'))) ? getReportInfo($(this), tab) : '';
            });
            //tabOb.push(tab);
        }
        function renderTabData(id, res, lvl, expndIdx) {
            //building table data
            var pkIdx = ((lvlPk != undefined) && (lvlPk[lvl] != undefined) && (lvlPk[lvl] != '')) ? lvlPk[lvl] : null;
            for (var i = 0, ien = res.length; i < ien; i++) {
                for (var j = 0; j < cnt; j++) {
                    if ((pkIdx == '' || pkIdx == undefined) && (expndIdx == '' || expndIdx == undefined))
                    {
                        if (($.inArray(lvl, hidColByLvl[j])) > -1) {
                            res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";
                        }
                    } else {
                        if ((j == expndIdx) && (res[i][pkIdx])) {
                            var uniqId = id + "_" + res[i][pkIdx];
                            res[i][j] = "<span class='drilldown-control' id='" + uniqId + "'></span><span class='expndr-col'>" + res[i][j] + "</span>";
                        } else if ((($.inArray(lvl, hidColByLvl[j])) > -1) && (res[i][pkIdx])) {
                            res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";
                        } else if (isGrnd == 1) {
                            if ((($.inArray(lvl, hidSumCol[j])) > -1) && (res[i][pkIdx] == '')) {
                                res[i][j] = "<span class='hide-col'>" + res[i][j] + "</span>";
                            } else if (((!($.inArray(lvl, hidSumCol[j]))) > -1) && (res[i][pkIdx] == '')) {
                                res[i][j] = "<b>" + res[i][j] + "<b>";
                            }
                        }
                    }
                }
            }
            return res;
        }
        function formatTab(chldLvl, id) {
            //creating child table elements
            var el = '<div class="slider' + chldLvl + ' other-scroll-container child-el-blk"><table class="grid table-hover table table-condensed res datatab-blk" id="l-' + chldLvl + '-tab-id-' + id + '" cellspacing="0" style="table-layout: fixed;background-color:' + colrCod[chldLvl] + '" width="100%"><thead>';
            for (var i = 0; i < cnt; i++) {
                el += '<th></th>';
            }
            el += '</thead><tbody level=' + chldLvl + ' >';
            el += '</tbody></table></div>';
            return el;
        }
        function getReportInfo(_this, tabl) {
            var id = _this.find('span.drilldown-control').attr('id');
            var _thisParent = _this.closest('tbody');
            var lvl = _thisParent.attr('level');
            var url = _thisParent.attr('data-url');
            var tr = _this.closest('tr');
            var chldLvL = parseInt(lvl) + 1;
            var row = tabl.row(tr);
            if ((tr.data('child-created') == undefined) || (_this.attr('data-err') == 1)) {
                row.child(formatTab(chldLvL, id), 'no-padding').show();
                init_child_table(id, chldLvL, url, _this);

                tr.data('child-created', true);
                tr.addClass('shown');
                tr.css({'background-color': hdrColor[0], 'font-weight': 'bold'});
                //trElem.push(tr);
            } else {
                if (!(tr.next().is(':hidden'))) {
                    tr.next().slideUp();
                    tr.removeClass('shown');
                    tr.css({'background-color': colrCod[lvl], 'font-weight': 'normal'});
                } else {
                    tr.next().slideDown();
                    tr.css({'background-color': hdrColor[0], 'font-weight': 'bold'});
                    tr.addClass('shown');
                }
            }
        }
        $.initDTabl('#l-0-tab-id-0');
    });
});