<?php

namespace IZMO\ReportConfigBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use IZMO\ReportConfigBundle\Entity\ReportTemplate;
use IZMO\ReportConfigBundle\Utils\ReportConfigConstants;

/**
 * @Route("/report-template")
 */
class ReportTemplateController extends Controller {

    /**
     *  Get Report Template Repository
     */
    public function getReportTemplateRepository() {
        return $this->getDoctrine()->getRepository('IZMOReportConfigBundle:ReportTemplate');
    }

    /**
     * @Route("/index", name="report_template_index")
     * @Template("IZMOReportConfigBundle:ReportTemplate:index.html.twig")
     */
    public function indexAction() {
        return $this->render('IZMOReportConfigBundle:ReportTemplate:index.html.twig', array('gridName' => 'report-template-grid'));
    }

    /**
     * @Route("/create", name="report_template_create")   
     * @Template("IZMOReportConfigBundle:ReportTemplate:update.html.twig")  
     */
    public function createAction(Request $request) {
        return $this->update(new ReportTemplate(), $request);
    }

    /**
     * @Route("/update/{id}", name="report_template_update", requirements={"id":"\d+"}, defaults={"id":0})
     * @Template("IZMOReportConfigBundle:ReportTemplate:update.html.twig") 
     */
    public function updateAction(ReportTemplate $reportTemplate, Request $request) {
        return $this->update($reportTemplate, $request);
    }

    /**
     * @Route("/template/{id}", name="report_template_view", requirements={"id"="\d+"})
     * @Template("IZMOReportConfigBundle:ReportTemplate:view.html.twig")
     * @Acl(
     *     id="report_template_view_1",
     *     type="entity",
     *     class="IZMOReportConfigBundle:ReportTemplate",
     *     permission="VIEW"
     * )     
     */
    public function viewAction(ReportTemplate $reportTemplate) {
        return $this->render('IZMOReportConfigBundle:ReportTemplate:view.html.twig', array('entity' => $reportTemplate, 'reporttemplate' => $reportTemplate));
    }

    /**
     * @param ReportTemplate $reportTemplate
     * @param Request  $request
     *
     * @return array
     */
    private function update(ReportTemplate $reportTemplate, Request $request) {
        $reportTemplatePath = ReportConfigConstants::TEMPLATE_PATH;
        $form = $this->get('form.factory')->create('report_template_form', $reportTemplate);

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {            
            $templateName = $form["templatePath"]->getData();

             if ($reportTemplate->getId()) {
                $reportTemplate->setTemplatePath($templateName);
            } else {
                $reportTemplate->setTemplatePath($reportTemplatePath . $templateName);
            }

            $this->getReportTemplateRepository()->processReportTemplate($reportTemplate);
            return $this->get('oro_ui.router')->redirectAfterSave(
                            array(
                        'route' => 'report_template_update',
                        'parameters' => array('id' => $reportTemplate->getId()),
                            ), array(
                        'route' => 'report_template_view',
                        'parameters' => array('id' => $reportTemplate->getId()))
            );
        }
        return array(
            'entity' => $reportTemplate,
            'form' => $form->createView(),
        );
    }

}
