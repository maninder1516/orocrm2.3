<?php

namespace IZMO\ReportConfigBundle\Controller;

use Oro\Bundle\SecurityBundle\Annotation\Acl;
use Oro\Bundle\SecurityBundle\Annotation\AclAncestor;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query;
use Doctrine\ORM\EntityRepository;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use IZMO\ReportConfigBundle\Provider\YmlReportConfigProcess;
use IZMO\ReportConfigBundle\Utils\ReportConfigConstants;
use IZMO\ReportConfigBundle\Entity\ReportConfig;
use IZMO\ReportConfigBundle\Entity\ReportYmlConfig;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use IZMO\ReportConfigBundle\Entity\ReportTemplate;
use Oro\Bundle\NavigationBundle\Event\MenuUpdateChangeEvent;

/**
 * @Route("/report")
 */
class ReportConfigController extends Controller {

    const EXCEL_EXPORT_TO = 'file'; // Options are:  'browser', 'file', 'string'    
    const EXCEL_FILE_TYPE = 'application/vnd.ms-excel';
    const EXCEL_FILE_EXTENSION = 'xls'; // Options are : 'xls', 'xlsx'
    const REPORT_VIEW_PERMISSION = 'view_perm';
    const NAV_MENU_TYPE = 'application_menu';
    const PARENT_NAV_MENU = 'other_reports';

    /**
     * Get the Translation
     * @param string $name
     * @return string
     */
    public function getTranslation($name) {
        return $this->get('translator')->trans($name);
    }

    /**
     *  Get Report Config Repository
     */
    public function getReportConfigRepository() {
        return $this->getDoctrine()->getRepository('IZMOReportConfigBundle:ReportConfig');
    }

    /**
     *  Get Report Repository
     */
    public function getReportRepository() {
        return $this->getDoctrine()->getRepository('IZMOReportAccessControlBundle:SalesRoleAccess');
    }

    /**
     *  Get Report Template Repository
     */
    public function getReportTemplateRepository() {
        return $this->getDoctrine()->getRepository('IZMOReportConfigBundle:ReportTemplate');
    }

    /**
     *  Get Export Data For Report Template
     */
    public function getExportDataForReportTemplate($reportName, $exportId, $configFile = 'reports.yml') {       
        $logger = $this->get('logger');
        $filter = [];
        $data = $_REQUEST;
        if (!(empty($data))) {
            $filtersJson = $data['filters'];
            $filtersData = json_decode($filtersJson);
        }
        $serverErrorMsg = $this->getTranslation('datatables.data.server_error_occured.label');        
        try {   
            //echo 'Hello :'.$configFile.'---'.$reportName;           
            //die;            
            $resultArr = $this->get('ymlparser.service.provider')->parseYmlFiles($configFile, '/../../ReportConfigBundle/Resources/config')['reports'][$reportName];            
            //echo 'Hello ';
            //print_r($resultArr);
            //die;
            if (!(empty($resultArr['exports'][$exportId]))) {
                $exportConfig = $resultArr['exports'][$exportId];
                //$exportConfig = $resultArr['export'][$exportIndx];
                $fileName = $exportConfig['file_title'];
                $exportContexts = $exportConfig['contexts'];
                $exportFilters = $exportConfig['filters'];

                $exportTo = $exportConfig['export_to']; // Retrieved from report config yml
                $fileType = $exportConfig['file_type'];
            } else {
                $exportTo = self::EXCEL_EXPORT_TO;
                $fileType = self::EXCEL_FILE_TYPE;
            }                       
            // this has to be placed at END.
            //$export['file'] = $fileTitle;
            //$export['context'] = $exportContexts;
            $exportContextsArr = $exportFiltersArr = [];
            $contextsArr = $resultArr['contexts'];
            foreach ($exportContexts as $k => $val) {
                if (!(empty($contextsArr[$val]))) {
                    $exportContextsArr[$val] = $contextsArr[$val];
                }
            }             
            $filtersArr = $resultArr['filters'];
            foreach ($exportFilters as $k => $val) {
                if (!(empty($filtersArr[$val]))) {
                    $exportFiltersArr[$val] = $filtersArr[$val];
                } else {
                    //if some FILTER IN EXPORT NOT IN REPORT - RARE CONDITION
                }
            }            

            $filter = $context = $dataType = [];
            // Get the Filters Details                
            $filterDetails = $this->get('reports_export.service_provider')->getReportExportFilters($exportFiltersArr, $filtersData);
            if (!(empty($filterDetails))) {
                $filter = $filterDetails[0];
                $dataType = $filterDetails[1];
            }            
            // Get the Context Details                       
            $contextDetails = $this->get('reports_export.service_provider')->getContextDetails($exportContextsArr);
            if (!(empty($contextDetails))) {
                $context = $contextDetails[0];
                $contextDataType = $contextDetails[1];
            }

            if (!(empty($exportConfig['stored_proc']))) {
                $storedProcName = $exportConfig['stored_proc'];
            }
            if (!(empty($exportConfig['stored_proc_params']))) {
                $storedProcParameters = $exportConfig['stored_proc_params'];
            }

            if ((!(empty($storedProcParameters))) && (!(empty($storedProcName)))) {
                $spParametersLabelArray = explode(',', $storedProcParameters);
                $spParametersArrayCount = count($spParametersLabelArray);

                $contextArrCnt = count($exportContexts);
                $filterCnt = $spParametersArrayCount - $contextArrCnt;

                $spFilterParam = [];
                for ($i = 0; $i < $filterCnt; $i++) { //to order filters & its data type based on sp_params order mentioned in yml
                    $paramLbl = $spParametersLabelArray[$i];
                    $spFilterParam[$i]['filter'] = $filter[$paramLbl];
                    $spFilterParam[$i]['data_type'] = $dataType[$paramLbl];
                }

                for ($j = $filterCnt; $j < $spParametersArrayCount; $j++) { //to order filters & its data type based on sp_params order mentioned in yml
                    $paramLbl = $spParametersLabelArray[$j];
                    $spFilterParam[$j]['filter'] = $context[$paramLbl];
                    $spFilterParam[$j]['data_type'] = $contextDataType[$paramLbl];
                }

                // Set the file name with report information
                $reportTitleInfo = $this->get('reports_export.service_provider')->getExportReportTitle($reportName, $filtersData);
                $fileName = $reportTitleInfo . '.' . $fileType;

                $qryResult = $this->getReportConfigRepository()->getReportExportDataForParameters($storedProcName, $spFilterParam);
                if (!(empty($qryResult))) {
                    if (!(empty($qryResult['err']))) {
                        return new Response($serverErrorMsg, Response::HTTP_NOT_FOUND);
                    } else {
                        if ((!(empty($exportConfig['is_seperate_output']))) && (!(empty($exportConfig['export_output_service']))) && (!(empty($exportConfig['export_output_func_name'])))) {
                            $funcName = $exportConfig['export_output_func_name'];
                            $serviceName = $exportConfig['export_output_service'];
                            $qryResult = $this->get($serviceName)->$funcName($qryResult);
                        } else {
                            foreach ($qryResult as $key => $cVal) {
                                if (!(empty($cVal['mon']))) {
                                    $qryResult[$key]['mon'] = $this->getTranslation($cVal['mon']);
                                }
                            }
                        }
                        $colHdrs = $exportConfig['header'];                        
                        $res = $this->get('custom_data.excel.export.provider')->generateReport($qryResult, $colHdrs, $fileName, $exportTo, $fileType);
                    }
                }

                return new Response($res, Response::HTTP_OK);
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured during fetching data with details below:");
            $logger->crit($e);
            return new Response($serverErrorMsg, Response::HTTP_NOT_FOUND);
        }
    }

    /**
     * @Route("/reportconfig", name="report_config_index")
     * @Template("IZMOReportConfigBundle:ReportConfig:index.html.twig")
     */
    public function indexAction() {

        return $this->render('IZMOReportConfigBundle:ReportConfig:index.html.twig', array('gridName' => 'report-config-grid'));
    }

    /**
     * @Route("/config/create", name="report_config_create")   
     * @Template("IZMOReportConfigBundle:ReportConfig:update.html.twig")  
     */
    public function createAction(Request $request) {
        return $this->update(new ReportConfig(), new ReportYmlConfig(), $request);
    }

    /**
     * @Route("/config/update/{id}", name="report_config_update", requirements={"id":"\d+"}, defaults={"id":0})
     * @Template("IZMOReportConfigBundle:ReportConfig:update.html.twig") 
     */
    public function updateAction(ReportConfig $reportConfig, Request $request) {
        $reportYmlConfig = $this->getDoctrine()->getRepository("IZMOReportConfigBundle:ReportYmlConfig")->findOneBy(array('reportConfigId' => $reportConfig->getId()));
        if (empty($reportYmlConfig)) {
            $reportYmlConfig = new ReportYmlConfig();
        }
        return $this->update($reportConfig, $reportYmlConfig, $request);
    }

    /**
     * @Route("/config/{id}", name="report_config_view", requirements={"id"="\d+"})
     * @Template("IZMOReportConfigBundle:ReportConfig:view.html.twig")
     * @Acl(
     *     id="report_config_view_1",
     *     type="entity",
     *     class="IZMOReportConfigBundle:ReportConfig",
     *     permission="VIEW"
     * )     
     */
    public function viewAction(ReportConfig $reportConfig) {
        return $this->render('IZMOReportConfigBundle:ReportConfig:view.html.twig', array('entity' => $reportConfig, 'reportconfig' => $reportConfig));
    }

    /**
     * @Route("/check_duplicate_report_name", name="check_duplicate_report_name")
     */
    public function checkDuplicateReportName() {
        $reportName = filter_input(INPUT_POST, 'report_name');
        $reportNameObj = $this->getReportConfigRepository()->getReportName($reportName);
        if (!(empty($reportNameObj))) {
            return new Response(json_encode(['numrecords_flg' => 1]));
        } else {
            return new Response(json_encode(['numrecords_flg' => 0]));
        }
    }

    /**
     *  Validates the YML content
     * @Route("/validate_yml_content", name="validate_yml_content")
     */
    public function validateYmlContent() {
        $ymlContent = filter_input(INPUT_POST, 'ymlContent');
        try {
            $yaml = new \Symfony\Component\Yaml\Parser();
            $dataConfig = $yaml->parse($ymlContent);
            if (is_array($dataConfig)) {
                return new Response(json_encode(['error_flg' => 0]));
            } else {
                return new Response(json_encode(['error_flg' => 1]));
            }
        } catch (\Exception $e) {
            return new Response(json_encode(['error_flg' => 1]));
        }
    }

    /**
     * @Route("/{reportUrl}", name="get_report_config" ,methods={"GET"})
     * @param string $reportUrl
     */
    public function getReportConfigAction($reportUrl) {
        if ($this->get('reports_config.service_provider')->checkReportExists($reportUrl)) {
            if ($this->get('reports_config.service_provider')->getReportAccess($reportUrl)) {
                return new Response($this->get('db_reports_config_process.service_provider')->initReport($reportUrl, $_REQUEST));
                //       return new Response($this->get('reports_config_process.service_provider')->initReport($reportUrl, $_REQUEST));
            } else {
                throw new AccessDeniedException();
            }
        } else {
            throw new NotFoundHttpException('Report Does not Exist');
        }
    }

    /**
     * @Route("/{reportUrl}/{level}", name="get_report_data" ,methods={"POST"})
     * @param string $reportUrl
     */
    public function getReportDataAction($reportUrl, $level = 0) {
        if ($this->get('reports_config.service_provider')->checkReportExists($reportUrl)) {
            if ($this->get('reports_config.service_provider')->getReportAccess($reportUrl)) {
                return ($this->get('db_reports_config_process.service_provider')->processReportConfig($reportUrl, $_REQUEST));
                // return $this->get('reports_config_process.service_provider')->processReportConfig($reportUrl, $_REQUEST);
            } else {
                throw new AccessDeniedException();
            }
        } else {
            throw new NotFoundHttpException('Report Does not Exist');
        }
    }

    /**
     * @Route("/{reportUrl}/export/{exportId}", name="post_report_data" ,methods={"POST"})
     * @param type $reportUrl
     */
    public function getReportExportAction($reportUrl, $exportId) {       
        if ($this->get('reports_config.service_provider')->checkReportExists($reportUrl)) {            
            if ($this->get('reports_config.service_provider')->getReportAccess($reportUrl)) {                
                return $this->getExportDataForReportTemplate($reportUrl, $exportId, $reportUrl . '.yml');
            } else {
                throw new AccessDeniedException();
            }
        } else {
            throw new NotFoundHttpException('Report Does not Exist');
        }
    }

    /**
     * @param ReportConfig $reportConfig
     * @param Request    $request
     *
     * @return array
     */
    protected function update(ReportConfig $reportConfig, ReportYmlConfig $reportYmlConfig, $request) {
        $logger = $this->get('logger');
        $reload = 0;
        $noSpChanges = 0;
        $ymlMapInfo = [];
        try {
            // Report Config Form
            $form = $this->get('form.factory')->create('report_config_form', $reportConfig);
            $form->handleRequest($request);
            $formYmlContent = $this->get('form.factory')->create('report_ymlconfig_form', $reportYmlConfig);
            $formYmlContent->handleRequest($request);

            // Stored Procedures Data
            if (!(empty($reportConfig->getId()))) {
                $reportConfigIdSel = $reportConfig->getId();
            } else {
                $reportConfigIdSel = NULL;
            }
            $storedProcedures = $this->getReportConfigRepository()->getStoredProceduresForReportConfig($reportConfigIdSel);

            $virtualAcl = null;
            $selectedRoles = null;

            if ($form->isSubmitted() && $form->isValid()) {
                $rolesSelected = $request->request->get('roles');
                $selStoredProcedureId = $request->request->get('sel_stored_procedure');
                $sel_template_id = $request->request->get('report_template_id');

                if ($reportConfig->getId() === null) {
                    // Generate the Virtual ACL here               
                    $virtualAcl = $this->getReportConfigRepository()->generateVirtualAclClass($reportConfig);
                    $virtualAclId = $virtualAcl->getId();
                    $reportConfig->setAclClassId($virtualAcl);
                } else {

                    $virtualAclId = $reportConfig->getAclClassId();
                }


                $reportConfig->setReportTemplateId($sel_template_id);
                $reportConfig->setPermissionType(self::REPORT_VIEW_PERMISSION);
                // Save the Report Config data
                $reportConfig = $this->getReportConfigRepository()->processReportConfiguration($reportConfig);

                // Set the Virtual ACL Role Information
                $virtualAclRoleInfoRes = $this->getReportConfigRepository()->processVirtualAclRoleInfo($rolesSelected, $virtualAclId);
                if (!(empty($virtualAclRoleInfoRes['err']))) {
                    $logger->crit(" Exception occured while inserting in processVirtualAclRoleInfo");
                    $logger->crit($virtualAclRoleInfoRes['err_info']);
                }

                $key = $reportConfig->getUrl();
                $isExistingMenu = $this->getDoctrine()->getRepository('OroNavigationBundle:MenuUpdate')->findOneBy(array('key' => $key));
                if (empty($isExistingMenu)) {
                    //ADD MENU ITEM
                    $uri = '/report/' . $reportConfig->getUrl();
                    $defaultTitle = $reportConfig->getReportTitle();

                    $this->get('izmo_extend_navigation_bundle.provider.navigation_menu')->createCustomNavigationMenu(SELF::NAV_MENU_TYPE, $key, SELF::PARENT_NAV_MENU, $uri, $defaultTitle);
                    $reload = 1;
                } else {
                    if ($isExistingMenu->getTitle() != $reportConfig->getReportTitle()) {
                        $isExistingMenu->setDefaultTitle($reportConfig->getReportTitle());
                        $em = $this->getDoctrine()->getEntityManager();
                        $em->persist($isExistingMenu);
                        $em->flush();
                        $reload = 1;
                        $this->container->get('event_dispatcher')->dispatch(
                                MenuUpdateChangeEvent::NAME, new MenuUpdateChangeEvent(SELF::NAV_MENU_TYPE, [])
                        );
                    }
                    // if change in report Title occured has to be updated.
                }
                //YML Content
                $reportYmlConfig->setReportConfigId($reportConfig);
                $reportYmlConfig = $this->getReportConfigRepository()->processReportYmlConfiguration($reportYmlConfig);
                $noSpChanges = $this->getReportConfigRepository()->mapStoredProcedureToReportId($selStoredProcedureId, $reportConfig);

                if ((!(empty($_REQUEST['sp-param-input']))) && (!(empty($_REQUEST['param-sel-content'])))) {

                    $this->getReportConfigRepository()->mapYmlConfigToSPparam($_REQUEST['sp-param-input'], $_REQUEST['param-sel-content'], $reportConfig->getId(), $noSpChanges);
                }
                $this->get('reports_config.service_provider')->clearCacheForReportDBConfiguration($reportConfig->getUrl());
                if ($reload == 1) {
                    $this->addFlash('success', '<span>Please <a href="#" onclick="window.location.reload(false);
                return false;"><bold>Reload</bold></a> the Page to reflect Navigation Menu </span>');
                }
                return $this->get('oro_ui.router')->redirectAfterSave(
                                array(
                            'route' => 'report_config_update',
                            'parameters' => array('id' => $reportConfig->getId()),
                                ), array(
                            'route' => 'report_config_view',
                            'parameters' => array('id' => $reportConfig->getId()))
                );
            }

            // Get  the logged in user
            // $objUser = $this->container->get('izmo_user_security_info.user_security_provider')->getLoggedInUsr();
            // Get the user roles
            // $roles = $this->get('reports_config.service_provider')->getUserRoles($objUser);
            $roles = $this->getReportConfigRepository()->getRolesForReportConfiguration();
            // Get the Templates
            $templates = $this->getReportTemplateRepository()->getTemplates();
            // Get the virtual acl clss and selected Roles for the report
            if ($reportConfig->getAclClassId()) {
                $virtualAclId = $reportConfig->getAclClassId();
                // Set the Acl Class name
                // Get the selected roles
                $selectedRoles = $this->getReportConfigRepository()->getSelectedRoles($virtualAclId);
            }
            if ($reportConfig->getId()) {
                $reportConfigId = $reportConfig->getId();
                $spSelId = $this->getReportConfigRepository()->getStoredProcedureForReport($reportConfigId);
                $ymlMapInfo = $this->get('reports_config.service_provider')->getParamDetailsForYmlProcessing($reportYmlConfig->getYmlConfigContent(), $spSelId, $reportConfigId);
            } else {
                $spSelId = null;
                $ymlMapInfo = null;
            }

            return array(
                'reportConfig' => $reportConfig,
                'form' => $form->createView(),
                'formYmlContent' => $formYmlContent->createView(),
                'roles' => $roles,
                'storedProcedures' => $storedProcedures,
                'sp_sel' => $spSelId,
                'yml_map_info' => $ymlMapInfo,
                'selectedRoles' => $selectedRoles,
                'templates' => $templates,
                'acl_class_name' => (!(empty($reportConfig->getId()))) ? $reportConfig->getAclClassId()->getClassName() : null
            );
        } catch (\Exception $e) {
            $logger->crit("Exception occured in report config create/update with following details");
            $logger->crit($e);
            $isErr = 1;
        }
    }

}
