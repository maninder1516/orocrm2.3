<?php
namespace IZMO\ReportConfigBundle\Provider;

class NumberFormatter {
    
    protected $container;
     
    public function __construct($container){
        $this->container = $container;
    }
   
    /**
     * This function is used to format number or currency
     * @param int $num
     * @param boolean $currencyFlag
     * @return string
     */
   public function formatNumberOrCurrency($num, $currencyFlag){
        $numberFormatter = $this->container->get('oro_locale.formatter.number');
        $localeSettings = $this->container->get('oro_locale.settings');
        $numberFormatted = $numberFormatter->formatDecimal($num);
        if ($currencyFlag) {
           $numberFormatted = ($numberFormatter->isCurrencySymbolPrepend()) ? $localeSettings->getCurrencySymbolByCurrency() . " " . $numberFormatted : $numberFormatted . " " . $localeSettings->getCurrencySymbolByCurrency();
        } 
        return $numberFormatted;
    }
}
