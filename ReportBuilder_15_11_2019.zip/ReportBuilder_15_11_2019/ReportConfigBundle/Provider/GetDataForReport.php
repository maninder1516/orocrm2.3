<?php

namespace IZMO\ReportConfigBundle\Provider;

use Symfony\Component\DependencyInjection\ContainerInterface;
use IZMO\ReportConfigBundle\Provider\ExcelExportData;
use IZMO\ReportConfigBundle\Provider\AbstractFactoryExportDataClass;

class GetDataForReport extends AbstractFactoryExportDataClass {

    /**
     * @var ContainerInterface
     */
    protected $container;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container) {
        $this->container = $container;
    }

    /**
     *  Get Translated Header
     */
    private function getTranslatedHeader($headerArray) {
        $translatorVar = $this->container->get('translator');

        foreach ($headerArray as $key => $val) {
            $headerArray[$key] = $translatorVar->trans($val);
        }
        return $headerArray;
    }

    /**
     *  Generate Report with provided data, filters and export type
     */
    public function generateReport($result = '', $hdr = '', $fileName = '', $exportTo, $fileType) { // generalized code for no roll up
        ob_start();
        // $exporter = new ExcelExportData($exportTo, $fileName);
        // $exporter = new CsvExportData($exportTo, $fileName);
        $exporter = $this->getExportDataClass($exportTo, $fileName, $fileType);        
        $exporter->initialize();

        if (!(empty($hdr))) {
            $header = $this->getTranslatedHeader($hdr);
            $exporter->addRow($header);
        }

        foreach ($result as $res) {
            $exporter->addRow($res);
        }
        $exporter->finalize();
    }
}
