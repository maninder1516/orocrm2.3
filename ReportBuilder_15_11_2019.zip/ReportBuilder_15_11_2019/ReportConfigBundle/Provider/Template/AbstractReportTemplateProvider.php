<?php
namespace IZMO\ReportConfigBundle\Provider\Template;


abstract class AbstractReportTemplateProvider {
    
    protected $config;
    protected $request;
    protected $container;
    
    public function __construct($container,$config,$request) {
        $this->container = $container;
        $this->config = $config;
        $this->request = $request;
        $this->reportConfigProviderId = 'reports_config.service_provider';
    }
    
    public function getTemplateName(){
      return $this->config['template_provider']['template_path'];
    }
    
    public function getReportTitle() {
        $reportTitleArr = [];
        $reportConfigDetails = $this->config;
        $filter = $this->getFilterConfig();
        if ((!(empty($reportConfigDetails['generate_title']))) && (!(empty($reportConfigDetails['generate_title']['service_name']))) && (!(empty($reportConfigDetails['generate_title']['function_name']))) && (!(empty($reportConfigDetails['generate_title']['function_params'])))) {
           $reportTitleRes = $this->container->get($this->reportConfigProviderId)->getConfigReportData($reportConfigDetails['generate_title'], $filter);
           if (is_array($reportTitleRes)) {
                if (!(empty($reportTitleRes['report_title']))) {
                    $reportTitle = $reportTitleRes['report_title'];
                }
                if (!(empty($reportTitleRes['report_title_key']))) {
                    $reportTitleKey = $reportTitleRes['report_title_key'];
                }
            } else {
                $reportTitle = $reportTitleKey = $reportTitleRes;
            }
        } else if (!(empty($reportConfigDetails['title']))) {
            $reportTitle = $this->container->get($this->reportConfigProviderId)->getTranslation($reportConfigDetails['title']);
            $reportTitleKey = $reportConfigDetails['title'];
        }
        $reportTitleArr['title'] = $reportTitle;
        $reportTitleArr['title_key'] = $reportTitleKey;
        return $reportTitleArr;
    }
    
    public function getReportTitleForDataProcessed($filters) {
        $reportTitleArr = [];
        $reportConfigDetails = $this->config;
        if ((!(empty($reportConfigDetails['generate_title']))) && (!(empty($reportConfigDetails['generate_title']['service_name']))) && (!(empty($reportConfigDetails['generate_title']['function_name']))) && (!(empty($reportConfigDetails['generate_title']['function_params'])))) {
           $reportTitleRes = $this->container->get($this->reportConfigProviderId)->getConfigReportData($reportConfigDetails['generate_title'], $filters);
           if (is_array($reportTitleRes)) {
                if (!(empty($reportTitleRes['report_title']))) {
                    $reportTitle = $reportTitleRes['report_title'];
                }
                if (!(empty($reportTitleRes['report_title_key']))) {
                    $reportTitleKey = $reportTitleRes['report_title_key'];
                }
            } else {
                $reportTitle = $reportTitleKey = $reportTitleRes;
            }
        } else if (!(empty($reportConfigDetails['title']))) {
            $reportTitle = $this->container->get($this->reportConfigProviderId)->getTranslation($reportConfigDetails['title']);
            $reportTitleKey = $reportConfigDetails['title'];
        }
        $reportTitleArr['title'] = $reportTitle;
        $reportTitleArr['title_key'] = $reportTitleKey;
        return $reportTitleArr;
    }
    
    
    abstract public function prepareTemplateParams();
    abstract protected function processFilters();
    abstract protected function getFilterConfig();
    abstract public function processTemplateData();
    abstract protected function invokeStoredProcedure($params);
    abstract protected function prepareStoredProcedureParams($storedProcParameters, $filter, $context,$extraParams, $dataType,$pkArr=null);
    abstract protected function getStoredProcedureParams();
    abstract protected function getStoredProcedureName($filters);
    abstract protected function getContexts($filters);
    abstract protected function getExtraParams();
    abstract protected function orderBy();

    abstract public function renderTemplate($templateParams,$extraParams,$templating);

}
