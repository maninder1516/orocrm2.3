<?php

namespace IZMO\ReportConfigBundle\Provider;

use Symfony\Component\DependencyInjection\ContainerInterface;
use IZMO\ReportConfigBundle\Provider\ExcelExportData;

class GetDataForExcel {

    /**
     * @var ContainerInterface
     */
    protected $container;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container) {
        $this->container = $container;
    }

    /**
     *  Get Translated Header
     */
    private function getTranslatedHeader($headerArray) {
        $translatorVar = $this->container->get('translator');

        foreach ($headerArray as $key => $val) {
            $headerArray[$key] = $translatorVar->trans($val);
        }
        return $headerArray;
    }

    /**
     *  Generate Excel For Report
     */
    public function generateExcelForReport($result = '', $hdr = '', $fileName = '', $exportTo) { // generalized code for no roll up
        ob_start();       
        //$exporter = new ExcelExportData($exportTo, $fileName);
        $exporter = new CsvExportData($exportTo, $fileName);
        $exporter->initialize();

        if (!(empty($hdr))) {
            $header = $this->getTranslatedHeader($hdr);
            $exporter->addRow($header);
        }

        foreach ($result as $res) {
            $exporter->addRow($res);
        }
        $exporter->finalize();
    }

    /**
     *  Generate Target Excel For Report
     */
    public function generateTargetExcelForReport($result = '', $hdr = '', $excelTitle = '', $except_field) { // generalized code for no roll up
        ob_start();
        $exporter = new ExcelExportData('browser', "$excelTitle.xls");
        $exporter->initialize();

        if (!(empty($hdr))) {
            $header = $this->getTranslatedHeader($hdr);
            $exporter->addRow($header);
        }

        foreach ($result as $key => $res) {
            foreach ($hdr as $k => $v) {
                if (!(in_array($v, $except_field)) && !(array_key_exists($v, $res))) {
                    $data[$v] = 0;
                } else {
                    $data[$v] = $res[$v];
                }
            }
            $exporter->addRow($data);
        }
        $exporter->finalize();
    }

}
