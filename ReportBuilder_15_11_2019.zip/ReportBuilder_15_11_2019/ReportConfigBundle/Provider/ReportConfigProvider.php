<?php

namespace IZMO\ReportConfigBundle\Provider;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Oro\Bundle\UserBundle\Entity\User;
use IZMO\ReportConfigBundle\Utils\ReportConfigConstants;
use Doctrine\Common\Cache\Cache;

class ReportConfigProvider {

    /**
     * @var ContainerInterface
     */
    protected $container;

    const JAN = 'January';
    const FEB = 'February';
    const MAR = 'March';
    const APR = 'April';
    const MAY = 'May';
    const JUN = 'June';
    const JUL = 'July';
    const AUG = 'August';
    const SEP = 'September';
    const OCT = 'October';
    const NOV = 'November';
    const DEC = 'December';
    const DB_REPORT_CONFIG = 'DB_REPORT_CONFIG_';
    const USER_SALES_CATEGORIES = 'USER_SALES_CATEGORIES';

    /**
     * @var Cache
     */
    protected $cache;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container, Cache $cache = null) {
        $this->container = $container;
        $this->cache = $cache;
    }

    public function getReportConfigRepository() {
        return $this->container->get('doctrine')->getRepository('IZMOReportConfigBundle:ReportConfig');
    }

    /**
     * 
     */
    public function checkResourceAccessForUser($permType, $aclClassId) {
        $obj = $this->container->get('security.context')->getToken();
        if ((!(empty($obj))) && ($obj->getUser() instanceof User)) {
            $usrObj = $obj->getUser();
            $roles = [];
            $usrRoleInfo = $usrObj->getRolesCollection();
            if (!(empty($usrRoleInfo))) {
                foreach ($usrRoleInfo as $usrRole) {
                    $roles[] = $usrRole->getId();
                }
            }

            if (!(empty($roles))) {
                $res = $this->getReportConfigRepository()->getReportsAccessCheck($roles, $permType, $aclClassId);
                return (!(empty($res['id']))) ? 1 : 0;
            }
        } else {
            return 1;
        }
    }

    public function getReportAclPermissionInfo($url) {
        $this->getReportConfigRepository()->getReportAclPermissionInfo($url);
    }

    public function getTranslation($name) {
        return $this->container->get('translator')->trans($name);
    }

    function getConfigReportData($config, $filter = null) {
        $container = $this->container;
        $funcName = $config['function_name'];
        $serviceName = $config['service_name'];
        if (empty($config['function_params'])) {
            return $container->get($serviceName)->$funcName();
        } else {
            $fparam = [];
            foreach ($config['function_params'] as $fkey => $fval) {
                if ((!(empty($fval['type'])))) {
                    if (($fval['type'] == 'filter') && (!(empty($fval['param'])))) {
                        $param = $fval['param'];
                        if (!(empty($filter[$param]['val']))) {  // here changes has to be done.
                            $fparam[$param]['val'] = $filter[$param]['val'];
                            $fparam[$param]['translatable'] = isset($fval['is_translatable']) ? $fval['is_translatable'] : 0;
                        } elseif ((!(empty($filter[$param])))) { //during sub lvl..
                            $fparam[$param]['val'] = $filter[$param];
                            $fparam[$param]['translatable'] = isset($fval['is_translatable']) ? $fval['is_translatable'] : 0;
                        }
                    } elseif (($fval['type'] == 'val') && (!(empty($fval['param_name']))) && (!(empty($fval['param_val'])))) {
                        $fparam[$fval['param_name']]['val'] = $fval['param_val'];
                        $fparam[$fval['param_name']]['translatable'] = isset($fval['is_translatable']) ? $fval['is_translatable'] : 0;
                    }
                }
            }

            return $container->get($serviceName)->$funcName($fparam);
        }
    }

    public function checkReportExists($url) {
        if (!(empty($this->getReportConfigRepository()->findOneBy(array('url' => $url))))) {
            return true;
        } else {
            return false;
        }
    }

    public function getReportAccess($url) {
        $reportAclPermInfoArr = $this->getReportConfigRepository()->getReportAclPermissionInfo($url);
        if ((!(empty($reportAclPermInfoArr['acl_class_id']))) && (!(empty($reportAclPermInfoArr['permission_type'])))) {
            $aclClassId = $reportAclPermInfoArr['acl_class_id'];
            $permType = $reportAclPermInfoArr['permission_type'];
            return $this->checkResourceAccessForUser($permType, $aclClassId->getId());
        } else {
            return false;
        }
    }

    public function checkIsNavigationMenuDisplayForUri($uri, $baseUrlInfo) {
        $uriInfo = explode('/', $uri);
        if (empty($baseUrlInfo)) {
            if (!(empty($uriInfo[1])) && ($uriInfo[1] == 'report') && (!(empty($uriInfo[2])))) { //for Nav URI match pattern /report/REPORT_ID
                return $this->getReportAccess($uriInfo[2]);
            }
        } else if (!(empty($uriInfo[2])) && ($uriInfo[2] == 'report') && (!(empty($uriInfo[3])))) {
            return $this->getReportAccess($uriInfo[3]);
        }
    }

    public function generateTitle($param) {
        $reportTitleArr = [];
        $reportTitle = '';
        $reportTitleKey = '';
        foreach ($param as $k => $val) {
            if ($k == 'report_name') {
                $reportTitleKey = $reportTitle = $val['val'];
                if ($val['translatable'] == 1) {
                    $reportTitle = $this->getTranslation($reportTitle);
                }
            } else {
                if ($val['translatable'] == 1) {
                    $reportTitle = $reportTitle . ' - ' . $this->getTranslation($val['val']);
                } else {
                    $reportTitle = $reportTitle . ' - ' . $val['val'];
                }
                $reportTitleKey = $reportTitleKey . ' - ' . $val['val'];
            }
        }
        $reportTitleArr['report_title'] = $reportTitle;
        $reportTitleArr['report_title_key'] = $reportTitleKey;
        return $reportTitleArr;
    }

    // Below provider copied from Multi Level:

    public function getLogger() {
        return $this->container->get('logger');
    }

    /**
     * Paging
     *
     * Construct the LIMIT clause for server-side processing SQL query
     *
     *  @param  array $request Data sent to server by DataTables
     *  @return string SQL limit clause
     */
    public function limit($request) {
        return ( isset($request['start']) && $request['length'] != -1 ) ? "LIMIT " . intval($request['start']) . ", " . intval($request['length']) : '';
    }

    /**
     * Ordering
     *
     * Construct the ORDER BY clause for server-side processing SQL query
     *
     *  @param  array $request Data sent to server by DataTables
     *  @param  array $columns Column information array
     *  @return string SQL order by clause
     */
    public function order($request, $columns) {
        $order = '';
        if (isset($request['order']) && count($request['order'])) {
            $orderBy = array();
            $dtColumns = $this->pluck($columns, 'dt');
            for ($i = 0, $ien = count($request['order']); $i < $ien; $i++) {
                // Convert the column index into the column data property
                $columnIdx = intval($request['order'][$i]['column']);
                $requestColumn = $request['columns'][$columnIdx];
                $columnIdx = array_search($requestColumn['data'], $dtColumns);
                $column = $columns[$columnIdx];
                if ($requestColumn['orderable'] == 'true') {
                    $dir = $request['order'][$i]['dir'] === 'asc' ? 'ASC' : 'DESC';
                    $orderBy[] = (!(empty($column['tab_alias']))) ? $column['tab_alias'] . '.' . $column['db'] . ' ' . $dir : $column['db'] . ' ' . $dir;
                }
            }
            $order = 'ORDER BY ' . implode(', ', $orderBy);
        }
        return $order;
    }

    /**
     * 
     * @param object $request
     * @param string $storedProcName
     * @param array $columns
     * @param boolean $storedProcContainsWhere
     * @param string $primaryKeyColForCnt
     * @param string $repoClass
     * @param string $dataOutputFunc
     * @param array $params
     * @return array
     */
    public function getTableDataRendered($request, $storedProcName, $columns, $dataOutputServiceRef, $dataOutputFunc, $params, $url, $serverFunctionParams = NULL) {
        try {
            $resultset = array();
            $result = $this->getReportConfigRepository()->fetchResultForQueryParams($storedProcName, $params['sp_params']);
            if (!(empty($result))) {
                if (!(empty($result['res'])) && (!(empty($result['cnt'])))) {
                    $data = $result['res'];
                    $resFilterLength = $result['cnt'];
                    if ($dataOutputFunc == 'default') {
                        $resultset = $this->formatResultSetToRenderDataForReports($columns, $data, $serverFunctionParams);
                    } else {
                        $resultset = $this->container->get($dataOutputServiceRef)->$dataOutputFunc($columns, $data, $serverFunctionParams);
                    }
                    $recordsFiltered = $resFilterLength['cnt'];
                    return array(
                        "draw" => isset($request['draw']) ? intval($request['draw']) : 0,
                        "recordsFiltered" => intval($recordsFiltered), //needed for pagination to work
                        "data" => $resultset,
                        "url" => $url,
                        "err" => 0,
                        "report_title" => (!(empty($params['report_title']))) ? $params['report_title'] : null
                    );
                } else if (!(empty($result['err_flg']))) {
                    return array('draw' => 0, "recordsFiltered" => 0, "data" => array(), "err" => 1);
                } else {//no data found
                    return array(
                        "draw" => isset($request['draw']) ? intval($request['draw']) : 0,
                        "recordsFiltered" => 0,
                        "data" => array(),
                        'no_data' => 1,
                        "report_title" => (!(empty($params['report_title']))) ? $params['report_title'] : null
                    );
                }
            }
        } catch (\Exception $e) {
            $logger = $this->getLogger();
            $logger->crit("Error Occured in getTableDataRendered with exception details below");
            $logger->crit($e);
            return array('draw' => 0, "recordsFiltered" => 0, "data" => array(), "err" => 1);
        }
    }

    public function pluck($a, $prop) {
        $out = array();
        for ($i = 0, $len = count($a); $i < $len; $i++) {
            $out[] = (($prop == 'db') && (!(empty($a[$i]['tab_alias'])))) ? $a[$i]['tab_alias'] . '.' . $a[$i][$prop] : $a[$i][$prop];
        }
        return $out;
    }

    /**
     * 
     * @param array $reportConfig
     * @param string $storedProcName
     * @param array $requestObj
     * @param array $params
     * @param string $url
     * @return Response
     */
    // public function processServerSideData($reportConfig, $storedProcName, $requestObj, $params, $url) {
    public function processServerSideData($requestObj, $params) {
        $reportConfig = $params['server_config'];
        $columns = $reportConfig['columns'];
        $storedProcName = $params['sp_name'];
        $url = $params['url'];
        $dataOutputServiceRef = $reportConfig['data_out_service_id'];
        $dataOutputFunc = $reportConfig['data_output_func_name'];
        $serverFunctionParams = (!(empty($reportConfig['function_params']))) ? $reportConfig['function_params'] : NULL;
        return new Response(json_encode($this->getTableDataRendered($requestObj, $storedProcName, $columns, $dataOutputServiceRef, $dataOutputFunc, $params, $url, $serverFunctionParams)));
    }

    /**
     *  Get the User Roles
     */
    function getUserRoles($objUser) {
        $roles = [];
        $userRoles = $objUser->getRolesCollection();
        if (!empty($userRoles)) {
            foreach ($userRoles AS $userRole) {
                $key = $userRole->getId();
                $val = $userRole->getLabel();
                $roles[$key] = $val;
            }
        }

        return $roles;
    }

    public function getReportPageLimit() {
        if (!(empty($_REQUEST))) {
            $request = $_REQUEST;
            return ( isset($request['start']) && $request['length'] != -1 ) ? "LIMIT " . intval($request['start']) . ", " . intval($request['length']) : '';
        } else {
            return '';
        }
    }

    public function getParamDetailsForYmlProcessing($ymlContent, $spId, $reportId) {
        try {
            $yaml = new \Symfony\Component\Yaml\Parser();
            $dataConfig = $yaml->parse($ymlContent);
            $pkParams = [];
            $contexts = $dataConfig['config']['contexts'];
            $filters = $dataConfig['config']['filters'];
            $extraParams = $dataConfig['config']['extra_params'];
            $serverProcessConfig = $dataConfig['config']['serverside_processing_detail'];
            if (!(empty($serverProcessConfig['columns']))) {
                foreach ($serverProcessConfig['columns'] as $k => $v) {
                    if ((!(empty($v['hidden']))) && ($v['hidden'] == 1) && ((!(empty($v['primary_key_info']))))) {
                        $pkCol = ReportConfigConstants::PRIMARY_KEY_PREFIX_TYPE . $v['db'];
                        $pkParams[$pkCol] = $v['db'];
                    }
                }
            }
        } catch (\Exception $e) {
            return array('err' => 1, 'msg' => 'Yml Config Parse issue occured');
        }
        try {
            $spParams = $this->container->get('doctrine')->getEntityManager()->getRepository('IZMOReportConfigBundle:ReportBuilderStoredProcedureParams')->findBy(array('storedProcedureId' => $spId));
            if (empty($spParams)) {
                return array('err' => 2, 'msg' => 'No Parameters defined for Stored Procedure');
            }
            $cntxArr = $filtersArr = $extraParamArr = [];
            $contexts = array_keys($contexts);
            $filters = array_keys($filters);
            $extraParams = array_keys($extraParams);

            foreach ($contexts as $k => $v) {
                $cntxtVal = ReportConfigConstants::CONTEXT_PREFIX_TYPE . $v;
                $cntxArr[$cntxtVal] = $v;
            }
            foreach ($filters as $k => $v) {
                $filterVal = ReportConfigConstants::FILTER_PREFIX_TYPE . $v;
                $filtersArr[$filterVal] = $v;
            }

            foreach ($extraParams as $k => $v) {
                $extraVal = ReportConfigConstants::EXTRA_PARAM_PREFIX_TYPE . $v;
                $extraParamArr[$extraVal] = $v;
            }


            $spParamArr = [];
            $spParamYmlContentMapArr = [];
            foreach ($spParams as $k => $val) {
                $spParamArr[$val->getId()] = $val->getDisplayName();
                if (!(empty($reportId))) {
                    $params = $this->container->get('doctrine')->getEntityManager()->getRepository('IZMOReportConfigBundle:ReportBuilderReportStoredProcedureParamMapper')->findOneBy(array('storedProcedureParamsId' => $val->getId(), 'reportConfigId' => $reportId));
                    if (!(empty($params))) {
                        $spParamYmlContentMapArr[$val->getId()] = $params->getReportParam();
                    }
                }
            }

            $res['sp_param'] = $spParamArr;
            $res['filter'] = $filtersArr;
            $res['context'] = $cntxArr;
            $res['extra'] = $extraParamArr;
            if (!(empty($pkParams))) {
                $res['pk'] = $pkParams;
            }
            if (!(empty($spParamYmlContentMapArr))) {
                if (count($spParamYmlContentMapArr) == count($spParamArr)) {
                    $res['sp_param_yml_map'] = $spParamYmlContentMapArr;
                }
            }
            return $res;
        } catch (\Exception $e) {
            return array('err' => 3, 'msg' => 'Yml Config and Stored Procedure issue occured');
        }
    }

    public function calcSubTotal($colName, $data, $i, $subTotData, $prev, $prevSec) {
        $monthPrev = (!(empty($data[$i - 2]))) ? $data[$i - 2] : '';
        $monthSecPrev = (!(empty($data[$i - 1]))) ? $data[$i - 1] : '';
        $subTotPrev = ((!(empty($monthPrev[$colName]))) && ($monthPrev['mon'] == $prev)) ? ($monthPrev[$colName]) : 0;
        $subTotSecPrev = ((!(empty($monthSecPrev[$colName]))) && (($monthSecPrev['mon'] == $prevSec) || (((empty($monthPrev['mon'])) || ($monthPrev['mon'] != $prev)) && ($monthSecPrev['mon'] == $prev)) )) ? ($monthSecPrev[$colName]) : 0;
        return $subTotData + $subTotPrev + $subTotSecPrev;
    }

    /**
     * To format the result set to fit DataTables
     * @param array $columns
     * @param array $data
     * @param string $sessionKeyId
     * @param string $sessionColumn
     * @return array
     */
    public function formatResultSetToRenderDataForReports($columns, $data, $params = NULL) {
        $out = array();
        $sessionKeyId = $sessionColumn = null;
        if (!(empty($params))) { // flexibility of providing params to O/p function
            foreach ($params as $k => $val) {
                if ($val['param_name'] == 'session_key_id') {
                    $sessionKeyId = $val['param_val'];
                } elseif ($val['param_name'] == 'session_column') {
                    $sessionColumn = $val['param_val'];
                }
            }
        }
        if ((!(empty($sessionKeyId))) && (!(empty($sessionColumn)))) {
            $reportTyp = isset($data[0]['report_lvl']) ? $data[0]['report_lvl'] : 1;
            $isStrt = isset($data[0]['is_start']) ? $data[0]['is_start'] : 1;
            $session = $this->container->get('session');

            if ($reportTyp == 0 && $isStrt == 0) {
                $session->set($sessionKeyId, (!(empty($data[0][$sessionColumn]))) ? $data[0][$sessionColumn] : 0);
            }
            $grndTotl = (!(empty($session->get($sessionKeyId)))) ? $session->get($sessionKeyId) : 0;
        }
        for ($i = 0, $ien = count($data); $i < $ien; $i++) {
            $resData = $data[$i];
            $row = array();
            for ($j = 0, $jen = count($columns); $j < $jen; $j++) {
                $column = $columns[$j];
                if (!(empty($sessionColumn))) {
                    if ($column['db'] == 'mon') {
                        $mon = $resData['mon'];
                        if (in_array($mon, array(SELF::MAR, SELF::JUN, SELF::SEP, SELF::DEC))) {
                            if ($mon == SELF::MAR) {
                                $prev = SELF::JAN;
                                $prevSec = SELF::FEB;
                            } else if ($mon == SELF::JUN) {
                                $prev = SELF::APR;
                                $prevSec = SELF::MAY;
                            } else if ($mon == SELF::SEP) {
                                $prev = SELF::JUL;
                                $prevSec = SELF::AUG;
                            } else if ($mon == SELF::DEC) {
                                $prev = SELF::OCT;
                                $prevSec = SELF::NOV;
                            }
                            $resData['subtotal'] = $this->calcSubTotal($sessionColumn, $data, $i, $resData[$sessionColumn], $prev, $prevSec);
                        } else {
                            $resData['subtotal'] = 0;
                        }
                    }
                }
                if ((!(empty($sessionKeyId))) && (!(empty($sessionColumn)))) {
                    if ($column['db'] == 'weight_of_line_for_total') {
                        $resData['weight_of_line_for_total'] = (!(empty($grndTotl))) ? ROUND((($data[$i][$sessionColumn] / $grndTotl) * 100), 2) : 0;
                    }
                }
                //}
                if (!(empty($column['formatter']))) {
                    $colFormatter = $column['formatter'];
                    if ($colFormatter == 'percent') {
                        if (!(empty($column['ref_col']))) {
                            $class = $this->container->get('reports_config.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                            $resData[$column['ref_col']] = "<span class='indicator $class'></span>";
                        }
                        $resData[$column['db']] = (!(empty($resData[$column['db']]))) ? $this->container->get('reports_config.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0) . ' %' : '0 %';
                    } else if ($colFormatter == 'ind' && ((!(empty($column['has_ref_col']))) && ($column['has_ref_col'] == 'none') )) {
                        $class = $this->container->get('reports_config.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                        $resData[$column['db']] = "<span class='indicator $class'></span>";
                    } else if ($colFormatter == 'ind_text') {
                        $class = $this->container->get('reports_config.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                        $txtIndVal = $resData[$column['db']];
                        $resData[$column['db']] = "<div class='txt-$class'>$txtIndVal</div>";
                    } else if ($colFormatter == 'ind_text_num') {
                        $class = $this->container->get('reports_config.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                        $txtIndVal = $this->container->get('reports_config.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0);
                        $resData[$column['db']] = "<div class='txt-$class'>$txtIndVal</div>";
                    } else if ($colFormatter == 'ind_text_curr') {
                        $class = $this->container->get('reports_config.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                        $txtIndVal = $this->container->get('reports_config.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 1);
                        $resData[$column['db']] = "<div class='txt-$class'>$txtIndVal</div>";
                    } else if ($colFormatter == 'ind_text_perc') {
                        $class = $this->container->get('reports_config.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                        $txtIndVal = (!(empty($resData[$column['db']]))) ? $this->container->get('reports_config.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0) . ' %' : '0 %';
                        $resData[$column['db']] = "<div class='txt-$class'>$txtIndVal</div>";
                    } else if (($colFormatter == 'ind_text_num_or_curr') && (!(empty($column['ref_col'])))) {
                        $class = $this->container->get('reports_config.indicator')->getIndicatorClassForVal($resData[$column['db']]);
                        $txtIndVal = $this->container->get('reports_config.number_formatter')->formatNumberOrCurrency($resData[$column['db']], $resData[$column['ref_col']]);
                        $resData[$column['db']] = "<div class='txt-$class'>$txtIndVal</div>";
                    } else if ($colFormatter == 'num') {
                        $resData[$column['db']] = $this->container->get('reports_config.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0);
                    } else if ($colFormatter == 'curr') {
                        if (!(empty($column['ref_col']))) {
                            $class = $this->container->get('reports_config.indicator')->getIndicatorClassForTargetVal($resData[$column['db']]);
                            $resData[$column['ref_col']] = "<span class='indicator $class'></span>";
                        }
                        $resData[$column['db']] = $this->container->get('reports_config.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 1);
                    } else if (($colFormatter == 'num_or_cur') && (!(empty($column['ref_col'])))) {
                        $resData[$column['db']] = $this->container->get('reports_config.number_formatter')->formatNumberOrCurrency($resData[$column['db']], $resData[$column['ref_col']]);
                    } else if ($colFormatter == 'subtotal_curr') {
                        $resData[$column['db']] = (!(empty($resData[$column['db']]))) ? $this->container->get('reports_config.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 1) : '';
                    } else if ($colFormatter == 'subtotal_num') {
                        $resData[$column['db']] = (!(empty($resData[$column['db']]))) ? $this->container->get('reports_config.number_formatter')->formatNumberOrCurrency($resData[$column['db']], 0) : '';
                    } else if ($colFormatter == 'date') {
                        $resData[$column['db']] = $this->container->get('reports_config.service_provider')->formatDate($resData[$column['db']]);
                    }
                }
                if (!(empty($column['is_translatable']))) {
                    $resData[$column['db']] = $this->getTranslation($resData[$column['db']]);
                }
                $row[$column['dt']] = $resData[$column['db']];
            }
            $out[] = $row;
        }
        return $out;
    }

    /**
     * Delete the Cache file when updated the config form for DB configuration
     * @param type $reportId
     * @return boolean
     */
    public function clearCacheForReportDBConfiguration($reportId) {
        $cacheKey = SELF::DB_REPORT_CONFIG . $reportId;
        if ($this->cache->contains($cacheKey)) {
            $this->cache->delete($cacheKey);
        }
        return true;
    }

    /**
     * Save Config prepared from DB into Cache 
     * @param type $reportId
     * @return array
     */
    public function getReportConfigurationFromDB($reportId) {

        $cacheKey = SELF::DB_REPORT_CONFIG . $reportId;
        if ($this->cache) {
            if ($this->cache->contains($cacheKey)) {
                return $this->cache->fetch($cacheKey);
            } else {
                $config = $this->container->get('doctrine')->getRepository('IZMOReportConfigBundle:ReportConfig')->getReportsConfigurationFromDb($reportId);
                $this->cache->save($cacheKey, $config);
                return $config;
            }
        }
    }

    public function getDataSrcByStoredProcedure($spName, $spParams = NULL) {
        // if $spParams modifications to be done.
        return $this->getReportConfigRepository()->getDataSourceResultByStoredProcedure($spName, $spParams);
    }

    // RELATED TO DB related DATA SOURCES --

    public function getDataSrcConfig($displayName, $params = NULL) {
        $defaultServiceId = 'reports_config.service_provider';
        $reportDataSrcObj = $this->container->get('doctrine')->getRepository("IZMOReportConfigBundle:ReportDataSource")->findOneBy(array('displayName' => $displayName));
        if (!(empty($reportDataSrcObj))) {
            $funcName = $reportDataSrcObj->getName();
            $type = $reportDataSrcObj->getType();
            if (!(empty($reportDataSrcObj->getParameters()))) {
                $functionProperties = json_decode($reportDataSrcObj->getParameters(), true);
            }
            $funcService = (!empty($functionProperties['service'])) ? $functionProperties['service'] : $defaultServiceId;
            return $this->defaultGetParamDataValByDbConfig($funcName, $type, $params, $functionProperties);
        }
    }

    public function getParamDataByDbConfig($displayName, $params = null, $filters = null, $contexts = null) {
        $defaultServiceId = 'reports_config.service_provider';
        $reportDataSrcObj = $this->container->get('doctrine')->getRepository("IZMOReportConfigBundle:ReportDataSource")->findOneBy(array('displayName' => $displayName));
        if (!(empty($reportDataSrcObj))) {
            $funcName = $reportDataSrcObj->getName(); // DEFAULT FUNC NAME Prototype for Reference is :defaultGetParamDataValByDbConfig
            $type = $reportDataSrcObj->getType();
            if (!(empty($reportDataSrcObj->getParameters()))) {
                $functionProperties = json_decode($reportDataSrcObj->getParameters(), true);
            }
            $funcService = (!empty($functionProperties['service'])) ? $functionProperties['service'] : $defaultServiceId;
            return $this->defaultGetParamDataValByDbConfig($funcName, $type, $params, $functionProperties);
        }
    }

    public function defaultGetParamDataValByDbConfig($funcName, $funcType, $params = NULL, $funcProperties = NULL) {
        try {
            $paramStrArr = [];

            if (!(empty($funcProperties['service']))) {
                $funcService = $funcProperties['service'];
            } else {
                $funcService = 'reports_config.service_provider';
            }
            if ($funcType == ReportConfigConstants::PHP_DATA_SRC_TYPE) {
                return $this->container->get($funcService)->$funcName($params, $funcProperties); // FOR FUNCTIONS WITHIN PHP Params have to be handled
            } elseif ($funcType == ReportConfigConstants::STORED_PROCEDURE_DATA_SRC_TYPE) {
                $paramStrArr = NULL;
                if (!(empty($params))) {
                    $i = 0;
                    foreach ($params as $k => $val) {
                        if ($val['type'] == 'fixed') {
                            if (!(empty($val['val']))) {
                                $paramStrArr[$i]['filter'] = $val['val'];
                            }
                        } else if ($val['type'] == 'function' && (!(empty($val['service_name']))) && (!(empty($val['function_name'])))) {
                            $fName = $val['function_name'];
                            $fParams = (!(empty($val['function_params']))) ? $val['function_params'] : NULL;
                            $paramStrArr[$i]['filter'] = $this->container->get($val['service_name'])->$fName($fParams);
                        }
                        if ((!(empty($val['data_type']))) && (!(empty($val['param_name'])))) {
                            $paramStrArr[$i]['data_type'] = $val['data_type'];
                        }
                        $i++;
                    }
                }
                $isSingleResultSet = (!(empty($funcProperties['is_single_resultset']))) ? $funcProperties['is_single_resultset'] : NULL;
                $res = $this->getReportConfigRepository()->getParamValFromStoredProc("call $funcName (", $paramStrArr, $isSingleResultSet);
                $renderFunc = (!(empty($funcProperties['render_function']))) ? $funcProperties['render_function'] : NULL;
                return (!(empty($renderFunc))) ? $this->container->get($funcService)->$renderFunc($res) : ((!(empty($funcProperties['resultset_col']))) ? $res[$funcProperties['resultset_col']] : $res);
            }
        } catch (\Exception $e) {
            $logger = $this->getLogger();
            $logger->crit("Exception Occuered");
            $logger->crit($e);
        }
    }

    public function prepareResultSetForOptions($res) {
        $selectOption = [];
        foreach ($res as $key => $val) {
            $selectOption[$val['key']] = $val['val'];
        }
        return $selectOption;
    }

    public function getRelatedBuIds() {
        $res = null;
        $buArr = $this->container->get('izmo_user_security_info.user_security_provider')->getBuRelatedToLoggedUser();
        if (!(empty($buArr))) {
            foreach ($buArr as $key => $val) {
                $buIds[] = $val->getId();
            }
            $res = implode(',', $buIds);
        }
        return $res;
    }

    /**
     * Get Owner BuId Of Usr Logged In
     * @return type
     */
    public function getOwnerBuIdOfUsrLoggedIn() {
        return $this->container->get('izmo_user_security_info.user_security_provider')->getLoggedInUsr()->getOwner()->getId();
    }

    /**
     * Get organization of logged in user
     * @return type
     */
    public function getOrganizationOfUsrLoggedIn() {
        return $this->container->get('oro_security.security_facade')->getOrganization()->getId();
    }

    public function formatDate($date) {
        $localeSettings = $this->container->get('oro_locale.settings');
        return $this->container->get('oro_locale.formatter.date_time')->formatDate($date, null, $localeSettings->getLocale(), $localeSettings->getTimeZone());
    }

    /**
     * Get User Sales Category Types For Bu
     * @return array
     */
    public function getUserSalesCategoryTypesForBu() {
        try {
            $orgId = $this->container->get('oro_security.security_facade')->getOrganization()->getId();
            $buId = $this->container->get('izmo_user_security_info.user_security_provider')->getLoggedInUsr()->getOwner()->getId();
            $userSalesCategories = $this->getReportConfigRepository()->getUserSalesCategoryTypesForBu($buId, $orgId);            
            $categories = [];
            foreach ($userSalesCategories as $k => $val) {
                $categories[$val['key']] = $val['val'];
            }        
            
            return $categories;
        } catch (\Exception $e) {
            $logger = $this->getLogger();
            $logger->crit('Exception occured in getUserSalesCategoryTypesForBu function of ReportsServiceProvider with exception info below:');
            $logger->crit($e);
            return null;
        }
    }

    /**
     * Get the categories Ids
     * @param array $params
     * @return string
     */
    public function getCategoryIds($params) {
        try {
            if (!(empty($params))) {
                if (((!(empty($params['bu_ids'])))) && (!(empty($params['product_type']))) && (!(empty($params['owner_bu'])))) {
                    $categoryType = $params['product_type'];
                    $ownerBu = $params['owner_bu'];
                    $buIds = $params['bu_ids'];
                    if ($buIds != (string) $ownerBu) {
                        $categoryTypeName = $this->getTypeForCategoryId(SELF::USER_SALES_CATEGORIES, $ownerBu, $categoryType);
                        return $this->getCategoryTypeForMultipleBuIds(SELF::USER_SALES_CATEGORIES, $buIds, $categoryTypeName);
                    } else {
                        return $categoryType;
                    }
                }
            } else {
                return null;
            }
        } catch (\Exception $e) {
            $logger = $this->getLogger();
            $logger->crit('Exception occured in getCategoryIds function of ReportsServiceProvider with exception info below:');
            $logger->crit($e);
            return null;
        }
    }

    /**
     * Get Type For the CategoryId
     * @param string $category
     * @param int $buId
     * @param int $catId
     * @return type
     */
    public function getTypeForCategoryId($category, $buId, $catId) {
        try {
            $categoryConfigObj = $this->getReportConfigRepository()->getCategoryTypeConfig($category, $buId);
            if (!empty($categoryConfigObj)) {
                $configVal = $categoryConfigObj->getConfigValue();
                $configValArr = json_decode($configVal, true);
                return $configValArr[$catId];
            }
        } catch (\Exception $e) {
            $logger = $this->getLogger();
            $logger->crit('Exception occured in getTypeForCategoryId function of ReportsServiceProvider with exception info below:');
            $logger->crit($e);
            return null;
        }
    }

    /**
     * Get Category Type For Multiple BuIds
     * @param string $category
     * @param string $buIds
     * @param string $type
     * @return string
     */
    public function getCategoryTypeForMultipleBuIds($category, $buIds, $type) {
        try {
            $buIdsArr = explode(',', $buIds);
            $configOb = $this->getReportRepository()->getCategoryTypeConfig($category, $buIdsArr, SELF::MULTIPLE_BU);
            $key = [];
            foreach ($configOb as $k => $val) {
                if (!empty($val)) {
                    $configVal = $val->getConfigValue();
                    $configValArr = json_decode($configVal, true);
                    $keySrchVal = array_search($type, $configValArr);
                    if (!(empty($keySrchVal))) {
                        $key[$k] = $keySrchVal;
                    }
                }
            }
            return implode(',', $key);
        } catch (\Exception $e) {
            $logger = $this->getLogger();
            $logger->crit('Exception occured in getCategoryTypeForMultipleBuIds function of ReportsServiceProvider with exception info below:');
            $logger->crit($e);
            return null;
        }
    }

}
