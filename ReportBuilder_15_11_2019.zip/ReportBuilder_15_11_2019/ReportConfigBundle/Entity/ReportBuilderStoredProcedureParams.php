<?php

namespace IZMO\ReportConfigBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\Config;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\ConfigField;
use Oro\Bundle\OrganizationBundle\Entity\Organization;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;

/**
 *
 * @ORM\Table(name="izmo_report_builder_stored_procedure_params") 
 * @ORM\Entity
 * @Config(
 *      defaultValues={
 *          "entity"={
 *              "icon"="",
 *          },
 *          "security"={
 *              "type"="ACL",
 *              "group_name"=""
 *          },
 *          "dataaudit"={
 *              "auditable"=true
 *          },
 *      }
 * )
 */
class ReportBuilderStoredProcedureParams {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
    
    /**
     * @var ReportBuilderStoredProcedure
     * @ORM\ManyToOne(targetEntity="IZMO\ReportConfigBundle\Entity\ReportBuilderStoredProcedure")
     * @ORM\JoinColumn(name="stored_procedure_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $storedProcedureId;
    
    /**
     * @var string
     *
     * @ORM\Column(name="parameter_name", type="string")
     */
    private $parameterName;
    
    /**
     * @var string
     *
     * @ORM\Column(name="display_name", type="string")
     */
    private $displayName;
    
    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string")
     */
    private $type;
    
    /**
     * @var string
     *
     * @ORM\Column(name="size", type="integer",nullable=true)
     */
    private $size;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId() {
        return $this->id;
    }

    
    /**
     * Set Stored Procedure name
     *
     * @param string  $spName
     *
     * @return ReportBuilderStoredProcedure
     */
    public function setStoredProcedureId($storedProcedureId) {
        $this->storedProcedureId = $storedProcedureId;
        return $this;
    }

    /**
     * Get Stored Procedure name
     *
     * @return string
     */
    public function getStoredProcedureId() {
        return $this->storedProcedureId;
    }

    /**
     * Set Display Name
     *
     * @param string  $displayName
     *
     * @return ReportBuilderStoredProcedure
     */
    public function setDisplayName($displayName) {
        $this->displayName = $displayName;
        return $this;
    }

    /**
     * Get Display Name
     *
     * @return string
     */
    public function getDisplayName() {
        return $this->displayName;
    }

    /**
     * Set parameter data type
     *
     * @param string  $type
     *
     * @return StoredProcedureParameter
     */
    public function setType($type) {
        $this->type = $type;

        return $this;
    }

    /**
     * Get parameter data type
     *
     * @return string
     */
    public function getType() {
        return $this->type;
    }        
    
    /**
     * Set parameter data size
     *
     * @param string  $size
     *
     * @return StoredProcedureParameter
     */
    public function setSize($size) {
        $this->size = $size;

        return $this;
    }

    /**
     * Get parameter data size
     *
     * @return string
     */
    public function getSize() {
        return $this->size;
    }
    
    /**
     * Set Parameter Name
     *
     * @param string  $parameterName
     *
     * @return StoredProcedureParameter
     */
    public function setParameterName($parameterName) {
        $this->parameterName = $parameterName;

        return $this;
    }

    /**
     * Get Parameter Name
     *
     * @return string
     */
    public function getParameterName() {
        return $this->parameterName;
    }


}
