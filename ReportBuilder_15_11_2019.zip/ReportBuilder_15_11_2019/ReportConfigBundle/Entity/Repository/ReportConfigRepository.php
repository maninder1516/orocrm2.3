<?php

namespace IZMO\ReportConfigBundle\Entity\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;
use Oro\Bundle\SecurityBundle\ORM\Walker\AclHelper;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use IZMO\ReportAccessControlBundle\Exception\CustomException;
use IZMO\ReportConfigBundle\Entity\ReportConfig;
use IZMO\ExtendSecurityBundle\Entity\VirtualAclClasses;
use IZMO\ReportConfigBundle\Entity\ReportYmlConfig;
use Oro\Bundle\NavigationBundle\Exception\NotFoundParentException;
use Oro\Bundle\NavigationBundle\Entity\MenuUpdate;
use IZMO\ExtendSecurityBundle\Entity\VirtualAclRoleInfo;
use IZMO\ReportConfigBundle\Utils\ReportConfigConstants;
use IZMO\ReportConfigBundle\Entity\ReportBuilderReportStoredProcedureParamMapper;

class ReportConfigRepository extends EntityRepository {

    /**
     * Get the enity manager preapre handler.
     */
    public function getEntityMgrPrepareHandler($qry) {
        return $this->getEntityManager()->getConnection()->prepare($qry);
    }

    /**
     *  Get Reports Access Check
     */
    public function getReportsAccessCheck($userRoles, $perm, $aclClassId) {
        if (count($userRoles) > 1) {
            $userRoles = implode(',', $userRoles);
            $qry = "call checkReportAccessByRoles('$userRoles','$perm',$aclClassId,1)";
        } else {
            $qry = "call checkReportAccessByRoles($userRoles[0],'$perm',$aclClassId,0)";
        }
        $qryPrepare = $this->getEntityMgrPrepareHandler($qry);
        $qryPrepare->execute();
        $res = $qryPrepare->fetch();

        return $res;
    }

    /**
     *  Get Report Acl Permission Information.
     */
    public function getReportAclPermissionInfo($url) {
        $em = $this->getEntityManager();
        $reportConfigArr = [];
        $reportConfigObj = $em->getRepository("IZMOReportConfigBundle:ReportConfig")->findOneBy(array('url' => $url));
        if (!(empty($reportConfigObj))) {
            $reportConfigArr['acl_class_id'] = $reportConfigObj->getAclClassId();
            $reportConfigArr['permission_type'] = $reportConfigObj->getPermissionType();
        }
        return $reportConfigArr;
    }

    /**
     * 
     * @param array $binding
     * @param string $storedProcName
     * @param string $primaryKeyColForCnt
     * @param boolean $flg
     * @param array $params
     * @param int $isStart
     * @return boolean
     */
    public function fetchResultForQueryParams($storedProcName, $params) {
        $result = array();
        $result['err_flg'] = 0;
        try {
            $spParams = $params['sp_params'];
            $pkInfo = null;
            $sql = $this->prepareQry("call $storedProcName(", $spParams);
            $sql = $sql . ")";

            $stmt = $this->getEntityMgrPrepareHandler($sql);
            $stmt = $this->prepareParams($stmt, $spParams);
            $stmt->execute();
        } catch (\Exception $e) {
            $logger = $GLOBALS['kernel']->getContainer()->get('logger');
            $logger->crit("Error Occured while executing stored procedure with exception details below");
            $logger->crit($e);
            $result['err_flg'] = 1;
            return $result;
        }
        $res = $stmt->fetchAll();
        $stmt->closeCursor();
        $cntQry = $this->getEntityMgrPrepareHandler("SELECT FOUND_ROWS() as cnt");
        $cntQry->execute();
        $cnt = $cntQry->fetch();
        $cntQry->closeCursor();
        $result['res'] = (!(empty($res))) ? $res : null;
        $result['cnt'] = (!(empty($cnt))) ? $cnt : 0;
        return $result;
    }

    /**
     * Build Query string with params[] 
     * @param string $qry
     * @param array $params
     * @return string
     */
    public function prepareQry($qry, $params) {
        foreach ($params as $k => $val) {
            if ((isset($val[ReportConfigConstants::CONTEXT_TYPE]))) {
                $parameterizedStrArr[$k] = ReportConfigConstants::BIND_CONTEXT . $k;
            } elseif ((isset($val[ReportConfigConstants::FILTER_TYPE]))) {
                $parameterizedStrArr[$k] = ReportConfigConstants::BIND_FILTER . $k;
            } elseif ((isset($val[ReportConfigConstants::PK_TYPE]))) {
                $parameterizedStrArr[$k] = ReportConfigConstants::BIND_PRIMARY_KEY . $k;
            } elseif ((isset($val[ReportConfigConstants::EXTRA_TYPE]))) {
                $parameterizedStrArr[$k] = ReportConfigConstants::BIND_EXTRA_PARAM . $k;
            }
        }
        $qry .= implode(',', $parameterizedStrArr);
        return $qry;
    }

    public function prepareParams($stmt, $params) {
        foreach ($params as $key => $val) {
            if ((isset($val[ReportConfigConstants::FILTER_TYPE]))) {
                $filtr = $this->prepareParamBindVals(ReportConfigConstants::FILTER_TYPE, $val);
                $stmt->bindValue(ReportConfigConstants::BIND_FILTER . $key, $filtr);
            } elseif ((isset($val[ReportConfigConstants::CONTEXT_TYPE]))) {
                $filtr = $this->prepareParamBindVals(ReportConfigConstants::CONTEXT_TYPE, $val);
                $stmt->bindValue(ReportConfigConstants::BIND_CONTEXT . $key, $filtr);
            } elseif ((isset($val[ReportConfigConstants::EXTRA_TYPE]))) {
                $filtr = $this->prepareParamBindVals(ReportConfigConstants::EXTRA_TYPE, $val);
                $stmt->bindValue(ReportConfigConstants::BIND_EXTRA_PARAM . $key, $filtr);
            } elseif ((isset($val[ReportConfigConstants::PK_TYPE]))) {
                $filtr = $this->prepareParamBindVals(ReportConfigConstants::PK_TYPE, $val);
                $stmt->bindValue(ReportConfigConstants::BIND_PRIMARY_KEY . $key, $filtr);
            }
        }
        return $stmt;
    }

    public function prepareParamBindVals($type, $val) {
        $filtr = $val[$type];
        if ((!(empty($val['data_type'])))) {
            if ($val['data_type'] == 'string') {
                $filtr = addslashes($val[$type]);
            } elseif (($val['data_type'] == 'date')) { // date-filter handling
                if (gettype($val[$type]) == 'array') {
                    // TO TEST SCENARIO
                    if (!empty($val[$type])) {
                        if ((!(empty($val[$type][0]))) && (!(empty($val[$type][1])))) {
                            $filtr = implode(',', $val[$type]);
                        } else {
                            $filtr = 'none';
                        }
                    }
                } else {
                    if ($val[$type] == 'none') {
                        $filtr = NULL;
                    } else {
                        $filtr = ($val[$type]);
                    }
                }
            }
        }
        return $filtr;
    }

    public function getDataSourceResultByStoredProcedure($spName, $spParams = NULL) {
        $qryParam = $this->getEntityMgrPrepareHandler("call $spName");
        $qryParam->execute();
        return $qryParam->fetchAll();
    }

    /**
     * This function returns array required for Excel Export 
     * @param string $procedureSelected
     * @param array $params
     * @return array
     */
    public function getReportExportDataForParameters($procedureSelected, $params) {
        try {
            return $this->getQueryResultForParamsToExport("call $procedureSelected (", $params);
        } catch (\Exception $e) {
            return array('err' => 1);
        }
    }

    /**
     *  Get Query Result For Params To Export
     */
    public function getQueryResultForParamsToExport($qry, $params) {
        if (!(empty($params))) {
            $paramCnt = count($params);
            for ($i = 0; $i < $paramCnt; $i++) {
                $parameterizedStrArr[$i] = ReportConfigConstants::BIND_FILTER . $i;
            }
            $qry .= implode(',', $parameterizedStrArr) . ")";
            $qryHandler = $this->getEntityMgrPrepareHandler($qry);
            $j = 0;
            foreach ($params as $key => $val) {
                $filtr = $val['filter'];
                if ((!(empty($val['data_type']))) && ($val['data_type'] == 'string')) {
                    $filtr = addslashes($val['filter']);
                }
                $qryHandler->bindValue(ReportConfigConstants::BIND_FILTER . $j, $filtr);
                $j++;
            }
            $qryHandler->execute();
            $res = $qryHandler->fetchAll();
            $qryHandler->closeCursor();
            return $res;
        }
    }

    //HANDLING CUSTOM MENUS -- to be moved to Navigation Repository.
    public function createCustomMenusForReports($menuName, $options) {
        $container = $GLOBALS['kernel']->getContainer();

        //code inside ref from MenuUpdateManager (vendor/oro/platform/src/Oro/Bundle/NavigationBundle/Manager/MenuUpdateManager)
        $menu = $container->get('izmo_extend_navigation_bundle.provider.navigation_menu')->getMenu($menuName, []);

        /** @var MenuUpdateInterface $entity */
        $entity = new MenuUpdate();
        $em = $this->getEntityManager();
        if (isset($options['key'])) {
            $item = $container->get('izmo_extend_navigation_bundle.provider.navigation_menu')->findMenuItem($menu, $options['key']);  // to check if item is present in non custom menu.
            if (!($item)) {
                $existingObj = $em->getRepository("OroNavigationBundle:MenuUpdate")->findOneBy(array('key' => $options['key']));
                if (!($existingObj)) {
                    $entity->setKey($options['key']);
                    $entity->setMenu($menu->getName());
                    if (isset($options['parentKey'])) {
                        $parent = $container->get('izmo_extend_navigation_bundle.provider.navigation_menu')->findMenuItem($menu, $options['parentKey']);
                        if (!$parent) {
                            throw new NotFoundParentException(
                            sprintf('Parent with "%s" parentKey not found.', $options['parentKey'])
                            );
                        }
                        $entity->setParentKey($options['parentKey']);
                    }

                    if (isset($options['isDivider']) && $options['isDivider']) {
                        $entity->setDivider(true);
                        $entity->setDefaultTitle(MenuUpdateTreeHandler::MENU_ITEM_DIVIDER_LABEL);
                        $entity->setUri('#');
                    }
                    if (isset($options['default_title'])) {
                        $entity->setDefaultTitle($options['default_title']);
                    }

                    if ($options['uri']) {
                        $entity->setUri($options['uri']);
                    }
                    if (isset($options['scope'])) {
                        $entity->setScope($options['scope']);
                    }
                    $entity->setCustom(true);
                    $entity->setIsReportMenu(true);
                    $em->persist($entity);

                    $em->flush();
                    return $entity;
                } else {
                    return ['error' => 1]; // key already exists
                }
            } else {
                return ['error' => 1]; // key already exists in Main Menu
            }
        }
    }

    //
    public function findMenuItemsExcludingCustomReportsForMenuReset($menuName, $scope) {
        $qb = $this->getEntityManager()->createQueryBuilder();

        return $qb->select(['u', 'titles', 'descriptions'])
                        ->from("OroNavigationBundle:MenuUpdate", 'u')
                        ->leftJoin('u.titles', 'titles')
                        ->leftJoin('u.descriptions', 'descriptions')
                        ->where($qb->expr()->eq('u.menu', ':menuName'))
                        ->andWhere($qb->expr()->eq('u.scope', ':scope'))
                        ->andWhere('u.is_report_menu is null')
                        ->orWhere($qb->expr()->eq('u.is_report_menu', ':not_report_menu'))
                        ->orderBy('u.id')
                        ->setParameters([
                            'menuName' => $menuName,
                            'scope' => $scope,
                            'not_report_menu' => 0
                        ])
                        ->getQuery()
                        ->getResult();
    }

    public function resetCustomReportsPosition() {
        $em = $this->getEntityManager();
        $menuUpdateObj = $em->getRepository("OroNavigationBundle:MenuUpdate")->findBy(array('is_report_menu' => 1));
        if (!(empty($menuUpdateObj))) {
            foreach ($menuUpdateObj as $k => $val) {
                $val->setPriority(NULL);
                $em->persist($val);
            }
            $em->flush();
        }
    }

    /**
     *  Process Report Configuration
     */
    public function processReportConfiguration(ReportConfig $reportConfig) {
        $em = $this->getEntityManager();
        $em->persist($reportConfig);
        $em->flush();
        return $reportConfig;
    }

    /**
     *  Generate Virtual Acl Class
     */
    public function generateVirtualAclClass($reportConfig) {
        $className = $reportConfig->getReportTitle();
        $classType = preg_replace("([- ]+)", "_", ReportConfigConstants::VIRTUAL_PREFIX_TYPE . $reportConfig->getUrl());
        $em = $this->getEntityManager();
        $virAclClass = new VirtualAclClasses();
        $virAclClass->setClassName($className);
        $virAclClass->setClassType($classType);

        $em->persist($virAclClass);
        $em->flush();
        return $virAclClass;
    }

    /**
     *  Process Stored Procedure Info
     */
    public function processStoredProcedureInfo(ReportConfig $reportConfig) {
        $em = $this->getEntityManager();
        $em->persist($reportConfig);
        $em->flush();
        return $reportConfig;
    }

    public function getStoredProceduresForReportConfig() {
        $qryPrepare = $this->getEntityMgrPrepareHandler("CALL getStoredProceduresDetails ()");
        $qryPrepare->execute();
        $res = $qryPrepare->fetchAll();
        $qryPrepare->closeCursor();
        $responseArray = array();
        foreach ($res as $sp) {
            $responseArray[] = array(
                "id" => $sp['id'],
                "name" => $sp['display_name']
            );
        }

        return $responseArray;
    }

    /**
     *  Process Report Yml Configuration
     */
    public function processReportYmlConfiguration(ReportYmlConfig $reportYmlConfig) {
        $em = $this->getEntityManager();
        $em->persist($reportYmlConfig);
        $em->flush();
        return $reportYmlConfig;
    }

    /**
     *  Process Virtual ACL Role Information
     */
    public function processVirtualAclRoleInfo($rolesSelected, $virtualAclId) {
        try {
            $em = $this->getEntityManager();
            $virtualAclObj = $em->getRepository("IZMOExtendSecurityBundle:VirtualAclClasses")->find($virtualAclId);
            //DELETE IF ROLE REMOVED
            $virtualAclRolePermissionDeletion = $em->getRepository("IZMOExtendSecurityBundle:VirtualAclRoleInfo")->findBy(array('aclClassId' => $virtualAclId));
            foreach ($virtualAclRolePermissionDeletion as $k => $v) {
                if (is_array($rolesSelected)) {
                    if (!(in_array($v->getRoleId(), $rolesSelected))) {
                        $v->setView(0);
                        $em->persist($v);
                        $em->flush();
                    }
                } else {
                    if ($v->getRoleId() != $rolesSelected) {
                        $v->setView(0);
                        $em->persist($v);
                        $em->flush();
                    }
                }
            }
            if ($rolesSelected) {
                foreach ($rolesSelected as $roleSel) {
                    $isVirtualAclRoleExist = $em->getRepository("IZMOExtendSecurityBundle:VirtualAclRoleInfo")->findOneBy(array('roleId' => $roleSel, 'aclClassId' => $virtualAclId));
                    if (!(empty($isVirtualAclRoleExist))) {
                        $isVirtualAclRoleExist->setView(1);
                        $em->persist($isVirtualAclRoleExist);
                    } elseif (empty($isVirtualAclRoleExist)) {
                        $virtualAclRole = new VirtualAclRoleInfo();
                        $roleObj = $em->getRepository("OroUserBundle:Role")->find($roleSel);
                        $virtualAclRole->setAclClassId($virtualAclObj);
                        $virtualAclRole->setRoleId($roleObj);
                        $virtualAclRole->setAssign(0);
                        $virtualAclRole->setView(1);
                        $virtualAclRole->setCreate(0);
                        $virtualAclRole->setDelete(0);
                        $virtualAclRole->setEdit(0);
                        $em->persist($virtualAclRole);
                    }
                }
                $em->flush();
            }
        } catch (\Exception $e) {
            return ['err' => 1, 'err_info' => $e];
        }
    }

    /**
     *  Get the Virtual Acl Class
     */
    public function getVirtualAclClass($virtualAclId) {
        $em = $this->getEntityManager();
        $virtualAclObj = $em->getRepository("IZMOExtendSecurityBundle:VirtualAclClasses")->find($virtualAclId);

        return $virtualAclObj;
    }

    /**
     *  Get the Virtual Acl Class With class Name
     */
    public function getVirtualAclClassWithName($aclClassName) {
        $em = $this->getEntityManager();
        $virtualAclObj = $em->getRepository("IZMOExtendSecurityBundle:VirtualAclClasses")->findOneBy([
            'className' => $aclClassName
        ]);

        return $virtualAclObj;
    }

    /**
     *  Get the Selected Roles
     */
    public function getSelectedRoles($virtualAclId) {
        $em = $this->getEntityManager();
        $aclRoleInfo = $em->getRepository("IZMOExtendSecurityBundle:VirtualAclRoleInfo")->findBy(array('aclClassId' => $virtualAclId, 'view' => 1));
        $aclRoleInfoArr = [];
        if (!(empty($aclRoleInfo))) {
            foreach ($aclRoleInfo as $k => $val) {
                $aclRoleInfoArr[] = $val->getRoleId()->getId();
            }
        }
        return array_values($aclRoleInfoArr);
    }

    /**
     *  Get the Report Name.
     */
    public function getReportName($url) {
        $em = $this->getEntityManager();
        $res = $em->getRepository("IZMOReportConfigBundle:ReportConfig")->findOneBy(array('url' => $url));
        $resp = (!(empty($res))) ? 1 : 0; //if the given url matched means it will return response as 1 or else 0
        return $resp;
    }

    public function mapYmlConfigToSPparam($spParam, $ymlConfig, $reportConfigId, $noSpChanges) {
        $em = $this->getEntityManager();
        if (count($spParam) == count($ymlConfig)) {
            if ($noSpChanges == 0) {
                $paramObj = $em->getRepository("IZMOReportConfigBundle:ReportBuilderReportStoredProcedureParamMapper")->findBy(array('reportConfigId' => $reportConfigId));
                if (!(empty($paramObj))) {
                    foreach ($paramObj as $key => $val) {
                        $em->remove($val);
                    }
                }
                $em->flush();
            }
            $reportConfigObj = $em->getRepository("IZMOReportConfigBundle:ReportConfig")->find($reportConfigId);
            foreach ($spParam as $k => $val) {
                $spParamMapObj = $em->getRepository("IZMOReportConfigBundle:ReportBuilderReportStoredProcedureParamMapper")->findOneBy(array('reportConfigId' => $reportConfigId, 'storedProcedureParamsId' => $val));
                if (!(empty($spParamMapObj))) {
                    if ($spParamMapObj->getReportParam() != $ymlConfig[$k]) {
                        $spParamMapObj->setReportParam($ymlConfig[$k]);
                        $em->persist($spParamMapObj);
                        $em->flush();
                    }
                } else {
                    $spParamMapObj = new ReportBuilderReportStoredProcedureParamMapper();
                    $spParamObj = $em->getRepository("IZMOReportConfigBundle:ReportBuilderStoredProcedureParams")->find($val);

                    $spParamMapObj->setReportConfigId($reportConfigObj);
                    $spParamMapObj->setReportParam($ymlConfig[$k]);
                    $spParamMapObj->setStoredProcedureParamsId($spParamObj);
                    $em->persist($spParamMapObj);
                    $em->flush();
                }
            }
        } else {
            return false;
        }
    }

    public function mapStoredProcedureToReportId($spId, $reportConfigObj) {
        $noSpMappedChanges = 0;

        $reportConfigId = $reportConfigObj->getId();
        $qryPrepare = $this->getEntityMgrPrepareHandler("CALL getStoredProcMappedToReport($reportConfigId)");
        $qryPrepare->execute();
        $res = $qryPrepare->fetch();
        $qryPrepare->closeCursor();
        if (!(empty($res['reportconfig_id']))) {
            if ($res['reportbuilderstoredprocedure_id'] != $spId) {
                $updateReport = $this->getEntityMgrPrepareHandler("CALL updateStoredProcedureForReport($spId,$reportConfigId)");
                $updateReport->execute();
                $updateReport->closeCursor();
            } else {
                $noSpMappedChanges = 1;
            }
        } else {
            $insertQry = $this->getEntityMgrPrepareHandler("CALL addStoredProcedureForReport($spId,$reportConfigId)");
            $insertQry->execute();
            $insertQry->closeCursor();
        }
        return $noSpMappedChanges;
    }

    public function getRolesForReportConfiguration() {// PENDING : Control based on User.
        $qryPrepare = $this->getEntityMgrPrepareHandler("select id,label from oro_access_role");
        $qryPrepare->execute();
        $res = $qryPrepare->fetchAll();
        $qryPrepare->closeCursor();
        $roles = [];
        foreach ($res as $k => $val) {
            $roles[$val['id']] = $val['label'];
        }
        return $roles;
    }

    public function getStoredProcedureForReport($reportId) {
        $spQry = $this->getEntityMgrPrepareHandler("CALL getStoredProcedureDetailsForReport($reportId)");
        $spQry->execute();
        $res = $spQry->fetch();
        $spQry->closeCursor();
        if (!(empty($res))) {
            $spConfig['id'] = $res['id'];
            $spConfig['sp_name'] = $res['sp_name'];
        }
        return $spConfig['id'];
    }

    public function getReportsConfigurationFromDb($url) {
        $reportOb = $this->getEntityManager()->getRepository("IZMOReportConfigBundle:ReportConfig")->findOneBy(array('url' => $url));
        $reportId = $reportOb->getId();
        $reportTemplateObj = $this->getEntityManager()->getRepository("IZMOReportConfigBundle:ReportTemplate")->find($reportOb->getReportTemplateId());
        $reportYmlConfigObj = $this->getEntityManager()->getRepository("IZMOReportConfigBundle:ReportYmlConfig")->findOneBy(array('reportConfigId' => $reportId));
        $yaml = new \Symfony\Component\Yaml\Parser();
        $dataConfig = $yaml->parse($reportYmlConfigObj->getYmlConfigContent());
        $config = [];
        $config = $dataConfig['config'];
        if (!(empty($reportTemplateObj))) {
            $config['template_provider']['template_path'] = $reportTemplateObj->getTemplatePath();
            $config['template_provider']['template_class'] = $reportTemplateObj->getTemplateClass();
        }

        $spQry = $this->getEntityMgrPrepareHandler("CALL getStoredProcedureDetailsForReport($reportId)");
        $spQry->execute();
        $res = $spQry->fetch();
        $spQry->closeCursor();

        if (!(empty($res))) {
            $spConfig['id'] = $res['id'];
            $spConfig['sp_name'] = $res['sp_name'];
            $config['sp_config'] = $spConfig;
        }

        $spId = $spConfig['id'];
        $spParamQry = $this->getEntityMgrPrepareHandler("CALL getReportParamMappedToStoredProcedure($spId,$reportId)");
        $spParamQry->execute();
        $spParamConfig = $spParamQry->fetch();
        $config['sp_param_config'] = $spParamConfig;
        $spParamQry->closeCursor();
        return $config;
    }

    public function getParamValFromStoredProc($qry, $params = NULL, $singleResultSet = NULL) {
        if (!(empty($params))) {
            $parameterizedStrArr = [];
            $paramCnt = count($params);
            for ($i = 0; $i < $paramCnt; $i++) {
                $parameterizedStrArr[$i] = ReportConfigConstants::BIND_FILTER . $i;
            }
            $qry .= implode(',', $parameterizedStrArr) . ")";
            $qryHandler = $this->getEntityMgrPrepareHandler($qry);
            $j = 0;
            foreach ($params as $key => $val) {
                $filtr = $val['filter'];
                if ((!(empty($val['data_type']))) && ($val['data_type'] == 'string')) {
                    $filtr = addslashes($val['filter']);
                }
                $qryHandler->bindValue(ReportConfigConstants::BIND_FILTER . $j, $filtr);
                $j++;
            }
            $qryHandler->execute();

            $res = (!(empty($singleResultSet))) ? $qryHandler->fetch() : $qryHandler->fetchAll();

            $qryHandler->closeCursor();
            return $res;
        } else {
            $qry .= ")";
            $qryHandler = $this->getEntityMgrPrepareHandler($qry);
            $qryHandler->execute();
            $res = (!(empty($singleResultSet))) ? $qryHandler->fetch() : $qryHandler->fetchAll();
            $qryHandler->closeCursor();
            return $res;
        }
    }

    /**
     * Get Category Type Config
     * @param string $category
     * @param string $buIds
     * @param int $multipleBu
     * @return array
     */
    public function getCategoryTypeConfig($category, $buIds, $multipleBu = 0) {
        if (!(empty($multipleBu))) {
            return $this->getEntityManager()->getRepository('IZMOCustomConfigBundle:CustomConfig')->findBy(array('configLabel' => $category, 'owner' => $buIds));
        } else {
            return $this->getEntityManager()->getRepository('IZMOCustomConfigBundle:CustomConfig')->findOneBy(array('configLabel' => $category, 'owner' => $buIds));
        }
    }

    /**
     * Get User Sales Category Types ForBu
     * @param int $buId
     * @param int $orgId
     * @return array
     */
    public function getUserSalesCategoryTypesForBu($buId, $orgId) {        
        return $this->getEntityManager()->createQuery("SELECT iusct.id as key, iusct.type as val from IZMOUserTargetBundle:UserSalesCategoryType  iusct where iusct.owner = $orgId and iusct.businessunit = $buId")->getResult();               
    }

}
