<?php

namespace IZMO\ReportConfigBundle\Entity\Repository;

use Doctrine\ORM\EntityRepository;
use IZMO\ReportConfigBundle\Entity\ReportTemplate;

class ReportTemplateRepository extends EntityRepository {
    
    const TEMPLATE_IS_ACTIVE = 1;


    /**
     *  Process Report Template
     */
    public function processReportTemplate(ReportTemplate $reportTemplate) {
        $em = $this->getEntityManager();
        $em->persist($reportTemplate);
        $em->flush();
        return $reportTemplate;
    }
    
     /**
     *  Get the Templates
     */
    public function getTemplates() {
        $templateObj = $this->getEntityManager()->getRepository("IZMOReportConfigBundle:ReportTemplate")->findBy(array('isActive'=>1));
        $res = [];
        if(!(empty($templateObj))){
            foreach($templateObj as $k=>$val){
                $res[$k]['id'] = $val->getId();
                $res[$k]['template_name'] = $val->getTemplateName();
            }
        }

        return $res;
    }

}
