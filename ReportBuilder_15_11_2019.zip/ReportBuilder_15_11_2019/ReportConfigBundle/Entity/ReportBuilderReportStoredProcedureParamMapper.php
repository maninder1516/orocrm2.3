<?php

namespace IZMO\ReportConfigBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\Config;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\ConfigField;
use Oro\Bundle\OrganizationBundle\Entity\Organization;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;

/**
 *
 * @ORM\Table(name="izmo_report_builder_report_stored_procedure_param_mapper") 
 * @ORM\Entity
 * @Config(
 *      defaultValues={
 *          "entity"={
 *              "icon"="",
 *          },
 *          "security"={
 *              "type"="ACL",
 *              "group_name"=""
 *          },
 *          "dataaudit"={
 *              "auditable"=true
 *          },
 *      }
 * )
 */
class ReportBuilderReportStoredProcedureParamMapper {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
    
    /**
     * @var ReportBuilderStoredProcedureParams
     * @ORM\ManyToOne(targetEntity="IZMO\ReportConfigBundle\Entity\ReportBuilderStoredProcedureParams")
     * @ORM\JoinColumn(name="stored_procedure_param_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $storedProcedureParamsId;
    
     /**
     * @var ReportConfig
     * @ORM\ManyToOne(targetEntity="IZMO\ReportConfigBundle\Entity\ReportConfig")
     * @ORM\JoinColumn(name="report_config_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $reportConfigId;
    
    /**
     * @var string
     *
     * @ORM\Column(name="report_param_map", type="string")
     */
    private $reportParamMap;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Set ReportConfigId
     *
     * @param string  $spName
     *
     * @return ReportBuilderReportStoredProcedureParamMapper
     */
    public function setReportConfigId($reportConfigId) {
        $this->reportConfigId = $reportConfigId;
        return $this;
    }

    /**
     * Get ReportConfigId
     *
     * @return string
     */
    public function getReportConfigId() {
        return $this->reportConfigId;
    }
    
    /**
     * Set Stored Procedure name
     *
     * @param string  $spName
     *
     * @return ReportBuilderReportStoredProcedureParamMapper
     */
    public function setStoredProcedureParamsId($storedProcedureParamsId) {
        $this->storedProcedureParamsId = $storedProcedureParamsId;
        return $this;
    }

    /**
     * Get Stored Procedure name
     *
     * @return string
     */
    public function getStoredProcedureParamsId() {
        return $this->storedProcedureParamsId;
    }

    
    
    /**
     * Set Parameter Name
     *
     * @param string  $parameterName
     *
     * @return ReportBuilderReportStoredProcedureParamMapper
     */
    public function setReportParam($reportParamMap) {
        $this->reportParamMap = $reportParamMap;

        return $this;
    }

    /**
     * Get Parameter Name
     *
     * @return string
     */
    public function getReportParam() {
        return $this->reportParamMap;
    }


}
