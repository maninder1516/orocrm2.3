<?php

namespace IZMO\ReportConfigBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\Config;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\ConfigField;
use Oro\Bundle\OrganizationBundle\Entity\Organization;

/**
 *
 * @ORM\Table(name="izmo_report_builder_configurations") 
 * @ORM\Entity(repositoryClass="IZMO\ReportConfigBundle\Entity\Repository\ReportConfigRepository")
 * @Config(
 *      defaultValues={
 *          "entity"={
 *              "icon"="",
 *          },
 *          "ownership"={
 *              "owner_type"="ORGANIZATION",
 *              "owner_field_name"="owner",
 *              "owner_column_name"="owner_id"
 *          },
 *          "security"={
 *              "type"="ACL",
 *              "group_name"=""
 *          },
 *          "dataaudit"={
 *              "auditable"=true
 *          },
 *      }
 * )
 */
class ReportConfig {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="url", type="string")
     */
    private $url;

    /**
     * @var string
     *
     * @ORM\Column(name="report_title", type="string")
     */
    private $reportTitle;

    /**
     * @var VirtualAclClasses
     * @ORM\ManyToOne(targetEntity="IZMO\ExtendSecurityBundle\Entity\VirtualAclClasses")
     * @ORM\JoinColumn(name="acl_class_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $aclClassId;

    /**
     * @var integer
     *
     * @ORM\Column(name="report_template_id", type="integer")
     */
    private $reportTemplateId;

    

    /**
     * @var string
     *
     * @ORM\Column(name="permission_type", type="string")
     */
    private $permissionType;

    /**
     * @var Organization
     * @ORM\ManyToOne(targetEntity="Oro\Bundle\OrganizationBundle\Entity\Organization")
     * @ORM\JoinColumn(name="owner_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $owner;
    
    /**
     * Stored Procedures 
     *
     * @var ArrayCollection $storedProcedures
     *
     * @ORM\ManyToMany(targetEntity="IZMO\ReportConfigBundle\Entity\ReportBuilderStoredProcedure", mappedBy="reportConfig")
     * @ORM\JoinTable(name="izmo_report_builder_report_stored_proc_mapper")
     */
    private $storedProcedures;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Set Url
     *
     * @param string  $url
     *
     * @return ReportConfig
     */
    public function setUrl($url) {
        $this->url = $url;

        return $this;
    }

    /**
     * Get Url
     *
     * @return string
     */
    public function getUrl() {
        return $this->url;
    }

    /**
     * Set ReportTitle
     *
     * @param string  $reportTitle
     *
     * @return ReportConfig
     */
    public function setReportTitle($reportTitle) {
        $this->reportTitle = $reportTitle;

        return $this;
    }

    /**
     * Get ReportTitle
     *
     * @return string
     */
    public function getReportTitle() {
        return $this->reportTitle;
    }

    /**
     * Set AclClassId
     *
     * @param integer $aclClassId
     *
     * @return ReportConfig
     */
    public function setAclClassId($aclClassId) {
        $this->aclClassId = $aclClassId;

        return $this;
    }

    /**
     * Get AclClassId
     *
     * @return int
     */
    public function getAclClassId() {
        return $this->aclClassId;
    }

    /**
     * Set ReportTemplateId
     *
     * @param integer $reportTemplateId
     *
     * @return ReportConfig
     */
    public function setReportTemplateId($reportTemplateId) {
        $this->reportTemplateId = $reportTemplateId;

        return $this;
    }

    /**
     * Get ReportTemplateId
     *
     * @return integer
     */
    public function getReportTemplateId() {
        return $this->reportTemplateId;
    }

    /**
     * Set Permission Type
     *
     * @param string  $permissionType
     *
     * @return ReportConfig
     */
    public function setPermissionType($permissionType) {
        $this->permissionType = $permissionType;

        return $this;
    }

    /**
     * Get Permission Type
     *
     * @return string
     */
    public function getPermissionType() {
        return $this->permissionType;
    }

    /**
     * Set owner
     *
     * @param Organization $owner
     *
     * @return ReportConfig
     */
    public function setOwner($owner) {
        $this->owner = $owner;

        return $this;
    }

    /**
     * Get owner
     *
     * @return Organization
     */
    public function getOwner() {
        return $this->owner;
    }

}
