<?php

namespace IZMO\ReportConfigBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\Config;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\ConfigField;
use Oro\Bundle\OrganizationBundle\Entity\Organization;
use Oro\Bundle\OrganizationBundle\Entity\BusinessUnit;

/**
 *
 * @ORM\Table(name="izmo_report_builder_stored_procedures") 
 * @ORM\Entity
 * @Config(
 *      defaultValues={
 *          "entity"={
 *              "icon"="",
 *          },
 *          "security"={
 *              "type"="ACL",
 *              "group_name"=""
 *          },
 *          "dataaudit"={
 *              "auditable"=true
 *          },
 *      }
 * )
 */
class ReportBuilderStoredProcedure {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="stored_procedure", type="string")
     */
    private $storedProcedure;

    /**
     * @var string
     *
     * @ORM\Column(name="display_name", type="string")
     */
    private $displayName;    

    
    /**
     * promotions storage
     *
     * @var ArrayCollection $promotions
     *
     * @ORM\ManyToMany(targetEntity="IZMO\ReportConfigBundle\Entity\ReportConfig", inversedBy="storedProcedures")
     * @ORM\JoinTable(name="izmo_report_builder_report_stored_proc_mapper")
     */
    private $reportConfig;
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId() {
        return $this->id;
    }

    
    /**
     * Set Stored Procedure name
     *
     * @param string  $spName
     *
     * @return ReportBuilderStoredProcedure
     */
    public function setStoredProcedure($storedProcedure) {
        $this->storedProcedure = $storedProcedure;
        return $this;
    }

    /**
     * Get Stored Procedure name
     *
     * @return string
     */
    public function getStoredProcedure() {
        return $this->storedProcedure;
    }

    /**
     * Set Display Name
     *
     * @param string  $displayName
     *
     * @return ReportBuilderStoredProcedure
     */
    public function setDisplayName($displayName) {
        $this->displayName = $displayName;
        return $this;
    }

    /**
     * Get Display Name
     *
     * @return string
     */
    public function getDisplayName() {
        return $this->displayName;
    }    


}
