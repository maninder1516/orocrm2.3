<?php

namespace IZMO\ReportConfigBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\Config;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\ConfigField;
use Oro\Bundle\OrganizationBundle\Entity\Organization;

/**
 *
 * @ORM\Table(name="izmo_report_templates") 
 * @ORM\Entity(repositoryClass="IZMO\ReportConfigBundle\Entity\Repository\ReportTemplateRepository")
 * @Config(
 *      defaultValues={
 *          "entity"={
 *              "icon"="",
 *          },
 *          "security"={
 *              "type"="ACL",
 *              "group_name"=""
 *          },
 *          "dataaudit"={
 *              "auditable"=true
 *          },
 *      }
 * )
 */
class ReportTemplate {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="template_name", type="string")
     */
    private $templateName;
    
     /**
     * @var string
     *
     * @ORM\Column(name="template_class", type="string")
     */
    private $templateClass;

    /**
     * @var string
     *
     * @ORM\Column(name="template_path", type="string")
     */
    private $templatePath;

    /**
     * @var boolean
     * 
     * @ORM\Column(name="is_active", type="boolean")
     */
    private $isActive = true;

    /**
     * @var Organization
     * @ORM\ManyToOne(targetEntity="Oro\Bundle\OrganizationBundle\Entity\Organization")
     * @ORM\JoinColumn(name="owner_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $owner;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Set Template Name
     * 
     * @param string $templateName
     * 
     * @return ReportTemplate
     */
    public function setTemplateName($templateName) {
        $this->templateName = $templateName;
        return $this;
    }

    /**
     * Get Templat Name
     * 
     * @return string
     */
    public function getTemplateName() {
        return $this->templateName;
    }
    
            /**
     * Set Template Class
     * 
     * @param string $templateClass
     * 
     * @return ReportTemplate
     */
    public function setTemplateClass($templateClass) {
        $this->templateClass = $templateClass;
        return $this;
    }

    /**
     * Get Template Class
     * 
     * @return string
     */
    public function getTemplateClass() {
        return $this->templateClass;
    }

    /**
     * Set Template Name
     * 
     * @param string $templatePath
     * 
     * @return ReportTemplate
     */
    public function setTemplatePath($templatePath) {
        $this->templatePath = $templatePath;
        return $this;
    }

    /**
     * Get templatePath
     * 
     * @return string
     */
    public function getTemplatePath() {
        return $this->templatePath;
    }

    /**
     * Set Is Active
     * 
     * @param boolean $isActive
     * 
     * @return ReportTemplate
     */
    public function setIsActive($isActive) {
        $this->isActive = $isActive;
        return $this;
    }

    /**
     * Get isActive
     *
     * @return boolean
     */
    public function getIsActive() {
        return $this->isActive;
    }

    /**
     * Set owner
     *
     * @param Organization $owner
     *
     * @return ReportConfig
     */
    public function setOwner($owner) {
        $this->owner = $owner;

        return $this;
    }

    /**
     * Get owner
     *
     * @return Organization
     */
    public function getOwner() {
        return $this->owner;
    }

}
