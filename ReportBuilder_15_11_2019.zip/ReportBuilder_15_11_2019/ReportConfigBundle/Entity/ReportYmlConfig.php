<?php

namespace IZMO\ReportConfigBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\Config;
use Oro\Bundle\EntityConfigBundle\Metadata\Annotation\ConfigField;
use Oro\Bundle\OrganizationBundle\Entity\Organization;

/**
 *
 * @ORM\Table(name="izmo_report_yml_configurations") 
 * @ORM\Entity(repositoryClass="IZMO\ReportConfigBundle\Entity\Repository\ReportConfigRepository")
 * @Config(
 *      defaultValues={
 *          "entity"={
 *              "icon"="",
 *          },
 *          "ownership"={
 *              "owner_type"="ORGANIZATION",
 *              "owner_field_name"="owner",
 *              "owner_column_name"="owner_id"
 *          },
 *          "security"={
 *              "type"="ACL",
 *              "group_name"=""
 *          },
 *          "dataaudit"={
 *              "auditable"=true
 *          },
 *      }
 * )
 */
class ReportYmlConfig {

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="yml_config_content", type="text")
     */
    private $ymlConfigContent;

    /**
     * @var Organization
     * @ORM\ManyToOne(targetEntity="Oro\Bundle\OrganizationBundle\Entity\Organization")
     * @ORM\JoinColumn(name="owner_id", referencedColumnName="id", onDelete="SET NULL")
     */
    private $owner;

    /**
     * @ORM\ManyToOne(targetEntity="IZMO\ReportConfigBundle\Entity\ReportConfig")
     * @ORM\JoinColumn(name="report_config_id", referencedColumnName="id", onDelete="SET NULL") 
     */
    private $reportConfigId;
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Set YmlConfigContent
     *
     * @param string  $ymlConfigContent
     *
     * @return ReportYmlConfig
     */
    public function setYmlConfigContent($ymlConfigContent) {
        $this->ymlConfigContent = $ymlConfigContent;

        return $this;
    }

    /**
     * Get YmlConfigContent
     *
     * @return string
     */
    public function getYmlConfigContent() {
        return $this->ymlConfigContent;
    }

    /**
     * Set owner
     *
     * @param Organization $owner
     *
     * @return ReportYmlConfig
     */
    public function setOwner($owner) {
        $this->owner = $owner;

        return $this;
    }

    /**
     * Get owner
     *
     * @return Organization
     */
    public function getOwner() {
        return $this->owner;
    }
    
    public function setReportConfigId($reportConfigId){
        $this->reportConfigId = $reportConfigId;
        return $this;
    }
    
    public function getReportConfigId(){
        return $this->reportConfigId;
    }

}
