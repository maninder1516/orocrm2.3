<?php

namespace IZMO\ReportConfigBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IZMOReportConfigBundle extends Bundle
{
}
