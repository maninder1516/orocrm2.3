<?php
namespace IZMO\ReportConfigBundle\Utils;

class ReportConfigConstants {
  const CONTEXT_PREFIX_TYPE ='context:';
  const FILTER_PREFIX_TYPE = 'filter:';
  const EXTRA_PARAM_PREFIX_TYPE = 'extra:';
  const PRIMARY_KEY_PREFIX_TYPE = 'pk:';
  const BIND_CONTEXT = ':context';
  const BIND_FILTER = ':filter';
  const BIND_PRIMARY_KEY = ':pk';
  const BIND_EXTRA_PARAM = ':extra';
  const TEMPLATE_PATH = "IZMOReportConfigBundle:Reports:Templates\\";
  const CONTEXT_TYPE = 'context';
  const EXTRA_TYPE = 'extra';
  const PK_TYPE = 'pk';
  const FILTER_TYPE = 'filter';
  const VIRTUAL_PREFIX_TYPE = 'virtual:';
  const PHP_DATA_SRC_TYPE = 1;
  const STORED_PROCEDURE_DATA_SRC_TYPE = 2;
}
