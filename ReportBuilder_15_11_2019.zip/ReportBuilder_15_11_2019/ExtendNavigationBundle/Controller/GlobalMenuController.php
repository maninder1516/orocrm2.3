<?php

namespace Oro\Bundle\NavigationBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Oro\Bundle\NavigationBundle\Controller\GlobalMenuController as BaseGlobalMenuController;

/**
 * @Route("/menu/global")
 */
class GlobalMenuController extends BaseGlobalMenuController
{
}
