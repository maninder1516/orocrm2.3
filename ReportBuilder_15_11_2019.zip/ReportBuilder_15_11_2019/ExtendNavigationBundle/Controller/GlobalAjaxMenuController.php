<?php

namespace IZMO\ExtendNavigationBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Oro\Bundle\NavigationBundle\Controller\GlobalAjaxMenuController as BaseGlobalAjaxMenuController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * @Route("/menu/global")
 */
class GlobalAjaxMenuController extends BaseGlobalAjaxMenuController
{
    /**
     * @Route("/reset/{menuName}", name="oro_navigation_global_menu_ajax_reset")
     * @Method({"DELETE"})
     *
     * {@inheritdoc}
     */
    public function resetAction($menuName, Request $request)
    {
        
        $context = $this->getContextFromRequest($request);
        $this->checkAcl($context);
        $manager = $this->getMenuUpdateManager();
        $scope = $this->get('oro_scope.scope_manager')->find($manager->getScopeType(), $context);
        if (null === $scope) {
            return new JsonResponse(null, Response::HTTP_NO_CONTENT);
        }
        // replaced func -findMenuUpdatesByScope with findMenuItemsExcludingCustomReportsForMenuReset
        $updates = $this->getDoctrine()->getRepository("IZMOReportConfigBundle:ReportConfig")->findMenuItemsExcludingCustomReportsForMenuReset($menuName, $scope);
        $em = $this->getDoctrine()->getManagerForClass($manager->getEntityClass());
        foreach ($updates as $update) {
            $em->remove($update);
        }
        $em->flush($updates);
        $this->getDoctrine()->getRepository("IZMOReportConfigBundle:ReportConfig")->resetCustomReportsPosition();
        $this->dispatchMenuUpdateScopeChangeEvent($menuName, $context);
        return new JsonResponse(null, Response::HTTP_NO_CONTENT);
    }

    /**
     * @Route("/clear-menu/{menuName}", name="clear_menu_cache")
     *
     * {@inheritdoc}
     */
    public function clearMenuCacheAfterChngAction($menuName){
        $this->dispatchMenuUpdateScopeChangeEvent($menuName, []);
    }
    
    /**
     * @Route("/create-custom-menu", name="create_custom_menu")
     */
    public function createCustomMenuAction() {
        $menuName = 'application_menu';
        $key = 'REPORT AB123s 1';
        $parentKey = 'other_reports';
        $uri = '/report/demo_sample234';
        $defaultTitle = 'REPORT AB LBL';
        return $this->get('izmo_extend_navigation_bundle.provider.navigation_menu')->createCustomNavigationMenu($menuName, $key, $parentKey, $uri, $defaultTitle);
    }
    
}
