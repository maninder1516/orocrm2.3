<?php

namespace IZMO\ExtendNavigationBundle\Migrations\Schema\v1_2;

use Doctrine\DBAL\Schema\Schema;

use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;
use Oro\Bundle\EntityExtendBundle\EntityConfig\ExtendScope;

class AddIsReportMenuColumnToMenuUpdate implements Migration {

    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries) {
        $table = $schema->getTable('oro_navigation_menu_upd');
        $table->addColumn('is_report_menu', 'boolean', ['default' => false,
            'oro_options' => [
                'extend' => ['owner' => ExtendScope::OWNER_CUSTOM],
                'datagrid' => ['is_visible' => false],
                'merge' => ['display' => true],
        ]]);
    }

    
}
