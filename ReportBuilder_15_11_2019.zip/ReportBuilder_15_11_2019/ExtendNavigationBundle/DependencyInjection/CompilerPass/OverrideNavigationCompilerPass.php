<?php

namespace IZMO\ExtendNavigationBundle\DependencyInjection\CompilerPass;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OverrideNavigationCompilerPass implements CompilerPassInterface
{
    public function process(ContainerBuilder $container)
    {
        $definition = $container->getDefinition('oro_navigation.menu_update.builder.abstract');
        $definition->setClass('IZMO\ExtendNavigationBundle\Builder\CustomMenuUpdateBuilder');
    }
}