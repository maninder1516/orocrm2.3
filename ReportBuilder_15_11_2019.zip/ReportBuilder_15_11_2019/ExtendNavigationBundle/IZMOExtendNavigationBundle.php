<?php
namespace IZMO\ExtendNavigationBundle;
use Symfony\Component\HttpKernel\Bundle\Bundle;
use IZMO\ExtendNavigationBundle\DependencyInjection\CompilerPass\OverrideNavigationCompilerPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class IZMOExtendNavigationBundle extends Bundle{
    public function getParent() {
        return 'OroNavigationBundle';
    }
    public function build(ContainerBuilder $container)
    {
        parent::build($container);
 
        $container->addCompilerPass(new OverrideNavigationCompilerPass());
    }
}

?>
