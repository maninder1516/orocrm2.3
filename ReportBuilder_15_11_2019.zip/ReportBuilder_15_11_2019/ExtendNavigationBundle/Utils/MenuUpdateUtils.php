<?php

namespace IZMO\ExtendNavigationBundle\Utils;

use Knp\Menu\ItemInterface;

use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\PropertyAccess\PropertyAccessor;

use Oro\Bundle\LocaleBundle\Helper\LocalizationHelper;
use Oro\Bundle\NavigationBundle\Entity\MenuUpdateInterface;
use Oro\Bundle\NavigationBundle\Menu\Helper\MenuUpdateHelper;
use Oro\Bundle\ScopeBundle\Entity\Scope;
use Oro\Bundle\NavigationBundle\Utils\MenuUpdateUtils as BaseMenuUpdateUtils;

class MenuUpdateUtils extends BaseMenuUpdateUtils
{
    /**
     * Apply changes from menu update to menu item
     *
     * @param MenuUpdateInterface $update
     * @param ItemInterface $menu
     * @param LocalizationHelper $localizationHelper
     * @param array $options
     */
    public static function updateMenuItem(
        MenuUpdateInterface $update,
        ItemInterface $menu,
        LocalizationHelper $localizationHelper,
        array $options = []
    ) {
        
        $container = $GLOBALS['kernel']->getContainer();
        
        $item = self::findOrCreateMenuItem($update, $menu, $options);
        if ($item === null) {
            return;
        }
        
        if ($update->getTitles()->count()) {
            $em = $container->get('doctrine')->getEntityManager();
            $localeSettings = $container->get('oro_locale.settings');
            $language = $localeSettings->getLanguage();

            $langObj = $em->getRepository("OroTranslationBundle:Language")->findOneBy(array('code' => $language));
            if (!(empty($langObj))) {
                $langObjId = $langObj->getId();
                $localizationObj = $em->getRepository("OroLocaleBundle:Localization")->findOneBy(array('language' => $langObjId));
                $item->setLabel((string) $update->getTitle($localizationObj));
            } else {
                $item->setLabel((string) $update->getTitle());
            }
        }
        
        if((!(empty($item->getLabel()))) && ($update->getIsReportMenu() == 1)){
                     $item->setLabel($container->get('translator')->trans($item->getLabel()));
        }
        
         $baseUrlInfo  = $GLOBALS['kernel']->getContainer()->get('router')->getContext()->getBaseUrl();
           
        // one extra translation label can be encapsulated to item->setLabel.
        if ($update->getUri() && ($update->getIsReportMenu() == 1)) {
            if (!(empty($baseUrlInfo))) {
                $uri = $baseUrlInfo . $update->getUri();
            } else {
                $uri = $update->getUri();
            }
            $item->setUri($uri);
        } else {
            $item->setUri($update->getUri());
        }

        if (($item->getUri()!='#') && ($update->getIsReportMenu() == 1)) {  // CUSTOM REPORT MENUS
                $isMenuVisible = $container->get('reports_config.service_provider')->checkIsNavigationMenuDisplayForUri($item->getUri(),$baseUrlInfo);
                if (!($isMenuVisible)) {
                   $item->setDisplay(0);
                }
            }
        foreach ($update->getExtras() as $key => $extra) {
           $item->setExtra($key, $extra);
        }
    }
}