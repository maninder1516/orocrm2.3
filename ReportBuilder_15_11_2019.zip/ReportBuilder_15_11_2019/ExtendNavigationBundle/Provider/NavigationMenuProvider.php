<?php

namespace IZMO\ExtendNavigationBundle\Provider;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Oro\Bundle\NavigationBundle\Event\MenuUpdateChangeEvent;
use Oro\Bundle\NavigationBundle\Builder\MenuUpdateBuilder;
use Oro\Bundle\NavigationBundle\Provider\BuilderChainProvider;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Knp\Menu\ItemInterface;
use Oro\Bundle\NavigationBundle\Utils\MenuUpdateUtils;

class NavigationMenuProvider {

    /**
     * @var ContainerInterface
     */
    protected $container;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container) {
        $this->container = $container;
    }

    public function getReportConfigRepository() {
        return $this->container->get('doctrine')->getRepository('IZMOReportConfigBundle:ReportConfig');
    }

    public function createCustomNavigationMenu($menuName, $key, $parentKey, $uri, $defaultTitle) {
        $logger = $this->container->get('logger');
        try {
            $options['key'] = $key;
            $options['parentKey'] = $parentKey;
            $options['uri'] = $uri;
            $options['default_title'] = $defaultTitle;
            $scopeType = $this->getMenuUpdateManager()->getScopeType();
            $scope = $this->container->get('oro_scope.scope_manager')->find($scopeType, []);
            $options['scope'] = $scope;

            $menuOb = $this->getReportConfigRepository()->createCustomMenusForReports($menuName, $options);
            if ((gettype($menuOb) == 'array') && (!(empty($menuOb['error'])))) {
                $logger->crit("Exception occured in Repository for createCustomNavigationMenu - Key already exists");
                return null;
            } else {
                // DELETE CACHE
                $this->container->get('event_dispatcher')->dispatch(
                        MenuUpdateChangeEvent::NAME, new MenuUpdateChangeEvent($menuName, [])
                );
                //
                return $menuOb;
            }
        } catch (\Exception $e) {
            $logger->crit("Exception occured in function createCustomNavigationMenu");
            $logger->crit($e);
            return null;
        }
    }

    public function getMenuUpdateManager() {
        return $this->container->get('oro_navigation.manager.menu_update');
    }
    
    public function findMenuItem(ItemInterface $menu, $key)
    {
        if ($menu->getName() === $key) {
            return $menu;
        }

        return MenuUpdateUtils::findMenuItem($menu, $key);
    }
    
    public function getMenu($menuName, array $context) {
        $options = [
            MenuUpdateBuilder::SCOPE_CONTEXT_OPTION => $context,
            BuilderChainProvider::IGNORE_CACHE_OPTION => true,
            BuilderChainProvider::MENU_LOCAL_CACHE_PREFIX => 'edit_'
        ];
        $menu = $this->container->get('oro_menu.builder_chain')->get($menuName, $options);
        if (!count($menu->getChildren())) {
            throw new NotFoundHttpException("Menu \"%s\" not found.", $menuName);
        }

        return $menu;
    }

}
